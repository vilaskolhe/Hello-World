import com.asurion.database.DatabaseValidationUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

/**
 * Created by Vilas.Kolhe on 9/7/2017.
 */
public class Test {
    private DatabaseValidationUtil databaseValidationUtil = DatabaseValidationUtil.getDatabaseValidationUtil();
    private static boolean isScenarioPassed;
    private String query;
    private String caseNumber;
    public static void main(String args[])
    {

        WebDriver webDriver = new ChromeDriver();
        webDriver.get("http://lqasedcobui001v:8080/SubBillingPortal/index.htm#/IntentChargeUpload");

        webDriver.findElement(By.xpath("//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[10]")).click();

        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        WebElement x = webDriver.findElement(By.xpath("//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]"));


        webDriver.findElement(By.xpath("//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[10]")).click();

        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Actions action = new Actions(webDriver);
        action.moveToElement(webDriver.findElement(By.xpath("//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]"))).doubleClick().build().perform();
        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("mmmm 1");
        action.sendKeys("123").build().perform();
        System.out.println("mmmm 2");


        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String jScript = "var myList = document.getElementsByXpath(\"//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]\");"
                + "myList[0].innerHTML=\"111\";";
        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        JavascriptExecutor executor = (JavascriptExecutor) webDriver;

        System.out.println("mmmm");
//        executor.executeScript(jScript);
//
//        try {
//            databaseValidationUtil.executeGivenQuery("select Client, Culture, IntentType, IntentReference, Currency, MethodofPayment, DAXCompanyID, AdditionalInfo\n" +
//                    "      from Basics.IncomingData.Event_Intent_Stage\n" +
//                    "         where IntentReference IN\n" +
//                    "          (select IntentReference from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%%' and client = 'Cricket' and IntentType like '%ServiceRequest%' and Items like '%DED%')");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }
}
