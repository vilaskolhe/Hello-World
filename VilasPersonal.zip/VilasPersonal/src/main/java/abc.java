import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

/**
 * Created by Vilas.Kolhe on 11/14/2017.
 */
public class abc {



    public static void main() {
        WebDriver webDriver = new FirefoxDriver();
        webDriver.get("http://lqasedcobui001v:8080/SubBillingPortal/index.htm#/IntentChargeUpload");

        webDriver.findElement(By.xpath("//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[10]")).click();

        webDriver.findElement(By.xpath("//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]")).click();

        WebElement x = webDriver.findElement(By.xpath("//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]"));


        Actions action = new Actions(webDriver);
        action.moveToElement(webDriver.findElement(By.xpath("//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]"))).doubleClick().build().perform();

        String jScript = "var myList = document.getElementsByXpath(\"//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]\");"
                + "myList[0].innerHTML=\"111\";";
        JavascriptExecutor executor = (JavascriptExecutor) webDriver;
        executor.executeScript(jScript);
    }
}
