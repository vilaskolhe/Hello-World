package com.asurion.util;

import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.error.YAMLException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public class Configuration {

    private static String configName = System.getProperty("user.dir") + "/src/main/resources/configuration.yaml";

    public Configuration(String configName) {
        Configuration.configName = configName;
    }

    public static Map getConfig(String environment) throws Exception {
        Map config = null;
        InputStream input = new FileInputStream(configName);
        try {
            if (input == null)
                throw new FileNotFoundException();

            for (Object data : new Yaml().loadAll(input)) {
                config = (Map) ((Map) data).get(environment);
            }

            // Validate environment details loaded properly
            if (config == null)
                throw new NullPointerException();
            input.close();
        } catch (IOException | NullPointerException e) {
            System.err.println("Configuration file : " + configName);
            System.err.println("May be the configuration file is missing or ....");
            System.err.println("Your trying to load a carrier / environment from configuration file which does not exist.");
            throw e;
        } catch (YAMLException e) {
            System.err.println("Configuration file : " + configName);
            System.err.println("Incorrect YAML format.");
            throw e;
        }
        return config;
    }
}
