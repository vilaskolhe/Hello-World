package com.asurion.util;

import com.asurion.database.DatabaseValidationUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

/**
 * Created by NANDINI.MUJUMDAR on 7/25/2016.
 * Updated by VILAS.KOLHE on 26/09/2017
 */
public class DatabaseUtils {
    static Connection conn = null;
   static DatabaseValidationUtil databaseValidationUtil;

    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        String url = "";
        String returnQueryValue="";
        Properties connectionProps = new Properties();
        String connection = null;
        if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqaeu")) {
            url = "jdbc:sqlserver://NPRQEUSQL501.int.asurion.com\\DAX;integratedSecurity=true";
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection(url);
            //  System.out.println("Server Info: "+url);
        }
        databaseValidationUtil = databaseValidationUtil.getDatabaseValidationUtil();
        System.out.println("databaseValidationUtil.returnFormattedQuery()" + databaseValidationUtil.returnQuery());
        if (databaseValidationUtil.returnQuery()==null){
            returnQueryValue="";
        }
        else {
            returnQueryValue=databaseValidationUtil.returnQuery();
        }
        if (ApplicationConfiguration.getModuleName().equalsIgnoreCase("rma") && !returnQueryValue.toLowerCase().contains("basics.")){
            url="jdbc:oracle:thin:@Q1HRZAM-SCAN.int.asurion.com:1530/Q1HRZAM";
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection(url,"vilas.kolhe","Asurion@3287");
            //System.out.println("Server Info: " + url);
            return conn;
        }
        else{
            url = "jdbc:sqlserver://QADB03\\SQL2008_1;integratedSecurity=true;";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conn = DriverManager.getConnection(url);
            //System.out.println("Server Info: " + url);
        }
        try {
            return conn;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static ResultSet getResultSet(String sqlQuery) throws Exception {
        Connection conn = DatabaseUtils.getConnection();
        if (conn == null) {
            throw new Exception("Unable to connect to database.");
        }
        List dataList = new ArrayList();
        Statement statement = null;
        ResultSet resultSet = null;

        statement = conn.createStatement();
        resultSet = statement.executeQuery(sqlQuery);
        return resultSet;
    }

    public static List executeQuery(String sqlQuery) throws Exception {
        Connection conn = DatabaseUtils.getConnection();
        if (conn == null) {
            throw new Exception("Unable to connect to database.");
        }
        List dataList = new ArrayList();
        Statement statement = null;
        ResultSet resultSet = null;

        statement = conn.createStatement();
        resultSet = statement.executeQuery(sqlQuery);
        while (resultSet.next()) {
            dataList.add(resultSet.getObject(1));
        }
        return dataList;
    }

    public static String getStringData(String sqlQuery) throws Exception {
        List data = (List) DatabaseUtils.executeQuery(sqlQuery);
        if (data.size() > 0 && data != null) {
            return data.get(0).toString().trim();
        } else {
            return "No data found.";
        }
    }

    public static List<String> getStringDataList(String sqlQuery) throws Exception{
        List data = (List) DatabaseUtils.executeQuery(sqlQuery);
        return data;
    }

    public static int getIntegerData(String sqlQuery) throws Exception {
        List data = (List) DatabaseUtils.executeQuery(sqlQuery);
        if (data.size() > 0 && data != null) {
            return Integer.parseInt(data.get(0).toString().trim());
        } else {
            return -1;
        }
    }


    public static boolean getBooleanData(String sqlQuery) throws Exception {
        List data = (List) DatabaseUtils.executeQuery(sqlQuery);
        if (data.size() > 0 && data != null) {
            return Boolean.parseBoolean(data.get(0).toString().trim());
        } else {
            return false;
        }
    }

    public static int executeUpdateSQLQuery(Connection conn, String sQuery) throws SQLException {
        Statement stmtQuery;
        stmtQuery = conn.createStatement();
            stmtQuery.setQueryTimeout(630);
            int rowAffected = stmtQuery.executeUpdate(sQuery);
           stmtQuery.close();
            conn.close();

            return  rowAffected;
    }
//    public static HashMap<String, String> executeSQLQuery(Connection conn, String sQuery, int x) {
//
//    }
    public static ArrayList<HashMap<String, String>> executeSQLQuery(Connection conn, String sQuery) {
        ResultSet rSet = null;
        Object connServer = null;
        Statement stmtQuery = null;
        ArrayList aRowsList = new ArrayList();
        HashMap hRow = null;

        try {
            stmtQuery = conn.createStatement();
            stmtQuery.setQueryTimeout(630);
            rSet = stmtQuery.executeQuery(sQuery);
            if(rSet.equals((Object)null)) {
                return aRowsList;
            }

            ResultSetMetaData e = rSet.getMetaData();
            int iColumns = e.getColumnCount();

            while(rSet.next()) {
                hRow = new HashMap();

                for(int index = 1; index <= iColumns; ++index) {
                    String formattedDecimal = "";
                    String result = rSet.getString(index);
                    if(result != null && result.contains(".") && result.substring(result.length() - 2).contains("00")) {
                        if(result.substring(result.indexOf(".") + 3).equals("00")) {
                            formattedDecimal = result.substring(0, result.indexOf(".") + 3);
                            hRow.put(e.getColumnName(index).toUpperCase(), formattedDecimal);
                        } else {
                            hRow.put(e.getColumnName(index).toUpperCase(), rSet.getString(index));
                        }
                    } else {
                        hRow.put(e.getColumnName(index).toUpperCase(), rSet.getString(index));
                    }
                }

                aRowsList.add(hRow);
            }

            rSet.close();
            stmtQuery.close();
            conn.close();
        } catch (SQLException var12) {
            if(!var12.getMessage().toUpperCase().equals("ORA-00900: INVALID SQL STATEMENT\n")) {
                var12.printStackTrace();
            }
            var12.printStackTrace();
        }

        return aRowsList;
    }
}






