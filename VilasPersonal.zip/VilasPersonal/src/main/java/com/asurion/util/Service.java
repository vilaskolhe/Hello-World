package com.asurion.util;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Map;

/**
 * Created by NANDINI.MUJUMDAR on 6/20/2017.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Service {
    private Map<String, String> horizonqa;
    private Map<String, String> horizondevint;
    private Map<String, String> horizondev;
    private Map<String, String> horizonprod;
    private Map<String, String> horizonuat;
    private Map<String, String> horizonqaeu;
    private Map<String, String> horizondevinteu;
    private Map<String, String> horizondevlab;
    private Map<String, String> horizonprodeu;
    private Map<String, String> horizonprodreplica;
    private Map<String, String> horizonperf;
    private Map<String, String> horizonustraining;
    private Map<String, String> horizonqa02;

    public void setHorizonprodeu(Map<String, String> horizonprodeu) {
        this.horizonprodeu = horizonprodeu;
    }

    public void setHorizonprodreplica(Map<String, String> horizonprodreplica) {
        this.horizonprodreplica = horizonprodreplica;
    }

    public void setHorizonperf(Map<String, String> horizonperf) {
        this.horizonperf = horizonperf;
    }

    public Map<String, String> getHorizonqa02() {
        return horizonqa02;
    }

    public void setHorizonqa02(Map<String, String> horizonqa02) {
        this.horizonqa02 = horizonqa02;
    }

    public Map<String, String> getHorizonustraining() {
        return horizonustraining;
    }

    public void setHorizonustraining(Map<String, String> horizonustraining) {
        this.horizonustraining = horizonustraining;
    }

    public Map<String, String> getHorizondevint() {
        return horizondevint;
    }

    public void setHorizondevint(Map<String, String> horizondevint) {
        this.horizondevint = horizondevint;
    }

    public Map<String, String> getHorizondev() {
        return horizondev;
    }

    public void setHorizondev(Map<String, String> horizondev) {
        this.horizondev = horizondev;
    }

    public Map<String, String> getHorizonprod() {
        return horizonprod;
    }

    public Map<String, String> getHorizonprodeu() {
        return horizonprodeu;
    }

    public void setHorizonprod(Map<String, String> horizonprod) {
        this.horizonprod = horizonprod;
    }

    public Map<String, String> getHorizonuat() {
        return horizonuat;
    }

    public void setHorizonuat(Map<String, String> horizonuat) {
        this.horizonuat = horizonuat;
    }

    public Map<String, String> getHorizonqaeu() {
        return horizonqaeu;
    }

    public void setHorizonqaeu(Map<String, String> horizonqaeu) {
        this.horizonqaeu = horizonqaeu;
    }

    public Map<String, String> getHorizondevinteu() {
        return horizondevinteu;
    }

    public void setHorizondevinteu(Map<String, String> horizondevinteu) {
        this.horizondevinteu = horizondevinteu;
    }

    public Map<String, String> getHorizondevlab() {
        return horizondevlab;
    }

    public void setHorizondevlab(Map<String, String> horizondevlab) {
        this.horizondevlab = horizondevlab;
    }

    public Map<String, String> getHorizonqa() {
        return horizonqa;
    }

    public void setHorizonqa(Map<String, String> horizonqa) {
        this.horizonqa = horizonqa;
    }

    public Map<String, String> getHorizonperf() {
        return horizonperf;
    }

    public Map<String, String> getHorizonprodreplica() {
        return horizonprodreplica;
    }

}

