package com.asurion.util;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by cwr.sachinn.more on 3/26/2015.
 */
public class CustomerDetails {

    public static HashMap<String,String> customerData =null;
    public static ArrayList<HashMap<String,String>> clientAssetList=null;

}
