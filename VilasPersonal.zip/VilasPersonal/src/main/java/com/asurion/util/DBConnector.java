package com.asurion.util;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

public class DBConnector {
    public static ArrayList<HashMap<String, String>> executeQuery(String sServer, String sQuery) {
        ResultSet rSet;
        Connection connServer;
        Statement stmtQuery;
        ArrayList<HashMap<String, String>> aRowsList = new ArrayList<>();
        HashMap<String, String> hRow;
        int iColumns;

        try {
            //get connection and execute SQL query
            connServer = DriverManager.getConnection(sServer);
            stmtQuery = connServer.createStatement();

            // Execute the query and set flag of whether or not current recordset is a valid result set.
            rSet = stmtQuery.executeQuery(sQuery);

            //get the number of columns using metadata
            ResultSetMetaData metaData = rSet.getMetaData();
            iColumns = metaData.getColumnCount();

            //if the SQL query returned a set, stored it in the arrayList of hashmaps
            while (rSet.next()) {
                //create a new
                hRow = new HashMap<>();

                //traverse thru the columns and add the Key(Column) and Value(Row)
                for (int index = 1; index <= iColumns; index++) {
                    hRow.put(metaData.getColumnName(index).toUpperCase(), rSet.getString(index));
                }

                //add hashmap to arraylist
                aRowsList.add(hRow);
            }

            //close the recordset, statement query and connection
            rSet.close();
            stmtQuery.close();
            connServer.close();
        } catch (SQLException e) {

            //If error message does not contain text when queries are executed but no results is returned back,
            //then exit test
            if (!e.getMessage().toUpperCase().equals("THE STATEMENT DID NOT RETURN A RESULT SET.")) {
                e.printStackTrace();
                throw new IllegalStateException("An issue was encountered while executing DB execution\n");
            }
        }

        return aRowsList;
    }

    public static ArrayList<HashMap<String, String>> executeSQLQueryMultipleRecords(String sServer, String sQuery) {
        return executeSQLQueryMultipleRecordsIterate(sServer, sQuery, 0);
    }

    public static ArrayList<HashMap<String, String>> executeSQLQueryMultipleRecordsIterate(String sServer, String sQuery, int recordSetPosition) {
        ResultSet rSet = null;
        Connection connServer;
        Statement stmtQuery;
        ArrayList<HashMap<String, String>> aRowsList = new ArrayList<>();
        HashMap<String, String> hRow;
        int iColumns;
        int iIterate = 0;
        int getPositionRs = 0;

        try {
            //get connection and execute SQL query
            connServer = DriverManager.getConnection(sServer);
            stmtQuery = connServer.createStatement();

            // Execute the query and set flag of whether or not current recordset is a valid result set.
            CallableStatement cs = connServer.prepareCall(sQuery);

            //get the number of columns using metadata
            boolean hasResults = cs.execute();
            ResultSetMetaData metaData = null;

            //Loop through the collection of recordsets.
            while (iIterate <= 150) {
                if (!hasResults)
                    hasResults = cs.getMoreResults();
                else {
                    rSet = cs.getResultSet();
                    metaData = rSet.getMetaData();

                    // If the column name is blank, then move to the next result set.
                    if (!metaData.getColumnName(1).isEmpty()) {
                        if (getPositionRs >= recordSetPosition)
                            break;
                        getPositionRs++;

                    }

                    hasResults = cs.getMoreResults();
                }

                iIterate++;
            }

            iColumns = metaData.getColumnCount();

            //if the SQL query returned a set, stored it in the arrayList of hashmaps
            while (rSet.next()) {
                //create a new
                hRow = new HashMap<>();

                //traverse thru the columns and add the Key(Column) and Value(Row)
                for (int index = 1; index <= iColumns; index++) {
                    hRow.put(metaData.getColumnName(index).toUpperCase(), rSet.getString(index));
                }

                //add hashmap to arraylist
                aRowsList.add(hRow);
            }

            //close the recordset, statement query and connection
            rSet.close();
            stmtQuery.close();
            connServer.close();
        } catch (SQLException e) {

            //If error message does not contain text when queries are executed but no results is returned back,
            //then exit test
            if (!e.getMessage().toUpperCase().equals("THE STATEMENT DID NOT RETURN A RESULT SET.")) {
                e.printStackTrace();
                throw new IllegalStateException("A problem occurred with DBConnector");
            }
        }

        return aRowsList;
    }
}
