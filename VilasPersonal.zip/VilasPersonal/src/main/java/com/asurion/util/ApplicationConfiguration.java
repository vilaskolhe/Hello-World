package com.asurion.util;

//import com.asurion.qa.util.Configuration;
//import com.asurion.qa.soap.Properties;
import com.asurion.horizon.client.StageClient;
import com.asurion.horizon.generic.Configuration;
import com.google.common.base.Strings;

import java.io.FileNotFoundException;
import java.util.Map;

public class ApplicationConfiguration {

    public static String dataFilePath;

    static {
        // Will be useful when running from Jenkins
        String filePath = System.getProperty("dataFilePath");
        if (filePath != null) {
            dataFilePath = System.getProperty("user.dir")
                    + filePath;
        } else {
            dataFilePath = System.getProperty("user.dir")
                    + "/src/test/resources/data/StagingData.xlsx";
        }

    }

    private static int enrollmentMaxWaitTime = 300;
    private static int enrollmentMaxJOBCOMPLETEDTime = 60;
    private static int enrollmentInDALMaxWaitTime = 180;

    private static final String default_environment = "horizonqa"; // horizonqaeu
    private static final String default_browser = "chrome"; // default browser
    private static final String default_run_type = "SBGRID"; // SBGRID
    private static final String default_browser_version = "63"; // default browser version
    private static final String default_browser_locale= "en-US"; // default browser version

//    private static final String default_client = "3UK"; //
//    private static final String default_urlType="pega";
//    private static final String default_moduleName = "";

    private static final String default_client = "Freedom"; //
    private static final String default_urlType="pega";
    private static final String default_moduleName = "Basics";
    private static String browserVersion;
    private static String browserLocale;
    private static String runType;
        private static String environment;
    private static String browser;
    private static String client;
    private static String urlType;
    private static ApplicationConfiguration configuration = null;
    private static Map config = null;
    private static String language = "English";
    private static int pageLoadTimeout = 120;
    private static int waitForElementTimeout = 15;
    private static String moduleName="rma";
    public static int overAllVariable = 0;


    // Timeout
    // Stub or live

    private ApplicationConfiguration() {
        // String testRunBrowser = System.getenv("TEST_RUN_BROWSER");
        // String testRunType = System.getenv("TEST_RUN_TYPE");
        // String testRunBrowserVersion = System.getenv("TEST_RUN_BROWSER_VERSION");
        //  String testRunEnvironment =System.getenv("TEST_RUN_ENV");

        String testRunBrowser = System.getProperty("test.run.browser");
        String testRunType = System.getProperty("test.run.type");
        String testRunBrowserVersion = System.getProperty("test.run.browser.version");
        String testRunEnvironment = System.getProperty("test.run.env");
        String testRunClient = System.getProperty("test.run.client");
        String testRunUrlType = System.getProperty("test.run.urlType");
        String testRunBrowserLocale = System.getProperty("test.browser.locale");
        String testModuleName= System.getProperty("test.run.module");
        // ApplicationConfiguration.environment = environment;
        browser = Strings.isNullOrEmpty(testRunBrowser) ? default_browser : testRunBrowser;
        browserVersion = Strings.isNullOrEmpty(testRunBrowserVersion) ? default_browser_version : testRunBrowserVersion;
        browserLocale = Strings.isNullOrEmpty(testRunBrowserLocale) ? default_browser_locale : testRunBrowserLocale;
        runType = Strings.isNullOrEmpty(testRunType) ? default_run_type : testRunType;
        environment = Strings.isNullOrEmpty(testRunEnvironment) ? default_environment : testRunEnvironment;
        client = Strings.isNullOrEmpty(testRunClient) ? default_client : testRunClient;
        urlType = Strings.isNullOrEmpty(testRunUrlType) ? default_urlType : testRunUrlType;
        moduleName = Strings.isNullOrEmpty(testModuleName) ? moduleName : testModuleName;
    }

    public static int getEnrollmentMaxWaitTime() {
        return enrollmentMaxWaitTime;
    }

    public static int getEnrollmentMaxJOBCOMPLETEDTime() {
        return enrollmentMaxJOBCOMPLETEDTime;
    }

    public static int getEnrollmentInDALMaxWaitTime() {
        return enrollmentInDALMaxWaitTime;
    }

    public static void loadConfiguration() {
        if (configuration == null) {
            configuration = new ApplicationConfiguration();
        }

        try {
            StageClient.environment=environment.toLowerCase();
            StageClient.clientName=client;
            StageClient.channel="";
            config = Configuration.getConfig(environment.toLowerCase());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    /* public static void setEmsProps()
     {

         Properties.setEmsPassword(config.get("emspassword").toString());
         Properties.setEmsServerUrl(config.get("emsurl").toString());
         Properties.setEmsUser(config.get("emsuser").toString());
         System.out.println(Properties.getEmsUser());
         Properties.setTopic(config.get("topic").toString());
         Properties.setQueue(config.get("queue").toString());
     }*/
    public static String getRunType() {
        return runType;
    }

    public static String getModuleName() {return moduleName;}

    public static String getBrowserVersion() {
        return browserVersion;
    }
    public static String getBrowserLocale() {
        return browserLocale;
    }

    public static String getApplicationURl() {
        return config.get("url").toString();
    }

    public static String getBrowser() {
        return browser;
    }

    public static String getLanguage() {
        return language;
    }

    public static String getEnvironment() {
        return environment;
    }
    public static String getClient() {
        return client;
    }
    public static String getUrlType(){return urlType;}

    public static int getWaitForElementTimeout() {
        return waitForElementTimeout;
    }

    public static int getPageLoadTimeout() {
        return pageLoadTimeout;
    }

    public static String getEastDBURL() {
        return config.get("eastdburl").toString();
    }
    public static String getmwdbserverURL() {
        return config.get("mwdbserver").toString();
    }

    public static void printTestRunDetails() {
        String cucumberOptions = System.getProperties().getProperty("cucumber.options");
        String cucumberMessage = "Setting from IDE or no cucumber options set.";
        System.out.println("*********************************************************************************");
        System.out.println("Application URL                       : " + ApplicationConfiguration.getApplicationURl());
        System.out.println("Running tests against the environment : " + ApplicationConfiguration.getEnvironment());
        System.out.println("Running tests through the browser     : " + ApplicationConfiguration.getBrowser());
        System.out.println("Running tests with cucumber options   : " + (Strings.isNullOrEmpty(cucumberOptions) ? cucumberMessage : cucumberOptions));
        System.out.println("*********************************************************************************");
    }

    public static String getDefaultEnvironment() {
        return default_environment;
    }
}
