package com.asurion.util;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.pages.KPNEnrolmentPage;
import com.asurion.pages.ThreeUKAddEnrollPage;
import com.asurion.qa.errorReporting.ExceptionInfo;
import org.junit.Assert;

import java.io.File;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.junit.Assert.assertTrue;

/**
 * Created by rbharamgonde on 10/29/2014.
 */
public class Generic {
    public static HashMap<String, String> euGlobals = new HashMap<String, String>();

    public static String getValuesFromGlobals(String variableName) {
        return euGlobals.get(variableName);
    }


    public static class run3UKEnrollmentJobs {
        public String scheduleJobId1 = "";
        public String scheduleJobId2 = "";
        public String scheduleJobId3 = "";
    }

    public static run3UKEnrollmentJobs run3UKEnrollmentJob() throws Exception {
        run3UKEnrollmentJobs returnValue = new run3UKEnrollmentJobs();

        returnValue.scheduleJobId1 =  executeEnrollmentJob("billing",
                ThreeUKAddEnrollPage.getValuesFromMAP("ENROLMENT_INBOUND_PATH"),
                ThreeUKAddEnrollPage.getValuesFromMAP("ENROLMENT_ARCHIVE_PATH"),
                ThreeUKAddEnrollPage.getValuesFromMAP("ENROLMENT_DONE_PATH"));
        //CommonUtilities.waitTime(10);
        verifyEnrollemntJobStatus("billing", returnValue.scheduleJobId1);

        returnValue.scheduleJobId2 =  executeEnrollmentJob("cancellation",
                ThreeUKAddEnrollPage.getValuesFromMAP("ENROLMENT_INBOUND_PATH"),
                ThreeUKAddEnrollPage.getValuesFromMAP("ENROLMENT_ARCHIVE_PATH"),
                ThreeUKAddEnrollPage.getValuesFromMAP("ENROLMENT_DONE_PATH"));
        //CommonUtilities.waitTime(10);
        verifyEnrollemntJobStatus("cancellation", returnValue.scheduleJobId2);

        returnValue.scheduleJobId3 =  executeEnrollmentJob("peoplesoft",
                ThreeUKAddEnrollPage.getValuesFromMAP("ENROLMENT_INBOUND_PATH"),
                ThreeUKAddEnrollPage.getValuesFromMAP("ENROLMENT_ARCHIVE_PATH"),
                ThreeUKAddEnrollPage.getValuesFromMAP("ENROLMENT_DONE_PATH"));
        //CommonUtilities.waitTime(30);
        verifyEnrollemntJobStatus("peoplesoft", returnValue.scheduleJobId3);

        return returnValue;
    }

    public static void waitForOrderStatusEU(String orderStatus, String orderType, String claimId, String wareHouse) {
        String serverConnection = "";
        if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizondevinteu")) {
            serverConnection = "jdbc:sqlserver://NPRDEUSQL501\\DAX;integratedSecurity=true";
        } else serverConnection = "jdbc:sqlserver://NPRQEUSQL501.int.asurion.com\\DAX;integratedSecurity=true";
        String strSql = "SELECT * FROM Axapta.dbo.asuSalesTableReference ASTR INNER JOIN Axapta.dbo.Salestable ST ON ASTR.SALESID = ST.SALESID WHERE REFERENCE_1 = '" + claimId + "' AND ST.DATAAREAID = '" + wareHouse + "'  and ST.ASU_ISSTATUS='" + orderType + "'";
        System.out.println("\nQuery to verify order status is  " + strSql);
        CommonUtilities.waitTime(10);
        ArrayList<HashMap<String, String>> recordSet = DBConnector.executeQuery(serverConnection, strSql);
        int i = 0;
        while ((recordSet.size() == 0) && i < 80) {
            CommonUtilities.waitTime(10);
            recordSet = DBConnector.executeQuery(serverConnection, strSql);
            i++;
            if (i == 80) {
                System.out.println("\nOrder didn't drop in DAX for the case id " + claimId + " with order status " + orderStatus);
                assertTrue("Order didn't drop in DAX for the case id " + claimId + " with order status " + orderStatus, false);
            }
        }
        if (recordSet.get(0).get("ASU_ISSTATUS").equals(orderType))
            System.out.println("\nCase ID : " + claimId + " has an order of status '" + orderStatus + "'");
    }


    public static void waitForRenewalOrderStatusEU(String orderStatus, String orderType, String claimId, String wareHouse) {
        String serverConnection = "";
        if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizondevinteu")) {
            serverConnection = "jdbc:sqlserver://NPRDEUSQL501\\DAX;integratedSecurity=true";
        } else serverConnection = "jdbc:sqlserver://NPRQEUSQL501\\DAX;integratedSecurity=true";

//        String strSql = "EXEC QADataPrep.dbo.QAPrep_WaitForOrderStatus_KPN @ClaimID = "+ claimId + ", @orderStatus = "+ orderStatus + ", @orderType=" + orderType + ", @warehouse=" + wareHouse ;
        String strSql = "SELECT ASU_ISSTATUS FROM Axapta.dbo.asuSalesTableReference ASTR INNER JOIN Axapta.dbo.Salestable ST ON ASTR.SALESID = ST.SALESID WHERE REFERENCE_1 = '" + claimId + "' AND ST.DATAAREAID = '" + wareHouse + "' and ST.ASU_ISSTATUS='" + orderType + "'";
        System.out.println("Query to verify order status is  " + strSql);
        CommonUtilities.waitTime(120);
        ArrayList<HashMap<String, String>> recordSet = DBConnector.executeQuery("jdbc:sqlserver://NPRQEUSQL501\\DAX;integratedSecurity=true", strSql);
//        ArrayList<HashMap<String, String>> recordSet = DBConnector.executeQuery(ApplicationConfiguration.getmwdbserverURL(), strSql);
        int i = 0;
        while ((recordSet.size() == 0) && i < 40) {
            CommonUtilities.waitTime(45);
//            recordSet = DBConnector.executeQuery("jdbc:sqlserver://NPRQEUSQL501\\DAX;integratedSecurity=true", strSql);
            recordSet = DBConnector.executeQuery(serverConnection, strSql);
            i++;
            if (i == 40) {
                System.out.println("Order didn't drop in DAX for the case id " + claimId);
                assertTrue("Order didn't drop in DAX for the case id " + claimId, false);
            }
        }

        while (!(recordSet.get(0).get("ASU_ISSTATUS").equals(orderType)) && i < 30) {
            CommonUtilities.waitTime(20);
//            recordSet = DBConnector.executeQuery("jdbc:sqlserver://NPRQEUSQL501\\DAX;integratedSecurity=true", strSql);
            recordSet = DBConnector.executeQuery(serverConnection, strSql);
            i++;
            if (i == 30) {
                System.out.println("Order didn't drop in DAX for the case id " + claimId);
                assertTrue("After waiting, Case ID : " + claimId + " does not have an order of status '" + orderStatus + "'", false);
            }
        }
        if (recordSet.get(0).get("ASU_ISSTATUS").equals(orderType))
            System.out.println("Case ID : " + claimId + " has an order of status '" + orderStatus + "'");
    }


    public static String RandomNumber() {

        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:MM:SS");
        Date d = new Date();
        if ((dateFormat.format(d).toString().replaceAll(":", "").split(" ")[1]).length() == 7)
            return ("555" + dateFormat.format(d).toString().replaceAll(":", "").split(" ")[1]);
        else
            return ("5554" + dateFormat.format(d).toString().replaceAll(":", "").split(" ")[1]);
    }

    public void datePicker(String date, UIElement calenderObject) {

        if (date.equalsIgnoreCase("Today")) {

        } else if (date.equalsIgnoreCase("Yesterday")) {

        }

    }

    /*
     * @param
	 * 		dateFormat -Required date format e.g " MM/DD/YYYY"
	 * 		dateDifference - is the parameter used to get future or past date, "+" indicate future date & "-" indicate past date
	 */
    public static String getDate(String dateFormat, int dateDifference) {
        Calendar cal = Calendar.getInstance();
        //subtracting a days
        cal.add(Calendar.DATE, +dateDifference);
        SimpleDateFormat s = new SimpleDateFormat(dateFormat);
        String date = s.format(new Date(cal.getTimeInMillis()));

        return date;
    }

    /**
     * Created by jitendra.k.tiwary on 21st December 2015.
     * Ships the phone for supplied claim id and company
     */
    public static void shipClaim(String strClaimId, String strCompany) {
//        String exe = "\\\\ndcsqafp401\\IT_QA_Test\\QATest_Selenium_SourceFiles\\EuropeDaxAutomationShipPortalsUtility\\DaxAutomationPortalsUtility\\bin\\Debug\\DaxAutomationPortalsUtility.exe TargetEnvironment=EU_QA TargetCompany="+strCompany+" RequestType=auto_ShipClaim Ship_ClaimId="+strClaimId+" C:\\at.txt";
        String exe = "\\\\ndcsqafp401\\IT_QA_Test\\QATest_Selenium_SourceFiles\\EuropeDaxAutomationShipPortalsUtility\\DaxAutomationPortalsUtility\\bin\\Debug\\DaxAutomationPortalsUtility.exe TargetEnvironment=EU_QA TargetCompany=" + strCompany + " RequestType=auto_ShipClaim Ship_ClaimId=" + strClaimId + " C:\\Asurion\\at.txt";
        try {
            String osName = System.getProperty("os.name");
            String[] cmd = new String[3];
            if (osName.equals("Windows NT") || osName.equals("Windows 7") || osName.equals("Windows Server 2008 R2")) {
                cmd[0] = "cmd.exe";
                cmd[1] = "/C";
                cmd[2] = exe;
            } else if (osName.equals("Windows 95")) {
                cmd[0] = "command.com";
                cmd[1] = "/C";
                cmd[2] = exe;
            } else {
                System.out.println("\n"+osName);
                cmd[0] = "cmd.exe";
                cmd[1] = "/C";
                cmd[2] = exe;
            }
            Runtime rt = Runtime.getRuntime();
            System.out.println("\nExecuting " + cmd[0] + " " + cmd[1] + " " + cmd[2]);
            Process proc = rt.exec(cmd);
            // any error message?
            StreamGobbler errorGobbler = new
                    StreamGobbler(proc.getErrorStream(), "ERROR");
            // any output?
            StreamGobbler outputGobbler = new
                    StreamGobbler(proc.getInputStream(), "OUTPUT");
            // kick them off
            errorGobbler.start();
            outputGobbler.start();
            // any error???
            int exitVal = proc.waitFor();
            System.out.println("\nExitValue: " + exitVal);
            //System.out.println("\n"+EastEnrollmentsHandler.checkClaimShippedorNot(strClaimId));
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    /**
     * Created by jitendra.k.tiwary on 21st December 2015.
     * Returns the phone for supplied claim id and company
     */

    public static void returnPhone(String strClaimId, String strCompany) {

        String exe = "\\\\ndcsqafp401\\IT_QA_Test\\QATest_Selenium_SourceFiles\\EuropeDaxAutomationReturnPortalsUtility\\DaxAutomationPortalsUtility\\bin\\Debug\\DaxAutomationPortalsUtility.exe TargetEnvironment=EU_QA TargetCompany=" + strCompany + " RequestType=auto_ReturnClaim Return_ClaimId=" + strClaimId + " C:\\Asurion\\at.txt";

        try {
            String osName = System.getProperty("os.name");
            String[] cmd = new String[3];
            if (osName.equals("Windows NT") || osName.equals("Windows 7")) {
                cmd[0] = "cmd.exe";
                cmd[1] = "/C";
                cmd[2] = exe;
            } else if (osName.equals("Windows 95")) {
                cmd[0] = "command.com";
                cmd[1] = "/C";
                cmd[2] = exe;
            }
            Runtime rt = Runtime.getRuntime();
            System.out.println("Execing " + cmd[0] + " " + cmd[1] + " " + cmd[2]);
            Process proc = rt.exec(cmd);
            // any error message?
            StreamGobbler errorGobbler = new
                    StreamGobbler(proc.getErrorStream(), "ERROR");

            // any output?
            StreamGobbler outputGobbler = new
                    StreamGobbler(proc.getInputStream(), "OUTPUT");

            // kick them off
            errorGobbler.start();
            outputGobbler.start();

            // any error???
            int exitVal = proc.waitFor();
            System.out.println("ExitValue: " + exitVal);

        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public static void setGlobals(String variableName, String variableValue) {
        euGlobals.put(variableName, variableValue);
        System.out.println("Set " + variableName + " values " + variableValue + " into the global ");
    }

    public static void updateServiceRequestStatusEU() throws Exception {
            Thread.sleep(5000);
            String updateOrderStatus = "update customer.SERVICE_REQUEST set SERVICE_REQUEST_STATUS_CODE='CMPLTD' \n" +
                    "where SERVICE_REQUEST_STATUS_CODE ='WORKNG'  and SERVICE_REQUEST_NBR in (select  SERVICE_REQUEST_NBR from customer.service_request \n" +
                    "where asset_id in (select asset.ASSET_ID from ASSET.asset where Mobile_device_nbr = '" + CustomerDetails.customerData.get("MDN") + "'))";
//
//        String updateOrderStatus = "update customer.SERVICE_REQUEST set SERVICE_REQUEST_STATUS_CODE='CMPLTD' \n" +
//                "where SERVICE_REQUEST_STATUS_CODE ='WORKNG'  and SERVICE_REQUEST_NBR in (select  SERVICE_REQUEST_NBR from customer.service_request \n" +
//                "where asset_id in (select asset.ASSET_ID from ASSET.asset where Mobile_device_nbr = '4000032378'))";


            String commitOrderStatus = "COMMIT";
            System.out.println("The Update Query is - " + updateOrderStatus);
            ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
            ArrayList<HashMap<String, String>> data = new ArrayList<>();
            EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), updateOrderStatus);
            EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), commitOrderStatus);
    }

    public static void executeEnrollmentJob(String typeOfQuery) throws Exception {
        executeEnrollmentJob(typeOfQuery, null, null, null);
    }

    public static String executeEnrollmentJob(String typeOfQuery, String inboundFolder, String archiveFolder, String doneFolder) throws Exception {

        // This SQL query will only INSERT into SCHEDULEDJOBS if there are no jobs that are still incomplete over the last 15 minutes.
        // If there are still incomplete jobs, it waits for 15s and then retries.
        // This logic prevents 2 jobs that were sheduled around the same time from creating the SAME enrollment ID - someth that was hapening intermittantly
        // about 5% of the time. By WAITING for any pending jobs with the same JobId to first complete before inserting the scheduled record

        String jobId = "";
        String job = "INSERT INTO ENRCONFIG.SCHEDULEDJOBS \n" +
                "  (\n" +
                "    ID, \n" +
                "    JOBID,\n" +
                "    SCHEDULEID,\n" +
                "    CLIENTPROFILEID,\n" +
                "    CLIENTCHANNELID,\n" +
                "    TASKID,\n" +
                "    JOBTYPE,\n" +
                "    STATUS,\n" +
                "    POLLONFAILURE,\n" +
                "    ENDPOLL,\n" +
                "    FILEFORMAT,\n" +
                "    ENCODINGFORMAT,\n" +
                "    DELIMITEDBY,\n" +
                "    ENCLOSEDBY,\n" +
                "    SCHEDULETYPE,\n" +
                "    IOTYPE,\n" +
                "    SCHEDULEDTIME,\n" +
                "    TIMEZONE,\n" +
                "    FILENAMEFORMAT1,\n" +
                "    FILENAMEFORMAT2,\n" +
                "    FILENAMEFORMAT3,\n" +
                "    MAXFILESTOPICK,\n" +
                "    MINFILESEXPECTED,\n" +
                "    NOOFCOLUMNS,\n" +
                "    FILERECEIPTCONFSTATUS,\n" +
                "    SOURCEPROTOCOL,\n" +
                "    SOURCEUSERNAME,\n" +
                "    SOURCEPASSWORD,\n" +
                "    SOURCEHOSTNAME,\n" +
                "    SOURCEDIRECTORY,\n" +
                "    SOURCEHOSTTYPE,\n" +
                "    SOURCEHOSTPORT,\n" +
                "    SOURCEHOSTTIMEOUT,\n" +
                "    SOURCEPRIVATEKEY,\n" +
                "    SOURCEPRIVATEKEYPASSPHRASE,\n" +
                "    DESTNPROTOCOL,\n" +
                "    DESTNUSERNAME,\n" +
                "    DESTNPASSWORD,\n" +
                "    DESTNHOSTNAME,\n" +
                "    DESTNDIRECTORY,\n" +
                "    DESTNHOSTTYPE,\n" +
                "    DESTNHOSTPORT,\n" +
                "    DESTNHOSTTIMEOUT,\n" +
                "    DESTNPRIVATEKEY,\n" +
                "    DESTNPRIVATEKEYPASSPHRASE,\n" +
                "    ARCHIVEPROTOCOL,\n" +
                "    ARCHIVEUSERNAME,\n" +
                "    ARCHIVEPASSWORD,\n" +
                "    ARCHIVEHOSTNAME,\n" +
                "    ARCHIVEDIRECTORY, \n" +
                "    ARCHIVEHOSTTYPE,\n" +
                "    ARCHIVEHOSTPORT,\n" +
                "    ARCHIVEHOSTTIMEOUT,\n" +
                "    ARCHIVEPRIVATEKEY,\n" +
                "    ARCHIVEPRIVATEKEYPASSPHRASE,\n" +
                "    ENCRYPTEDYN,\n" +
                "    KEYID,\n" +
                "    PASSPHRASE,\n" +
                "    CREATEDBY,\n" +
                "    LASTUPDATEDBY,\n" +
                "    CREATIONDATE,\n" +
                "    LASTUPDATEDATE,\n" +
                "    OPERATIONTYPE,\n" +
                "    OPERATIONSTATUS,\n" +
                "    REMARKS,\n" +
                "    STRUCTURETYPE,\n" +
                "    RETRYCOUNT,\n" +
                "    SOURCEFILERENAMEFORMAT,\n" +
                "    DESTINATIONFILERENAMEFORMAT,\n" +
                "    ARCHIVEFILERENAMEFORMAT\n" +
                "  )\n" +
                "\n" +
                "SELECT \n" +
                "(select  MAX(ID) + 1 FROM ENRCONFIG.SCHEDULEDJOBS), " +
                "JOBID,\n" +
                "SCHEDULEID,\n" +
                "CLIENTPROFILEID,\n" +
                "CLIENTCHANNELID,\n" +
                "TASKID,\n" +
                "JOBTYPE,\n" +
                "'JOBCREATED', -- STATUS\n" +
                "POLLONFAILURE,\n" +
                "ENDPOLL,\n" +
                "FILEFORMAT,\n" +
                "ENCODINGFORMAT,\n" +
                "DELIMITEDBY,\n" +
                "ENCLOSEDBY,\n" +
                "SCHEDULETYPE,\n" +
                "IOTYPE,\n" +
                "sysdate - (1/24/60) * 2, --SCHEDULEDTIME\n" +
                "TIMEZONE,\n" +
                "FILENAMEFORMAT1,\n" +
                "FILENAMEFORMAT2,\n" +
                "FILENAMEFORMAT3,\n" +
                "MAXFILESTOPICK,\n" +
                "MINFILESEXPECTED,\n" +
                "NOOFCOLUMNS,\n" +
                "FILERECEIPTCONFSTATUS,\n" +
                "SOURCEPROTOCOL,\n" +
                "SOURCEUSERNAME,\n" +
                "SOURCEPASSWORD,\n" +
                "SOURCEHOSTNAME,\n" +
                "'" + inboundFolder + "',\n" +
                "SOURCEHOSTTYPE,\n" +
                "SOURCEHOSTPORT,\n" +
                "SOURCEHOSTTIMEOUT,\n" +
                "SOURCEPRIVATEKEY,\n" +
                "SOURCEPRIVATEKEYPASSPHRASE,\n" +
                "DESTNPROTOCOL,\n" +
                "DESTNUSERNAME,\n" +
                "DESTNPASSWORD,\n" +
                "DESTNHOSTNAME,\n" +
                "'" + doneFolder + "',\n" +
                "DESTNHOSTTYPE,\n" +
                "DESTNHOSTPORT,\n" +
                "DESTNHOSTTIMEOUT,\n" +
                "DESTNPRIVATEKEY,\n" +
                "DESTNPRIVATEKEYPASSPHRASE,\n" +
                "ARCHIVEPROTOCOL,\n" +
                "ARCHIVEUSERNAME,\n" +
                "ARCHIVEPASSWORD,\n" +
                "ARCHIVEHOSTNAME,\n" +
                "'" +  archiveFolder + "',\n" +
                "ARCHIVEHOSTTYPE,\n" +
                "ARCHIVEHOSTPORT,\n" +
                "ARCHIVEHOSTTIMEOUT,\n" +
                "ARCHIVEPRIVATEKEY,\n" +
                "ARCHIVEPRIVATEKEYPASSPHRASE,\n" +
                "ENCRYPTEDYN,\n" +
                "KEYID,\n" +
                "PASSPHRASE,\n" +
                "USER,\n" +
                "LASTUPDATEDBY,\n" +
                "sysdate AS CREATIONDATE,\n" +
                "sysdate AS LASTUPDATEDATE,\n" +
                "OPERATIONTYPE,\n" +
                "OPERATIONSTATUS,\n" +
                "REMARKS,\n" +
                "STRUCTURETYPE,\n" +
                "RETRYCOUNT,\n" +
                "SOURCEFILERENAMEFORMAT,\n" +
                "DESTINATIONFILERENAMEFORMAT,\n" +
                "ARCHIVEFILERENAMEFORMAT\n" +
                "\n" +
                "FROM ENRCONFIG.SCHEDULEDJOBS  \n" +
                "WHERE id=(select MAX(ID) FROM ENRCONFIG.SCHEDULEDJOBS WHERE JOBID = {jobId})\n" +
//                "and  exists ( SELECT * FROM ENRCONFIG.SCHEDULEDJOBS WHERE JOBID = {jobId}  AND STATUS IN ('JOBCOMPLETED','JOBCREATED')) \n" +
                // "and not exists ( SELECT * FROM ENRCONFIG.SCHEDULEDJOBS WHERE JOBID = {jobId} AND STATUS IN ('JOBCREATED', 'JOBPUBLISHED') AND CREATIONDATE > (sysdate - (1/24/60) * 15))  \n" +
                "\n" ;


        switch (typeOfQuery.toUpperCase()) {
            case "BILLING":
                jobId = "4403002";
                break;
            case "CANCELLATION":
                jobId = "4403003";
                break;
            case "PEOPLESOFT":
                jobId = "4403001";
                break;
            case "KPN_MULTI_CANCEL":
                jobId = "2004";
                break;
            case "KPN_MULTI_FILE_PARALLEL":
                jobId = "2010";
                break;
            case "KPN_BTA_MCCS":
                if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa")) {
                    job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET sourcedirectory='OUTBOUND', status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, destnhostname='localhost', destndirectory='/opt/sftprepo/euqa01/euqa01/kpn_enrollment/outbound/', destnhosttype='LocalHost', ARCHIVEDIRECTORY='/opt/sftprepo/euqa01/euqa01/kpn_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null WHERE id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2023)";
                } else {
                    job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET sourcedirectory='OUTBOUND', status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, destnhostname='localhost', destndirectory='/opt/sftprepo/kpn_enrollment/outbound/', destnhosttype='LocalHost', ARCHIVEDIRECTORY='/opt/sftprepo/kpn_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null WHERE id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2023)";
                }

                break;
            case "KPN_BTA_BOSS":
                if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa")) {
                    job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET sourcedirectory='OUTBOUND', status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, destnhostname='localhost', destndirectory='/opt/sftprepo/euqa01/euqa01/kpn_enrollment/outbound/', destnhosttype='LocalHost', ARCHIVEDIRECTORY='/opt/sftprepo/euqa01/euqa01/kpn_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null WHERE id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2024)";
                } else {
                    job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET sourcedirectory='OUTBOUND', status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, destnhostname='localhost', destndirectory='/opt/sftprepo/kpn_enrollment/outbound/', destnhosttype='LocalHost', ARCHIVEDIRECTORY='/opt/sftprepo/kpn_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null WHERE id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2024)";
                }

                break;
            case "KPN_SWAPPED_IMEI_MCCS":
                job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET sourcedirectory='OUTBOUND', status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, destnhostname='localhost', destndirectory='/opt/sftprepo/kpn_enrollment/outbound/', destnhosttype='LocalHost', ARCHIVEDIRECTORY='/opt/sftprepo/kpn_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null WHERE id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2011)";
                break;
            case "KPN_SWAPPED_IMEI_BOSS":
                job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET sourcedirectory='OUTBOUND', status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, destnhostname='localhost', destndirectory='/opt/sftprepo/kpn_enrollment/outbound/', destnhosttype='LocalHost', ARCHIVEDIRECTORY='/opt/sftprepo/kpn_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null WHERE id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2001)";
                break;
            case "KPN_2IN12CANCELLATION_MCCS":
                job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET sourcedirectory='OUTBOUND', status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, destnhostname='localhost', destndirectory='/opt/sftprepo/kpn_enrollment/outbound/', destnhosttype='LocalHost', ARCHIVEDIRECTORY='/opt/sftprepo/kpn_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null WHERE  id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2008)";
                break;
            case "KPN_2IN12CANCELLATION_BOSS":
                job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET sourcedirectory='OUTBOUND', status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, destnhostname='localhost', destndirectory='/opt/sftprepo/kpn_enrollment/outbound/', destnhosttype='LocalHost', ARCHIVEDIRECTORY='/opt/sftprepo/kpn_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null WHERE  id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2009)";
                break;
            case "KPN_SHIPPED_SIM_MCCS":
                if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa")) {
                    job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, LASTUPDATEDATE=sysdate, remarks=null, DESTNDIRECTORY = '/opt/sftprepo/euqa01/euqa01/kpn_enrollment/outbound/', ARCHIVEDIRECTORY = '/opt/sftprepo/euqa01/euqa01/kpn_enrollment/archive/' WHERE id = (select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2012)";
                } else {
                    job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, LASTUPDATEDATE=sysdate, remarks=null, DESTNDIRECTORY = '/opt/sftprepo/kpn_enrollment/outbound/', ARCHIVEDIRECTORY = '/opt/sftprepo/kpn_enrollment/archive/' WHERE id = (select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2012)";
                }

                break;
            case "KPN_SHIPPED_SIM_BOSS":
                if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa")) {
                    job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, LASTUPDATEDATE=sysdate, remarks=null, DESTNDIRECTORY = '/opt/sftprepo/euqa01/euqa01/kpn_enrollment/outbound/', ARCHIVEDIRECTORY = '/opt/sftprepo/euqa01/euqa01/kpn_enrollment/archive/' WHERE id = (select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2002)";
                } else {
                    job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, LASTUPDATEDATE=sysdate, remarks=null, DESTNDIRECTORY = '/opt/sftprepo/kpn_enrollment/outbound/', ARCHIVEDIRECTORY = '/opt/sftprepo/kpn_enrollment/archive/' WHERE id = (select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2002)";
                }

                break;
            case "DELIVERYCONFIRMATION":
                jobId = "2015";
                break;
            case "KPN_SHIPMENT_STATUS":
                job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET sourcedirectory='/opt/sftprepo/kpn_enrollment/dpd/', status='JOBCREATED', scheduledtime=sysdate - (1/24),  destnusername=null, destnpassword=null,  destnhostname='localhost', destndirectory='/opt/sftprepo/kpn_enrollment/done/', destnhosttype='LocalHost', ARCHIVEDIRECTORY='/opt/sftprepo/kpn_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null WHERE  id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 1241)";
                break;
            case "DELIVERYCONFIRMATION3UK":
                job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET sourcedirectory='/opt/sftprepo/3uk_enrollment/dpd/', status='JOBCREATED', scheduledtime=sysdate - (1/24),  destnusername=null, destnpassword=null,  destnhostname=null, destndirectory=null, destnhosttype=null, ARCHIVEDIRECTORY='/opt/sftprepo/3uk_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null WHERE  id= (select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 4403020)";
                break;
            case "SWAPPEDIMEI3UK":
                job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, LASTUPDATEDATE=sysdate, remarks=null, DESTNDIRECTORY = '/opt/sftprepo/3uk_enrollment/outbound/', ARCHIVEDIRECTORY = '/opt/sftprepo/3uk_enrollment/archive/' WHERE id = (select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 4403022)";
                break;

            case "3UK_SIM_SHIPPED":
                if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa")) {
                    job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, LASTUPDATEDATE=sysdate, remarks=null, DESTNDIRECTORY = '/opt/sftprepo/euqa01/euqa01/3uk_enrollment/outbound/', ARCHIVEDIRECTORY = '/opt/sftprepo/euqa01/euqa01/3uk_enrollment/archive/' WHERE id = (select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 4403021)";
                } else {
                    job = "UPDATE ENRCONFIG.SCHEDULEDJOBS SET status='JOBCREATED', scheduledtime=sysdate - (1/24), destnusername=null, destnpassword=null, LASTUPDATEDATE=sysdate, remarks=null, DESTNDIRECTORY = '/opt/sftprepo/3uk_enrollment/outbound/', ARCHIVEDIRECTORY = '/opt/sftprepo/3uk_enrollment/archive/' WHERE id = (select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 4403021)";
                }
                break;

            default:
                System.out.println("\nJob is not configured for -" + typeOfQuery);
                break;
        }

        String scheduledJobId = "";
        if (!jobId.isEmpty()) {
            // ENROLLMENT JOB

            job = job.replace("{jobId}", jobId);
            System.out.println("\nThe Update Query is:\n" + job);

            Boolean sheduleRecordInserted = false;
            while (!sheduleRecordInserted) {

                Integer insertedRecs = EUDBHandler.executeSQLInsertQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), job);

                if (insertedRecs != null && insertedRecs >= 1) {
                    sheduleRecordInserted = true;
                    ArrayList<HashMap<String, String>> statusData  = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"),
                            "select * from ENRCONFIG.SCHEDULEDJOBS  where id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = " + jobId + ")");

                    if (!(statusData.size() == 0)) {
                        scheduledJobId = statusData.get(0).get("ID");
                        System.out.println("\nENROLMENT_SCHEDULEDJOBID = " + scheduledJobId);
                    } else {
                        System.out.println("\nCould not find ENRCONFIG.SCHEDULEDJOBS (JOBID = " + jobId + ") record that was just inserted");
                        assertTrue("Could not find ENRCONFIG.SCHEDULEDJOBS (JOBID = " + jobId + ") record that was just inserted", false);
                    }
                }

                if (!sheduleRecordInserted) {
                    System.out.println("\nINSERT RETURNED 0 RECORDS - Trying again in 15 seconds...");
                    CommonUtilities.waitTime(15);
                }

            }

            return scheduledJobId;


        } else {
            // OUTBOUND JOB

            System.out.println("\nThe Update Query is - " + job);
            EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), job);


        }

        // combine the following logic:
        //  are any jobs with {jobid} from last 10m in JOBCREATED or JOBPUBLISHED state?
        //  select * from ENRCONFIG.SCHEDULEDJOBS  where id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = " + jobId + ")"
        //  commit

        // Yes - keep waiting...
        //
        return scheduledJobId;
    }


    public static void executeDenialJob(String typeOfQuery) throws Exception {
            String updateJob = "";
            if (typeOfQuery.equalsIgnoreCase("denial")) {
                updateJob = "update ENRCONFIG.SCHEDULEDJOBS set   status='JobCreated', scheduledtime=sysdate - (1/24),destnusername=null,destnpassword=null, destnhostname='localhost', LASTUPDATEDATE=sysdate, remarks=null where id=3983";
            } else {
                System.out.println("Job is not configured for -" + typeOfQuery);
            }
            String commit = "COMMIT";
            System.out.println("The Update Query is - " + updateJob);
            EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), updateJob);
            EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), commit);
    }

    public static void runStopChaseJob(String typeOfQuery) throws Exception {
            String updateJob = "";
            if (typeOfQuery.equalsIgnoreCase("STOPCHASE")) {
                updateJob = "update ENRCONFIG.SCHEDULEDJOBS set   status='JobCreated', scheduledtime=sysdate - (1/24),destnusername=null,destnpassword=null, destnhostname='localhost', LASTUPDATEDATE=sysdate, remarks=null where id=6131";
            } else {
                System.out.println("Job is not configured for -" + typeOfQuery);
            }

            String commit = "COMMIT";
            System.out.println("The Update Query is - " + updateJob);
            EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), updateJob);
            EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), commit);
    }


    public static void verifyStopChaseJobStatus(String typeOfQuery) throws Exception {
            Thread.sleep(50);
            ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
            String query = "";
            if (typeOfQuery.equalsIgnoreCase("STOPCHASE")) {
                query = "select * from ENRCONFIG.SCHEDULEDJOBS  where id=6131";
            } else {
                System.out.println("Job is not configured for -" + typeOfQuery);
            }

            System.out.println("The Query is - " + query);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            if (!(statusData.size() == 0)) {
                if (statusData.get(0).get("STATUS").equalsIgnoreCase("JOBCOMPLETED")) {
                    System.out.println("Job Status is " + statusData.get(0).get("STATUS"));
                } else {
                    System.out.println("Job Status is " + statusData.get(0).get("STATUS"));
                    assertTrue("Job Status is " + statusData.get(0).get("STATUS"), false);
                }
            } else {
                System.out.println("An Data returned from the verifyDenialJobStatus query.");
                assertTrue("An Data returned from the verifyDenialJobStatus query.", false);
            }
    }

    public static void runStartChaseJob(String typeOfQuery) throws Exception {
            String updateJob = "";
            if (typeOfQuery.equalsIgnoreCase("STARTCHASE")) {
                updateJob = "update ENRCONFIG.SCHEDULEDJOBS set   status='JobCreated', scheduledtime=sysdate - (1/24),destnusername=null,destnpassword=null, destnhostname='localhost', LASTUPDATEDATE=sysdate, remarks=null where id=6130";
            } else {
                System.out.println("Job is not configured for -" + typeOfQuery);
            }

            String commit = "COMMIT";
            System.out.println("The Update Query is - " + updateJob);
            EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), updateJob);
            EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), commit);
    }


    public static void verifyStartChaseJobStatus(String typeOfQuery) throws Exception {
        Thread.sleep(50);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "";
        if (typeOfQuery.equalsIgnoreCase("STARTCHASE")) {
            query = "select * from ENRCONFIG.SCHEDULEDJOBS  where id=6130";
        } else {
            System.out.println("Job is not configured for -" + typeOfQuery);
        }

        System.out.println("The Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if (!(statusData.size() == 0)) {
            if (statusData.get(0).get("STATUS").equalsIgnoreCase("JOBCOMPLETED")) {
                System.out.println("Job Status is " + statusData.get(0).get("STATUS"));
            } else {
                System.out.println("Job Status is " + statusData.get(0).get("STATUS"));
                assertTrue("Job Status is " + statusData.get(0).get("STATUS"), false);
            }
        } else {
            System.out.println("An Data returned from the verifyDenialJobStatus query.");
            assertTrue("An Data returned from the verifyDenialJobStatus query.", false);
        }
    }

    public static void verifyDenialJobStatus(String typeOfQuery) throws Exception {

            Thread.sleep(50);
            ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
            String query = "";
            if (typeOfQuery.equalsIgnoreCase("denial")) {
                query = "select * from ENRCONFIG.SCHEDULEDJOBS  where id=3983";
            } else {
                System.out.println("Job is not configured for -" + typeOfQuery);
            }

            System.out.println("The Query is - " + query);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            if (!(statusData.size() == 0)) {
                if (statusData.get(0).get("STATUS").equalsIgnoreCase("JOBCOMPLETED")) {
                    System.out.println("Job Status is " + statusData.get(0).get("STATUS"));
                } else {
                    System.out.println("Job Status is " + statusData.get(0).get("STATUS"));
                    assertTrue("Job Status is " + statusData.get(0).get("STATUS"), false);
                }
            } else {
                System.out.println("An Data returned from the verifyDenialJobStatus query.");
                assertTrue("An Data returned from the verifyDenialJobStatus query.", false);
            }
    }


    public static void runDenialJob() throws Exception {
            executeDenialJob("denial");
            CommonUtilities.waitTime(30);
            verifyDenialJobStatus("denial");
    }

    public static void verifyEnrollemntJobStatus(String typeOfQuery, String scheduleJobId ) throws Exception {
        int maxWaitTime = ApplicationConfiguration.getEnrollmentMaxWaitTime();
        // Thread.sleep(50);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "";
        switch (typeOfQuery.toUpperCase()) {
            case "BILLING":
                query = "select * from ENRCONFIG.SCHEDULEDJOBS  where id = " + scheduleJobId;
                break;
            case "CANCELLATION":
                query = "select * from ENRCONFIG.SCHEDULEDJOBS  where id = " + scheduleJobId;;;
                break;
            case "PEOPLESOFT":
                query = "select * from ENRCONFIG.SCHEDULEDJOBS  where id = " + scheduleJobId;;;
                break;
            case "KPN_MULTI_FILE_PARALLEL":
                query = "select * from ENRCONFIG.SCHEDULEDJOBS  where id = " + scheduleJobId;;;
                break;
            case "KPN_MULTI_CANCEL":
                query = "select * from ENRCONFIG.SCHEDULEDJOBS   where id = " + scheduleJobId;;;
                break;
            case "KPN_SHIPPED_SIM_MCCS":
                query = "select * from ENRCONFIG.SCHEDULEDJOBS  where id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2012)";
                break;
            case "KPN_SHIPPED_SIM_BOSS":
                query = "select * from ENRCONFIG.SCHEDULEDJOBS  where id=(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2002)";
                break;
            default:
                System.out.println("\nJob is not configured for -" + typeOfQuery);
                break;
        }
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        if (!(statusData.size() == 0)) {
            int i = 0;
            while (!(statusData.get(0).get("STATUS").equalsIgnoreCase("JOBCOMPLETED")) && i < maxWaitTime) {
                CommonUtilities.waitTime(1);

                i++;

                if (i % 10 == 0) {
                    System.out.println("\nJob Status is not completed yet, Querying since " + i + " seconds.");
                    statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
                }
                if (i == maxWaitTime) {
                    System.out.println("\nJob Status is " + statusData.get(0).get("STATUS"));
//                    assertTrue("Job Status is " + statusData.get(0).get("STATUS"), false);
                }
            }
            System.out.println("\nJob Status is " + statusData.get(0).get("STATUS"));

            // if we are on QA03, then print out n detailed debugging info being printed out for the enrolment
            if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqaeu") && i > ApplicationConfiguration.getEnrollmentMaxJOBCOMPLETEDTime()) {
                System.out.println("\nEnrollment Job took took more than " + ApplicationConfiguration.getEnrollmentMaxJOBCOMPLETEDTime() +"s to move into JOBCOMPLETED status!!");
                String debugInfo = Debug.GetEnrolmentDebugInfoFromScheduleJobId(scheduleJobId);
                System.out.println("\n"+debugInfo);
            }

            if (!statusData.get(0).get("STATUS").equalsIgnoreCase("JOBCOMPLETED"))  {
                String debugInfo = Debug.GetEnrolmentDebugInfoFromScheduleJobId(scheduleJobId);

                debugInfo += "\n SQL for checking DAL:" + query;
                throw new ExceptionInfo(new Exception("verifyEnrollemntJobStatus failed"), debugInfo);
            }

        } else {
            System.out.println("\nAn Data returned from the verifyJobStatus query.");
            assertTrue("An Data returned from the verifyJobStatus query.", false);
        }
    }


    public static void verifyMDNPresentInAssetTableDAL(String deviceID, String status) throws Exception {
        Thread.sleep(50);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
//        String query = "select Count(*) As Present from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
        String query = "select * from ASSET.asset where Mobile_device_nbr = '" + deviceID + "' and ASSET_STATUS_CODE = '" + status + "'";

        System.out.println("The Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("No record found for MDN -" + deviceID + " with status " + status);
            assertTrue("No record found  for MDN -" + deviceID + " with status " + status, false);
        } else System.out.println("Record found in Asset table for MDN - " + deviceID + " with status " + status);


    }

    public static void verifyMDNPresentInAgreementTableDAL(String deviceID, String status, String scheduleJobId ) throws Exception {
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "Select * from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '" + deviceID + "' and AG.AGREEMENT_STATUS_CODE = '" + status + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        int i = 0;


        while ((statusData.size() == 0) && i < ApplicationConfiguration.getEnrollmentInDALMaxWaitTime()) {
            com.asurion.qa.util.CommonUtilities.waitTime(1);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);

            if (i % 10 == 0) {
                System.out.println("\nEnrollment is not dropped in Dal yet, Querying since " + i + " seconds.");
            }

            i++;
            if (i == ApplicationConfiguration.getEnrollmentInDALMaxWaitTime()) {
                System.out.println("\nNo record found for MDN " + deviceID + " with status " + status + " after " + ApplicationConfiguration.getEnrollmentInDALMaxWaitTime()  + "s");

                String debugInfo = "\n\nNo record found for MDN " + deviceID + " with status " + status + " after " + ApplicationConfiguration.getEnrollmentInDALMaxWaitTime()  + "s\n\n";

                debugInfo += Debug.GetEnrolmentDebugInfoFromScheduleJobId(scheduleJobId);
                throw new ExceptionInfo(new Exception("verify MDN Present In AgreementTableDAL is failed"), debugInfo);
            }
        }
//
//            if ((statusData.size() == 0)) {
//                System.out.println("\nNo record found for MDN -" + deviceID + " with status " + status);
//                assertTrue("No record found  for MDN - " + deviceID + " with status " + status, false);
//            } else
        System.out.println("\nRecord found in AGREEMENT table for MDN *******- " + deviceID + " with status " + status);
    }

    public static void verifyCustomerTypeInClientAccntDAL(String deviceID, String status) throws Exception {
        Thread.sleep(25000);
        com.asurion.qa.util.CommonUtilities.waitTime(30);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = " select * from dal.client_account where CLIENT_ACCOUNT_TYPE_CODE = '" + status + "' and Client_Account_ID =( Select AST.CLIENT_ACCOUNT_ID from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '" + deviceID + "')";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for MDN -" + deviceID + " with status " + status);
            assertTrue("No record found  for MDN - " + deviceID + " with status " + status, false);
        } else
            System.out.println("\nRecord found in client account table for MDN - " + deviceID + " with status " + status);
    }
    public static void verifySalutationInCustomerTableDALEU(String deviceID, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from dal.customer where NAME_PREFIX = '" + status + "' AND customer_id =( select CUSTOMER_ID from dal.CUSTOMER_AGREEMENT_ROLE where AGREEMENT_ID=( Select AG.AGREEMENT_ID from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '" + deviceID + "'))";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for MDN -" + deviceID + " with status " + status);
            assertTrue("No record found  for MDN - " + deviceID + " with status " + status, false);
        } else
            System.out.println("\nRecord found in customer table for MDN - " + deviceID + " with salutation " + status);
    }
    public static void verifyCustomerTableDALEU(String column, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from customer.customer c INNER JOIN customer.customer_agreement_role ct ON c.customer_id=ct.customer_id INNER JOIN Asset.Agreement ag ON ag.Agreement_ID = ct.Agreement_ID INNER JOIN ASSET.ASSET et ON et.Client_account_id= ag.Client_account_id where "+column+" = '"+status+"' and et.Mobile_device_nbr = '"+Generic.getValuesFromGlobals("DAL_MDN")+"'and ct.ROLE_END_DATE is null and ASSET_STATUS_CODE = 'ACTV'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        int i = 0;

        while ((statusData.size() == 0) && i < ApplicationConfiguration.getEnrollmentMaxWaitTime()) {
            com.asurion.qa.util.CommonUtilities.waitTime(7);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);

            i++;
            if (i == ApplicationConfiguration.getEnrollmentMaxWaitTime()) {
                System.out.println("\nNo record found for with status " + status);
                assertTrue("No record found  for with status " + status, false);
            }
        }
        System.out.println("\nRecord found in customer table for with "+column+":-" + status);
    }

    public static void verifyCustomTableDALEU(String column, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from customer.customer c INNER JOIN customer.customer_agreement_role ct ON c.customer_id=ct.customer_id INNER JOIN Asset.Agreement ag ON ag.Agreement_ID = ct.Agreement_ID INNER JOIN ASSET.ASSET et ON et.Client_account_id= ag.Client_account_id where "+column+" = '"+status+"' and et.Mobile_device_nbr = '"+Generic.getValuesFromGlobals("MDN")+"'and ct.ROLE_END_DATE is null and ASSET_STATUS_CODE = 'ACTV'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nRecord found in custom table for with "+column+":-" + status);
            assertTrue("record found  for with status " + status, true);
        } else
            System.out.println("\nNo record found for with status " + status);
    }

    public static void verifyContactTableDALEU(String column, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM REFERENCE.CONTACT_POINT p INNER JOIN REFERENCE.CONTACT_POINT_USAGE u on p.contact_point_id=u.contact_point_id INNER JOIN ASSET.ASSET et ON et.Client_account_id= u.Client_account_id where "+column+" = '"+status+"' and et.Mobile_device_nbr = '"+Generic.getValuesFromGlobals("DAL_MDN")+"'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for with status " + status);
            assertTrue("No record found  for with status " + status, false);
        } else
            System.out.println("\nRecord found in contact table for with "+column+":-" + status);
    }

    public static void verifyAgreementTableDALEU(String column, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "Select * from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where "+column+" = '"+status+"' and AST.Mobile_device_nbr = '"+Generic.getValuesFromGlobals("DAL_MDN")+"'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for with status " + status);
            assertTrue("No record found  for with status " + status, false);
        } else
            System.out.println("\nRecord found in agreement table for with "+column+":-" + status);
    }

    public static void verifyAddressTableDALEU(String column, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from Reference.Address ra INNER JOIN ASSET.AGREEMENT AG ON AG.Address_id=ra.Address_id INNER JOIN ASSET.ASSET et ON et.Client_account_id= ag.Client_account_id where ra."+column+" = '"+status+"' and et.Mobile_device_nbr = '"+Generic.getValuesFromGlobals("DAL_MDN")+"'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for with status " + status);
            assertTrue("No record found  for with status " + status, false);
        } else
            System.out.println("\nRecord found in address table for with "+column+":-" + status);
    }

    public static void verifyAssetTableDALEU(String column, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from ASSET.ASSET where "+column+" = '"+status+"' and Mobile_device_nbr = '"+Generic.getValuesFromGlobals("DAL_MDN")+"'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for with status " + status);
            assertTrue("No record found  for with status " + status, false);
        } else
            System.out.println("\nRecord found in asset table for with "+column+":-" + status);
    }

    public static void verifyAssetAttributeTableDALEU(String column, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from Asset.Asset_Attribute_Value va INNER JOIN ASSET.ASSET et ON va.asset_id=et.asset_id where "+column+" = '"+status+"' and et.Mobile_device_nbr = '"+Generic.getValuesFromGlobals("DAL_MDN")+"'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for with status " + status);
            assertTrue("No record found  for with status " + status, false);
        } else
            System.out.println("\nRecord found in AssetAttribute table for with "+column+":-" + status);
    }
    public static void verifyAgreementPurchaseTableDALEU(String column, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from dal.agreement_purchase where agreement_id = (SELECT AG.AGREEMENT_ID FROM ASSET.AGREEMENT AG INNER JOIN ASSET.AGREEMENT_ASSET_XREF ASX ON AG.AGREEMENT_ID = ASX.AGREEMENT_ID INNER JOIN ASSET.asset AST ON AST.ASSET_ID=ASX.ASSET_ID WHERE AST.Mobile_device_nbr = '"+Generic.getValuesFromGlobals("MDN")+"' and ROWNUM = 1)and '"+column+"'='"+status+"'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for with status " + status);
            assertTrue("No record found  for with status " + status, false);
        } else
            System.out.println("\nRecord found in agreement table for with "+column+":-" + status);
    }

    public static void verifyAddOnIDAgreementTable(final String addOnID) throws Exception {
        final String deviceID = Generic.getValuesFromGlobals("DAL_MDN");
        ArrayList<HashMap<String, String>> value = new ArrayList<>();

        final String query = "SELECT * FROM ASSET.AGREEMENT AG INNER JOIN ASSET.AGREEMENT_ASSET_XREF ASX ON AG.AGREEMENT_ID = ASX.AGREEMENT_ID INNER JOIN ASSET.ASSET AST ON AST.ASSET_ID = ASX.ASSET_ID WHERE AST.MOBILE_DEVICE_NBR = '"+deviceID+"' AND AG.CLIENT_PRODUCT_SKU_NBR = '"+addOnID+"'";
        System.out.println("\nThe Query is : "+query);
        value = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        int i =0;

        while((value.size() == 0) && i <=120) {
            com.asurion.qa.util.CommonUtilities.waitTime(5);
            value = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            i++;

            if (i == 120) {
                System.out.println("\nNo record found with Add On ID " + addOnID);
                assertTrue("No record found for with Add On ID " + addOnID, false);
            }
            assertTrue("\nRecord found in agreement table with Add On ID " + addOnID, true);
        }
    }

    public static void verifyAddOnDescriptionInProductTable(final String addOnID, final String addOnDesc) throws Exception {
        ArrayList<HashMap<String, String>> value = new ArrayList<>();
        final String query = "SELECT * FROM PRODUCT.CLIENT_PRODUCT WHERE CLIENT_PRODUCT_SKU_NBR = '"+addOnID+"'  AND CLIENT_PRODUCT_SKU_DESC = '"+addOnDesc+"'";
        System.out.println("\nThe Query is : "+query);
        value = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);

        if(!(value.size()== 1)) {
            assertTrue("\nNo record found for with Add On ID " + addOnID+" and Add ON Description "+addOnDesc, false);
        }
        System.out.println("\nRecord found in Product Table With Add On ID : "+addOnID+" and Add On Description : "+addOnDesc);
    }

    public static void verifyRecordPresentInTableDQReport3UK(String ban, String status) throws Exception {
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM enrollment.enrollmentvalidationreport WHERE accountidfr ='" + ban + "' and STATUS= '" + status + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i=0;
        while ((statusData.size() == 0)&& i<120) {
            com.asurion.qa.util.CommonUtilities.waitTime(3);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            i++;
            if (i == 120) {
                System.out.println("\nNo record found in EnrollmentValidationReport table for BAN -" + ban + " with status " + status);
                assertTrue("No record found  in EnrollmentValidationReport table for BAN - " + ban + " with status " + status, false);
            }
        }
        System.out.println("\nRecord found in EnrollmentValidationReport table for BAN- " + ban + " with status " + status);
    }
    public static void verifyRecordPresentInTableDenial3UK(String ban, String status,String type) throws Exception {
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM enrollment.enrollmentvalidationreport WHERE accountidfr ='" + ban + "' and STATUS= '" + status + "'and  ATT12='"+type+"'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i=0;
        while ((statusData.size() == 0)&& i<120) {
            com.asurion.qa.util.CommonUtilities.waitTime(3);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            i++;
            if (i == 120) {
                System.out.println("\nNo record found in EnrollmentValidationReport table for BAN -" + ban + " with status " + status);
                assertTrue("No record found  in EnrollmentValidationReport table for BAN - " + ban + " with status " + status, false);
            }
        }
        System.out.println("\nRecord found in EnrollmentValidationReport table for BAN- " + ban + " with status " + status);
    }
    public static void verifyCancellationReasonInAgreementTableDAL(String cancellationReason) throws Exception {
        Thread.sleep(5000);
        com.asurion.qa.util.CommonUtilities.waitTime(20);
        String deviceID =null;
        if(ApplicationConfiguration.getClient().equalsIgnoreCase("kpn")){
            deviceID = Generic.getValuesFromGlobals("MDN");
        }else {
            deviceID = Generic.getValuesFromGlobals("DAL_MDN");
        }
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "Select * from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '" + deviceID + "' and AG.AGREEMENT_TERMINATION_RSN_CD = '" + cancellationReason + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for MDN -" + deviceID + " with cancellation Reason " + cancellationReason);
            assertTrue("No record found for MDN -" + deviceID + " with cancellation Reason " + cancellationReason, false);
        } else
            System.out.println("\nRecord found in AGREEMENT table for MDN - " + deviceID + " with cancellation Reason " + cancellationReason);
    }
    public static void verifyCancellationReasonInCancelledAgreementTableDAL(String cancellationReason) throws Exception {
        Thread.sleep(5000);
        com.asurion.qa.util.CommonUtilities.waitTime(20);
        String deviceID = Generic.getValuesFromGlobals("MDN");
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from enrstaging.cancelledagreements where MOBILEDEVICENUMBER= '" + deviceID + "' and CANCELLATIONCODE = '" + cancellationReason + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 150) {
            com.asurion.qa.util.CommonUtilities.waitTime(2);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            System.out.println("\nCancellation Reason "+cancellationReason+" is not dropped in Dal yet, Querying since " + i * 5 + " seconds.");
            i++;
            if (i == 150) {
                System.out.println("\nNo record found for MDN -" + deviceID + " with cancellation Reason " + cancellationReason);
                assertTrue("No record found for MDN -" + deviceID + " with cancellation Reason " + cancellationReason, false);
            }
        }
        System.out.println("\nRecord found in Cancelled AGREEMENT table for MDN - " + deviceID + " with cancellation Reason " + cancellationReason);
    }
    public static void verifyRecordPresentInDenialAgreementTableDAL(String key) throws Exception {
        String deviceID = Generic.getValuesFromGlobals(key);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from ENRSTAGING.DENIEDAGREEMENTS where MSISDN='" + deviceID + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for MDN -" + deviceID);
            assertTrue("No record found for MDN -" + deviceID, false);
        } else
            System.out.println("\nRecord found denial AGREEMENT table for MDN - " + deviceID);
    }
    public static void verifyRecordPresentInClaimStatusTableENRSTAGING(String claimStatus) throws Exception {
        String deviceID = Generic.getValuesFromGlobals("DAL_MDN");
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from ENRstaging.claimStatus where mobiledevicenumber ='" + deviceID + "'and SRStatus ='"+claimStatus+"'" ;
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i=0;
        while ((statusData.size() == 0) && i < 80) {
            com.asurion.qa.util.CommonUtilities.waitTime(3);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            i++;
            if (i == 80) {
                System.out.println("\nNo record found for MDN -" + deviceID);
                assertTrue("No record found for MDN -" + deviceID, false);
            }
        }
        System.out.println("\nRecord found claim status table for MDN - " + deviceID);
    }
    public static String getTrackingNumber(String deviceID, String status) throws Exception {
        String trackingNumber = null;
        String sParam = null;
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select OBSHIPMENTTRACKINGNUMBER from enrollment.REPLACEDASSETS where MOBILEDEVICENUMBER = '" + deviceID + "' and STATUS = '" + status + "' order by creationdate desc";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for MDN -" + deviceID + " with status " + status);
            assertTrue("No record found  for MDN - " + deviceID + " with status " + status, false);
        } else
            System.out.println("\nRecord found in replaced assets table for MDN - " + deviceID + " with status " + status);
        trackingNumber = statusData.get(0).toString().substring(26).replace("}", "").trim();
        return trackingNumber;
    }
    public static String getSalesNumber(String deviceID) throws Exception {
        String salesNumber = null;
        String sParam = null;
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
//        String query = "select Count(*) As Present from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
//        String query = "select * from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
        String query = "select DAX_SALES_ORDER_ID from customer.shipping_order inner join asset.asset on shipping_order.asset_id=asset.asset_id where  MOBILE_DEVICE_NBR = '" + deviceID + "' order by dax_sales_order_id desc";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for MDN -" + deviceID);
            assertTrue("No record found  for MDN - " + deviceID, false);
        } else System.out.println("\nRecord found in shipping order table for MDN - " + deviceID);
        salesNumber = statusData.get(0).toString().substring(20).replace("}", "").trim();
        return salesNumber;
    }
    public static void runKPNShipmentStatusJob() throws Exception {
        Thread.sleep(50);
        executeEnrollmentJob("KPN_Shipment_Status");
        com.asurion.qa.util.CommonUtilities.waitTime(10);
    }
    public static void runKPNSwappedIMEIJob(String sysType) throws Exception {
        Thread.sleep(50);
        if (sysType.contains("MCCS")) {
            executeEnrollmentJob("KPN_Swapped_IMEI_MCCS");
            com.asurion.qa.util.CommonUtilities.waitTime(10);
        } else {
            executeEnrollmentJob("KPN_Swapped_IMEI_BOSS");
            com.asurion.qa.util.CommonUtilities.waitTime(10);
        }
    }
    public static void verifyTrackingNumberRecordPresentInShipmentTransactionDetailTableDAL(String trackingNumber, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
//        String query = "select Count(*) As Present from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
//        String query = "select * from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
        String query = "select * from enrollment.shipmenttransactiondetail where shipmenttrackingnumber = '" + trackingNumber + "' and PROCESSSTATUS = '" + status + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 80) {
            com.asurion.qa.util.CommonUtilities.waitTime(3);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            System.out.println("\nWaiting for Tracking number to be populated in ShipmentTransactionDetailTable since '" + 5*( i+1) + "' seconds");
            i++;
            if (i == 80) {
                System.out.println("\nNo record found for tracking number -" + trackingNumber + " with status " + status);
                assertTrue("No record found  for tracking number - " + trackingNumber + " with status " + status, false);
            }
        }
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for tracking number -" + trackingNumber + " with status " + status);
            assertTrue("No record found  for tracking number - " + trackingNumber + " with status " + status, false);
        } else
            System.out.println("\nRecord found in Shipment Transaction Detail Table for Tracking Number - " + trackingNumber + " with status " + status);
    }
    public static void verifyRecordInInboudPreinterfaceTableDAL(String trackingNumber) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
//        String query = "select Count(*) As Present from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
//        String query = "select * from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
        String query = "select * from enrollment.inboundfilepreinterface where ATTRIBUTE1 ='" + trackingNumber + "' ";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 80) {
            com.asurion.qa.util.CommonUtilities.waitTime(3);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            System.out.println("\nWaiting for Tracking number to be populated in InboudPreinterface table since '" + 5*( i+1) + "' seconds");
            i++;
            if (i == 80) {
                System.out.println("\nNo record found for tracking number -" + trackingNumber );
                assertTrue("No record found  for tracking number - " + trackingNumber ,false);
            }
        }
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for tracking number -" + trackingNumber );
            assertTrue("No record found  for tracking number - " + trackingNumber , false);
        } else
            System.out.println("\nRecord found in Inbound preinterface Table for Tracking Number - " + trackingNumber);
    }
    public static void verifyStatusInReplacedAssetTable(String MDN, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
//        String query = "select Count(*) As Present from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
//        String query = "select * from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
        String query = "select * from enrollment.REPLACEDASSETS where MOBILEDEVICENUMBER = '" + MDN + "' and STATUS = '" + status + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for MDN -" + MDN + " with status " + status);
            assertTrue("No record found  for MDN - " + MDN + " with status " + status, false);
        } else
            System.out.println("\nRecord found in enrollment.REPLACEDASSETS Table for MDN - " + MDN + " with status " + status);
    }
    public static String runKPNMultiEnrollmentJob() throws Exception {
        //Thread.sleep(50);
        //executeEnrollmentJob("KPN_MULTI_FILE_ENROLL"); //uncommented by willem on 25/01/2017
        // CommonUtilities.waitTime(1);  //uncommented by willem on 25/01/2017
        //executeEnrollmentJob("KPN_MULTI_FILE_CONFIG"); //uncommented by willem on 25/01/2017

        Calendar calendar = GregorianCalendar.getInstance(); // creates a new calendar instance
        calendar.setTime(new Date());
        int hour = calendar.get(Calendar.HOUR_OF_DAY); // gets hour in 24h format
        int minute = calendar.get(Calendar.MINUTE);        // gets hour in 12h format

        if (hour == 0 && minute < 3)
        {
            Thread.sleep(1000 * 60 * 3);
        }

        String scheduleJobId = executeEnrollmentJob(  "KPN_MULTI_FILE_PARALLEL",
                KPNEnrolmentPage.getValuesFromKPNMAP("ENROLMENT_INBOUND_PATH"),
                KPNEnrolmentPage.getValuesFromKPNMAP("ENROLMENT_ARCHIVE_PATH"),
                KPNEnrolmentPage.getValuesFromKPNMAP("ENROLMENT_DONE_PATH"));

//            CommonUtilities.waitTime(10);


        return scheduleJobId;
    }
    public static void verifyPurchaseDate(String datePurchase) throws Exception {
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT PURCHASE_DATE FROM ASSET.ASSET_PURCHASE WHERE ASSET_ID = (SELECT ASSET_ID FROM ASSET.ASSET WHERE ASSET_STATUS_CODE = 'ACTV' AND MOBILE_DEVICE_NBR = '" + Generic.getValuesFromGlobals("MDN") + "')";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            assertTrue("No record found  for MDN - " + Generic.getValuesFromGlobals("MDN"), false);
        } else {
            Date formattedPurchaseDate = new SimpleDateFormat("yyyy-MM-dd").parse(statusData.get(0).get("PURCHASE_DATE"));
            String formattedDateString = new SimpleDateFormat("yyyyMMdd").format(formattedPurchaseDate);
            if (formattedDateString.equalsIgnoreCase(datePurchase)) {
                System.out.println("\nDevice Purchase date is correctly updated");
            } else {
                System.out.println("\nDevice Purchase date is not correctly updated in the database");
                assertTrue("Device Purchase date is not correctly updated in the database", false);
            }
        }
    }
    public static void verifyTerminatedRenewalRecord(String deviceID, String status, String canceldate, String terminationreason) throws Exception {
//        String canceldate = "20160607";
//        String deviceID = "555414062610";
//        String status = "ACTV";
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "Select to_date(to_char(TERMINATION_DATE,'DD-MON-YY')) as TERMINATION_DATE from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '" + deviceID + "' and AG.AGREEMENT_STATUS_CODE = '" + status + "'and AG.AGREEMENT_TERMINATION_RSN_CD = '" + terminationreason + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            assertTrue("No record found  for MDN - " + Generic.getValuesFromGlobals("MDN"), false);
        } else {
            Date formattedTerminationDate = new SimpleDateFormat("yyyy-MM-dd").parse(statusData.get(0).get("TERMINATION_DATE"));
            System.out.println("\nformattedTerminationDate is correctly updated" + formattedTerminationDate);
            String formattedDateString = new SimpleDateFormat("yyyyMMdd").format(formattedTerminationDate);
            if (formattedDateString.equalsIgnoreCase(canceldate)) {
                System.out.println("\nOld Agreement termination date is correctly updated to cancel date" + formattedDateString);
            } else {
                System.out.println("\nOld Agreement termination date is not correctly updated to cancel date" + formattedDateString);
                assertTrue("Old Agreement termination date is not correctly updated to cancel date", false);
            }
        }
    }

    public static class KPNMultiFileCancelJobs {
        public String scheduleJobId1;
        public String scheduleJobId2;
    }

    public static KPNMultiFileCancelJobs runKPNMultiFileCancelJob() throws Exception {
        KPNMultiFileCancelJobs returnValue = new KPNMultiFileCancelJobs();

        returnValue.scheduleJobId1 = executeEnrollmentJob("KPN_MULTI_CANCEL",
                KPNEnrolmentPage.getValuesFromKPNMAP("ENROLMENT_INBOUND_PATH"),
                KPNEnrolmentPage.getValuesFromKPNMAP("ENROLMENT_ARCHIVE_PATH"),
                KPNEnrolmentPage.getValuesFromKPNMAP("ENROLMENT_DONE_PATH"));
//            CommonUtilities.waitTime(60);
        verifyEnrollemntJobStatus("KPN_MULTI_CANCEL", returnValue.scheduleJobId1);

        returnValue.scheduleJobId2 = Generic.runKPNMultiEnrollmentJob();
        verifyEnrollemntJobStatus("KPN_MULTI_FILE_PARALLEL", returnValue.scheduleJobId2);

        return returnValue;
    }
    public static void verifyCaseStatusIsShipInShippingOrderTableDAL(String deviceID, String status) throws Exception {
        Thread.sleep(10);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from customer.shipping_order inner join asset.asset on shipping_order.asset_id=asset.asset_id where  MOBILE_DEVICE_NBR = '" + deviceID + "' and SHIPPING_STATUS_CODE = '" + status + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 80) {
            com.asurion.qa.util.CommonUtilities.waitTime(10);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            System.out.println("\nCaseStatus is not " + status + " yet, Querying since " + i * 10 + " seconds.");
            i++;
            if (i == 80) {
                System.out.println("\nNo record found  for MDN - " + deviceID + " with status " + status);
                assertTrue("No record found  for MDN - " + deviceID + " with status " + status, false);
            }
        }
        System.out.println("\nRecord found in Shipping Order table for MDN - " + deviceID + " with status " + status);
    }
    public static void verifyStartRMATableDAL(String caseNumber) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
//        String query = "select Count(*) As Present from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
//        String query = "select * from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
        String query = "select * from enrstaging.initiateRMA where casenumber = '" + caseNumber + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for case number -" + caseNumber);
            assertTrue("No record found  for case number- " + caseNumber, false);
        } else System.out.println("\nRecord found in starting RMA table for case number - " + caseNumber);
    }
    public static void verifyTransactionType() throws Exception {
        //In progress
        String datePurchase = KPNEnrolmentPage.hm.get("ASSETPURCHASEDATE");
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT PURCHASE_DATE FROM ASSET.ASSET_PURCHASE WHERE ASSET_ID = (SELECT ASSET_ID FROM ASSET.ASSET WHERE ASSET_STATUS_CODE = 'ACTV' AND MOBILE_DEVICE_NBR = '" +
                Generic.getValuesFromGlobals("MDN") + "')";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            assertTrue("No record found  for MDN - " + Generic.getValuesFromGlobals("MDN"), false);
        } else {
            Date formattedPurchaseDate = new SimpleDateFormat("yyyy-MM-dd").parse(statusData.get(0).get("PURCHASE_DATE"));
            String formattedDateString = new SimpleDateFormat("yyyyMMdd").format(formattedPurchaseDate);
            if (formattedDateString.equalsIgnoreCase(datePurchase)) {
                System.out.println("\nDevice Purchase date is correctly updated");
            } else {
                System.out.println("\nDevice Purchase date is not correctly updated in the database");
                assertTrue("Device Purchase date is not correctly updated in the database", false);
            }
        }
    }
    public static void waitAndCheckForServiceRequestStatusReturn_EU(String deviceID, String status) throws Exception {
        System.out.println("\nWaiting and checking for Shipping Order Status in DAL");
        int i = 0;
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "Select SHIPPING_STATUS_CODE from customer.shipping_order inner join asset.asset on shipping_order.asset_id=asset.asset_id where MOBILE_DEVICE_NBR ='" + deviceID + "' and SHIPPING_STATUS_CODE = '" + status + "' order by asset.CREATED_DATE desc";
//        if (driver.getText(enrollmentGridRow1).contains("Working")) {
        while (i <= 25) {
            System.out.println("\nChecking status of order in DAL ");
            com.asurion.qa.util.CommonUtilities.waitTime(45);
            System.out.println("\nThe Query is - " + query);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            if ((statusData.size() != 0)) {
                System.out.println("\nRecords found with shipping status as return");
                break;
            }
            i++;
        }
    }
   /* public static String runDPDDeliveryConfirmationJob() throws Exception {
        Thread.sleep(50);

        String scheduleJobId = executeEnrollmentJob(  "DeliveryConfirmation",
                KPNSwappedIMEIPage.getValuesFromKPNMAP("DPD_INBOUND_PATH"),
                KPNSwappedIMEIPage.getValuesFromKPNMAP("DPD_ARCHIVE_PATH"),
                KPNSwappedIMEIPage.getValuesFromKPNMAP("DPD_DONE_PATH"));


        return scheduleJobId;
    }*/
    public static void runDPDDeliveryConfirmationJob3UK() throws Exception {
        Thread.sleep(50);
        executeEnrollmentJob("DeliveryConfirmation3UK");
        com.asurion.qa.util.CommonUtilities.waitTime(10);
    }
    public static void executeRMAUpdate(String typeOfQuery) throws Exception {
        String casenumber = Generic.getValuesFromGlobals("CASENUMBER");
        String updateJob = "";
        if (typeOfQuery.equalsIgnoreCase("UPDATERMA")) {
            updateJob = "update ENRSTAGING.UPDATERMA set returnassettype='Salvage' where casenumber='" + casenumber + "'";
        } else {
            System.out.println("\nJob is not configured for -" + typeOfQuery);
        }
        String commit = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), commit);
    }
    public static void runKPN2in12CancellationJob(String sysType) throws Exception {
        Thread.sleep(50);
        if (sysType.contains("MCCS")) {
            executeEnrollmentJob("KPN_2in12Cancellation_MCCS");
            com.asurion.qa.util.CommonUtilities.waitTime(10);
        } else {
            executeEnrollmentJob("KPN_2in12Cancellation_BOSS");
            com.asurion.qa.util.CommonUtilities.waitTime(10);
        }
    }
    public static void verify2in12CancelJobStatusCompleteInDAL(String sysType, String status) throws Exception {
        Thread.sleep(100);
        if (sysType.contains("MCCS")) {
            ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
//        String query = "select Count(*) As Present from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
//        String query = "select * from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
            String query = "select STATUS from ENRCONFIG.SCHEDULEDJOBS where id =(select MAX(ID) from ENRCONFIG.SCHEDULEDJOBS where JOBID = 2008)";
            System.out.println("\nThe Query is - " + query);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            String status1 = statusData.get(0).toString().substring(8).replace("}", "").trim();
            if (status1.contains(status)) {
                System.out.println("\n2 in 12 Cancel MCCS job status is JOBCOMPLETED");
            } else {
                System.out.println("\n2 in 12 Cancel MCCS job status is not completed.Status is" + status1);
                //assertTrue("2 in 12 Cancel MCCS job status is not completed.Status is " + status1, false);
            }
        } else {
            ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
//        String query = "select Count(*) As Present from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
//        String query = "select * from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
            String query = "select STATUS from ENRCONFIG.SCHEDULEDJOBS where id =5148";
            System.out.println("\nThe Query is - " + query);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            String status1 = statusData.get(0).toString().substring(8).replace("}", "").trim();
            if (status1.contains(status)) {
                System.out.println("\n2 in 12 Cancel BOSS job status is JOBCOMPLETED");
            } else {
                System.out.println("\n2 in 12 Cancel BOSS job status is not completed.Status is" + statusData);
                //assertTrue("2 in 12 Cancel BOSS job status is not completed.Status is " + statusData, false);
            }
        }
    }
    public static void updateAssetFailureDateFor2In12KPNEU(String caseNumber) throws Exception {
        Thread.sleep(5000);
        String updateAssetFailureDate = "update CUSTOMER.SERVICE_REQUEST set Asset_failure_date = (sysdate-367) where service_request_nbr = " + "(" + "select service_request_nbr from customer.customer_case inner join CUSTOMER.SERVICE_REQUEST " + "on customer_case.ASSET_ID = SERVICE_REQUEST.ASSET_id " + "where customer_case_nbr ='" + caseNumber + "')";
//
//        String updateOrderStatus = "update customer.SERVICE_REQUEST set SERVICE_REQUEST_STATUS_CODE='CMPLTD' \n" +
//                "where SERVICE_REQUEST_STATUS_CODE ='WORKNG'  and SERVICE_REQUEST_NBR in (select  SERVICE_REQUEST_NBR from customer.service_request \n" +
//                "where asset_id in (select asset.ASSET_ID from ASSET.asset where Mobile_device_nbr = '4000032378'))";
        String commitAssetFailureDate = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateAssetFailureDate);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        ArrayList<HashMap<String, String>> data = new ArrayList<>();
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), updateAssetFailureDate);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), commitAssetFailureDate);
    }
    public static void updateExpiryDate3UKEU(String date) throws Exception {
        Thread.sleep(5000);
        String updateExpiryDate = "Update PEGADS.ASR_SVCS_AGENTQUEUE Set EXPIRYDATE = '"+date+"' where mobiledevicenumber like '"+Generic.getValuesFromGlobals("DAL_MDN")+"' ";
//
//        String updateOrderStatus = "update customer.SERVICE_REQUEST set SERVICE_REQUEST_STATUS_CODE='CMPLTD' \n" +
//                "where SERVICE_REQUEST_STATUS_CODE ='WORKNG'  and SERVICE_REQUEST_NBR in (select  SERVICE_REQUEST_NBR from customer.service_request \n" +
//                "where asset_id in (select asset.ASSET_ID from ASSET.asset where Mobile_device_nbr = '4000032378'))";
        String commitExpiryDate = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateExpiryDate);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        ArrayList<HashMap<String, String>> data = new ArrayList<>();
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), updateExpiryDate);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), commitExpiryDate);
        com.asurion.qa.util.CommonUtilities.waitTime(120);
    }

    public static void getDetailsFromDAXDB(String daxField, String claimId, String wareHouse) throws Exception {
        String serverConnection = "";
        if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizondevinteu")) {
            serverConnection = "jdbc:sqlserver://NPRDEUSQL501\\DAX;integratedSecurity=true";
        } else serverConnection = "jdbc:sqlserver://NPRQEUSQL501.int.asurion.com\\DAX;integratedSecurity=true";
        String strSql = "SELECT * FROM Axapta.dbo.asuSalesTableReference ASTR INNER JOIN Axapta.dbo.Salestable ST ON ASTR.SALESID = ST.SALESID WHERE REFERENCE_1 = '" + claimId + "' AND ST.DATAAREAID = '" + wareHouse + "' AND SALESSTATUS = 2 order by ASTR.salesID DESC";
        System.out.println("\nQuery to get details from DAX DB is  " + strSql);
        com.asurion.qa.util.CommonUtilities.waitTime(5);
        ArrayList<HashMap<String, String>> recordSet = DBConnector.executeQuery(serverConnection, strSql);
        if (recordSet.size() > 0) {
            switch (daxField) {
                case "SALESORDERNUMBER":
                    setGlobals("SALESORDERNUMBER", recordSet.get(0).get("SALESID"));
                    break;
                case "TRACKINGNUMBER":
                    setGlobals("TRACKINGNUMBER", recordSet.get(0).get("ASU_TRACKINGNUMBER"));
                    break;
                default:
                    System.out.println("\nColumnName not configured");
            }
        }
    }
    public static void runExceptionJob() throws Exception {
        com.asurion.qa.util.CommonUtilities.waitTime(250);
        String updateJob = "";
        if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizondevinteu")) {
            updateJob = "update ENRCONFIG.SCHEDULEDJOBS set sourcedirectory='OUTBOUND', status='JOBCREATED', scheduledtime=sysdate - (1/24), destnhostname='localhost', destndirectory='/opt/sftprepo/KPN_enrollment/outbound/', destnhosttype='LocalHost', ARCHIVEDIRECTORY='/opt/sftprepo/KPN_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null where id=" + collectLatestSchId("2013");
        } else {
            updateJob = "update ENRCONFIG.SCHEDULEDJOBS set sourcedirectory='OUTBOUND', status='JOBCREATED', scheduledtime=sysdate - (1/24), destnhostname='localhost', destndirectory='/opt/sftprepo/kpn_enrollment/outbound/', destnhosttype='LocalHost', ARCHIVEDIRECTORY='/opt/sftprepo/kpn_enrollment/archive/', LASTUPDATEDATE=sysdate, remarks=null where id=" + collectLatestSchId("2013");
        }
        String commit = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), commit);
    }
    public static void runShippedSIMJob(String sysType) throws Exception {
        Thread.sleep(50);
        if (sysType.contains("MCCS")) {
            executeEnrollmentJob("KPN_SHIPPED_SIM_MCCS");
            com.asurion.qa.util.CommonUtilities.waitTime(50);
        }else if (sysType.contains("3UK")) {
            executeEnrollmentJob("3UK_SIM_SHIPPED");
            com.asurion.qa.util.CommonUtilities.waitTime(50);
        } else {
            executeEnrollmentJob("KPN_SHIPPED_SIM_BOSS");
            com.asurion.qa.util.CommonUtilities.waitTime(50);
        }
    }
    public static void verifyPortingStatus(String portFlag) throws Exception {
        String portingChar ;
        if (portFlag.equalsIgnoreCase("Y")) {
            portingChar = "F74C37754D3A4DCB9CCC63744730DB68~Y";
        } else   portingChar = "F74C37754D3A4DCB9CCC63744730DB68~N";

        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM ENRSTAGING.ASSETS WHERE MDN = '" + Generic.getValuesFromGlobals("MDN") + "' ORDER BY ID DESC";
        System.out.println("\nThe Query is - " + query);
        com.asurion.qa.util.CommonUtilities.waitTime(150);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        if ((statusData.size() == 0)) {
            assertTrue("No record found  for MDN - " + Generic.getValuesFromGlobals("MDN"), false);
        } else {
            if (statusData.get(0).get("PORTINGSTATUS").equalsIgnoreCase(portingChar)) {
                System.out.println("\nPorting status is updated correctly");
            } else {
                System.out.println("\nPorting status is not updated correctly in the database");
                assertTrue("Porting status is not updated correctly in the database", false);
            }
        }
    }
    public static String collectLatestSchId(String jobId) throws Exception {
        String collectId = "";
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        collectId = "SELECT ID FROM ENRCONFIG.SCHEDULEDJOBS WHERE JOBID =" + jobId + " and ROWNUM = 1 ORDER BY ID DESC";
        System.out.println("\nThe Query for fetching latest schedule id is - " + collectId);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), collectId);
        return statusData.get(0).get("ID");
    }
    public static void verifyShipmentStatus(String trackingNumber, String status) throws Exception {
        Thread.sleep(3000);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from enrollment.shipmenttransactiondetail where shipmenttrackingnumber = '" + trackingNumber + "' and SHIPMENTSTATUS = '" + status + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 50) {
            System.out.println("\nThis is attempt time '" + i*30 + "' to get shipment status.");
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            i++;
            com.asurion.qa.util.CommonUtilities.waitTime(30);
            if (i == 50) {
                System.out.println("\nNo record found for tracking number -" + trackingNumber + " with shipment status " + status);
                if (status.equalsIgnoreCase("LD"))
                    assertTrue("No record found  for tracking number - " + trackingNumber + " with shipment status " + status, false);
            }else if(statusData.size()>0){
                System.out.println("\nRecord found in Shipment Transaction Detail Table for Tracking Number - " + trackingNumber + " with shipment status " + status);
            }
        }
//
//        if ((statusData.size() == 0)) {
//            System.out.println("\nNo record found for tracking number -" + trackingNumber + " with shipment status " + status);
//            if (status.equalsIgnoreCase("LD"))
//                assertTrue("No record found  for tracking number - " + trackingNumber + " with shipment status " + status, false);
//        } else
//            System.out.println("\nRecord found in Shipment Transaction Detail Table for Tracking Number - " + trackingNumber + " with shipment status " + status);
//        CommonUtilities.waitTime(30);
    }
    public static void updateREPLACEDASSETICCID() throws Exception {
        String warehouse = "RNL";
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk")) warehouse = "RUK";
        if (Generic.getValuesFromGlobals("TRACKINGNUMBER").isEmpty())
            getDetailsFromDAXDB("TRACKINGNUMBER", Generic.getValuesFromGlobals("CASENUMBER"), warehouse);
        verifyTrackingNumberPopulatedInStoreReplacementTable(Generic.getValuesFromGlobals("TRACKINGNUMBER"));
        createSIMID();
        String updateStr = "update enrstaging.storereplacements set REPLACEDASSETICCID = '" + Generic.getValuesFromGlobals("SIMID") + "' where OBSHIPMENTTRACKINGNUMBER = '" + Generic.getValuesFromGlobals("TRACKINGNUMBER") + "'";
        String commit = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateStr);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), updateStr);
        com.asurion.qa.util.CommonUtilities.waitTime(2);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), commit);
        String verifySimPopulated = "select * from enrstaging.storereplacements where OBSHIPMENTTRACKINGNUMBER = '" + Generic.getValuesFromGlobals("TRACKINGNUMBER") + "' and REPLACEDASSETICCID  = '" + Generic.getValuesFromGlobals("SIMID") + "'";
        ArrayList<HashMap<String, String>> recordSet = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), verifySimPopulated);
        int i = 0;
        while ((recordSet.size() == 0) && i < 80) {
            EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), updateStr);
            com.asurion.qa.util.CommonUtilities.waitTime(2);
            EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), commit);
            com.asurion.qa.util.CommonUtilities.waitTime(1);
            System.out.println("\nThis is attempt Number '" + i + "'");
            recordSet = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), verifySimPopulated);
            i++;
            if (i == 80) {
                System.out.println("\nSIM ID is not successfully updated in enrstaging.storereplacements table");
                assertTrue("SIM ID is not successfully updated in enrstaging.storereplacements table", false);
            }
        }
    }
    public static void createSIMID() throws Exception {
        String simid = Generic.getValuesFromGlobals("CASENUMBER") + 0;
        Generic.setGlobals("SIMID", simid);
    }
    public static void updateServiceRequestCreationDate(int days) throws Exception {
        String updateStr = "UPDATE CUSTOMER.SERVICE_REQUEST SET CREATED_DATE = '" + DateUtil.getFormattedDatetime("dd-MMM-yy", DateUtil.getModifiedDateTime("Day", -days)) + "' WHERE CUSTOMER_CASE_ID = (SELECT CUSTOMER_CASE_ID FROM CUSTOMER.CUSTOMER_CASE WHERE CUSTOMER.CUSTOMER_CASE.CUSTOMER_CASE_NBR = '" + Generic.getValuesFromGlobals("CASENUMBER") + "')";
        String commit = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateStr);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), updateStr);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), commit);
    }
    public static void updateServiceRequestUpdatedDate(int days) throws Exception {
        String updateStr = "UPDATE CUSTOMER.SERVICE_REQUEST SET UPDATED_DATE = '" + DateUtil.getFormattedDatetime("dd-MMM-yy", DateUtil.getModifiedDateTime("Day", -days)) + "' WHERE CUSTOMER_CASE_ID = (SELECT CUSTOMER_CASE_ID FROM CUSTOMER.CUSTOMER_CASE WHERE CUSTOMER.CUSTOMER_CASE.CUSTOMER_CASE_NBR = '" + Generic.getValuesFromGlobals("CASENUMBER") + "')";
        //String StaticCase = "133054000736";
        //String updateStr = "UPDATE CUSTOMER.SERVICE_REQUEST SET UPDATED_DATE = '" + DateUtil.getFormattedDatetime("dd-MMM-yy", DateUtil.getModifiedDateTime("Day", -days)) + "' WHERE CUSTOMER_CASE_ID = (SELECT CUSTOMER_CASE_ID FROM CUSTOMER.CUSTOMER_CASE WHERE CUSTOMER.CUSTOMER_CASE.CUSTOMER_CASE_NBR = '" + StaticCase + "')";
        String commit = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateStr);
        com.asurion.qa.util.CommonUtilities.waitTime(10);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), updateStr);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), commit);
    }
    //verify end call details saved in DAL interaction table..sandeep.supekar
    public static void verifyEndCallDetailsinDAL() throws Exception {
        Thread.sleep(100);
        com.asurion.qa.util.CommonUtilities.waitTime(30);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from dal.INTERACTION_LINE where INTERACTION_ID='" + Generic.getValuesFromGlobals("CORRID") + "' and interaction_line_wrap_1='" + Generic.getValuesFromGlobals("INTENT") + "'and interaction_line_wrap_2='" + Generic.getValuesFromGlobals("INTRSN") + "' and interaction_line_wrap_3='" + Generic.getValuesFromGlobals("ENDRSN") + "'and interaction_line_wrap_4='" + Generic.getValuesFromGlobals("ENDSUBRSN") + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() != 0)) {
            System.out.println("\nrecord found with correct end call details in DAL with intent:" + Generic.getValuesFromGlobals("INTENT") + "Intent reason:" + Generic.getValuesFromGlobals("INTRSN") + "Endcall reason:" + Generic.getValuesFromGlobals("ENDRSN") + "SubReason:" + Generic.getValuesFromGlobals("ENDSUBRSN"));
        } else
            System.out.println("\nRecord not found in DAL with given end call details");
    }
    //verify end call Notes saved in DAL Notes table..sandeep.supekar
    public static void verifyEndCallNotesinDAL() throws Exception {
        Thread.sleep(100);
        com.asurion.qa.util.CommonUtilities.waitTime(15);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        //String query1 = "select * from dal.INTERACTION_LINE where INTERACTION_ID='"+Generic.getValuesFromGlobals("CORRID")+"' and interaction_line_wrap_1='"+Generic.getValuesFromGlobals("INTENT")+"'and interaction_line_wrap_2='"+Generic.getValuesFromGlobals("INTRSN")+"' and interaction_line_wrap_3='"+Generic.getValuesFromGlobals("ENDRSN")+"'and interaction_line_wrap_4='"+Generic.getValuesFromGlobals("ENDSUBRSN")+"'";
        String query = "select * from customer.note where INTERACTION_LINE_ID =(select INTERACTION_LINE_ID from dal.INTERACTION_LINE where INTERACTION_ID='" + Generic.getValuesFromGlobals("CORRID") + "') and NOTE_TEXT='End - Other : Customer called to get info'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() != 0)) {
            System.out.println("\nrecord found with correct end call details in DAL with Notes :" + statusData.get(0).get("NOTE_TEXT"));
        } else
            System.out.println("\nRecord not found in DAL with given end call Notes");
    }
    public static void verifyClaimVoidReason(String reason) throws Exception {
        Thread.sleep(100);
        com.asurion.qa.util.CommonUtilities.waitTime(25);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM CUSTOMER.SERVICE_REQUEST WHERE ASSET_ID IN (SELECT ASSET_ID FROM ASSET.ASSET WHERE ASSET.MOBILE_DEVICE_NBR = '" + Generic.getValuesFromGlobals("MDN") + "') ORDER BY CREATED_DATE DESC";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() != 0)) {
            if (statusData.get(0).get("SERVICE_REQUEST_SUB_RSN_CODE").equals(reason)) {
                System.out.println("\nCorrect Claim void reason code is updated in database");
            } else {
                System.out.println("\nClaim void reason code is updated incorrectly in the database. Expected: " + reason + " ,Actual: " + statusData.get(0).get("SERVICE_REQUEST_SUB_RSN_CODE"));
                Assert.assertTrue("Claim void reason code is updated incorrectly in the database. Expected: " + reason + " ,Actual: " + statusData.get(0).get("SERVICE_REQUEST_SUB_RSN_CODE"), false);
            }
        } else {
            System.out.println("\nRecord not found in DAL for the case number used");
            Assert.assertTrue("Record not found in DAL for the case number used", false);
        }
    }
    public static void verifyCommsConsentStatus(String CommsStatus) throws Exception {
        Thread.sleep(50);
        com.asurion.qa.util.CommonUtilities.waitTime(25);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM REFERENCE.CONTACT_POINT_USAGE WHERE CLIENT_ACCOUNT_ID = (SELECT DISTINCT CLIENT_ACCOUNT_ID FROM ASSET.ASSET WHERE MOBILE_DEVICE_NBR = '" + Generic.getValuesFromGlobals("MDN") + "') and reference_type_code='SRVRQST' ORDER BY CREATED_DATE DESC";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if (!(statusData.size() == 0)) {
            if (statusData.get(0).get("COMMUNICATION_CONSENT_TYPE_CD").equalsIgnoreCase(CommsStatus)) {
                System.out.println("\nclaim based Comms status " + CommsStatus + " Correctly saved in DAL");
            } else {
                System.out.println("\nclaim based Comms status " + statusData.get(0).get("COMMUNICATION_CONSENT_TYPE_CD") + " wrongly saved in DAL");
                assertTrue("Job Status is " + statusData.get(0).get("STATUS"), false);
            }
        } else {
            System.out.println("\nNo Record found in CONTACT_POINT_USAGE table ");
            assertTrue("No Record found in CONTACT_POINT_USAGE table", false);
        }
    }
    public static void verifyClaimIncidentReason(String reason) throws Exception {
        Thread.sleep(100);
        com.asurion.qa.util.CommonUtilities.waitTime(15);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM CUSTOMER.SERVICE_REQUEST WHERE CUSTOMER_CASE_ID = (SELECT CUSTOMER_CASE_ID FROM CUSTOMER.CUSTOMER_CASE WHERE CUSTOMER_CASE_NBR = '" + Generic.getValuesFromGlobals("CASENUMBER") + "')and COVERED_EVENT_CODE='"+reason+"' ORDER BY CREATED_DATE DESC";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() != 0)) {

            System.out.println("\nCorrect Claim incident reason code is updated in database");
        } else {
            System.out.println("\nRecord not found in DAL for the case number used");
            Assert.assertTrue("Record not found in DAL for the case number used", false);
        }
    }
    public static void verifyDALForCancelIncidentEU(String deviceID, String status) throws Exception {
        Thread.sleep(50);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
//        String query = "select Count(*) As Present from ASSET.asset where Mobile_device_nbr = '"+deviceID+"' and ASSET_STATUS_CODE = '"+status+"'";
        String query = "SELECT * FROM CUSTOMER.SERVICE_REQUEST WHERE SERVICE_REQUEST_SUB_RSN_CODE ='" + status + "' and AGREEMENT_ID= (SELECT AG.AGREEMENT_ID FROM ASSET.AGREEMENT AG INNER JOIN ASSET.AGREEMENT_ASSET_XREF ASX ON AG.AGREEMENT_ID = ASX.AGREEMENT_ID INNER JOIN ASSET.asset AST ON AST.ASSET_ID=ASX.ASSET_ID WHERE AST.Mobile_device_nbr = '" + deviceID + "'and ROWNUM = 1)ORDER BY created_date DESC";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for MDN -" + deviceID + " with status " + status);
            assertTrue("No record found  for MDN -" + deviceID + " with status " + status, false);
        } else
            System.out.println("\nRecord found in customer service request table for MDN - " + deviceID + "with status-" + status);
    }
    public static void deleteFromDailyEnrollmentDelta() throws Exception {
        Thread.sleep(5000);
        String queryMCCS = "DELETE from ENRSTAGING.DAILY_ENROLLMENT_DELTA where BAN='" + getValuesFromGlobals("CUSTOMERNUMBER-MCCS") + "'";
        String queryBOSS = "DELETE from ENRSTAGING.DAILY_ENROLLMENT_DELTA where BAN='" + getValuesFromGlobals("CUSTOMERNUMBER-BOSS") + "'";
        String commit = "COMMIT";
        System.out.println("\nThe Delete Query for MCCS is - " + queryMCCS);
        System.out.println("\nThe Delete Query for BOSS is - " + queryBOSS);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), queryMCCS);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), queryBOSS);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), commit);
    }
    public static void verifyMDNPresentChangeLogTableDAL(String deviceID, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "Select * from ENRSTAGING.enrollmentchangelog where MDN= '" + deviceID + "' and IMPLIEDTRANSTYPE ='" + status + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 60) {
            com.asurion.qa.util.CommonUtilities.waitTime(5);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            System.out.println("\nEnrollment is not dropped in Change Log table yet, Querying since " + i * 5 + " seconds.");
            i++;
            if (i == 60) {
                System.out.println("\nNo record found for MDN -" + deviceID + " with status " + status);
                assertTrue("No record found for MDN -" + deviceID + " with status " + status, false);
            }
        }
//
//            if ((statusData.size() == 0)) {
//                System.out.println("\nNo record found for MDN -" + deviceID + " with status " + status);
//                assertTrue("No record found  for MDN - " + deviceID + " with status " + status, false);
//            } else
        System.out.println("\nRecord found in Change log table for MDN *******- " + deviceID + " with status " + status);
    }
    public static void verifyNewMDNAndOldMDNPresentChangeLogTableDAL(String newMDN, String oldMDN) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "Select * from ENRSTAGING.enrollmentchangelog where MDN=  '" + newMDN + "' and PREVMDN ='" + oldMDN + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 60) {
            com.asurion.qa.util.CommonUtilities.waitTime(5);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            System.out.println("\nEnrollment is not dropped in Change Log table yet, Querying since " + i * 5 + " seconds.");
            i++;
            if (i == 60) {
                System.out.println("\nNo record found for MDN -" + newMDN + " and old MDN " + oldMDN);
                assertTrue("No record found for MDN -" + newMDN + " and old MDN " + oldMDN, false);
            }
        }
//
//            if ((statusData.size() == 0)) {
//                System.out.println("\nNo record found for MDN -" + deviceID + " with status " + status);
//                assertTrue("No record found  for MDN - " + deviceID + " with status " + status, false);
//            } else
        System.out.println("\nRecord found in Change log table for MDN *******- " + newMDN + " old MDN " + oldMDN);
    }
    public static void verifyNewIMEIAndOldIMEIPresentChangeLogTableDAL(String newIMEI, String oldIMEI) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "Select * from ENRSTAGING.enrollmentchangelog where IMEI=  '" + newIMEI + "' and PREVIMEI ='" + oldIMEI + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 60) {
            com.asurion.qa.util.CommonUtilities.waitTime(5);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            System.out.println("\nEnrollment is not dropped in Change Log table yet, Querying since " + i * 5 + " seconds.");
            i++;
            if (i == 60) {
                System.out.println("\nNo record found for IMEI -" + newIMEI + " and old IMEI " + oldIMEI);
                assertTrue("No record found for IMEI -" + newIMEI + " and old IMEI" + oldIMEI, false);
            }
        }
//
//            if ((statusData.size() == 0)) {
//                System.out.println("\nNo record found for MDN -" + deviceID + " with status " + status);
//                assertTrue("No record found  for MDN - " + deviceID + " with status " + status, false);
//            } else
        System.out.println("\nRecord found in Change log table for IMEI *******- " + newIMEI + " old IMEI " + oldIMEI);
    }
    public static void verifyNewASSETSKUAndOldASSETSKUPresentChangeLogTableDAL(String MDN, String newAssetSKU, String oldAssetSKU) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "Select * from ENRSTAGING.enrollmentchangelog where MDN=  '" + MDN + "' and CLIENTASSETSKU ='" + newAssetSKU + "' and PREVCLIENTASSETSKU ='" + oldAssetSKU + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 60) {
            com.asurion.qa.util.CommonUtilities.waitTime(5);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            System.out.println("\nEnrollment is not dropped in Change Log table yet, Querying since " + i * 5 + " seconds.");
            i++;
            if (i == 60) {
                System.out.println("\nNo record found for MDN -" + MDN + " and ASSET SKU " + newAssetSKU);
                assertTrue("No record found for MDN -" + MDN + " and ASSET SKU " + newAssetSKU, false);
            }
        }
//
//            if ((statusData.size() == 0)) {
//                System.out.println("\nNo record found for MDN -" + deviceID + " with status " + status);
//                assertTrue("No record found  for MDN - " + deviceID + " with status " + status, false);
//            } else
        System.out.println("\nRecord found in Change log table for MDN *******- " + MDN + " and ASSETSKU " + newAssetSKU);
    }
    public static void verifyNewAndOldClientProductSKUPresentChangeLogTableDAL(String MDN, String newSKU, String oldSKU) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "Select CLIENTPRODUCTSKU,PREVCLIENTPRODUCTSKU from ENRSTAGING.enrollmentchangelog where MDN=  '" + MDN + "' order by CREATIONDATE desc ";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        com.asurion.qa.util.CommonUtilities.waitTime(15);
        if (statusData.get(0).get("CLIENTPRODUCTSKU").contains(newSKU) && statusData.get(0).get("PREVCLIENTPRODUCTSKU").contains(oldSKU)) {
            System.out.println("\nRecord found in Change log table for MDN *******- " + MDN + " and CLIENTPRODUCTSKU Contains " + newSKU + " and PREVCLIENTPRODUCTSKU Contains " + oldSKU);
        } else {
            System.out.println("\nNo record found for MDN -" + MDN + " and ASSET SKU " + newSKU);
            assertTrue("No record found for MDN -" + MDN + " and ASSET SKU " + newSKU, false);
        }
    }
    public static void insertOneTimeRecord(String srcFile, String insuranceStartDate) throws Exception {
        Thread.sleep(50);
        String updateJob = "";
        updateJob = "insert into enrstaging.ONETIMEREPORT values('" + KPNEnrolmentPage.hm.get("CUSTOMERNUMBER-" + srcFile) + "','" + KPNEnrolmentPage.hm.get("COUNTRYCODE-" + srcFile) + "','" + KPNEnrolmentPage.hm.get("MDN-" + srcFile) + "','KPN','" + insuranceStartDate + "','" + KPNEnrolmentPage.hm.get("ASSETSKU-" + srcFile) + "','" + KPNEnrolmentPage.hm.get("IMEI-" + srcFile) + "')";
        String commit = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), commit);
    }
    public static String captureCustomerCorrespondenceId(String commPack) throws Exception {
        com.asurion.qa.util.CommonUtilities.waitTime(150);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String updateJob = "";
        updateJob = "SELECT CUSTOMER_CORRESPONDENCE_ID FROM CUSTOMER.CUSTOMER_CORRESPONDENCE WHERE AGREEMENT_ID IN (SELECT DISTINCT DALAGREEMENTID FROM ENRSTAGING.CORRESPONDENCELETTER WHERE MOBILEDEVICENUMBER = '" + Generic.getValuesFromGlobals("MDN") + "') AND CORRESPONDENCE_REASON_CODE = '" + commPack + "';";
        System.out.println("\nThe Update Query is - " + updateJob);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), updateJob);
        return (statusData.get(0).get("CUSTOMER_CORRESPONDENCE_ID"));
    }
    public static void runCommsJob() throws Exception {
        com.asurion.qa.util.CommonUtilities.waitTime(150);
        String updateJob = "";
        updateJob = "update ENRCONFIG.SCHEDULEDJOBS set status='JOBCREATED', scheduledtime=sysdate - (1/24), remarks=null where  id=" + collectLatestSchId("2041");
        String commit = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), commit);
    }
    public static void runAmendmentEntityCommsJob() throws Exception {
        com.asurion.qa.util.CommonUtilities.waitTime(150);
        String updateJob = "";
        updateJob = "update ENRCONFIG.SCHEDULEDJOBS set status='JOBCREATED', scheduledtime=sysdate - (1/24), remarks=null where  id=" + collectLatestSchId("2040");
        String commit = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), commit);
    }
    public static String runCommsJob(String mdn) throws Exception {
        com.asurion.qa.util.CommonUtilities.waitTime(150);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String updateJob = "";
        String jobId="";
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("kpn"))  jobId = "2041";
        else if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk")) jobId ="4403023";
        else assertTrue("Comunications Job is not configured, kindly contact Automation Team.",false);
        updateJob = "update ENRCONFIG.SCHEDULEDJOBS set status='JOBCREATED', scheduledtime=sysdate - (1/24), remarks=null where  id=" + collectLatestSchId(jobId);
        String commit = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), commit);
        verifyCORRESPONDENCELETTER(mdn,"COMPLETED");
        String query = "SELECT * FROM CUSTOMER.CUSTOMER_CORRESPONDENCE WHERE AGREEMENT_ID IN (SELECT DISTINCT DALAGREEMENTID FROM ENRSTAGING.CORRESPONDENCELETTER WHERE MOBILEDEVICENUMBER = '" + mdn +"') order by updated_date desc";
        System.out.println("\nThe Select Query for comms is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 80) {
            com.asurion.qa.util.CommonUtilities.waitTime(10);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            System.out.println("\nNo entry in CUSTOMER.CUSTOMER_CORRESPONDENCE yet, Querying since " + i * 10 + " seconds.");
            i++;
            if (i == 80) {
                System.out.println("\nNo entry in CUSTOMER.CUSTOMER_CORRESPONDENCE table for MDN - " + mdn);
                assertTrue("No entry in CUSTOMER.CUSTOMER_CORRESPONDENCE table for MDN - " + mdn, false);
            }
        }
        System.out.println("\nEntry is present in CUSTOMER.CUSTOMER_CORRESPONDENCE table");
        String customerCorrespondanceId = statusData.get(0).get("CUSTOMER_CORRESPONDENCE_ID");
        return customerCorrespondanceId;
    }

    public static void verifyCommunicationTriggered(String mdn, String comms, String count) throws Exception    {

        com.asurion.qa.util.CommonUtilities.waitTime(5);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();

        String query = "\nSELECT Count(*) AS NUMBEROFRECORD FROM CUSTOMER.CUSTOMER_CORRESPONDENCE WHERE AGREEMENT_ID in (Select AG.AGREEMENT_ID from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '" + mdn + "') AND CORRESPONDENCE_REASON_CODE ='" + comms + "'";

        System.out.println("\n\nThe Select Query for comms is - "+ query );
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        int i=0;
        while ((statusData.size() == 0) && i < 80) {
            com.asurion.qa.util.CommonUtilities.waitTime(10);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            System.out.println("\n"+comms+"Letter entry is not inserted in CUSTOMER.CUSTOMER_CORRESPONDENCE yet, Querying since "+ (i+1)*10 +" seconds.");
            i++;
            if (i == 80) {
                System.out.println("\nNo entry in CUSTOMER.CUSTOMER_CORRESPONDENCE table for MDN - " + mdn + "for '"+comms+"' Letter");
                assertTrue("No entry in CUSTOMER.CUSTOMER_CORRESPONDENCE table for MDN - " + mdn + "for '"+comms+"' Letter", false);
            }
        }
        i=0;
        while ((!statusData.get(0).get("NUMBEROFRECORD").equalsIgnoreCase(count) && i < 80)) {
            com.asurion.qa.util.CommonUtilities.waitTime(10);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            System.out.println("\n"+comms+"Letter entry is not inserted in CUSTOMER.CUSTOMER_CORRESPONDENCE yet, Querying since "+ (i+1)*10 +" seconds.");
            i++;
            if (i == 80) {
                System.out.println("\nNo entry in CUSTOMER.CUSTOMER_CORRESPONDENCE table for MDN - " + mdn + "for '"+comms+"' Letter");
                assertTrue("No entry in CUSTOMER.CUSTOMER_CORRESPONDENCE table for MDN - " + mdn + "for '"+comms+"' Letter", false);
            }
        }
        System.out.println("\n"+count+" Entry/Entries present in CUSTOMER.CUSTOMER_CORRESPONDENCE table for MDN '"+mdn+"' for '"+comms+"'");

    }
    public static void verifyCommunicationNotTriggered(String mdn, String comms) throws Exception    {

        com.asurion.qa.util.CommonUtilities.waitTime(5);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();

        String query = "SELECT *  FROM CUSTOMER.CUSTOMER_CORRESPONDENCE WHERE AGREEMENT_ID in (SELECT DISTINCT DALAGREEMENTID FROM ENRSTAGING.CORRESPONDENCELETTER WHERE MOBILEDEVICENUMBER = '" + mdn + "') AND CORRESPONDENCE_REASON_CODE ='" + comms + "'";
        System.out.println("\nThe Select Query for comms is - "+ query );
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0) ) System.out.println("\n"+comms+" Letter not triggered for MDN '" + mdn + "' which is as expected");
        else  {
            System.out.println("\n"+comms+" Letter triggered for MDN '" + mdn + "' which is not expected");
            assertTrue(comms+" Letter triggered for MDN '" + mdn + "' which is not expected", false);
        }

    }
    public static void verifyChargeOrderStatusCode(String chargeOrderStatusCode, String chargeOrderLineType, String claimid) throws Exception {
        Thread.sleep(5000);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM customer.charge_order_line col, customer.charge_order cor WHERE col.charge_order_id = cor.charge_order_id   AND cor.CHARGE_ORDER_STATUS_CODE = '"+chargeOrderLineType+"' AND col.CHARGE_ORDER_LINE_TYPE_CODE = '"+chargeOrderStatusCode+"' AND cor.charge_order_id IN (SELECT co.charge_order_id FROM customer.charge_order co, customer.customer_case_category ccc  WHERE co.charge_order_id = ccc.item_id  AND ccc.customer_case_id IN (SELECT customer_case_id FROM customer.customer_case WHERE customer_case_nbr =  '"+claimid+"'))";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for Charge Order Status Code -" + chargeOrderStatusCode + " for Charge Order Line Type - " + chargeOrderLineType + "for claim id - "+claimid);
            assertTrue("No record found for Charge Order Status Code -" + chargeOrderStatusCode + " for Charge Order Line Type - " + chargeOrderLineType + "for claim id - "+claimid, false);
        } else
            System.out.println("\nRecord found for Charge Order Status Code -" + chargeOrderStatusCode + " for Charge Order Line Type - " + chargeOrderLineType + "for claim id - "+claimid);

    }

    public static void verifyDataNotInCORRESPONDENCELETTER(String mdn, String comms,String status) throws Exception    {

        com.asurion.qa.util.CommonUtilities.waitTime(5);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();

        String query = "SELECT * FROM ENRSTAGING.CORRESPONDENCELETTER WHERE MOBILEDEVICENUMBER = '"+mdn+"' AND CREATEDBY ='"+comms+"' AND STATUS = '"+status+"'";
        System.out.println("\nThe Select Query to verify Data in ENRSTAGING.CORRESPONDENCELETTER is - "+ query );
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        if ((statusData.size() == 0) ) System.out.println("\n"+ comms+" Event not triggered for MDN '" + mdn + "'  with STATUS = '"+status+"' which is as expected");
        else  {
            System.out.println("\n"+comms+" Event triggered for MDN '" + mdn + "' which is not expected");
            assertTrue(comms+" Event triggered for MDN '" + mdn + "' which is not expected", false);
        }
    }

    public static void verifyCORRESPONDENCELETTER(String mdn, String status) throws Exception    {

        com.asurion.qa.util.CommonUtilities.waitTime(5);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();

        String query = "SELECT * FROM ENRSTAGING.CORRESPONDENCELETTER WHERE MOBILEDEVICENUMBER = '"+mdn+"' AND STATUS = '"+status+"'";
        System.out.println("\nThe Select Query to verify Data in ENRSTAGING.CORRESPONDENCELETTER is - "+ query );
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);

        int i=0;
        while ((statusData.size()== 0 && i < 80)) {
            com.asurion.qa.util.CommonUtilities.waitTime(3);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            System.out.println("\nLetter entry is not inserted in ENRSTAGING.CORRESPONDENCELETTER with Status - '"+status+"' yet, Querying since "+ (i+1)*10 +" seconds.");
            i++;
            if (i == 80) {
                System.out.println("\nNo entry in ENRSTAGING.CORRESPONDENCELETTER table for MDN - " + mdn + " with Status - '"+status+"'");
                assertTrue("No entry in ENRSTAGING.CORRESPONDENCELETTER table for MDN - " + mdn , false);
            }
        }
        System.out.println("\nRecord is present in ENRSTAGING.CORRESPONDENCELETTER table for MDN '"+mdn+"' with status - '"+status+"'");
    }

    public static void insertMigrationRecord(String insuranceStartDate) throws Exception {
        Thread.sleep(50);
        String updateJob = "";
        updateJob = "insert into ENRSTAGING.MCCS_BOSS_MIGRATION (MCCS_SERVICE_PROVIDER_ID,MCCS_CUSTOMER_ID,BOSS_CUSTOMER_NUMBER_NEW,MCCS_CUSTOMER_NUMBER_OLD,MOBILE_DEVICE_NUMBER,INSURANCE_CONTRACT_START_DATE,IMEI,COVERED_DEVICE_ID) values ('02','194621157','" + KPNEnrolmentPage.getUniqueCUSTOMERNUMBERBOSS_EU() + "','" + KPNEnrolmentPage.hm.get("CUSTOMERNUMBER-MCCS") + "','" + KPNEnrolmentPage.hm.get("MDN-MCCS") + "','" + insuranceStartDate + "','" + KPNEnrolmentPage.hm.get("IMEI-MCCS") + "','" + KPNEnrolmentPage.hm.get("ASSETSKU-MCCS") + "')";
        String commit = "COMMIT";
        KPNEnrolmentPage.hm.put("CUSTOMERNUMBER-MCCS", Generic.getValuesFromGlobals("CUSTOMERNUMBERBOSS"));
        Generic.setGlobals("CUSTOMERNUMBER-MCCS", Generic.getValuesFromGlobals("CUSTOMERNUMBERBOSS"));
        System.out.println("\nThe Update Query is - " + updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), commit);
    }


    public static void truncateKVK() throws Exception {
        KPNEnrolmentPage.hm.put("KVKNUMBER-MCCS", KPNEnrolmentPage.hm.get("KVKNUMBER-MCCS").substring(0,8));
        Generic.setGlobals("KVKNUMBER-MCCS", KPNEnrolmentPage.hm.get("KVKNUMBER-MCCS"));
        System.out.println("\nTruncated KVK is - " + Generic.getValuesFromGlobals("KVKNUMBER-MCCS"));
    }
    public static void verifyRecordStatusInPREINTERFACE(String mdn, String status) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM enrstaging.enrollmentsnapshotPREINTERFACE WHERE MDN = '"+mdn+"' AND STATUS = '"+status+"'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i=0;
        while ((statusData.size() == 0) && i < 80) {
            com.asurion.qa.util.CommonUtilities.waitTime(3);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            i++;
            if (i == 80) {
                System.out.println("\n No record found for MDN -" + mdn + " with status '" + status+"' in PREINTERFACE");
                assertTrue("No record found for MDN -" + mdn + " with status '" + status+"' in PREINTERFACE", false);
            }
        }
        System.out.println("\n Record found in PREINTERFACE table for MDN - " + mdn + " with status " + status);

    }

    public static void verifyRecordRemarkInPREINTERFACE(String mdn, String remark) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM enrstaging.enrollmentsnapshotPREINTERFACE WHERE MDN = '"+mdn+"' AND REMARK = '"+remark+"'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i=0;
        while ((statusData.size() == 0) && i < 80) {
            com.asurion.qa.util.CommonUtilities.waitTime(3);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            i++;
            if (i == 80) {
                System.out.println("\n No record found for MDN -" + mdn + " with remark '" + remark+"' in PREINTERFACE");
                assertTrue("No record found for MDN -" + mdn + " with remark '" + remark+"' in PREINTERFACE", false);
            }
        }
        System.out.println("\n Record found in PREINTERFACE table for MDN - " + mdn + " with remark " + remark);

    }

    public static void verifyRejectionCodeInPREINTERFACE(String mdn, String rejectionCode) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query="";
        if(rejectionCode.equalsIgnoreCase("NULL")) query = "SELECT * FROM enrstaging.enrollmentsnapshotPREINTERFACE WHERE MDN = '"+mdn+"' AND REJECTIONCODE is NULL";
        else query = "SELECT * FROM enrstaging.enrollmentsnapshotPREINTERFACE WHERE MDN = '"+mdn+"' AND REJECTIONCODE ='"+rejectionCode+"'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i=0;
        while ((statusData.size() == 0) && i < 80) {
            com.asurion.qa.util.CommonUtilities.waitTime(3);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
            i++;
            if (i == 80) {
                System.out.println("\n No record found for MDN -" + mdn + " with REJECTIONCODE '" + rejectionCode+"' in PREINTERFACE");
                assertTrue("No record found for MDN -" + mdn + " with REJECTIONCODE '" + rejectionCode+"' in PREINTERFACE", false);
            }
        }
        System.out.println("\n Record found in PREINTERFACE table for MDN - " + mdn + " with REJECTIONCODE " + rejectionCode);

    }

    public static void verifyInsuranceAddOnDateUpdatedInDAL(String deviceID, String addOnDate) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM Asset.Agreement_Purchase WHERE PURCHASE_DATE = '"+addOnDate+"' AND AGREEMENT_ID IN (Select AG.AGREEMENT_ID from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '"+deviceID+"')";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nInsurance Add On date is not populated as "+addOnDate+" in DAL which is not expected");
            assertTrue("Insurance Add On date is not populated as '"+addOnDate+"' in DAL  which is not expected", false);
        }
        System.out.println("\nInsurance Add On date is populated as '"+addOnDate+"' in DAL which is as expected");
    }

    public static void verifyInsuranceAddOnDateNOTUpdatedInDAL(String deviceID, String addOnDate) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM Asset.Agreement_Purchase WHERE PURCHASE_DATE = '"+addOnDate+"' AND AGREEMENT_ID IN (Select AG.AGREEMENT_ID from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '"+deviceID+"')";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if (!(statusData.size() == 0)) {
            System.out.println("\nInsurance Add On date is populated as '"+addOnDate+"' in DAL which is not expected");
            assertTrue("Insurance Add On date is not populated as '"+addOnDate+"' in DAL which is not expected", false);
        }
        System.out.println("\nInsurance Add On date is not populated as "+addOnDate+" in DAL which is as expected ");

    }
    public static String getInsuranceAddOnDate(String value) throws Exception {
        if (value.equalsIgnoreCase("Yesterday")) {
            value = DateUtil.getFormattedDatetime("dd-MMM-yy", DateUtil.getModifiedDateTime("Day", -1));
        } else if (value.equalsIgnoreCase("Today")) {
            value = DateUtil.getFormattedDatetime("dd-MMM-yy", DateUtil.getModifiedDateTime("Day", 0));
        } else if (value.contains("Today")) {
            value = value.replace("Today","").replace(" ","");
            value = DateUtil.getFormattedDatetime("dd-MMM-yy", DateUtil.getModifiedDateTime("DAY",Integer.parseInt(value)));
        }
        return value+" 12.00.00.000000000 AM";
    }

    public static void verifyMDNNotPresentInAgreementTableDAL(String deviceID) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "Select * from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '" + deviceID + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        int i = 0;
        if (statusData.size() == 0)   System.out.println("\nNo record found for MDN - " + deviceID +" in AGREEMENT table which is as expected");
        else{
            System.out.println("\nRecord found in AGREEMENT table for MDN " + deviceID + " which is not as expected");
            assertTrue("Record found in AGREEMENT table for MDN " + deviceID + " which is not as expected", false);
        }

    }

    public static void verifyCommsConsentInDALForEU3UK(String deviceID, String reference) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from REFERENCE.CONTACT_POINT_USAGE where COMMUNICATION_CONSENT_TYPE_CD ='ALL' and REFERENCE_TYPE_CODE ='"+reference+"' and Client_Account_ID =( Select AST.CLIENT_ACCOUNT_ID from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '" + deviceID + "' and ROWNUM = 1)";
        System.out.println("\nThe Query for verifying record availability in CONTACT_POINT_USAGE table is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if (statusData.size() == 0) {
            System.out.println("\nNo record found for MDN - " + deviceID + " in REFERENCE.CONTACT_POINT_USAGE table.");
            assertTrue("No Record found in REFERENCE.CONTACT_POINT_USAGE table for MDN " + deviceID + ".", false);
        }
        query = "select * from REFERENCE.CONTACT_POINT_USAGE where COMMUNICATION_CONSENT_TYPE_CD !='ALL' and REFERENCE_TYPE_CODE ='"+reference+"' and Client_Account_ID =( Select AST.CLIENT_ACCOUNT_ID from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '" + deviceID + "' and ROWNUM = 1)";
        System.out.println("\nThe Query for verifying the consent is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if (statusData.size() == 0) {
            System.out.println("\nRecord found in REFERENCE.CONTACT_POINT_USAGE table for MDN " + deviceID + " which is as expected");
        }
        else{
            System.out.println("\nNo record found for MDN - " + deviceID + " in REFERENCE.CONTACT_POINT_USAGE table which is as expected");
            assertTrue("Record Not found in REFERENCE.CONTACT_POINT_USAGE table for MDN " + deviceID + " which is not as expected", false);
        }

    }


    public static void verifyIMEIListedInBLOCKEDASSETS(String imei, String incidentType,String clientChannelId) throws Exception {
        Thread.sleep(10);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT NOTIFICATIONTYPE FROM ENRSTAGING.BLOCKEDASSETS WHERE MOBILEEQUIPMENTIDENTIFIER = '"+imei+"' AND UPPER(NOTIFICATIONTYPE) IN ('"+incidentType+"') AND CLIENTCHANNELID='"+clientChannelId+"'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 80) {
            com.asurion.qa.util.CommonUtilities.waitTime(10);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            System.out.println("\nIMEI is not listed in BLOCKEDASSETS table yet, Querying since " + i * 10 + " seconds.");
            i++;
            if (i == 80) {
                System.out.println("\nNo record found  for IMEI - " + imei);
                assertTrue("No record found  for IMEI - " + imei, false);
            }
        }
        System.out.println("\nRecord found in BLOCKEDASSETS table for IMEI - " + imei + " for incident type " + incidentType);
    }

    public static String getBlockedIMEI3UK(String incidentType) throws Exception {
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT MOBILEEQUIPMENTIDENTIFIER FROM ENRSTAGING.BLOCKEDASSETS WHERE ID =(SELECT MAX(ID) FROM ENRSTAGING.BLOCKEDASSETS WHERE NOTIFICATIONTYPE = '"+incidentType+"' AND CLIENTCHANNELID='23B864D7B96706CAE053C971020A8EB6' AND MOBILEEQUIPMENTIDENTIFIER is not null)";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo IMEI found for incident type -" + incidentType);
            assertTrue("No IMEI found for incident type -" + incidentType, false);
        } else
            System.out.println("\nIMEI found for incident type -" + incidentType);
        String imei = statusData.get(0).toString().substring(27).replace("}", "").trim();
        return imei;
    }

    public static void searchDALForStagedMDN(String systemType, String mdn) throws Exception {
        ArrayList<HashMap<String, String>> customerDetails = null;

        String query = "select Customer.Full_Name as CustomerName, First_Name as FirstName, Last_Name as LastName, Customer_Identification.IDENTIFICATION_NBR as NATIONALID, \n" +
                "Asset.MOBILE_DEVICE_NBR as MDN, Asset.MOBILE_EQUIPMENT_ID as IMEI, Client_Account.EXTERNAL_REFERENCE_ID as BAN,\n" +
                "ADDRESS_TYPE_CODE as AddressCode, Address_Line_1 as AddressLine1, Address_Line_2 as AddressLine2, City_Name as City, Postal_Code as PostalCode, Agreement.CLIENT_PRODUCT_SKU_NBR as ProductCode,\n" +
                "Agreement_Purchase.REGION_CODE as Region,  \n" +
                "Asset_Make_Name as MAKE, Asset_Model_NBR as MODEL,Asset_Catalog.ASSET_CATALOG_DESC as ModelName, Asset.Asset_catalog_id as AssetCatalogId, Country.COUNTRY_NAME as COUNTRY\n" +
                ",CP.EMAIL_ADDRESS as EMAIL,Asset_Color.ASSET_COLOR_NAME as COLOR,State_province.STATE_PROVINCE_CODE as STATE, Agreement.External_Reference_Id as Customer_Number \n" +
                "from Asset.asset   \n" +
                "left outer join Asset.Asset_Catalog on Asset_catalog.Asset_Catalog_Id = Asset.Asset_Catalog_Id\n" +
                "left outer join Asset.Asset_Color  ON Asset_color.Asset_color_Id = Asset_catalog.Asset_Color_Id\n" +
                "left outer join Asset.Asset_Model on Asset_Model.Asset_Model_Id = Asset_Catalog.Asset_Model_ID   \n" +
                "left outer join Asset.Asset_Make on Asset_Make.Asset_Make_Id = Asset_Catalog.Asset_Make_ID and  Asset_Make.Asset_Make_Id =  Asset_Model.Asset_Make_Id\n" +
                "left outer join  Asset.Asset_Purchase on Asset_Purchase.ASSET_ID = Asset.ASSET_ID -- Asset Purchase  \n" +
                "left outer join client.Client_Account on Client_Account.CLIENT_ACCOUNT_ID = Asset.CLIENT_ACCOUNT_ID -- Client Account\n" +
                "left outer join Asset.Agreement on Agreement.CLIENT_ACCOUNT_ID = Client_Account.CLIENT_ACCOUNT_ID -- Agreement  \n" +
                "left outer join Asset.Agreement_Purchase on Agreement_Purchase.AGREEMENT_ID = Agreement.AGREEMENT_ID -- Agreement Purchase\n" +
                "left outer join Asset.Agreement_Asset_Xref on Agreement_Asset_Xref.AGREEMENT_ID = Agreement.AGREEMENT_ID  \n" +
                "and Agreement_Asset_Xref.ASSET_ID = Asset.ASSET_ID -- Agreement Asset \n" +
                "left outer join Customer.Customer_Agreement_Role on Customer_Agreement_Role.Agreement_ID = Agreement.Agreement_ID   -- CustomerAgreementRole \n" +
                "left outer join Customer.Customer on Customer.Customer_ID = Customer_Agreement_Role.CUSTOMER_ID -- Customer    \n" +
                "left outer join Customer.Customer_Identification on Customer_Identification.Customer_Id = Customer.Customer_ID -- Customer Identifiers\n" +
                "left outer join client.Client_Account_Address_Usage on Client_Account_Address_Usage.Client_Account_Id = Client_Account.Client_Account_ID    \n" +
                "left outer join Reference.Address on Address.Address_Id = Agreement.Address_Id and Address.Address_Id = Client_Account_Address_Usage.Address_ID  \n" +
                "left outer join Reference.Country on Country.Country_Code = Address.COUNTRY_CODE \n" +
                "left outer join Reference.State_province on State_province.STATE_PROVINCE_CODE=Address.STATE_PROVINCE_CODE\n" +
                "LEFT OUTER JOIN REFERENCE.CONTACT_POINT_USAGE CPU ON CPU.CLIENT_ACCOUNT_ID=asset.CLIENT_ACCOUNT_ID\n" +
                "LEFT OUTER JOIN REFERENCE.CONTACT_POINT CP ON CPU.CONTACT_POINT_ID =CP.CONTACT_POINT_ID\n" +
                "where Mobile_Device_NBr='" + mdn + "'";
        int size = 0;
        int i = 0;
        do {
            customerDetails = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            if (customerDetails.size() > 0) {
                break;
            }
            i++;
        } while (size == 0 && i <= 1500);
        if (customerDetails.size() == 0) {
            assertTrue("MDN is not present in DAL DB " + CustomerDetails.customerData.get("MDN") + "", false);
        }
//        if (systemType.equalsIgnoreCase("MCCS")) {
//            stagedData.put("CUSTOMERNUMBER_MCCS", customerDetails.get(0).get("CUSTOMER_NUMBER"));
//            stagedData.put("IMEI-MCCS", customerDetails.get(0).get("IMEI"));
//            stagedData.put("KVKNUMBER-MCCS", customerDetails.get(0).get("BAN"));
//        } else {
//            stagedData.put("CUSTOMERNUMBER_BOSS", customerDetails.get(0).get("CUSTOMER_NUMBER"));
//            stagedData.put("IMEI-BOSS", customerDetails.get(0).get("IMEI"));
//            stagedData.put("KVKNUMBER-BOSS", customerDetails.get(0).get("BAN"));
//        }
    }

    public static void verifyTrackingNumberPopulatedInStoreReplacementTable(String trackingNumber) throws Exception {
        Thread.sleep(3000);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM ENRSTAGING.STOREREPLACEMENTS WHERE OBSHIPMENTTRACKINGNUMBER = '" + trackingNumber + "'";
        System.out.println("\nThe Query is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), query);
        if ((statusData.size() == 0)) {
            System.out.println("\nNo record found for tracking number - '" + trackingNumber + "'.");
            assertTrue("No record found  for tracking number - '" + trackingNumber + "' in ENRSTAGING.STOREREPLACEMENTS", false);
        } else
            System.out.println("\nRecord found in ENRSTAGING.STOREREPLACEMENTS Table for Tracking Number - '" + trackingNumber + "'");
    }

    public static void verifyPrimaryIndicatorFlagIsTrueInDALForEU3UK(String deviceID) throws Exception {
        Thread.sleep(100);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();

        String query = "select * from REFERENCE.CONTACT_POINT_USAGE where PRIMARY_IND ='Y' and Client_Account_ID =( Select AST.CLIENT_ACCOUNT_ID from ASSET.AGREEMENT AG inner join ASSET.AGREEMENT_ASSET_XREF ASX  on AG.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '" + deviceID + "' and ROWNUM = 1)";
        System.out.println("\nThe Query for verifying the consent is - " + query);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if (statusData.size() == 0) {
            System.out.println("\nNo record found for MDN - " + deviceID + " in REFERENCE.CONTACT_POINT_USAGE table with Indicator flag True which is Not expected");
            assertTrue("Record Not found in REFERENCE.CONTACT_POINT_USAGE table for MDN " + deviceID + " with Indicator flag True which is not as expected", false);
        }
        else{
            System.out.println("\nRecord found in REFERENCE.CONTACT_POINT_USAGE table for MDN " + deviceID + " with Indicator flag True which is as expected");
        }

    }

    public static void updateReplacedIMEIAssetTable(String IMEI) throws Exception {
        String MDN = Generic.getValuesFromGlobals("MDN");
        String updateJob = "update Asset.asset set MOBILE_EQUIPMENT_ID = '" + IMEI + "' where MOBILE_DEVICE_NBR='" + MDN + "' and asset_instance_code='REPLACED'";
        String commit = "COMMIT";
        System.out.println("\nThe Update Query is - " + updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), updateJob);
        EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), commit);
    }

    public static void verifyCustomerTable(String mdn,String column, String value) throws Exception    {

        com.asurion.qa.util.CommonUtilities.waitTime(5);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();

        String query = "Select * from CUSTOMER.CUSTOMER CU inner join CUSTOMER.CUSTOMER_AGREEMENT_ROLE CR on CU.CUSTOMER_ID = CR.CUSTOMER_ID inner join ASSET.AGREEMENT_ASSET_XREF ASX  on CR.AGREEMENT_ID = ASX.AGREEMENT_ID inner join ASSET.asset AST on AST.ASSET_ID=ASX.ASSET_ID where AST.Mobile_device_nbr = '"+mdn+"'";
        if (column.equalsIgnoreCase("GENDER")) query = query + " and CU.GENDER = '"+value+"'";
        else {
            System.out.println("\nQuery is not configured for column '"+column+"'");
            assertTrue("Query is not configured for column '"+column+"'", false);
        }
        System.out.println("\nThe Select Query for comms is - "+ query );
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        int i=0;
        while ((statusData.size() == 0)&& i<120) {
            com.asurion.qa.util.CommonUtilities.waitTime(3);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            i++;
            if (i == 120) {
                System.out.println("\n"+column+" field is not populated with value '"+value+" which is not as expected");
                assertTrue(column+" field is not populated with value '"+value+" which is not as expected", false);
            }
        }
        System.out.println("\n"+column+" field is populated with value '"+value+" which is as expected");


    }

    public static void verifyAddressInDALDB(String mdn,String column, String value) throws Exception    {

        com.asurion.qa.util.CommonUtilities.waitTime(5);
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "SELECT * FROM REFERENCE.ADDRESS AD inner join CLIENT.CLIENT_ACCOUNT_ADDRESS_USAGE CAAU on AD.ADDRESS_ID = CAAU.ADDRESS_ID inner join ASSET.ASSET AST on CAAU.CLIENT_ACCOUNT_ID = AST.CLIENT_ACCOUNT_ID where  AST.Mobile_device_nbr = '"+mdn+"'";

        if(value.equalsIgnoreCase("NULL")){
            if (column.equalsIgnoreCase("ADDRESSLINE1")) query = query + " and AD.ADDRESS_LINE_1 is NULL";
            else if (column.equalsIgnoreCase("ADDRESSLINE2")) query = query + " and AD.ADDRESS_LINE_2 is NULL";
            else if (column.equalsIgnoreCase("ADDRESSLINE3")) query = query + " and AD.ADDRESS_LINE_3 is NULL";
            else if (column.equalsIgnoreCase("CITY")) query = query + " and AD.CITY_NAME is NULL";
            else if (column.equalsIgnoreCase("STATE")) query = query + " and AD.STATE_PROVINCE_CODE is NULL";
            else if (column.equalsIgnoreCase("COUNTRY")) query = query + " and AD.COUNTRY_CODE is NULL";
            else if (column.equalsIgnoreCase("POSTCODE")) query = query + " and AD.POSTAL_CODE is NULL";
            else {
                System.out.println("\nQuery is not configured for column '"+column+"'");
                assertTrue("Query is not configured for column '"+column+"'", false);
            }
        } else {
            if (column.equalsIgnoreCase("ADDRESSLINE1")) query = query + " and AD.ADDRESS_LINE_1 = '" + value + "'";
            else if (column.equalsIgnoreCase("ADDRESSLINE2"))
                query = query + " and AD.ADDRESS_LINE_2 = '" + value + "'";
            else if (column.equalsIgnoreCase("ADDRESSLINE3"))
                query = query + " and AD.ADDRESS_LINE_3 = '" + value + "'";
            else if (column.equalsIgnoreCase("CITY")) query = query + " and AD.CITY_NAME = '" + value + "'";
            else if (column.equalsIgnoreCase("STATE")) query = query + " and AD.STATE_PROVINCE_CODE = '" + value + "'";
            else if (column.equalsIgnoreCase("COUNTRY")) query = query + " and AD.COUNTRY_CODE = '" + value + "'";
            else if (column.equalsIgnoreCase("POSTCODE")) query = query + " and AD.POSTAL_CODE = '" + value + "'";
            else {
                System.out.println("\nQuery is not configured for column '" + column + "'");
                assertTrue("Query is not configured for column '" + column + "'", false);
            }
        }
        System.out.println("\nThe Select Query for Address verification is - "+ query );
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        int i=0;
        while ((statusData.size() == 0)&& i<120) {
            com.asurion.qa.util.CommonUtilities.waitTime(3);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            i++;
            if (i == 120) {
                System.out.println("\n"+column+" field is not populated with value '"+value+"' which is not as expected");
                assertTrue(column+" field is not populated with value '"+value+" which is not as expected", false);
            }
        }
        System.out.println("\n"+column+" field is populated with value '"+value+"' which is as expected");

    }

    public static void verifyAddressLine1DAL() throws Exception {
        String addressLine1 = "";
        if(!ThreeUKAddEnrollPage.hm.get("Flat_number").equalsIgnoreCase("") && !ThreeUKAddEnrollPage.hm.get("House_name").equalsIgnoreCase("")  && !ThreeUKAddEnrollPage.hm.get("House_number").equalsIgnoreCase("") && !ThreeUKAddEnrollPage.hm.get("Billing_address_line1").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("Flat_number")+" "+ThreeUKAddEnrollPage.hm.get("House_name")+" "+ThreeUKAddEnrollPage.hm.get("House_number")+" "+ThreeUKAddEnrollPage.hm.get("Billing_address_line1")).replace("  "," ");
        else if(ThreeUKAddEnrollPage.hm.get("Flat_number").equalsIgnoreCase("") && ThreeUKAddEnrollPage.hm.get("House_name").equalsIgnoreCase("")  && ThreeUKAddEnrollPage.hm.get("House_number").equalsIgnoreCase("") && ThreeUKAddEnrollPage.hm.get("Billing_address_line1").equalsIgnoreCase(""))
            addressLine1 = "NULL";
        else if(!ThreeUKAddEnrollPage.hm.get("Flat_number").equalsIgnoreCase("") && !ThreeUKAddEnrollPage.hm.get("House_name").equalsIgnoreCase("")  && !ThreeUKAddEnrollPage.hm.get("House_number").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("Flat_number")+" "+ThreeUKAddEnrollPage.hm.get("House_name")+" "+ThreeUKAddEnrollPage.hm.get("House_number")).replace("  "," ");
        else if(!ThreeUKAddEnrollPage.hm.get("Flat_number").equalsIgnoreCase("") && !ThreeUKAddEnrollPage.hm.get("House_name").equalsIgnoreCase("")  && !ThreeUKAddEnrollPage.hm.get("Billing_address_line1").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("Flat_number")+" "+ThreeUKAddEnrollPage.hm.get("House_name")+" "+ThreeUKAddEnrollPage.hm.get("Billing_address_line1")).replace("  "," ");
        else if(!ThreeUKAddEnrollPage.hm.get("Flat_number").equalsIgnoreCase("") && !ThreeUKAddEnrollPage.hm.get("House_number").equalsIgnoreCase("")  && !ThreeUKAddEnrollPage.hm.get("Billing_address_line1").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("Flat_number")+" "+ThreeUKAddEnrollPage.hm.get("House_number")+" "+ThreeUKAddEnrollPage.hm.get("Billing_address_line1")).replace("  "," ");
        else if(!ThreeUKAddEnrollPage.hm.get("House_name").equalsIgnoreCase("") && !ThreeUKAddEnrollPage.hm.get("House_number").equalsIgnoreCase("")  && !ThreeUKAddEnrollPage.hm.get("Billing_address_line1").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("House_name")+" "+ThreeUKAddEnrollPage.hm.get("House_number")+" "+ThreeUKAddEnrollPage.hm.get("Billing_address_line1")).replace("  "," ");
        else if(!ThreeUKAddEnrollPage.hm.get("Flat_number").equalsIgnoreCase("")  && !ThreeUKAddEnrollPage.hm.get("House_name").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("Flat_number")+" "+ThreeUKAddEnrollPage.hm.get("House_name")).replace("  "," ");
        else if(!ThreeUKAddEnrollPage.hm.get("Flat_number").equalsIgnoreCase("")  && !ThreeUKAddEnrollPage.hm.get("House_number").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("Flat_number")+" "+ThreeUKAddEnrollPage.hm.get("House_number")).replace("  "," ");
        else if(!ThreeUKAddEnrollPage.hm.get("Flat_number").equalsIgnoreCase("")  && !ThreeUKAddEnrollPage.hm.get("Billing_address_line1").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("Flat_number")+" "+ThreeUKAddEnrollPage.hm.get("Billing_address_line1")).replace("  "," ");
        else if(!ThreeUKAddEnrollPage.hm.get("House_name").equalsIgnoreCase("")  && !ThreeUKAddEnrollPage.hm.get("House_number").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("House_name")+" "+ThreeUKAddEnrollPage.hm.get("House_number")).replace("  "," ");
        else if(!ThreeUKAddEnrollPage.hm.get("House_name").equalsIgnoreCase("")  && !ThreeUKAddEnrollPage.hm.get("Billing_address_line1").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("House_name")+" "+ThreeUKAddEnrollPage.hm.get("Billing_address_line1")).replace("  "," ");
        else if(!ThreeUKAddEnrollPage.hm.get("House_number").equalsIgnoreCase("")  && !ThreeUKAddEnrollPage.hm.get("Billing_address_line1").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("House_number")+" "+ThreeUKAddEnrollPage.hm.get("Billing_address_line1")).replace("  "," ");
        else if (!ThreeUKAddEnrollPage.hm.get("Flat_number").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("Flat_number"));
        else if (!ThreeUKAddEnrollPage.hm.get("House_number").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("House_number"));
        else if (!ThreeUKAddEnrollPage.hm.get("House_name").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("House_name"));
        else if (!ThreeUKAddEnrollPage.hm.get("Billing_address_line1").equalsIgnoreCase(""))
            addressLine1 = (ThreeUKAddEnrollPage.hm.get("Billing_address_line1"));
        Generic.verifyAddressInDALDB(Generic.getValuesFromGlobals("DAL_MDN"),"ADDRESSLINE1",addressLine1);
    }

    /**
     * This method is used to load the Web Properties file.
     * @param path
     * @return p
     * @author prabhat.das
     * @since 06/12/2017
     */
    public static Properties loadWebProperties(String path){
        Properties p = new Properties();
        try {
            File f = new File(path);
            FileReader fr = new FileReader(f);
            p.load(fr);
            fr.close();
            return p;
        }
        catch(Exception a){
            System.out.println("Something went wrong in Generic.loadWebProperties() method");
            a.printStackTrace();
        }
        finally{
            return p;
        }
    }

    /**
     * This method is used to wait
     * @param minutes to wait
     * @author Nandini Mujumdar
     * @since 07/07/2017
     */
    public static void waitForGivenMinute(int minute) throws InterruptedException{
        long curr = System.currentTimeMillis();
        int i=minute;
        while (true) {
            System.out.println("\nWaiting for " + i + " mins more...!!");
            Thread.sleep(60000);
            long temp = System.currentTimeMillis();
            if (temp - curr > 60 * 1000 * minute) {
                System.out.println("Given "+minute+" minutes are completed!!");
                break;
            }
            i--;
        }

    }
}
