package com.asurion.util;

import com.asurion.horizon.client.StageData;
import com.asurion.horizon.generic.ExcelReader;

import java.util.ArrayList;
import java.util.HashMap;

import static org.junit.Assert.assertTrue;

/**
 * Created by _sachinn.more on 1/6/2016.
 */
public class Asset {
    // declare
    public static String scenarioName = "";
    public static ArrayList<HashMap<String, String>> assetList = null;
    public static ArrayList<HashMap<String, String>> clientOfferData = null;

    public static void setClientOfferList() {
        String dataPath = "";
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("rogers") || ApplicationConfiguration.getClient().equalsIgnoreCase("Fido")) {
            dataPath = "Data/Rogers_client_offers.xlsx";
        } else {
            dataPath = "Data/Rogers_client_offers.xlsx";
        }

        StageData.setAssetData(dataPath);
        assetList = StageData.assetData.get(scenarioName);
    }

    public static void setClientOfferData() {

        clientOfferData = ExcelReader.getClientOfferData("Data/Client_Offer_Solution.xlsx", ApplicationConfiguration.getClient());
    }

    public static void setAssetList() {
        String dataPath = "";
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
            dataPath = "Data/TelcelAssetValidation.xlsx";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("claro peru")) {
            dataPath = "Data/ClaroPeruAssetValidation.xlsx";
        } else {
            dataPath = "Data/NorthAmericaAssetValidation.xlsx";
        }
        StageData.setAssetData(dataPath);
        assetList = StageData.assetData.get(scenarioName);
    }

    public static void getAsset(int rowIndex) {
        if (rowIndex + 1 > assetList.size()) {
            // driver.quit();
            assertTrue("NO MORE DATA ROWS AVAILBLE TO EXECUTE SCENARIO", false);
            // throw new Exception("NO MORE DATA ROWS AVAILBLE TO EXECUTE SCENARIO");
        }
        CustomerDetails.customerData = assetList.get(rowIndex);
    }

    public void getAssetData(int rowIndex)

    {
        if (rowIndex + 1 > CustomerDetails.clientAssetList.size()) {
            // driver.quit();
            assertTrue("NO MORE DATA ROWS AVAILBLE TO EXECUTE SCENARIO", false);
            // throw new Exception("NO MORE DATA ROWS AVAILBLE TO EXECUTE SCENARIO");
        }
        CustomerDetails.customerData = CustomerDetails.clientAssetList.get(rowIndex);

        if (CustomerDetails.customerData.get("DATASTAGGED").equalsIgnoreCase("NO")) {
            assertTrue("Asset Verification against DB is Failed", false);
        }
    }
}
