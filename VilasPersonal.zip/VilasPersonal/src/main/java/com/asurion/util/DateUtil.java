package com.asurion.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 
 * @author cwr.sachinn.more
 * 
 * This class contains methods to deal with date.
 *
 */
public class DateUtil {
	
	private static final String[] formats = { 
        "yyyy-MM-dd'T'HH:mm:ss'Z'",   "yyyy-MM-dd'T'HH:mm:ssZ",
        "yyyy-MM-dd'T'HH:mm:ss",      "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
        "yyyy-MM-dd'T'HH:mm:ss.SSSZ", "yyyy-MM-dd HH:mm:ss.SSS",
        "yyyy-MM-dd HH:mm:ss", 
        "MM/dd/yyyy HH:mm:ss",        "MM/dd/yyyy'T'HH:mm:ss.SSS'Z'", 
        "MM/dd/yyyy'T'HH:mm:ss.SSSZ", "MM/dd/yyyy'T'HH:mm:ss.SSS", 
        "MM/dd/yyyy'T'HH:mm:ssZ",     "MM/dd/yyyy'T'HH:mm:ss", 
        "yyyy:MM:dd HH:mm:ss",        "M/dd/yyyy", "yyyy-MM-dd", "yyyy/MM/dd", "yyyyMMdd", "MM/dd/yyyy", "dd/MM/yyyy"};
	
	/**
	 * This method is used to get the date in whatever format passed.
	     *
	     * @param sFormat
	     * @param date
	     * @return 
	     * 	Returns the date as a string
	 */
	public static String getFormattedDatetime(String sFormat, Date date){
		String sFormatted;
		SimpleDateFormat sdf = new SimpleDateFormat(sFormat);
		sFormatted = sdf.format(date);
		return sFormatted;
	}
	
	/**
	 * This method is used to get the date modified by adding days, months, years, etc.
	     *
	     * @param date
	     * @param sDatePart
	     * @param num
	     * @return 
	     * 	Returns the date
	 */
	public static Date getModifiedDateTime(String sDatePart, int num){
		Calendar cal = Calendar.getInstance();
		//cal.setTime(date);
		switch(sDatePart.toUpperCase()){
		case "DAY":
			cal.add(Calendar.DATE, num);
			return cal.getTime();
		case "MONTH":
			cal.add(Calendar.MONTH, num);
			return cal.getTime();
		case "YEAR":
			cal.add(Calendar.YEAR, num);
			return cal.getTime();
		case "HOUR":
			cal.add(Calendar.HOUR, num);
			return cal.getTime();
		case "MINUTE":
			cal.add(Calendar.MINUTE, num);
			return cal.getTime();
		case "SECOND":
			cal.add(Calendar.SECOND, num);
			return cal.getTime();
		default:
			return cal.getTime();
		}
	}
	
	/**
	 * This method is used to get the date format of date.
	 * @param date 
	 * 			String with date
	 * @return
	 * 		Returns format of date.
	 */
	 public static String parseDateFormat(String date) {
	        if (date != null) {
	            for (String parse : formats) {
	                SimpleDateFormat sdf = new SimpleDateFormat(parse);
	                try {
	                    sdf.parse(date);
	                    System.out.println("Printing the value of " + parse);
	                    return parse;
	                    
	                } catch (ParseException e) {

	                }
	            }
	        }
			return null;
	    }
	    
	 /**
	  * This method given date into format mm/dd/yyyy
	  * 
	  * @param date
	  * 		-Date string to format
	  * @param format
	  * 		-current date format
	  * @return
	  */
	 public static String forMatDate(String date,String format) 
		{		
		
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			DateFormat targetFormat = new SimpleDateFormat("MM/dd/yyyy");
			String expDate=null;
			try {
				Date ExpDate = sdf.parse(date);
				expDate=targetFormat.format(ExpDate);
				
			} 
			catch (ParseException e) {}
			
			return expDate;
		 	
		 	 
		}
	    
	    
	    /**This method will receive a string in format MM/dd/yyyy and return the
	     * 
	     *
	     * @param sDate
	     * @return date
	     */
	    public static Date getDateFormatObject(String sDate){
	    	DateFormat formatter =  null;
	    	Date date = null;
	    	formatter = new SimpleDateFormat("MM/dd/yyyy");
	    	try{
	    		date = formatter.parse(sDate);
	    	}catch(ParseException ex){
	    		ex.printStackTrace();
	    	}

	    	return date;	    	
	    }
}
