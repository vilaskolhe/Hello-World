package com.asurion.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/**
 * Created by NANDINI.MUJUMDAR on 6/19/2017.
 */
public class Debug {

    public static class EnrolmentStatus {
        public String Status;
        public Integer ExpectedExecutionTime;
    }



    public static EnrolmentStatus NewStatus(String status, int expectedExecutionTime) {
        EnrolmentStatus returnStatus = new EnrolmentStatus();
        returnStatus.Status = status;
        returnStatus.ExpectedExecutionTime = expectedExecutionTime;
        return returnStatus;
    }


    public static String GetClaimDebugInfo( ) throws Exception {
        String returnInfo = "\n\n";
        String correlationId = Generic.getValuesFromGlobals("CORRID");

        if (correlationId == null) {
            returnInfo = "correlationId IS NULL!";
            return returnInfo;
        }

        returnInfo +=  "\n-----------------------------------\n";
        returnInfo +=  " CLAIM DEBUG INFO\n";
        returnInfo += "  CORRID: " + correlationId + '\n';
        returnInfo +=  "-----------------------------------\n\n";

        correlationId = "IM" + correlationId;

        String kibanaUrl = null;
        if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa") ||
                ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqaeu")) {
            kibanaUrl = "http://lqasedhzkib003v.int.asurion.com:5601";
        }

        if (kibanaUrl != null) {
            String traceCorrelationUrl = kibanaUrl + "/app/kibana#/discover?_g=(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-12h,mode:quick,to:now))&_a=(columns:!(LogEntry.Timer1,LogEntry.ServiceEndpoint,LogMessage.LogInformation.LogCategorization.Operation),filters:!(('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'applog-*',key:environment,negate:!f,value:qa3),query:(match:(environment:(query:qa3,type:phrase)))),('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'applog-*',key:query,negate:!f,value:'(LogEntry.CorrelationID:"+ correlationId +")  OR LogMessage.Header.CorrelationId:" + correlationId + "'),query:(query_string:(analyze_wildcard:!t,query:'(LogEntry.CorrelationID:" + correlationId +")  OR LogMessage.Header.CorrelationId:" + correlationId + "')))),index:'applog-*',interval:auto,query:(query_string:(analyze_wildcard:!t,query:'*')),sort:!('@timestamp',desc),uiState:(spy:(mode:(fill:!f,name:!n))),vis:(aggs:!((params:(field:type,orderBy:'2',size:20),schema:segment,type:terms),(id:'2',schema:metric,type:count)),type:histogram))&indexPattern=applog-*&type=histogram";
            returnInfo += "  TRACE PERFORMANCE: " + traceCorrelationUrl + "\n\n";

            String traceDAXUrl = kibanaUrl + "/app/kibana?#/discover?_g=(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-7d,mode:quick,to:now))&_a=(columns:!(_source),filters:!(('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'applog-*',key:environment,negate:!f,value:qa3),query:(match:(environment:(query:qa3,type:phrase)))),('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'applog-*',key:LogEntry.ServiceName,negate:!t,value:AddressStandardizationManager),query:(match:(LogEntry.ServiceName:(query:AddressStandardizationManager,type:phrase)))),('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'applog-*',key:LogMessage.Header.ServiceName,negate:!t,value:AddressStandardizationManager),query:(match:(LogMessage.Header.ServiceName:(query:AddressStandardizationManager,type:phrase)))),('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'applog-*',key:query,negate:!f,value:'LogMessage.LogInformation.LogCategorization.ProcessIdentifier:*SoapHttpDispatcher* AND (LogEntry.CorrelationID:" + correlationId + "  OR LogMessage.Header.CorrelationId:" + correlationId + ")'),query:(query_string:(analyze_wildcard:!t,query:'LogMessage.LogInformation.LogCategorization.ProcessIdentifier:*SoapHttpDispatcher* AND (LogEntry.CorrelationID:" + correlationId + "  OR LogMessage.Header.CorrelationId:" + correlationId + ")')))),index:'applog-*',interval:auto,query:(query_string:(analyze_wildcard:!t,query:'*')),sort:!('@timestamp',desc),uiState:(spy:(mode:(fill:!f,name:!n))),vis:(aggs:!((params:(field:type,orderBy:'2',size:20),schema:segment,type:terms),(id:'2',schema:metric,type:count)),type:histogram))&indexPattern=applog-*&type=histogram";
            returnInfo += "  DAX REQUESTS/RESPONSES: " + traceDAXUrl + "\n\n";

            String traceErrorsUrl = kibanaUrl + "/app/kibana?#/discover?_g=(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-7d,mode:quick,to:now))&_a=(columns:!(_source),filters:!(('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'applog-*',key:environment,negate:!f,value:qa3),query:(match:(environment:(query:qa3,type:phrase)))),('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'applog-*',key:query,negate:!f,value:'(LogEntry.CorrelationID:e2851ce81f7e79beab045898b49aac78  OR LogMessage.Header.CorrelationId:" + correlationId + ") AND (LogEntry.ProcessResult:Error OR LogMessage.Header.Status:Failure)'),query:(query_string:(analyze_wildcard:!t,query:'(LogEntry.CorrelationID:" + correlationId + " OR LogMessage.Header.CorrelationId:" + correlationId + ") AND (LogEntry.ProcessResult:Error OR LogMessage.Header.Status:Failure)')))),index:'applog-*',interval:auto,query:(query_string:(analyze_wildcard:!t,query:'*')),sort:!('@timestamp',desc),uiState:(spy:(mode:(fill:!f,name:!n))),vis:(aggs:!((params:(field:type,orderBy:'2',size:20),schema:segment,type:terms),(id:'2',schema:metric,type:count)),type:histogram))&indexPattern=applog-*&type=histogram";
            returnInfo += "  ERRORS: " + traceErrorsUrl + "\n\n";
        }


        return returnInfo;
    }

    public static String GetEnrolmentDebugInfoFromScheduleJobId( String jobScheduleId) throws Exception {
        String returnInfo = "\n\n";
        returnInfo +=  "-----------------------------------\n";
        returnInfo +=  " ENROLMENT DEBUG INFO\n";
        returnInfo +=  "-----------------------------------\n\n";


        if (jobScheduleId == null) {
            returnInfo = "jobScheduleId IS NULL!";
            return returnInfo;
        }


        String check1Sql = "SELECT * FROM ENRCONFIG.SCHEDULEDJOBS WHERE ID = '{jobScheduleId}'";
        String check2Sql = "SELECT * FROM ENRSTAGING.SCHEDULEDJOBINSTANCE WHERE JOBSCHEDULEID = '{jobScheduleId}'";
        String check3Sql = "SELECT * FROM ENRSTAGING.FILESTATUSHANDLER WHERE JOBSCHEDULEID = '{jobScheduleId}' ORDER BY FILESTATUSHANDLER.CREATIONDATE ASC" ;
        String check4Sql = " SELECT * FROM ENRSTAGING.ENROLLMENTSTATUS WHERE ENROLLMENTID = '{enrollmentId}' AND (STATUS = 'EnrollmentComplete'  )" ;
        String check5Sql = " SELECT * FROM ENRSTAGING.ENROLLMENTSTATUS WHERE ENROLLMENTID = '{enrollmentId}'  ORDER BY ENROLLMENTSTATUS.LASTUPDATEDATE ASC" ;

        check1Sql = check1Sql.replace("{jobScheduleId}", jobScheduleId);
        check2Sql = check2Sql.replace("{jobScheduleId}", jobScheduleId);
        check3Sql = check3Sql.replace("{jobScheduleId}", jobScheduleId);


        returnInfo +=  "-----------------------------------\n";
        returnInfo +=  " ENROLMENT DEBUG INFO\n";
        returnInfo +=  "-----------------------------------\n\n";
        returnInfo +=  " STEP 1: Schedule job for execution \n";
        returnInfo +=  " SQL: " + check1Sql + '\n';

        ArrayList<HashMap<String, String>> results  = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"),  check1Sql);
        Boolean foundScheduledJob = false;
        Boolean foundDupScheduledJob = false;
        Date scheduledJobCreationDate = new Date();
        String scheduledJobStatus = "";
        String scheduledJobOperationStatus = "";
        String scheduledJobRemarks = "";

        if (results.size() == 1) {
            foundScheduledJob = true;
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            df.setTimeZone(TimeZone.getTimeZone("GMT"));
            scheduledJobCreationDate = df.parse(results.get(0).get("CREATIONDATE"));

            scheduledJobStatus = results.get(0).get("STATUS");
            scheduledJobOperationStatus = results.get(0).get("OPERATIONSTATUS");
            scheduledJobRemarks = results.get(0).get("REMARKS");


        } else if (results.size() > 2) {
            foundDupScheduledJob = true;
        }
        else {

        }

        if (foundDupScheduledJob)
        {
            returnInfo +=  " Found multiple SCHEDULEDJOBS records with same Id!" + '\n';
            returnInfo +=  "  Check 1: Have their been recent changes to ENRSTAGING.SCHEDULEDJOBINSTANCE table structure?"    + '\n';
        }
        else
        {
            returnInfo +=  " Found ScheduleJobs record " + jobScheduleId + ": " + (foundScheduledJob ? "[YES]" : "[NO - Follow troubleshooting checks]") + '\n';
            if (!foundScheduledJob)
            {
                returnInfo +=  "  Check 1: Is there a previous record in ENRSTAGING.SCHEDULEDJOBINSTANCE with same jobid?"    + '\n';
                returnInfo +=  "  Check 2: Is the Job Scheduler process running (MidnightPoller.Timer.process)?"    + '\n';
                returnInfo +=  "  Check 3: Did the midnight poller create records that interfered with our tests?"    + '\n';
            }
            else
            {
                returnInfo +=  "  CreationDate : " + scheduledJobCreationDate.toString() + '\n';
                returnInfo +=  "  Status : " + scheduledJobStatus + " (Expected: JOBCOMPLETED)\n";
                returnInfo +=  "  OperationStatus : " + scheduledJobOperationStatus + '\n';
            }

            if (scheduledJobStatus.equalsIgnoreCase("JOBCOMPLETED") &&
                    scheduledJobOperationStatus.equalsIgnoreCase("ENROLLMENTCOMPLETED")) {
                returnInfo +=  "  Scheduled Job Record looks healthy. " + '\n';
            } else {
                returnInfo +=  "  Scheduled Job Record did not go into JOBCOMPLETED after " + ApplicationConfiguration.getEnrollmentMaxWaitTime() + "s\n";
                returnInfo +=  "  Explanation for status follows:\n\n";
            }

            if (scheduledJobStatus.equalsIgnoreCase("JOBEXPIRED")) {
                returnInfo +=  "  JOBEXPIRED = the enrolment process aborted most likely because due to a file-access related issue" + '\n';
                returnInfo +=  "  Check 1: Does ScheduleJob's SOURCE, DESTINATION and ARCHIVE fields all have values?" + '\n';
                returnInfo +=  "  Check 2: Do the values point to paths that exist?" + '\n';
                returnInfo +=  "  Check 3: Are the files in the expected location? " + '\n';
                returnInfo +=  "  Check 4: Is something deleting the files?" + '\n';
                returnInfo +=  "  Check 5: Do BW servers have access to the mounted storage. Review the REMARKS below" + '\n';
                returnInfo += "   Review the REMARKS below: " + '\n';;
                returnInfo += scheduledJobRemarks  + '\n';
            }
            else if (scheduledJobStatus.equalsIgnoreCase("JOBCREATED")) {
                returnInfo +=  "  JOBCREATED = a freshly created, untouched  record that was never picked up by the Job Publisher" + '\n';
                returnInfo +=  "  Check 1: Are the Job Publisher and Enrollment Handler processes up and running?" + '\n';
                returnInfo +=  "  Check 2: Was this record created very close to midnight? This may cause jobs be postponed by 24h." + '\n';
                returnInfo += "   Review the REMARKS below: " + '\n';
                returnInfo += scheduledJobRemarks  + '\n';
            }
            else if (scheduledJobStatus.equalsIgnoreCase("JOBPUBLISHED")) {
                returnInfo +=  "  JOBPUBLISHED = The Job Publisher picked up the job and kicked off the chain of events (although it's not yet complete)" + '\n';
                returnInfo +=  "  Check 1: Review step 3 in this report to see exactly how far it got and where it failed" + '\n';
                returnInfo +=  "  Check 2: Jobs may get stuck if Enrolment Handler, Enrolment Orchestrator, Process Enrollment and Account Handler processes are not up" + '\n';
                returnInfo +=  "  Check 3: Consider increasing the timeout for very large files which may need more time to execute" + '\n';
                returnInfo +=  "  Check 4: Various folders used within enrollment may get filled up if they aren't cleared out, causing slow access to those paths, forcing the enrolment to take longer and appearing to get stuck." + '\n';
                returnInfo += "   Review the REMARKS below: " + '\n';
                returnInfo += scheduledJobRemarks  + '\n';
            }


            returnInfo += "\n\n" + " STEP 2: START ENROLMENT AND GET ENROLMENTID \n";
            returnInfo += " SQL: " + check2Sql + '\n';

            ArrayList<HashMap<String, String>> results2 = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), check2Sql);

            Boolean foundScheduledJobInstance = false;
            Boolean foundDupScheduledJobInstance = false;
            Date scheduledJobInstanceCreationDate = new Date();
            String scheduledJobInstanceJobTypeId = "";
            String scheduledJobInstanceRemarks = "";
            String scheduledJobInstanceProcessStatus = "";

            if (results2.size() == 1) {
                foundScheduledJobInstance = true;
                //DateFormat df = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SSSSSSSSS");
                DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                df.setTimeZone(TimeZone.getTimeZone("GMT"));
                scheduledJobInstanceCreationDate = df.parse(results2.get(0).get("CREATIONDATE"));
                scheduledJobInstanceJobTypeId = results2.get(0).get("JOBTYPEID");
                scheduledJobInstanceRemarks = results2.get(0).get("REMARKS");
                scheduledJobInstanceProcessStatus = results2.get(0).get("PROCESSSTATUS");

            } else if (results2.size() > 2) {
                foundDupScheduledJobInstance = true;
            }

            if (foundDupScheduledJobInstance) {
                returnInfo += " Found multiple SCHEDULEDJOBINSTANCE records with same Id!" + '\n';
                returnInfo += "  Check 1: This should never happen and likely a bug in the tibco code that picks up the job. See REMARKS:" + '\n';
                returnInfo += scheduledJobInstanceRemarks;
            } else {
                returnInfo += " Found ScheduleJobInstance record " + jobScheduleId + ": " + (foundScheduledJobInstance ? "[YES]" : "[NO]") + '\n';

                if (!foundScheduledJobInstance) {
                    returnInfo += "  NOTE: ScheduleJobInstance record is only created after EnrollmentHandler has completed (after the files have been picked up)." + '\n';
                    returnInfo += "  Check 1: Did the job ever start processing?" + '\n';
                    returnInfo += "  Check 2: Was the job scheduled to run very close to midnight?" + '\n';
                    returnInfo += "  Check 3: Is the Job Publisher and Enrollment Handler process running?" + '\n';
                } else {
                    returnInfo += "  CreationDate : " + scheduledJobInstanceCreationDate.toString() + '\n';
                    returnInfo += "  JobTypeId (aka EnrolmmentId) : " + scheduledJobInstanceJobTypeId + '\n';
                    returnInfo += "  Status : " + scheduledJobInstanceProcessStatus + '\n';



                    if (scheduledJobInstanceProcessStatus.equalsIgnoreCase("EnrollmentComplete")) {
                        returnInfo += "  Scheduled Job Instance Record looks healthy. " + '\n';
                    } else {
                        returnInfo += "  PROCESSSTATUS != EnrollmentComplete, means job got picked up but failed during processing" + '\n';
                        returnInfo += "  Check 1: Review step 3 in this report to see exactly how far it got and where it failed" + '\n';
                        returnInfo += "  See REMARKS:" + '\n';
                        returnInfo += scheduledJobInstanceRemarks;
                    }
                }
            }



            returnInfo +=  "\n\n" + " STEP 3: COPY FILES FROM INBOUND PATH TO BW SERVERS \n";
            returnInfo +=  " SQL: " + check3Sql + '\n';
            ArrayList<HashMap<String, String>> results3  = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"),  check3Sql);


            if (results3.size() > 0) {
                Date firstPickup = null;
                for (int i = 0; i < results3.size(); i++)
                {
                    Date prevEnrolmentStatusDate;
                    Long stepDurationInSeconds;

                    DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    //df.setTimeZone(TimeZone.getTimeZone("GMT"));
                    Date fileStatusHandlerCreationDate = df.parse(results3.get(i).get("CREATIONDATE"));
                    if (i > 0) {
                        prevEnrolmentStatusDate =  df.parse(results3.get(i - 1).get("CREATIONDATE"));
                        stepDurationInSeconds = TimeUnit.MILLISECONDS.toSeconds(fileStatusHandlerCreationDate.getTime() - prevEnrolmentStatusDate.getTime());
                    } else {
                        firstPickup = fileStatusHandlerCreationDate;
                        stepDurationInSeconds = TimeUnit.MILLISECONDS.toSeconds(fileStatusHandlerCreationDate.getTime() - scheduledJobInstanceCreationDate.getTime());
                    }

                    String fileStatusHandlerFilename = results3.get(i).get("FILENAME");
                    String fileStatusHandlerStatus = results3.get(i).get("STATUS");
                    String fileStatusHandlerRemarks = results3.get(i).get("REMARKS");

                    returnInfo += fileStatusHandlerCreationDate + " " + fileStatusHandlerFilename + " - " + fileStatusHandlerStatus  + " - " + stepDurationInSeconds + "s ";

                    if (fileStatusHandlerStatus.equalsIgnoreCase("OperationCompleted")) {
                        returnInfo += (stepDurationInSeconds < 5) ? " [OK] " : "[FILE COPY TOOK > 10s]";
                    }
                    else if (fileStatusHandlerStatus.equalsIgnoreCase("OperationStarted")) {
                        returnInfo += (stepDurationInSeconds < 5) ? " [OK] " : "[FILE COPY TOOK > 2s]";
                    }

                    returnInfo += "\n";

                }

                long durationInSeconds = TimeUnit.MILLISECONDS.toSeconds(firstPickup.getTime() - scheduledJobInstanceCreationDate.getTime());
                String pickupTimeWarning = "";
                if (durationInSeconds > 60) {
                    pickupTimeWarning = " (WARNING: File movement took more than 60s which is unusually high, should be < 60s)";
                }

                returnInfo += "  Pickup Time : " + durationInSeconds + "s" + pickupTimeWarning + "\n";
            }

            int expectedFilterStatusHandlerRecs =  2;
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("kpn")) {
                expectedFilterStatusHandlerRecs = 4;
            }

            if (results3.size() < expectedFilterStatusHandlerRecs) {
                returnInfo += "Less than 4 records found in FILESTATUSHANDLER - This means the file copy did not complete! ";
            }
            else {

                if (foundScheduledJobInstance && !foundDupScheduledJobInstance) {
                    // Step 4
                    // SELECT * FROM ENRSTAGING.ENROLLMENTSTATUS WHERE ENROLLMENTID = '201702021104493742010'; --JOBID = 2010
                    Date enrolmentStatusDate = new Date();
                    Date prevEnrolmentStatusDate = new Date();
                    String enrolmentStatusStatus = "";
                    String enrolmentStatusRemarks = "";
                    long stepDurationInSeconds = 0;

                    // these averages were taken from 3 months of data on QA03
                    final ArrayList<EnrolmentStatus> ExpectedStatus = new ArrayList<EnrolmentStatus>();
                    ExpectedStatus.add(NewStatus("EnrollmentHandlerStarted", 2));
                    ExpectedStatus.add(NewStatus("EnrollmentHandlerCompleted", 2));
                    ExpectedStatus.add(NewStatus("PreElegibiligyCheckCompleted", 2));
                    ExpectedStatus.add(NewStatus("FileRecordsCheckCompleted", 2));
                    ExpectedStatus.add(NewStatus("LoadFileToPreInterfaceInitiated", 2));
                    ExpectedStatus.add(NewStatus("LoadFileToPreInterfaceCompleted", 5));
                    ExpectedStatus.add(NewStatus("EnrichPreInterfaceDataCompleted", 13));
                    ExpectedStatus.add(NewStatus("ApplyPostEnrichRulesCompleted", 14));
                    ExpectedStatus.add(NewStatus("LoadPreInterfaceToInterfaceCompleted", 8));
                    ExpectedStatus.add(NewStatus("EnrollmentPublisherInitiated", 2));
                    ExpectedStatus.add(NewStatus("PublishAccountListInitiated", 0));
                    ExpectedStatus.add(NewStatus("PublishAccountListCompleted", 0));
                    ExpectedStatus.add(NewStatus("EnrollmentPublisherCompleted", 0));
                    ExpectedStatus.add(NewStatus("EnrollmentComplete", 30));


                    check4Sql = check4Sql.replace("{enrollmentId}", scheduledJobInstanceJobTypeId);
                    int attempts = 0;
                    while (attempts < 300) {
                        Thread.sleep(1000);
                        attempts++;

                        if (attempts % 10 == 0) {
                            System.out.println("Waiting for Enrollment to complete.. " + attempts + "s");

                            ArrayList<HashMap<String, String>> results4 = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), check4Sql);
                            if (results4.size() == 1) {
                                break;
                            }

                        }


                    }


                    check5Sql = check5Sql.replace("{enrollmentId}", scheduledJobInstanceJobTypeId);
                    returnInfo += "\n\n" + " STEP 4: STAGING AND DAL PROCESSING \n";
                    returnInfo += " SQL: " + check5Sql + '\n';
                    ArrayList<HashMap<String, String>> results5 = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "ENROLLMENT"), check5Sql);
                    for (int i = 0; i < results5.size(); i++) {
                        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        df.setTimeZone(TimeZone.getTimeZone("GMT"));
                        enrolmentStatusDate = df.parse(results5.get(i).get("LASTUPDATEDATE"));
                        if (i > 0) {
                            prevEnrolmentStatusDate = df.parse(results5.get(i - 1).get("LASTUPDATEDATE"));
                            stepDurationInSeconds = TimeUnit.MILLISECONDS.toSeconds(enrolmentStatusDate.getTime() - prevEnrolmentStatusDate.getTime());
                        }

                        enrolmentStatusStatus = results5.get(i).get("STATUS");
                        enrolmentStatusRemarks = results5.get(i).get("REMARKS");

                        if (i < ExpectedStatus.size()) {
                            if (ExpectedStatus.get(i).Status.equalsIgnoreCase(enrolmentStatusStatus)) {
                                returnInfo += "  " + enrolmentStatusStatus + " " + stepDurationInSeconds + "s ";

                                returnInfo += stepDurationInSeconds <= ExpectedStatus.get(i).ExpectedExecutionTime ? " [OK] " : "[Slower than expected " + ExpectedStatus.get(i).ExpectedExecutionTime + "s]";
                                returnInfo += "\n";
                            } else {
                                returnInfo += "  UNEXPECTED: " + enrolmentStatusStatus + " " + stepDurationInSeconds + "s ";
                                returnInfo += "\n" + enrolmentStatusRemarks;
                                returnInfo += "\n";
                            }
                        }
                    }
                }
            }

        }




        //returnInfo +=  " CHECK 2: " + check2Sql;
        //returnInfo +=  " CHECK 3: " + check3Sql;



        return returnInfo;
    }



}
