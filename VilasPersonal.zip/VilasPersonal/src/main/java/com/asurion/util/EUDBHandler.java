package com.asurion.util;


import com.asurion.horizon.generic.SetUp;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by jitendra.k.tiwary on 2/16/2016.
 */
public class EUDBHandler{

    // Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)//
    static Connection conn = null;
    public EUDBHandler() {
    }


    public static Connection getDBConnection(String environment, String dbName) throws SQLException, ClassNotFoundException {
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());

        try {

            Service user = mapper.readValue(new File("configuration.yaml"), Service.class);
            Map<String,String> map1 = user.getHorizonqa();
            if (environment.equalsIgnoreCase("horizonqa")) {
                map1 = user.getHorizonqa();
            } else if (environment.equalsIgnoreCase("horizondevint")) {
                map1 = user.getHorizondevint();
            } else if (environment.equalsIgnoreCase("horizondevlab")) {
                map1 = user.getHorizondevlab();
            } else if (environment.equalsIgnoreCase("horizonprod")) {
                map1 = user.getHorizonprod();
            } else if (environment.equalsIgnoreCase("horizonqaeu")) {
                map1 = user.getHorizonqaeu();
            } else if (environment.equalsIgnoreCase("horizonprodeu")) {
                map1 = user.getHorizonprodeu();
            } else if (environment.equalsIgnoreCase("horizondevinteu")) {
                map1 = user.getHorizondevinteu();
            } else if (environment.equalsIgnoreCase("horizonqa02")) {
                map1 = user.getHorizondevinteu();
            }

            Properties connectionProps = new Properties();
            String connection = null;

            if (dbName.equalsIgnoreCase("ENROLLMENT")) {
                connectionProps.put("user", map1.get("enrollmentdbusername"));
                connectionProps.put("password", map1.get("enrollmentdbpassword"));
                System.out.println("map1.get enrollmentdbusername: " + map1.get("enrollmentdbusername"));
                System.out.println("map1.get enrollmentdbpassword: " + map1.get("enrollmentdbpassword"));
                System.out.println("map1.get enrollmentdbhostname: " + (String) map1.get("enrollmentdbhostname"));
                connection = "jdbc:oracle:thin:@//" + (String) map1.get("enrollmentdbhostname") + ":" + (String) map1.get("enrollmentdbhostport") + "/" + (String) map1.get("enrollmentdbhostservicename");
            } else if (dbName.equalsIgnoreCase("DAL")) {
                connectionProps.put("user", map1.get("daldbusername"));
                connectionProps.put("password", map1.get("daldbpassword"));
                connection = "jdbc:oracle:thin:@//" + (String) map1.get("daldbhostname") + ":" + (String) map1.get("daldbhostport") + "/" + (String) map1.get("daldbhostservicename");
            }
            if (dbName.equalsIgnoreCase("RISK")) {
                connectionProps.put("user", map1.get("blokusdbusername"));
                connectionProps.put("password", map1.get("blokusdbpassword"));
                connection = "jdbc:oracle:thin:@//" + (String) map1.get("blokusdbhostname") + ":" + (String) map1.get("blokusdbhostport") + "/" + (String) map1.get("blokusdbhostservicename");
            }

            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection(connection, connectionProps);
            return conn;

        } catch (Exception var6) {
            var6.printStackTrace();
            return null;
        }

//        HashMap config = SetUp.getConfig();
//
//        Properties connectionProps = new Properties();
//        String connection = null;
//        if (environment.equalsIgnoreCase("horizonqa")) {
//            if (dbName.equalsIgnoreCase("ENROLLMENT")) {
//                connectionProps.put("user", config.get("QADBUSERNAME"));
//                connectionProps.put("password", config.get("QADBPASSWORD"));
//                connection = "jdbc:oracle:thin:@//" + (String) config.get("QADBHOSTNAME") + ":" + (String) config.get("QADBHOSTPORT") + "/" + (String) config.get("QADBHOSTSERVICENAME");
//            } else if (dbName.equalsIgnoreCase("DAL")) {
//                connectionProps.put("user", config.get("DALQAUSERNAME"));
//                connectionProps.put("password", config.get("DALQADBPASSWORD"));
//                connection = "jdbc:oracle:thin:@//" + (String) config.get("DALQADBHOSTNAME") + ":" + (String) config.get("DALQADBHOSTPORT") + "/" + (String) config.get("DALQADBHOSTSERVICENAME");
//            }
//            if (dbName.equalsIgnoreCase("RISK")) {
//                connectionProps.put("user", config.get("QABLOKUSDBUSERNAME"));
//                connectionProps.put("password", config.get("QABLOKUSDBPASSWORD"));
//                connection = "jdbc:oracle:thin:@//" + (String) config.get("QABLOKUSDBHOSTNAME") + ":" + (String) config.get("QABLOKUSDBHOSTPORT") + "/" + (String) config.get("QABLOKUSDBHOSTSERVICENAME");
//            }
//        } else if (environment.equalsIgnoreCase("horizondevint")) {
//            connectionProps.put("user", config.get("DEVINTDBUSERNAME"));
//            connectionProps.put("password", config.get("DEVINTDBPASSWORD"));
//            connection = "jdbc:oracle:thin:@//" + (String) config.get("DEVINTDBHOSTNAME") + ":" + (String) config.get("DEVINTDBHOSTPORT") + "/" + (String) config.get("DEVINTDBHOSTSERVICENAME");
//        } else if (environment.equalsIgnoreCase("horizondevlab")) {
//            connectionProps.put("user", config.get("DEVLABUSERNAME"));
//            connectionProps.put("password", config.get("DEVLABPASSWORD"));
//            connection = "jdbc:oracle:thin:@" + (String) config.get("DEVLABDBHOSTNAME") + ":" + (String) config.get("DEVLABPORT") + ":" + (String) config.get("DEVLABSID");
//        } else if (environment.equalsIgnoreCase("horizonprod")) {
//            if (dbName.equalsIgnoreCase("ENROLLMENT")) {
//                connectionProps.put("user", config.get("EnrollmentPRODUSERNAME"));
//                connectionProps.put("password", config.get("EnrollmentPRODPASSWORD"));
//                connection = "jdbc:oracle:thin:@//" + (String) config.get("EnrollmentPRODHOSTNAME") + ":" + (String) config.get("EnrollmentPRODHOSPORT") + "/" + (String) config.get("EnrollmentPRODSERVICENAME");
//            } else if (dbName.equalsIgnoreCase("DAL")) {
//                connectionProps.put("user", config.get("DALPRODUSERNAME"));
//                connectionProps.put("password", config.get("DALPRODPASSWORD"));
//                connection = "jdbc:oracle:thin:@//" + (String) config.get("DALPRODHOSTNAME") + ":" + (String) config.get("DALPRODHOSPORT") + "/" + (String) config.get("DALPRODSERVICENAME");
//            }
//        } else if (environment.equalsIgnoreCase("horizonqaeu")) {
//            if (dbName.equalsIgnoreCase("ENROLLMENT")) {
//                connectionProps.put("user", config.get("DALEUQAUSERNAME"));
//                connectionProps.put("password", config.get("DALEUQAPASSWORD"));
//                connection = "jdbc:oracle:thin:@//" + (String) config.get("DALEUQAHOSTNAME") + ":" + (String) config.get("DALEUQAHOSPORT") + "/" + (String) config.get("DALEUQASERVICENAME");
//            } else if (dbName.equalsIgnoreCase("DAL")) {
//                connectionProps.put("user", config.get("DALEUQAUSERNAME"));
//                connectionProps.put("password", config.get("DALEUQAPASSWORD"));
//                connection = "jdbc:oracle:thin:@//" + (String) config.get("DALEUQAHOSTNAME") + ":" + (String) config.get("DALEUQAHOSPORT") + "/" + (String) config.get("DALEUQASERVICENAME");
//            }
//        } else if (environment.equalsIgnoreCase("horizonprodeu")) {
//            if (dbName.equalsIgnoreCase("DAL")) {
//                connectionProps.put("user", config.get("DALEUPRODUSERNAME"));
//                connectionProps.put("password", config.get("DALEUPRODPASSWORD"));
//                connection = "jdbc:oracle:thin:@//" + (String) config.get("DALEUPRODHOSTNAME") + ":" + (String) config.get("DALEUPRODHOSPORT") + "/" + (String) config.get("DALEUPRODSERVICENAME");
//            }
//        } else if (environment.equalsIgnoreCase("horizondevinteu")) {
//            if (dbName.equalsIgnoreCase("ENROLLMENT")) {
//                connectionProps.put("user", config.get("DALDEVINTUSERNAME"));
//                connectionProps.put("password", config.get("DALDEVINTDBPASSWORD"));
//                connection = "jdbc:oracle:thin:@//" + (String) config.get("DALDEVINTDBHOSTNAME") + ":" + (String) config.get("DALDEVINTDBHOSTPORT") + "/" + (String) config.get("DALDEVINTDBHOSTSERVICENAME");
//            } else if (dbName.equalsIgnoreCase("DAL")) {
//                connectionProps.put("user", config.get("DALDEVINTUSERNAME"));
//                connectionProps.put("password", config.get("DALDEVINTDBPASSWORD"));
//                connection = "jdbc:oracle:thin:@//" + (String) config.get("DALDEVINTDBHOSTNAME") + ":" + (String) config.get("DALDEVINTDBHOSTPORT") + "/" + (String) config.get("DALDEVINTDBHOSTSERVICENAME");
//            }
//        }
//        try {
//            Class.forName("oracle.jdbc.OracleDriver");
//            conn = DriverManager.getConnection(connection, connectionProps);
//            return conn;
//        } catch (Exception var6) {
//            var6.printStackTrace();
//            return null;
//        }
    }

    public static int  executeSQLInsertQuery(Connection conn, String sQuery) {
        Integer insertedRecords = null;
        Statement stmtQuery = null;


        try {
            stmtQuery = conn.prepareStatement(sQuery);
            stmtQuery.setQueryTimeout(630);
            insertedRecords = stmtQuery.executeUpdate(sQuery);

            stmtQuery.close();
            conn.close();
        } catch (SQLException var12) {
            if (!var12.getMessage().toUpperCase().equals("ORA-00900: INVALID SQL STATEMENT\n")) {
                var12.printStackTrace();
            }
        }
        if (insertedRecords == null) { return 0; }
        return insertedRecords;
    }

    public static ArrayList<HashMap<String, String>> executeSQLQuery(Connection conn, String sQuery) {
        ResultSet rSet = null;
        Object connServer = null;
        Statement stmtQuery = null;
        ArrayList aRowsList = new ArrayList();
        HashMap hRow = null;
        try {
            stmtQuery = conn.createStatement();
            stmtQuery.setQueryTimeout(630);
            rSet = stmtQuery.executeQuery(sQuery);
            if (rSet.equals((Object) null)) {
                return aRowsList;
            }
            ResultSetMetaData e = rSet.getMetaData();
            int iColumns = e.getColumnCount();
            while (rSet.next()) {
                hRow = new HashMap();
                for (int index = 1; index <= iColumns; ++index) {
                    String formattedDecimal = "";
                    String result = rSet.getString(index);
                    if (result != null && result.contains(".") && result.substring(result.length() - 2).contains("00")) {
                        if (result.substring(result.indexOf(".") + 3).equals("00")) {
                            formattedDecimal = result.substring(0, result.indexOf(".") + 3);
                            hRow.put(e.getColumnName(index).toUpperCase(), formattedDecimal);
                        } else {
                            hRow.put(e.getColumnName(index).toUpperCase(), rSet.getString(index));
                        }
                    } else {
                        hRow.put(e.getColumnName(index).toUpperCase(), rSet.getString(index));
                    }
                }
                aRowsList.add(hRow);
            }
            rSet.close();
            stmtQuery.close();
            conn.close();
        } catch (SQLException var12) {
            if (!var12.getMessage().toUpperCase().equals("ORA-00900: INVALID SQL STATEMENT\n")) {
                var12.printStackTrace();
            }
        }
        return aRowsList;
    }

}


