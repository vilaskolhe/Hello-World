package com.asurion.util;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by NANDINI.MUJUMDAR on 3/1/2017.
 */
public class ScenarioNameGetter {
    public static void getScenarioNamesList() throws Throwable {
        System.out.println("program started");
        List<String> defaultArguments = new LinkedList<String>();
        defaultArguments.add("--plugin");
        defaultArguments.add("html:target/report/not-to-use");
        defaultArguments.add("--glue");
        defaultArguments.add("runner");
        defaultArguments.add("src/test/resources/features");
        List<String> allArguments = new LinkedList<String>();
        allArguments.addAll(defaultArguments);
        allArguments.addAll(getJenkinsTagList());
        // printList(allArguments);
        //String configArray[] = {"--plugin", "html:target/report/not-to-use", "resources/features", "--tags", "@E2ETesting", "--glue", "com.asurion.qa.steps", "--tags", "@nTelos",};
        String allArgsArray[] = new String[allArguments.size()];
        for (int i = 0; i < allArguments.size(); i++) {
            allArgsArray[i] = allArguments.get(i);
        }

        try {
            CucumberCliMain.main(allArgsArray);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("PROGRAM END, This should print :)");
    }

    private static List<String> getJenkinsTagList() {
        List<String> list = new LinkedList<>();
        String args = System.getProperty("cucumber.options");
       // String args = "--tags @nTelos_CRE_DED_E2E,@nTelos_DEDRefund_CreditCard";
        System.out.println("cucumber options =" + args);
        String tags[] = args.split("--tags");
        System.out.println("split array size=" + tags.length);
        for (String tag : tags) {
            if (tag != null && !tag.trim().isEmpty()) {
                list.add("--tags ");
                list.add(tag.trim());
            }
        }
        printList(list);
        return list;
    }

    private static void printList(List<String> list) {
        for (String item : list) {
            System.out.println(item);
        }
    }
}
