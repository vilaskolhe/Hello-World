//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.asurion.common.core.util;

public class CommonUtilities {
    public CommonUtilities() {
    }

    public static void waitTime(int seconds) {
        try {
            Thread.sleep((long)(seconds * 1000));
        } catch (InterruptedException var2) {
            ;
        }

    }
}
