//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.asurion.common.core.driver;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.util.ApplicationConfiguration;
import cucumber.api.Scenario;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHttpEntityEnclosingRequest;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.HttpCommandExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import net.sourceforge.htmlunit.corejs.javascript.JavaScriptException;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;

import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.*;


import java.io.*;

public class TestDriver {
    private static String GRID_HUB;
    private static final String LOCAL_DIRECTORY_SOURCE = "C:\\Windows\\System32";
    protected static TestDriver driver = null;
    static int timeOut = 150;
    private static WebDriver webDriver = null;
    private String browserName;
    private String runType;
    private String browserVersion;
    public static String originalWindowHandle = null;
    public static String filename = System.getProperty("C:\\Intent.xlsx" +
            ".dir")+"\\src\\test\\resources\\data\\StagingData.xlsx";
    public  String path=filename;
    public FileInputStream fis = null;
    public FileOutputStream fileOut =null;
    private XSSFWorkbook workbook = null;
    private XSSFSheet sheet = null;
    private XSSFRow row   =null;
    private XSSFCell cell = null;
    private static String pageName = null;

    protected TestDriver(String browser, String runType, String version) {
        System.out.println("Initializing the web driver... ");
        webDriver = createDriver(browser, runType, version);
        this.browserName = browser;
        this.runType = runType;
        this.browserVersion = version;
    }

    public static void setPageName(String pageName) {
        TestDriver.pageName = pageName;
    }

    public static String getPageName() {
        return pageName;
    }

    protected String getBrowserName() {
        return this.browserName;
    }

    protected String getRunType() {
        return this.runType;
    }

    protected String getBrowserVersion() {
        return this.browserVersion;
    }

    public static TestDriver getDriver(String browser, String runType, String version) {
        if (driver == null) {
            driver = new TestDriver(browser, runType, version);
        }

        return driver;
    }

    public static WebDriver getWebDriver() {
        return webDriver;
    }

    private static WebDriver createDriver(String browser, String runType, String version) {
        WebDriver webDriver = null;
        setGridHub(runType);
        DesiredCapabilities desiredCap;

        switch (browser.toLowerCase()) {
            case "chrome":
                desiredCap = DesiredCapabilities.chrome();
//                ChromeOptions options1 = new ChromeOptions();
//                options1.addArguments(new String[]{"--test-type"});
//                options1.addArguments(new String[]{"--disable-extensions"});
//                desiredCap.setCapability("chromeOptions", options1);
                if (!runType.equalsIgnoreCase("grid") && !runType.equalsIgnoreCase("spoon") && !runType.equalsIgnoreCase("horizongrid") && !runType.equalsIgnoreCase("LATAMGRID") && !runType.equalsIgnoreCase("horizonwebgrid") && !runType.equalsIgnoreCase("euhorizongrid") && !runType.equalsIgnoreCase("horizonprod") && !runType.equalsIgnoreCase("PROD-GRID") && !runType.equalsIgnoreCase("SBGRID")) {
                    System.setProperty("webdriver.chrome.driver", "C:\\Windows\\System32\\chromedriver.exe");
                    desiredCap.setCapability("chrome.binary", "C:\\Windows\\System32\\chromedriver.exe");
                    webDriver = new ChromeDriver(desiredCap);
                } else {
                    desiredCap.setVersion(version);
                    webDriver = getRemoteWebDriver(desiredCap);
                }

                break;
            case "safari":
                webDriver = new SafariDriver();

                break;
            case "android":
                DesiredCapabilities capabilities1 = new DesiredCapabilities();
                capabilities1.setCapability("deviceName", "6485d8c4");
                capabilities1.setCapability("browserName", "Chrome");
                capabilities1.setCapability("version", "48");
                capabilities1.setCapability("platformName", "Android");
                if (!runType.equalsIgnoreCase("grid") && !runType.equalsIgnoreCase("spoon") && !runType.equalsIgnoreCase("android") && !runType.equalsIgnoreCase("horizonwebgrid") && !runType.equalsIgnoreCase("LATAMGRID") && !runType.equalsIgnoreCase("euhorizongrid") && !runType.equalsIgnoreCase("horizonprod") && !runType.equalsIgnoreCase("PROD-GRID") && !runType.equalsIgnoreCase("SBGRID")) {
                    System.out.println("Please specify run type as : android");
                    webDriver = null;
                } else {
                    webDriver = getRemoteWebDriver(capabilities1);
                }

                break;
            case "firefox":
                if (!runType.equalsIgnoreCase("grid") && !runType.equalsIgnoreCase("spoon") && !runType.equalsIgnoreCase("horizongrid") && !runType.equalsIgnoreCase("LATAMGRID") && !runType.equalsIgnoreCase("horizonwebgrid") && !runType.equalsIgnoreCase("euhorizongrid") && !runType.equalsIgnoreCase("horizonprod") && !runType.equalsIgnoreCase("PROD-GRID") && !runType.equalsIgnoreCase("SBGRID")) {
                    System.out.println("Local execution");
                    ProfilesIni options = new ProfilesIni();
                    FirefoxProfile capabilities = options.getProfile("default");
                    webDriver = new FirefoxDriver(capabilities);
                } else {
                    System.out.println("Remote execution; sending test to the Grid");
                    desiredCap = DesiredCapabilities.firefox();
                    desiredCap.setVersion(version);
                    webDriver = getRemoteWebDriver(desiredCap);
                }

                break;
            case "ie":

                desiredCap = DesiredCapabilities.internetExplorer();
                desiredCap.setCapability("ie.ensureCleanSession", true);
                if (!runType.equalsIgnoreCase("grid") && !runType.equalsIgnoreCase("spoon") && !runType.equalsIgnoreCase("horizongrid") && !runType.equalsIgnoreCase("LATAMGRID") && !runType.equalsIgnoreCase("horizonwebgrid") && !runType.equalsIgnoreCase("euhorizongrid") && !runType.equalsIgnoreCase("horizonprod") && !runType.equalsIgnoreCase("PROD-GRID") && !runType.equalsIgnoreCase("SBGRID")) {
                    System.setProperty("webdriver.ie.driver", "C:\\Windows\\System32\\IEDriverServer.exe");
                    webDriver = new InternetExplorerDriver(desiredCap);
                } else {
                    desiredCap.setVersion(version);
                    webDriver = getRemoteWebDriver(desiredCap);
                }
                break;
            default:
                break;
        }

        webDriver.manage().timeouts().pageLoadTimeout((long) timeOut, TimeUnit.SECONDS);
        webDriver.manage().window().maximize();
        return webDriver;
    }

    private static RemoteWebDriver getRemoteWebDriver(DesiredCapabilities desiredCap) {
        RemoteWebDriver gridWebDriver;
        String nodeHostName;
        try {
            gridWebDriver = new RemoteWebDriver(new URL("http://" + GRID_HUB + ":4444/wd/hub"), desiredCap);
            nodeHostName = getHostNameOfNode(gridWebDriver);
        } catch (MalformedURLException var7) {
            throw new IllegalStateException("The Selenium Hub " + GRID_HUB + " might be down. Contact Automation team");
        }

        Capabilities caps = gridWebDriver.getCapabilities();
        System.out.println("The Host Name of the node is " + nodeHostName);
        System.out.println("Browser for current execution and version are " + caps.getBrowserName() + " " + caps.getVersion());
        String actualVersion = caps.getVersion();
        int indexDot = actualVersion.indexOf(".");
        if (indexDot == -1) {
            indexDot = actualVersion.length();
        }

        String trimmedVersion = actualVersion.substring(0, indexDot).trim();
        if (!desiredCap.getVersion().equals(trimmedVersion)) {
            throw new IllegalStateException("Requested browser version " + desiredCap.getVersion() + " does not match actual version " + trimmedVersion);
        } else {
            return gridWebDriver;
        }
    }

    private static String getHostNameOfNode(RemoteWebDriver remoteDriver) {
        String hostFound = "Unable to retrieve";

        try {
            HttpCommandExecutor ce = (HttpCommandExecutor) remoteDriver.getCommandExecutor();
            String hostName = ce.getAddressOfRemoteServer().getHost();
            int port = ce.getAddressOfRemoteServer().getPort();
            HttpHost host = new HttpHost(hostName, port);
            DefaultHttpClient client = new DefaultHttpClient();
            URL sessionURL = new URL("http://" + hostName + ":" + port + "/grid/api/testsession?session=" + remoteDriver.getSessionId());
            BasicHttpEntityEnclosingRequest r = new BasicHttpEntityEnclosingRequest("POST", sessionURL.toExternalForm());
            HttpResponse response = client.execute(host, r);
            JSONObject object = extractObject(response);
            URL myURL = new URL(object.getString("proxyId"));
            if (myURL.getHost() != null && myURL.getPort() != -1) {
                hostFound = myURL.getHost();
            }
        } catch (Exception var12) {

        }

        return hostFound;
    }

    private static JSONObject extractObject(HttpResponse resp) throws IOException, JSONException {
        InputStream contents = resp.getEntity().getContent();
        StringWriter writer = new StringWriter();
        IOUtils.copy(contents, writer, "UTF8");
        return new JSONObject(writer.toString());
    }

    protected WebElement getElement(UIElement uiElement) {
        boolean result = false;
        int i = 0;

        while (true) {
            try {
                return webDriver.findElement(this.findBy(uiElement));
            } catch (StaleElementReferenceException var5) {
                ++i;
                if (i > 10) {
                    return null;
                }
            }
        }
    }

    private static void setGridHub(String runType) {
        if (runType.equalsIgnoreCase("grid")) {
            GRID_HUB = "PNEITSH61996D";   //Pratima's Machine
        } else if (runType.equalsIgnoreCase("spoon")) {
            GRID_HUB = "618ITS4F97MM1";
        } else if (runType.equalsIgnoreCase("horizongrid")) {
            GRID_HUB = "WQASEDCOHOR003V";
        } else if (runType.equalsIgnoreCase("horizonwebgrid")) {
            GRID_HUB = "WQASEDCOITL011V";
        } else if (runType.equalsIgnoreCase("euhorizongrid")) {
            GRID_HUB = "nprlabsqa5153";
        } else if (runType.equalsIgnoreCase("horizonprod")) {
            GRID_HUB = "WQASEDCOITL005V";
        } else if (runType.equalsIgnoreCase("SBGRID")) {
            // Temporary solution to give this value from Jenkins or as maven parameter
            String sbGrid = System.getProperty("SBGRID");
            if (sbGrid != null)
                GRID_HUB = sbGrid;
            else
                //GRID_HUB = "WQASEDCOBAT001V";
                GRID_HUB = "nprlabsqa5125";
        } else if (runType.equalsIgnoreCase("LATAMGRID")) {
            GRID_HUB = "WQASEDQAGEN001V";
        } else if (runType.equalsIgnoreCase("PROD-GRID")) {
            GRID_HUB = "nprlabsqa5338";
        }

        if (runType.equalsIgnoreCase("android")) {
            GRID_HUB = "10.60.141.39";
        }

    }

    public void openURL(String url) {
        webDriver.get(url);
    }

    private By findBy(UIElement uiElement) {
        By locator = null;
        if (uiElement.getLocatorType() == UILocatorType.ID) {
            locator = By.id(uiElement.getLocator());
        } else if (uiElement.getLocatorType() == UILocatorType.CSS) {
            locator = By.cssSelector(uiElement.getLocator());
        } else if (uiElement.getLocatorType() == UILocatorType.Xpath) {
            locator = By.xpath(uiElement.getLocator());
        } else if (uiElement.getLocatorType() == UILocatorType.Name) {
            locator = By.name(uiElement.getLocator());
        } else if (uiElement.getLocatorType() == UILocatorType.Text) {
            locator = By.partialLinkText(uiElement.getLocator());
        } else if (uiElement.getLocatorType() == UILocatorType.Link) {
            locator = By.linkText(uiElement.getLocator());
        }

        return locator;
    }

    public void navigate(String url) {
        webDriver.get(url);
        //  this.acceptAlert();
    }

    public void navigateTo(String locator) {
        webDriver.navigate().to("javascript:document.getElementById(\'" + locator + "\').click()");
    }


    public void dismissAlert() {
        try {
            if ((new WebDriverWait(webDriver, 0L)).until(ExpectedConditions.alertIsPresent()) != null) {
                Alert alert = webDriver.switchTo().alert();
                alert.dismiss();
            }
        } catch (Exception var2) {

        }

    }

    public void acceptAlert() {
        if ((new WebDriverWait(webDriver, 0L)).until(ExpectedConditions.alertIsPresent()) != null) {
            Alert alert = webDriver.switchTo().alert();
            alert.accept();
        }
    }


    public boolean isAlertPresent() {
        boolean retValue = false;

        try {
            if ((new WebDriverWait(webDriver, 5L)).until(ExpectedConditions.alertIsPresent()) != null) {
                retValue = true;
            }
        } catch (Exception var3) {

        }

        return retValue;
    }

    public boolean alertPresence(int iTimeOut) {
        FluentWait wait = (new FluentWait(webDriver)).withTimeout((long) iTimeOut, TimeUnit.SECONDS).pollingEvery(1000L, TimeUnit.MILLISECONDS).ignoring(NoAlertPresentException.class);

        try {
            wait.until(ExpectedConditions.alertIsPresent());
            return true;
        } catch (TimeoutException var4) {
            return false;
        }
    }

    public String getAlertText() {
        String alertText = "";
        if (this.isAlertPresent()) {
            Alert alert = webDriver.switchTo().alert();
            alertText = alert.getText();
        }

        return alertText;
    }

    public String getCurrentUrl() {
        originalWindowHandle = webDriver.getWindowHandle();
        Set windowHandles = webDriver.getWindowHandles();
        int count = windowHandles.size();
        if (count > 1) {
            Iterator var4 = windowHandles.iterator();

            while (var4.hasNext()) {
                String window = (String) var4.next();
                if (!window.equals(originalWindowHandle)) {
                    webDriver.switchTo().window(window);
                }
            }
        }

        return getWebDriver().getCurrentUrl();
    }

    public void closeCurrentBrowser() {
        Set windowHandles = webDriver.getWindowHandles();
        int count = windowHandles.size();
        if (count > 1) {
            Iterator var4 = windowHandles.iterator();

            while (var4.hasNext()) {
                String window = (String) var4.next();
                if (!window.equals(originalWindowHandle)) {
                    webDriver.switchTo().window(window);
                    webDriver.close();
                }
            }
        }

    }

    public void navigateToMainPage() {
        CommonUtilities.waitTime(2);
        webDriver.switchTo().window(originalWindowHandle);
        CommonUtilities.waitTime(4);
    }

    public void waitForTextFieldToBeEnableWithTimeOut(UIElement uiElement, int seconds) {
        for (int i = 1; i <= seconds; i++) {
            try {
                By w = this.findBy(uiElement);
                webDriver.findElement(w).clear();
                break;
            } catch (NoSuchElementException | StaleElementReferenceException | InvalidElementStateException e) {
                CommonUtilities.waitTime(1);
                if (i == seconds)
                    throw e;
            }
        }

    }

    public void type(UIElement uiElement, String text) {
        boolean result = false;
        int i = 0;

        do {
            try {
                By w = this.findBy(uiElement);
                webDriver.findElement(w).clear();
                webDriver.findElement(w).sendKeys(new CharSequence[]{text});
                result = true;
            } catch (StaleElementReferenceException var6) {
                ++i;
            } catch (WebDriverException var7) {
                ++i;
            }
        } while(!result && i <= 10);

    }

    public void deleteAndType(UIElement uiElement, String text) {
        By locator = this.findBy(uiElement);
        webDriver.findElement(locator).sendKeys(new CharSequence[]{Keys.CONTROL + "a"});
        webDriver.findElement(locator).sendKeys(new CharSequence[]{Keys.DELETE});
        CommonUtilities.waitTime(2);
        webDriver.findElement(locator).sendKeys(new CharSequence[]{text});
    }

    public void switchToFrame(UIElement uiElement) {
        if (uiElement.getLocatorType().toString().equalsIgnoreCase("CSS")) {
            webDriver.switchTo().frame(this.getElement(uiElement));
        } else {
            webDriver.switchTo().frame(uiElement.getLocator());
        }

    }

    public boolean waitForFrameToLoad(UIElement uiElement, int iTimeOut) {
        return (new WebDriverWait(webDriver, (long) iTimeOut)).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(this.findBy(uiElement))) != null;
    }

    public void navigateToFrame(UIElement uiElement) {
        webDriver.switchTo().defaultContent();
        this.switchToFrame(uiElement);
    }

    public void switchToDefaultContent() {
        webDriver.switchTo().defaultContent();
    }

    public void select(UIElement uiElement, String text) {
        boolean result = false;
        int i = 0;

        do {
            try {
                Select w = new Select(webDriver.findElement(this.findBy(uiElement)));
                w.selectByVisibleText(text);
                result = true;
            } catch (StaleElementReferenceException var6) {
                ++i;
            } catch (WebDriverException var7) {
                ++i;
            }
        } while(!result && i <= 10);

    }

    public boolean checkWebList(String sProperty, String sExpectedValue, UIElement uiElement) {
        boolean result = false;
        WebElement object = webDriver.findElement(this.findBy(uiElement));
        if (!sProperty.equalsIgnoreCase("VALUE") && !sProperty.equalsIgnoreCase("SELECTION") && !sProperty.equalsIgnoreCase("DEFAULTVALUE")) {
            System.out.println(sProperty + " property is not supported");
            return result;
        } else {
            Select itemList = new Select(object);
            if (!sExpectedValue.equalsIgnoreCase("null") && !sExpectedValue.isEmpty() && sExpectedValue != null) {
                WebElement actualSelected2 = itemList.getFirstSelectedOption();
                if (!actualSelected2.getText().equalsIgnoreCase(sExpectedValue)) {
                    System.out.println(actualSelected2.getText() + " is selected which was not expected");
                    return result;
                }

                System.out.println("Item value :: " + actualSelected2.getText() + " is selected by default as expected");
                result = true;
            } else {
                List actualSelected = itemList.getAllSelectedOptions();
                if (actualSelected.size() != 0 && !itemList.getFirstSelectedOption().getText().isEmpty()) {
                    WebElement actualSelected1 = itemList.getFirstSelectedOption();
                    System.out.println(actualSelected1.getText() + " is selected by default which was not expected");
                    return result;
                }

                System.out.println("No Item is selected by default as expected");
                result = true;
            }

            return result;
        }
    }

    public void selectListBox(UIElement uiElement, String value) {
        this.waitForElementPresence(uiElement);
        List allElements = webDriver.findElements(this.findBy(uiElement));
        Iterator var5 = allElements.iterator();

        while (var5.hasNext()) {
            WebElement element = (WebElement) var5.next();
            if (element.getText().equalsIgnoreCase(value)) {
                element.click();
                break;
            }
        }

    }

    public void selectCaseSensitiveListItem(UIElement uiElement, String value) {
        this.waitForElementPresence(uiElement);
        List allElements = webDriver.findElements(this.findBy(uiElement));
        Iterator var5 = allElements.iterator();

        while (var5.hasNext()) {
            WebElement element = (WebElement) var5.next();
            if (element.getText().equals(value)) {
                element.click();
                break;
            }
        }

    }

    public boolean elementExists(UIElement uiElement) {
        try {
            this.waitForElementPresenceWithTimeOut(uiElement, 1);
            return webDriver.findElement(this.findBy(uiElement)).isDisplayed();
        } catch (NoSuchElementException var3) {
            return false;
        }
    }

    public void click(UIElement uiElement) {
        boolean result = false;
        int i = 0;

        do {
            try {
                webDriver.findElement(this.findBy(uiElement)).click();
                result = true;
            } catch (StaleElementReferenceException var5) {
                ++i;
            } catch (WebDriverException var6) {
                ++i;
            }
        } while(!result && i <= 10);

    }

    public void clickonWebElement(WebElement webElement) {
        boolean result = false;
        int i = 0;

        do {
            try {
                webElement.click();
                result = true;
            } catch (StaleElementReferenceException var5) {
                ++i;
            } catch (WebDriverException var6) {
                ++i;
            }
        } while(!result && i <= 10);

    }

    public void doubleClick(UIElement uiElement) {
        Actions action = new Actions(webDriver);
        action.moveToElement(webDriver.findElement(this.findBy(uiElement))).doubleClick().build().perform();
    }

    public void sendEnterKey(UIElement uiElement) {
        By locator = this.findBy(uiElement);
        webDriver.findElement(locator).sendKeys(new CharSequence[]{Keys.ENTER});
    }

    public void sendDownArrow(UIElement uiElement) {
        By locator = this.findBy(uiElement);
        webDriver.findElement(locator).sendKeys(new CharSequence[]{Keys.ARROW_DOWN});
    }

    public void tabOutOf(UIElement uiElement) {
        (new Actions(webDriver)).moveToElement(this.getElement(uiElement)).click().perform();
        webDriver.findElement(this.findBy(uiElement)).sendKeys(new CharSequence[]{Keys.TAB});
    }

    public void waitAndClick(UIElement uiElement) {
        boolean result = false;
        int i = 0;

        do {
            try {
                if((new WebDriverWait(webDriver, 5L)).ignoring(NoSuchElementException.class).until(ExpectedConditions.elementToBeClickable(this.findBy(uiElement))) != null) {
                    webDriver.findElement(this.findBy(uiElement)).click();
                    result = true;
                }
            } catch (StaleElementReferenceException var5) {
                ++i;
            } catch (WebDriverException var6) {
                ++i;
            }
        } while(!result && i <= 10);

    }

    public void waitElementToBeClickable(UIElement uiElement) {
        new FluentWait<WebDriver>(webDriver).withTimeout(ApplicationConfiguration.getWaitForElementTimeout(), TimeUnit.SECONDS)
                .ignoring(NoSuchElementException.class, StaleElementReferenceException.class)
                .until(ExpectedConditions.elementToBeClickable(this.getElement(uiElement)));
    }

    public String getText(UIElement uiElement) {
        boolean result = false;
        String text = "";
        int i = 0;

        do {
            try {
                text = webDriver.findElement(this.findBy(uiElement)).getText();
                result = true;
            } catch (StaleElementReferenceException var6) {
                ++i;
            } catch (WebDriverException var7) {
                ++i;
            }
        } while (!result && i <= 10);

        return text;
    }

    public void quit() {
        try {
            //webDriver.close();
            webDriver.quit();
        }finally {
            driver = null;
        }
    }

    public void close(){
        webDriver.close();
    }

    public void failure(Scenario scenario) {
        try {
            if (scenario.isFailed()) {
                byte[] exception = (byte[]) ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.BYTES);
                scenario.embed(exception, "image/png");
            }
        } catch (WebDriverException var6) {
            System.out.println("Exception while capturing screenshot for scenario " + scenario);
        }
    }

    public void waitForElementPresence(UIElement uiElement) {
        this.elementPresence(this.findBy(uiElement));
    }

    public boolean waitForElementPresenceWithTimeOut(UIElement uiElement, int iTimeOut) {
        return this.elementPresence(this.findBy(uiElement), iTimeOut);

    }

    public boolean waitForElementAbsence(UIElement uiElement, int iTimeOut) {
        return this.elementAbsence(this.findBy(uiElement), iTimeOut);
    }

    public boolean elementFromListExists(int sleepTime, UIElement uiElement) {
        List elements = webDriver.findElements(this.findBy(uiElement));
        boolean elementExists = false;
        Iterator var6 = elements.iterator();

        while (var6.hasNext()) {
            WebElement element = (WebElement) var6.next();

            try {
                if (!element.isDisplayed()) {
                    try {
                        element = (WebElement) (new WebDriverWait(webDriver, (long) sleepTime)).until(ExpectedConditions.visibilityOf(element));
                    } catch (Exception var8) {
                        ;
                    }
                }
            } catch (Exception var9) {
                ;
            }

            if (element != null && element.isDisplayed()) {
                elementExists = true;
                break;
            }
        }

        return elementExists;
    }

    public void clickOnVisibleElement(int sleepTime, UIElement uiElement) {
        List elements = webDriver.findElements(this.findBy(uiElement));
        Iterator var5 = elements.iterator();

        while (var5.hasNext()) {
            WebElement element = (WebElement) var5.next();
            if (!element.isDisplayed()) {
                element = (WebElement) (new WebDriverWait(webDriver, (long) sleepTime)).until(ExpectedConditions.visibilityOf(element));
            }

            if (element != null && element.isDisplayed()) {
                element.click();
                break;
            }
        }

    }

    public boolean elementPresence(By by) {
        return this.elementPresence(by, timeOut);
    }

    public boolean elementPresence(By by, int iTimeOut) {
        FluentWait wait = (new FluentWait(webDriver)).withTimeout((long) iTimeOut, TimeUnit.SECONDS).pollingEvery(1000L, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class, StaleElementReferenceException.class);

        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(by));
            return true;
        } catch (TimeoutException var5) {
            return false;
        }
    }

    public boolean elementNotPresent(UIElement uiElement, int iTimeOut) {
        try {
            return (new WebDriverWait(webDriver, (long) iTimeOut)).until(ExpectedConditions.invisibilityOfElementLocated(this.findBy(uiElement))) != null;
        } catch (Exception var4) {
            return false;
        }
    }

    public boolean elementNotExist(By by, int iTimeOut) {
        FluentWait wait = (new FluentWait(webDriver)).withTimeout((long) iTimeOut, TimeUnit.SECONDS).pollingEvery(1000L, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);

        try {
            wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOfElementLocated(by)));
            return true;
        } catch (TimeoutException var5) {
            return false;
        }
    }

    public boolean elementAbsence(By by, int iTimeOut) {
        FluentWait wait = (new FluentWait(webDriver)).withTimeout((long) iTimeOut, TimeUnit.SECONDS).pollingEvery(1000L, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);

        try {
            wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOfElementLocated(by)));
            return true;
        } catch (TimeoutException var5) {
            return false;
        }
    }

    public void elementAbsence(By by) {
        this.elementAbsence(by, timeOut);
    }

    public List<WebElement> findElements(By locator) {
        return webDriver.findElements(locator);
    }

    public List<WebElement> findElements(UIElement uiElements) {
        return webDriver.findElements(this.findBy(uiElements));
    }

    public void waitForAllElementsToDisappear(int sleepTime, UIElement uiElement) {
        List images = webDriver.findElements(this.findBy(uiElement));
        Iterator var5 = images.iterator();

        while (var5.hasNext()) {
            WebElement image = (WebElement) var5.next();
            if (image.isDisplayed()) {
                (new WebDriverWait(webDriver, (long) sleepTime)).until(ExpectedConditions.not(ExpectedConditions.visibilityOf(image)));
            }
        }

    }

    public void waitForAllElementsToAppear(int sleepTime, UIElement uiElement) {
        List images = webDriver.findElements(this.findBy(uiElement));
        Iterator var5 = images.iterator();

        while (var5.hasNext()) {
            WebElement image = (WebElement) var5.next();
            if (!image.isDisplayed()) {
                (new WebDriverWait(webDriver, (long) sleepTime)).until(ExpectedConditions.visibilityOf(image));
            }
        }

    }

    public String getAttribute(UIElement uiElement, String attribute) {
        return webDriver.findElement(this.findBy(uiElement)).getAttribute(attribute);
    }

    public void javaScriptClick(UIElement uiElement) {
        boolean result = false;
        int i = 0;

        do {
            try {
                ((JavascriptExecutor)webDriver).executeScript("arguments[0].click();", new Object[]{this.getElement(uiElement)});
                result = true;
            } catch (StaleElementReferenceException var5) {
                ++i;
            } catch (JavaScriptException var6) {
                var6.printStackTrace();
                throw new IllegalStateException("Error occurred when executing javascriptClick()");
            } catch (WebDriverException var7) {
                ++i;
            }
        } while(!result && i <= 10);

    }

    public void javaScriptScrollAndClick(UIElement uiElement) {
        try {
            CommonUtilities.waitTime(5);
            JavascriptExecutor e = (JavascriptExecutor) webDriver;
            e.executeScript("window.scrollTo(0,2000);", new Object[0]);
            CommonUtilities.waitTime(3);
            this.getElement(uiElement).click();
        } catch (Exception var3) {
            var3.printStackTrace();
            throw new IllegalStateException("Error occurred when executing javaScriptScrollAndClick()");
        }
    }

    public String getTextByJavaScript(String xPath) {
        JavascriptExecutor jse = (JavascriptExecutor) webDriver;
        String script = " return document.getElementByXPath(\'" + xPath + "\').getText();";
        return ((JavascriptExecutor) webDriver).executeScript(script, new Object[0]).toString();
    }

    public void setTextByJavaScript(String className,String text){


        //JavascriptExecutor jse = (JavascriptExecutor) webDriver;

        //className="//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]";
//        ((JavascriptExecutor) webDriver).executeScript("document.getElementsByXpath("").value='ABC'");

//        String jScript = "var myList = document.getElementsByClassName(\"selectBox-label\");"
//                +"myList[0].innerHTML=\"YourNumber\";";
//
        //((JavascriptExecutor)webDriver).executeScript("document.getElementsByXpath('//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]').setAttribute('innerHTML', '123')");
       // ((JavascriptExecutor)webDriver).executeScript("document.getElementsByXpath('className').value='123'");

WebElement x= webDriver.findElement(By.xpath("//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]"));
     //   JavascriptExecutor jse = (JavascriptExecutor) webDriver;
   //     jse.executeScript("document.getElementsByXpath('//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]').value = '111';",x);

        String jScript = "var myList = document.getElementsByXpath(\"//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]\");"
                +"myList[0].innerHTML=\"555\";";
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript(jScript);


    }

    public List getFramesByJavaScript(String frame, String locatorType) {
        JavascriptExecutor jse = (JavascriptExecutor) webDriver;
        String script;
        if (locatorType.equalsIgnoreCase("name")) {
            script = " return window.frames(\'" + frame + "\');";
        } else {
            script = " return document.getElementById(\'" + frame + "\');";
        }

        return (List) ((JavascriptExecutor) webDriver).executeScript(script, new Object[0]);
    }

    public void closeBrowser() {
        String parentWnh = webDriver.getWindowHandle();
        ((JavascriptExecutor) webDriver).executeScript("window.open(\'\', \'_blank\');", new Object[0]);
        webDriver.switchTo().window(parentWnh);
        ((JavascriptExecutor) webDriver).executeScript("window.focus()", new Object[0]);
        webDriver.close();
        this.acceptAlert();
        webDriver.switchTo().window(webDriver.getWindowHandles().toArray()[0].toString());
        webDriver.manage().window().maximize();
    }


    public void hoverOnMenu(UIElement uiElement) {
        boolean result = false;
        int i = 0;

        do {
            try {
                Actions e = new Actions(webDriver);
                WebElement element = webDriver.findElement(this.findBy(uiElement));
                e.moveToElement(element).build().perform();
                result = true;
            } catch (StaleElementReferenceException var6) {
                ++i;
            }
        } while (!result && i <= 10);

    }
//Method is use to enter text using Action class
    public void actionType(UIElement uiElement, String typeText) {
        try {
            Actions e = new Actions(webDriver);
            e.sendKeys(typeText).build().perform();
            e.sendKeys(Keys.TAB).build().perform();
        } catch (StaleElementReferenceException var6) {
            System.out.println(var6);
        }

    }



    public boolean checkObjectExists(UIElement uiElement, int iTimeOut) {
        boolean exist = false;

        try {
            if ((new WebDriverWait(webDriver, (long) iTimeOut)).until(ExpectedConditions.visibilityOfElementLocated(this.findBy(uiElement))) != null) {
                exist = true;
            }

            return exist;
        } catch (Exception var5) {
            return false;
        }
    }

    public boolean isSelected(UIElement uiElement) {
        boolean result = false;
        boolean isSelected = false;
        int i = 0;

        do {
            try {
                isSelected = webDriver.findElement(this.findBy(uiElement)).isSelected();
                result = true;
            } catch (StaleElementReferenceException var6) {
                ++i;
            }
        } while (!result && i <= 10);

        return isSelected;
    }

    public String getPageSource() {
        String source = webDriver.getPageSource();
        return source;
    }

    public String executeJavaScript(String javaScript, UIElement webElement){
        if (webElement!=null) {
            return ((JavascriptExecutor) getWebDriver()).executeScript(javaScript, webElement).toString();
        }
        else
            return   ((JavascriptExecutor) getWebDriver()).executeScript(javaScript).toString();
    }

    public String getUniqueStringOfReqLength(int length, boolean needNumbersOnly) {

        String randomString = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG).format(new Date()).toString().toUpperCase().replaceAll(" ", "").replaceAll("[/: ,-]","");
        randomString = randomString + randomString + randomString + randomString + randomString+randomString+randomString;
        if (needNumbersOnly)
            randomString=randomString.replaceAll("[^\\d.]","");
        randomString = randomString.substring(0, length);
        return randomString;
    }

    }
