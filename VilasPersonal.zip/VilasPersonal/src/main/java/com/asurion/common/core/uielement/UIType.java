//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.asurion.common.core.uielement;

public enum UIType {
    TextBox,
    Label,
    Button,
    Link,
    Image,
    CheckBox,
    ListBox,
    RadioButton,
    Frame;

    private UIType() {
    }
}
