//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.asurion.common.core.util;

import java.util.HashMap;

public class CaseInsensitiveMap extends HashMap<String, String> {
    public CaseInsensitiveMap() {
    }

    public String put(String key, String value) {
        return (String)super.put(key.toLowerCase(), value);
    }

    public String get(String key) {
        return (String)super.get(key.toLowerCase());
    }
}
