//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.asurion.common.core.util;

import com.sun.rowset.CachedRowSetImpl;

import javax.sql.rowset.CachedRowSet;
import java.sql.*;

public class Database {
    private String serverURL = null;
    private Connection serverConnection = null;
    private CachedRowSet resultSet;

    public Database(String serverURL) {
        this.serverURL = serverURL;
    }

    public CachedRowSet getResultSet() {
        return this.resultSet;
    }

    private void connect() {
        try {
            this.serverConnection = DriverManager.getConnection(this.serverURL);
        } catch (SQLException var2) {
            var2.printStackTrace();
        }

    }

    public void executeSelectSQL(String sqlQuery) {
        this.connect();

        try {
            this.resultSet = new CachedRowSetImpl();
            Statement sQLStatement = this.serverConnection.createStatement();
            ResultSet resultSet = sQLStatement.executeQuery(sqlQuery);
            this.resultSet.populate(resultSet);
            this.closeConnection();
        } catch (SQLException var5) {
            var5.printStackTrace();
        }

    }

    public void executeStoreProcedure(String storeProc) {
        this.connect();

        try {
            this.resultSet = new CachedRowSetImpl();
            CallableStatement callableStatement = this.serverConnection.prepareCall(storeProc);
            callableStatement.execute();
            ResultSet resultSet = callableStatement.getResultSet();
            this.resultSet.populate(resultSet);
            this.closeConnection();
        } catch (SQLException var5) {
            var5.printStackTrace();
        }

    }

    public void closeConnection() {
        if(!this.isClosed().booleanValue()) {
            try {
                this.serverConnection.close();
            } catch (SQLException var2) {
                var2.printStackTrace();
            }
        }

    }

    private Boolean isClosed() {
        try {
            return Boolean.valueOf(this.serverConnection.isClosed());
        } catch (SQLException var2) {
            var2.printStackTrace();
            return null;
        }
    }

    public CaseInsensitiveMap columnNamesToValues() {
        this.selectNonNullColumn();
        CaseInsensitiveMap columnNamesToValues = new CaseInsensitiveMap();

        try {
            ResultSetMetaData resultSetMetaData = this.resultSet.getMetaData();

            while(this.resultSet.next()) {
                for(int e = 1; e <= resultSetMetaData.getColumnCount(); ++e) {
                    columnNamesToValues.put(resultSetMetaData.getColumnName(e), this.resultSet.getString(e));
                }
            }
        } catch (SQLException var4) {
            var4.printStackTrace();
        }

        return columnNamesToValues;
    }

    private void selectNonNullColumn() {
        boolean hasResult = true;

        try {
            ResultSetMetaData resultSetMetaData = this.resultSet.getMetaData();

            while(hasResult && resultSetMetaData.getColumnName(1).isEmpty()) {
                if(hasResult = this.resultSet.next()) {
                    resultSetMetaData = this.resultSet.getMetaData();
                }
            }
        } catch (SQLException var4) {
            var4.printStackTrace();
        }

    }
}
