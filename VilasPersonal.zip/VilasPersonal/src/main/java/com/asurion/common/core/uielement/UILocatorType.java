//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.asurion.common.core.uielement;

public enum UILocatorType {
    ID,
    Name,
    Xpath,
    CSS,
    Text,
    Link;

    private UILocatorType() {
    }
}
