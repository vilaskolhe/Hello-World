//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.asurion.common.core.uielement;

public class UIElement {
    private UIType type;
    private UILocatorType locator_type;
    private String locator;

    public UIElement(UIType uiType, UILocatorType uiLocatorType, String locator) {
        this.type = uiType;
        this.locator_type = uiLocatorType;
        this.locator = locator;
    }

    public UIType getUIType() {
        return this.type;
    }

    public UILocatorType getLocatorType() {
        return this.locator_type;
    }

    public String getLocator() {
        return this.locator;
    }
}
