package com.asurion.database;

import com.asurion.common.core.util.CommonUtilities;
import com.asurion.pages.CaptureIncidentPage;
import com.asurion.pages.IncidentPathPage;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.DatabaseUtils;
import org.junit.Assert;

import java.util.*;

/**
 * This is singleton class for common database validations
 * <p>
 * Created by User on 8/24/2016.
 */
public class DatabaseValidationUtil {

    private static DatabaseValidationUtil databaseValidationUtil;

    private final String NUMERIC = "NUMERIC";
    private final String ALPHANUMERIC = "ALPHANUMERIC";
    private final String ALPHABETIC = "ALPHABETIC";

    // cucumber datatable column names, please do not change
    private final String COLUMN_NAME = "Column Name";
    private final String COLUMN_VALUE = "Column Value";
    private final String DATA_TYPE = "Data Type";
    private final String NULL_STATUS = "Null Status";
    private final String CONTAINING_STRING_1 = "Containing String 1";
    private final String CONTAINING_STRING_2 = "Containing String 2";
    private static String query=null;
    // common value map
    private Map<String, String> commonValuesMap = new HashMap<String, String>();

    private DatabaseValidationUtil() {
        // Stopping Object creation from outside
    }

    public static DatabaseValidationUtil getDatabaseValidationUtil() {
        if (databaseValidationUtil == null) {
            databaseValidationUtil = new DatabaseValidationUtil();
        }
        return databaseValidationUtil;
    }


    public List<Map<String, String>> verifyGivenDataInTable(String query, String caseNumber, List<Map<String, String>> expectedValidationData) throws Exception {
        List<Map<String, String>> actualValidationData = new ArrayList<>();
        ArrayList<HashMap<String, String>> result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), getQuery(query, caseNumber));

        if (result == null || result.size() == 0) {
            System.out.println("result set has no value trying again after 30 seconds");
            int retryCount = 20;
            for (int i = 1; i <= retryCount; i++) {
                System.out.println("retrying = " + i);
                CommonUtilities.waitTime(30);
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), getQuery(query, caseNumber));
                if (result.size() != 0) {
                    break;
                }
            }
        }

        Assert.assertTrue("No Data fetched", result != null && result.size() != 0);
        for (int i = 0; i < expectedValidationData.size(); i++) {
            Map<String, String> resultMap = new HashMap<>();
            // expected values
            String expectedColumnValue = expectedValidationData.get(i).get(COLUMN_VALUE);
            String expectedColumnName = expectedValidationData.get(i).get(COLUMN_NAME);
            String expectedDataType = expectedValidationData.get(i).get(DATA_TYPE);
            String expectedNullStatus = expectedValidationData.get(i).get(NULL_STATUS);
            String expectedContainingString1 = expectedValidationData.get(i).get(CONTAINING_STRING_1);
            String expectedContainingString2 = expectedValidationData.get(i).get(CONTAINING_STRING_2);

            // actual values
            String actualColumnValue = result.get(0).get(expectedColumnName.toUpperCase());
            // Putting value into map
            resultMap.put(COLUMN_NAME, expectedColumnName);

            if (expectedColumnValue.trim().equals(""))
                resultMap.put(COLUMN_VALUE, "");
            else {
                if (expectedColumnValue.toLowerCase().contains("from other table")) {
                    String valueFromOtherTable = getCommonValueFromMapByExpectedValue(expectedColumnValue);
                    if (valueFromOtherTable.equalsIgnoreCase(actualColumnValue))
                        resultMap.put(COLUMN_VALUE, expectedColumnValue);
                    else
                        resultMap.put(COLUMN_VALUE, "Expected Value:=" + valueFromOtherTable + " is not same as Actual Value:=" + actualColumnValue);

                } else if (expectedColumnValue.toUpperCase().contains("[OR]")) {
                    expectedColumnName = expectedColumnValue.trim();
                    String arr[] = expectedColumnName.split("\\[OR]");
                    boolean isContains = arr[0].trim().equals(actualColumnValue) || arr[1].trim().equals(actualColumnValue) || arr[2].trim().equals(actualColumnValue) || arr[3].trim().equals(actualColumnValue);
                    if (isContains)
                        resultMap.put(COLUMN_VALUE, expectedColumnValue);
                    else
                        resultMap.put(COLUMN_VALUE, "Expected Value:=" + expectedColumnName + " is not same as Actual Value:= " + actualColumnValue);
                } else {
                    resultMap.put(COLUMN_VALUE, actualColumnValue == null ? "Null" : actualColumnValue);
                }
            }


            if (expectedNullStatus.equals(""))
                resultMap.put(NULL_STATUS, expectedNullStatus);
            else
                resultMap.put(NULL_STATUS, actualColumnValue != null ? "Not Null" : "Null");


            System.out.println("actual column value-> " + expectedColumnName + "==" + actualColumnValue);

            if (expectedContainingString1.equals(""))
                resultMap.put(CONTAINING_STRING_1, expectedContainingString1);
            else
                resultMap.put(CONTAINING_STRING_1, actualColumnValue.contains(expectedContainingString1) ? expectedContainingString1 : "false");

            if (expectedContainingString2.equals(""))
                resultMap.put(CONTAINING_STRING_2, expectedContainingString2);
            else
                resultMap.put(CONTAINING_STRING_2, actualColumnValue.contains(expectedContainingString2) ? expectedContainingString2 : "false");

            if (expectedDataType.equals(""))
                resultMap.put(DATA_TYPE, expectedDataType);
            else
                resultMap.put(DATA_TYPE, getDataTypeOfGivenText(actualColumnValue));

            actualValidationData.add(resultMap);
        }
        return actualValidationData;
    }

    private String getCommonValueFromMapByExpectedValue(String s) {
        String key = s.substring(s.indexOf("(") + 1, s.indexOf(")")).trim();
        return commonValuesMap.get(key);
    }

    private String getDataTypeOfGivenText(String value) {
        try {
            Double.parseDouble(value);
            return "NUMERIC";
        } catch (Exception ex) {
            if(value.matches("[a-zA-Z]+(\\s+[a-zA-Z]+)*")){
                return "ALPHABETIC";
            } else {
                return "ALPHANUMERIC";
            }
        }
    }

    private String getQuery(String rawQuery, String caseNumber) throws Exception {
        if (caseNumber == null) {
            return rawQuery;
        }
        String formattedQuery = rawQuery.replace("\" + caseNumber + \"", caseNumber);
        System.out.println("\nformatted query=" + formattedQuery);
        System.out.println();
        query=formattedQuery;
        System.out.println("query=formattedQuery;" + query);
        return formattedQuery;
    }
    // ----------------------- fetch common values ----------------------

    public String returnFormattedQuery(String queryInput){
        query=queryInput;
        return queryInput;
    }

    public String returnQuery(){
        return query;
    }

    public void initializeCommonValues_core(String transaction, String caseNumber) throws Exception {
        Thread.sleep(1000);
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        String transactionData[] = transaction.split(":");
        String transactionType = transactionData[0];
        String client = transactionData[1];
        System.out.println("\nFor client : " + client + " fetching common value for: " + transactionType);
        if (transactionType.equalsIgnoreCase("DED") || transactionType.equalsIgnoreCase("DED ECK") || transactionType.equalsIgnoreCase("DED ESC")) {
            if (client.equalsIgnoreCase("Tracfone")&& transactionType.equalsIgnoreCase("DED ESC")){
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%'  and IntentType like '%ServiceRequest%' and Items like '%CWPF%'");
            } else {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%'  and IntentType like '%ServiceRequest%' and Items like '%DED%'");
            }
            commonValuesMap.put("IntentReferenceDEDClaim from IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));
           // System.out.println("\nValues INTENTREFERENCE: "+result.get(0).get("INTENTREFERENCE"));

            if ((client.equalsIgnoreCase("Cricket") && transactionType.equalsIgnoreCase("DED")) || client.equalsIgnoreCase("SPRINT")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference, PaymentProcessorReference, Amount from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntentReferenceDEDClaim from IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%CHARGE%' and CONVERT(FLOAT, Amount) > 1");
            } else {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference, PaymentProcessorReference, Amount from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntentReferenceDEDClaim from IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%CHARGE%'");
            }
            commonValuesMap.put("BillingGatewayReferenceDEDCharge from IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));
            commonValuesMap.put("PaymentProcessorReferenceDEDCharge from IncomingData.Event_Charge_Stage", result.get(0).get("PAYMENTPROCESSORREFERENCE"));
            commonValuesMap.put("ChargeAmount from from IncomingData.Event_Charge_Stage", result.get(0).get("AMOUNT"));
            //  System.out.println("\nValues BILLINGGATEWAYREFERENCE: " + result.get(0).get("BILLINGGATEWAYREFERENCE")+"\nAMOUNT: "+result.get(0).get("AMOUNT")+"\nPAYMENTPROCESSORREFERENCE: "+result.get(0).get("PAYMENTPROCESSORREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID,Amount from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntentReferenceDEDClaim from IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentIdCharge from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
            commonValuesMap.put("Amount from BillingAnalytics.Intent", result.get(0).get("AMOUNT"));
            //  System.out.println("\nValues INTENTID: "+result.get(0).get("INTENTID")+"\nAMOUNT: "+result.get(0).get("AMOUNT"));
        }
        if (transactionType.equalsIgnoreCase("DED Refund") || transactionType.equalsIgnoreCase("DED ECK Refund") || transactionType.equalsIgnoreCase("DEDRefund ESC")) {
            if (client.equalsIgnoreCase("Tracfone")&& transactionType.equalsIgnoreCase("DEDRefund ESC"))
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%Refund%' and Items like '%CWPF%'");
            else
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%Refund%' and Items like '%DED%'");
            commonValuesMap.put("IntReferenceDEDRefund from IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));
            //  System.out.println("\nValues INTENTREFERENCE: "+result.get(0).get("INTENTREFERENCE"));

            if ((client.equalsIgnoreCase("Cricket") && transactionType.equalsIgnoreCase("DED Refund")) || client.equalsIgnoreCase("SPRINT"))
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference, PaymentProcessorReference, Amount from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntReferenceDEDRefund from IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%REFUND%' and CONVERT(FLOAT, Amount) > 1");
            else
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference, PaymentProcessorReference, Amount from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntReferenceDEDRefund from IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%REFUND%'");
            commonValuesMap.put("BillingGatewayReferenceDEDCharge from IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));
            commonValuesMap.put("PaymentProcessorReferenceDEDCharge from IncomingData.Event_Charge_Stage", result.get(0).get("PAYMENTPROCESSORREFERENCE"));
            commonValuesMap.put("Amount from IncomingData.Event Charge Stage", result.get(0).get("AMOUNT"));
            //   System.out.println("\nValues BILLINGGATEWAYREFERENCE: " + result.get(0).get("BILLINGGATEWAYREFERENCE")+"\nAMOUNT: "+result.get(0).get("AMOUNT")+"\nPAYMENTPROCESSORREFERENCE: "+result.get(0).get("PAYMENTPROCESSORREFERENCE"));


            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID, Amount from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntReferenceDEDRefund from IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentID from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
            commonValuesMap.put("Amount from BillingAnalytics.Intent", result.get(0).get("AMOUNT"));
            //  System.out.println("\nValues INTENTID: "+result.get(0).get("INTENTID")+"\nAMOUNT: "+result.get(0).get("AMOUNT"));

        }

        if (transactionType.equalsIgnoreCase("SNR")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference, AdditionalInfo from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%RMAFee%' and Items like '%SNR%'");
            commonValuesMap.put("IntentReferenceSNR from IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference, PaymentProcessorReference from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntentReferenceSNR from IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%CHARGE%'");
            commonValuesMap.put("BillingGatewayReferenceSNRCharge from IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));
            commonValuesMap.put("PaymentProcessorReferenceSNRCharge from IncomingData.Event_Charge_Stage", result.get(0).get("PAYMENTPROCESSORREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntentReferenceSNR from IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentIdCharge from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
        }

        if (transactionType.equalsIgnoreCase("SNRRefund")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%Refund%' and Items like '%SNR%'");
            commonValuesMap.put("IntentReferenceSNRRefund from Basics.IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference, PaymentProcessorReference, Amount from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntentReferenceSNRRefund from Basics.IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%REFUND%'");
            commonValuesMap.put("BillingGatewayReferenceSNRRefund from IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));
            commonValuesMap.put("PaymentProcessorReferenceSNRRefund from IncomingData.Event_Charge_Stage", result.get(0).get("PAYMENTPROCESSORREFERENCE"));
            // commonValuesMap.put("Amount from IncomingData.Event Charge Stage", result.get(0).get("AMOUNT"));
           //  System.out.println("********** BillingGateway: "+ result.get(0).get("BILLINGGATEWAYREFERENCE")+"And PayemnetProcessor :"+ result.get(0).get("PAYMENTPROCESSORREFERENCE"));


            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID, Amount from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntentReferenceSNRRefund from Basics.IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentID from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
            commonValuesMap.put("Amount from BillingAnalytics.Intent", result.get(0).get("AMOUNT"));
          //  System.out.println("********* IntentID: "+result.get(0).get("INTENTID")+"And ");
        }

        if (transactionType.equalsIgnoreCase("PNR")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference, AdditionalInfo from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%RMAFee%' and Items like '%PNR%'");
            commonValuesMap.put("IntentReferencePNR from IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));
            //String intentReference[] = result.get(0).get("ADDITIONALINFO").split("SourceOrderNumber,");
            // commonValuesMap.put("IntentReferencePNRCharge from IncomingData.Event_Intent_Stage", intentReference[1]);
            //  System.out.println("\nValues INTENTREFERENCE: "+result.get(0).get("INTENTREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference, PaymentProcessorReference, Amount from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntentReferencePNR from IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%CHARGE%'");
            commonValuesMap.put("BillingGatewayReferencePNRCharge from IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));
            commonValuesMap.put("PaymentProcessorReferencePNRCharge from IncomingData.Event_Charge_Stage", result.get(0).get("PAYMENTPROCESSORREFERENCE"));
            commonValuesMap.put("ChargeAmount from from IncomingData.Event_Charge_Stage", result.get(0).get("AMOUNT"));
            // System.out.println("\nValues BILLINGGATEWAYREFERENCE: " + result.get(0).get("BILLINGGATEWAYREFERENCE")+"\nAMOUNT: "+result.get(0).get("AMOUNT")+"\nPAYMENTPROCESSORREFERENCE: "+result.get(0).get("PAYMENTPROCESSORREFERENCE"));


            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID, Amount from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntentReferencePNR from IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentIdCharge from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
            commonValuesMap.put("Amount from BillingAnalytics.Intent", result.get(0).get("AMOUNT"));
            // System.out.println("\nValues INTENTID: "+result.get(0).get("INTENTID")+"\nAMOUNT: "+result.get(0).get("AMOUNT"));
        }

        if (transactionType.equalsIgnoreCase("PNRRefund")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%Refund%' and Items like '%PNR%'");
            commonValuesMap.put("IntentReferencePNRRefund from Basics.IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference, PaymentProcessorReference from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntentReferencePNRRefund from Basics.IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%REFUND%'");
            commonValuesMap.put("BillingGatewayReferencePNRRefund from Basics.IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));
            commonValuesMap.put("PaymentProcessorReferencePNRRefund from Basics.IncomingData.Event_Charge_Stage", result.get(0).get("PAYMENTPROCESSORREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID, Amount from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntentReferencePNRRefund from Basics.IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentIDPNRRefund from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
            commonValuesMap.put("Amount from BillingAnalytics.Intent", result.get(0).get("AMOUNT"));

        }

        if (transactionType.equalsIgnoreCase("DeductibleClaim")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%ServiceRequest%' and Items like '%DED%'");
            commonValuesMap.put("IntentReferenceDEDClaim from IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntentReferenceDEDClaim from IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("BillingGatewayReferenceDEDCharge from IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntentReferenceDEDClaim from IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentIdCharge from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
        }

        if (transactionType.equalsIgnoreCase("DeductibleRefund") || transactionType.equalsIgnoreCase("Telcel ISP DEDRefund")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%Refund%' and Items like '%DED%'");
            commonValuesMap.put("IntReferenceDEDRefund from IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntReferenceDEDRefund from IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("BillingGatewayReferenceDEDCharge from IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID, Amount from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntReferenceDEDRefund from IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentID from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
            commonValuesMap.put("Amount from BillingAnalytics.Intent", result.get(0).get("AMOUNT"));

        }
        if (transactionType.equalsIgnoreCase("BTASNR")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference, AdditionalInfo from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%RMAFee%' and Items like '%SNR%'");
            commonValuesMap.put("IntentReferenceSNR from IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntentReferenceSNR from IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%CHARGE%'");
            commonValuesMap.put("BillingGatewayReferenceSNRCharge from IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID, Amount from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntentReferenceSNR from IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentIdCharge from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
            commonValuesMap.put("Amount from BillingAnalytics.Intent", result.get(0).get("AMOUNT"));

        }
        if (transactionType.equalsIgnoreCase("BTASNRRefund")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%Refund%' and Items like '%SNR%'");
            commonValuesMap.put("IntentReferenceSNRRefund from Basics.IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntentReferenceSNRRefund from Basics.IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%REFUND%'");
            commonValuesMap.put("BillingGatewayReferenceSNRRefund from IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID, Amount from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntentReferenceSNRRefund from Basics.IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentID from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
            commonValuesMap.put("Amount from BillingAnalytics.Intent", result.get(0).get("AMOUNT"));
        }

        if (transactionType.equalsIgnoreCase("BTAPNR")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference, AdditionalInfo from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%RMAFee%' and Items like '%PNR%'");
            commonValuesMap.put("IntentReferencePNR from IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntentReferencePNR from IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%CHARGE%'");
            commonValuesMap.put("BillingGatewayReferencePNRCharge from IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID, Amount from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntentReferencePNR from IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentIdCharge from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
            commonValuesMap.put("Amount from BillingAnalytics.Intent", result.get(0).get("AMOUNT"));

        }

        if (transactionType.equalsIgnoreCase("BTAPNRRefund")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentReference from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%' and IntentType like '%Refund%' and Items like '%PNR%'");
            commonValuesMap.put("IntentReferencePNRRefund from Basics.IncomingData.Event_Intent_Stage", result.get(0).get("INTENTREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select BillingGatewayReference, PaymentProcessorReference from Basics.IncomingData.Event_Charge_Stage where IntentReference like '%" + commonValuesMap.get("IntentReferencePNRRefund from Basics.IncomingData.Event_Intent_Stage") + "%' and TransactionType like '%REFUND%'");
            commonValuesMap.put("BillingGatewayReferencePNRRefund from Basics.IncomingData.Event_Charge_Stage", result.get(0).get("BILLINGGATEWAYREFERENCE"));

            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select IntentID, Amount from Basics.BillingAnalytics.Intent where ModifiedBy like '%" + commonValuesMap.get("IntentReferencePNRRefund from Basics.IncomingData.Event_Intent_Stage") + "%'");
            commonValuesMap.put("IntentIDPNRRefund from Basics.BillingAnalytics.Intent", result.get(0).get("INTENTID"));
            commonValuesMap.put("Amount from BillingAnalytics.Intent", result.get(0).get("AMOUNT"));

        }
        System.out.println("Common value map for " + transactionType + ":-" + commonValuesMap);
    }

    public void printResultSet(List<HashMap<String, String>> result) {
        if (result.size() == 0) {
            System.out.println("No rows to print!");
            return;
        }
        Set<String> set = result.get(0).keySet();
        Iterator<String> it = set.iterator();
        int size[] = new int[set.size()];
        int minLen = 5;
        for (int j = 0; j < set.size(); j++) {
            size[j] = minLen;
            String key = it.next();
            if (key.length() > size[j]) {
                size[j] = key.length();
            }
        }
        for (int i = 0; i < result.size(); i++) {
            it = set.iterator();
            for (int j = 0; j < set.size(); j++) {

                String text = result.get(i).get(it.next());
                if (text.length() > size[j]) {
                    size[j] = text.length();
                }
            }
        }
        //--------------------
        it = set.iterator();
        for (int j = 0; j < set.size(); j++) {
            String key = it.next();
            int len = size[j];
            System.out.format("|  %1$-" + len + "s  ", key);
            if (j == set.size() - 1)
                System.out.format("|");
        }

        for (int i = 0; i < result.size(); i++) {
            it = set.iterator();
            System.out.println();
            for (int j = 0; j < set.size(); j++) {
                String text = result.get(i).get(it.next());
                int len = size[j];
                System.out.format("|  %1$-" + len + "s  ", text);
                if (j == set.size() - 1)
                    System.out.format("|");
            }
        }
        System.out.println();
    }

    /**
     * Execute given query in data base
     *
     * @param query
     * @return
     * @throws Exception
     */
    public List<HashMap<String, String>> executeGivenQuery(String query) throws Exception {
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3UK"))
            return DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), getQuery(query, IncidentPathPage.caseID));
        else
            return DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), getQuery(query, CaptureIncidentPage.claimId));
    }

    /**
     * Execute databse update/insert queries
     *
     * @param updateQuery
     * @return
     * @throws Exception
     */
    public int executeGivenUpdateQuery(String updateQuery) throws Exception {
        int rowAffected;
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3UK"))
            rowAffected = DatabaseUtils.executeUpdateSQLQuery(DatabaseUtils.getConnection(), getQuery(updateQuery, IncidentPathPage.caseID));
        else
            rowAffected = DatabaseUtils.executeUpdateSQLQuery(DatabaseUtils.getConnection(), getQuery(updateQuery, CaptureIncidentPage.claimId));

        System.out.println("row affected =" + rowAffected);
        return rowAffected;
    }

    /**
     * retry for fetching common values
     *
     * @param transactionType
     * @param caseNumber
     */
    public void initializeCommonValues(String transactionType, String caseNumber) throws Exception {
        // System.out.println("CASE NUMBER FOR 3UK: "+caseNumber);
         CommonUtilities.waitTime(120);
        int retryCount = 15;
        for (int i = 1; i <= retryCount; i++) {
            try {
                 Thread.sleep(10000);
                databaseValidationUtil.initializeCommonValues_core(transactionType, caseNumber);
                break;
            } catch (Exception e) {
                System.out.println("\nretrying for fetch common values =" + i);
                   CommonUtilities.waitTime(60);
                if (retryCount == i) {
                    throw e;
                }
            }
        }
    }

}