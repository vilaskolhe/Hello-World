package com.asurion.pages;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.horizon.generic.DataBaseHandler;
import com.asurion.util.Generic;
import com.asurion.util.EUDBHandler;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.HashMap;

import static org.junit.Assert.assertTrue;

public class IdentifyCustomerPage extends BasePage {
    private UIElement clientChannel = new UIElement(UIType.RadioButton, UILocatorType.ID, "ClientChannelNumber");
    private UIElement searchField = new UIElement(UIType.TextBox, UILocatorType.CSS, "#SearchStringPhone");
    //  private UIElement searchBtn = new UIElement(UIType.Button, UILocatorType.CSS, "div[class='content set-width-auto layout-content-inline content-inline hoz_searchBtn ']>div>div>div>span>button[class='SearchButtons pzhc']");
   // private UIElement searchBtn = new UIElement(UIType.Button, UILocatorType.CSS, "button.Hoz_New_Gray_Btn.pzhc");
    private UIElement searchBtn = new UIElement(UIType.Button, UILocatorType.CSS, ".Hoz_New_Gray_Search_Btn.pzhc");
    private UIElement customersOnAccount = new UIElement(UIType.RadioButton, UILocatorType.Name, "$PpyWorkPage$pVerifyConsumer$pSelectedConsumer");
    private UIElement verifyEnrolled = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//input[@name='$PD_CustomerAgmtAddress$pSelectedAddress']");
    // private UIElement continueBtn = new UIElement(UIType.Button, UILocatorType.CSS, "button.InFormContinueButton.pzhc");
    private UIElement continueBtn = new UIElement(UIType.Button, UILocatorType.CSS, "button.Hoz_New_Continue_Btn.pzhc");
    private UIElement firstName = new UIElement(UIType.TextBox, UILocatorType.CSS, "#PrimaryFirstName");
    //    private UIElement lastName = new UIElement(UIType.TextBox,UILocatorType.Xpath,"//input[@id='PrimaryLastName']");
    private UIElement lastName = new UIElement(UIType.TextBox, UILocatorType.CSS, "#PrimaryLastName");
    private UIElement authorisedUserTitle = new UIElement(UIType.RadioButton, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div/div/div/div[1]/div/div/div/div/div[2]/div/div/div/div[2]/span/label");
    private UIElement customersAccountHolder = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "//input[@name='$PpyWorkPage$pVerifyConsumer$pSelectedConsumer']");
    private UIElement cpmInteractionDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmInteractionDivFrame");
    private UIElement diaction = new UIElement(UIType.Frame, UILocatorType.Name, "DIACTION");

    private UIElement securityPIN = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//a[1]/span/table/tbody/tr/td/nobr[contains(text(),'PIN')]");
    private UIElement answerPIN = new UIElement(UIType.TextBox, UILocatorType.CSS, "div>span>input#HVPINAnswer");
    private UIElement securityQA = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//a/span/table/tbody/tr/td/nobr[contains(text(),'Security Q&A')]");
    private UIElement caseSearchField = new UIElement(UIType.TextBox, UILocatorType.ID, "SearchStringWorkID");
    private UIElement otherAccount = new UIElement(UIType.RadioButton, UILocatorType.Name, "$PpyWorkPage$pVerifyConsumer$pEnterOtherUser");
    private UIElement verifyByPrimaryHolder = new UIElement(UIType.RadioButton, UILocatorType.Xpath, ".//*[@id='PACVerified']");

    //3UK
    private UIElement listClient = new UIElement(UIType.ListBox, UILocatorType.ID, "ClientProfileID");
    private UIElement myWorkRefresh = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div/div/table/tbody/tr/td[3]/nobr/span/a");
    private UIElement listCountryCode = new UIElement(UIType.ListBox, UILocatorType.ID, "CountryCallingCode");
    private UIElement searchBtnEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='201607261021550754119314']");



    public void searchUsingMDN(String mdn) throws Exception {
        ArrayList<HashMap<String, String>> customerDetails = null;
         /*   String query ="select Customer.Full_Name as CustomerName, First_Name as FirstName, Last_Name as LastName, Customer_Identification.IDENTIFICATION_NBR as NATIONALID, \n"+
                    "Asset.MOBILE_DEVICE_NBR as MDN, Asset.MOBILE_EQUIPMENT_ID as IMEI, Client_Account.EXTERNAL_REFERENCE_ID as BAN,  \n"+
                    "ADDRESS_TYPE_CODE as AddressCode, Address_Line_1 as AddressLine1, Address_Line_2 as AddressLine2, City_Name as City, Postal_Code as PostalCode, Agreement.CLIENT_PRODUCT_SKU_NBR as ProductCode,\n"+
                    "Agreement_Purchase.REGION_CODE as Region,   \n"+
                    "Asset_Make_Name as MAKE, Asset_Model_NBR as MODEL,Asset_Catalog.ASSET_CATALOG_DESC as ModelName, Asset.Asset_catalog_id as AssetCatalogId, Country.COUNTRY_NAME as COUNTRY\n"+
                    "from Asset.asset   \n"+
                    "left outer join Asset.Asset_Catalog on Asset_catalog.Asset_Catalog_Id = Asset.Asset_Catalog_Id\n"+
                    "left outer join Asset.Asset_Model on Asset_Model.Asset_Model_Id = Asset_Catalog.Asset_Model_ID   \n"+
                    "left outer join Asset.Asset_Make on Asset_Make.Asset_Make_Id = Asset_Catalog.Asset_Make_ID and  Asset_Make.Asset_Make_Id =  Asset_Model.Asset_Make_Id\n"+
                    "left outer join  Asset.Asset_Purchase on Asset_Purchase.ASSET_ID = Asset.ASSET_ID -- Asset Purchase  \n"+
                    "left outer join client.Client_Account on Client_Account.CLIENT_ACCOUNT_ID = Asset.CLIENT_ACCOUNT_ID -- Client Account\n"+
                    "left outer join Asset.Agreement on Agreement.CLIENT_ACCOUNT_ID = Client_Account.CLIENT_ACCOUNT_ID -- Agreement  \n"+
                    "left outer join Asset.Agreement_Purchase on Agreement_Purchase.AGREEMENT_ID = Agreement.AGREEMENT_ID -- Agreement Purchase\n"+
                    "left outer join Asset.Agreement_Asset_Xref on Agreement_Asset_Xref.AGREEMENT_ID = Agreement.AGREEMENT_ID   \n"+
                    "and Agreement_Asset_Xref.ASSET_ID = Asset.ASSET_ID -- Agreement Asset  \n"+
                    "left outer join Customer.Customer_Agreement_Role on Customer_Agreement_Role.Agreement_ID = Agreement.Agreement_ID   -- CustomerAgreementRole \n"+
                    "left outer join Customer.Customer on Customer.Customer_ID = Customer_Agreement_Role.CUSTOMER_ID -- Customer    \n"+
                    "left outer join Customer.Customer_Identification on Customer_Identification.Customer_Id = Customer.Customer_ID -- Customer Identifiers \n"+
                    "left outer join client.Client_Account_Address_Usage on Client_Account_Address_Usage.Client_Account_Id = Client_Account.Client_Account_ID    \n"+
                    "left outer join Reference.Address on Address.Address_Id = Agreement.Address_Id and Address.Address_Id = Client_Account_Address_Usage.Address_ID  \n"+
                    "left outer join Reference.Country on Country.Country_Code = Address.COUNTRY_CODE     \n"+
                    "where Mobile_Device_NBr='"+mdn+"'";
                    */
        String query = "select DAL.XXASU_DECRYPT_RESTWS_CALL(Customer.Full_Name) as CustomerName, DAL.XXASU_DECRYPT_RESTWS_CALL(First_Name) as FirstName, DAL.XXASU_DECRYPT_RESTWS_CALL(Last_Name) as LastName, Customer_Identification.IDENTIFICATION_NBR as NATIONALID, \n" +
                "DAL.XXASU_DECRYPT_RESTWS_CALL(Asset.MOBILE_DEVICE_NBR) as MDN, DAL.XXASU_DECRYPT_RESTWS_CALL(Asset.MOBILE_EQUIPMENT_ID) as IMEI, DAL.XXASU_DECRYPT_RESTWS_CALL(Client_Account.EXTERNAL_REFERENCE_ID) as BAN,\n" +
                "ADDRESS_TYPE_CODE as AddressCode, DAL.XXASU_DECRYPT_RESTWS_CALL(Address_Line_1) as AddressLine1, DAL.XXASU_DECRYPT_RESTWS_CALL(Address_Line_2) as AddressLine2, City_Name as City, Postal_Code as PostalCode, Agreement.CLIENT_PRODUCT_SKU_NBR as ProductCode,\n" +
                "Agreement_Purchase.REGION_CODE as Region,  \n" +
                "Asset_Make_Name as MAKE, Asset_Model_NBR as MODEL,Asset_Catalog.ASSET_CATALOG_DESC as ModelName, Asset.Asset_catalog_id as AssetCatalogId, Country.COUNTRY_NAME as COUNTRY\n" +
                ",DAL.XXASU_DECRYPT_RESTWS_CALL(CP.EMAIL_ADDRESS) as EMAIL,Asset_Color.ASSET_COLOR_NAME as COLOR,State_province.STATE_PROVINCE_CODE as STATE \n" +
                "from Asset.asset   \n" +
                "left outer join Asset.Asset_Catalog on Asset_catalog.Asset_Catalog_Id = Asset.Asset_Catalog_Id\n" +
                "left outer join Asset.Asset_Color  ON Asset_color.Asset_color_Id = Asset_catalog.Asset_Color_Id\n" +
                "left outer join Asset.Asset_Model on Asset_Model.Asset_Model_Id = Asset_Catalog.Asset_Model_ID   \n" +
                "left outer join Asset.Asset_Make on Asset_Make.Asset_Make_Id = Asset_Catalog.Asset_Make_ID and  Asset_Make.Asset_Make_Id =  Asset_Model.Asset_Make_Id\n" +
                "left outer join  Asset.Asset_Purchase on Asset_Purchase.ASSET_ID = Asset.ASSET_ID -- Asset Purchase  \n" +
                "left outer join client.Client_Account on Client_Account.CLIENT_ACCOUNT_ID = Asset.CLIENT_ACCOUNT_ID -- Client Account\n" +
                "left outer join Asset.Agreement on Agreement.CLIENT_ACCOUNT_ID = Client_Account.CLIENT_ACCOUNT_ID -- Agreement  \n" +
                "left outer join Asset.Agreement_Purchase on Agreement_Purchase.AGREEMENT_ID = Agreement.AGREEMENT_ID -- Agreement Purchase\n" +
                "left outer join Asset.Agreement_Asset_Xref on Agreement_Asset_Xref.AGREEMENT_ID = Agreement.AGREEMENT_ID  \n" +
                "and Agreement_Asset_Xref.ASSET_ID = Asset.ASSET_ID -- Agreement Asset \n" +
                "left outer join Customer.Customer_Agreement_Role on Customer_Agreement_Role.Agreement_ID = Agreement.Agreement_ID   -- CustomerAgreementRole \n" +
                "left outer join Customer.Customer on Customer.Customer_ID = Customer_Agreement_Role.CUSTOMER_ID -- Customer    \n" +
                "left outer join Customer.Customer_Identification on Customer_Identification.Customer_Id = Customer.Customer_ID -- Customer Identifiers\n" +
                "left outer join client.Client_Account_Address_Usage on Client_Account_Address_Usage.Client_Account_Id = Client_Account.Client_Account_ID    \n" +
                "left outer join Reference.Address on Address.Address_Id = Agreement.Address_Id and Address.Address_Id = Client_Account_Address_Usage.Address_ID  \n" +
                "left outer join Reference.Country on Country.Country_Code = Address.COUNTRY_CODE \n" +
                "left outer join Reference.State_province on State_province.STATE_PROVINCE_CODE=Address.STATE_PROVINCE_CODE\n" +
                "LEFT OUTER JOIN REFERENCE.CONTACT_POINT_USAGE CPU ON CPU.CLIENT_ACCOUNT_ID=asset.CLIENT_ACCOUNT_ID\n" +
                "LEFT OUTER JOIN REFERENCE.CONTACT_POINT CP ON CPU.CONTACT_POINT_ID =CP.CONTACT_POINT_ID\n" +
//                "where Mobile_Device_NBr='" + mdn + "'";
                "where Mobile_Device_NBr=dal.XXASU_ENCRYPT_RESTWS_CALL('voltage:fpe:1:enterprise.sprint@asurion.com'," + mdn + ") and Address.STATE_PROVINCE_CODE is NOT NULL";

       // System.out.println(query);
        int size = 0;
        int i = 0;
        boolean sflag = false;
        do {
            customerDetails = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            if (customerDetails.size() > 0) {
                sflag = true;
                break;
            }
            i++;
        } while (size == 0 && i <= 1500);
        //Put all data of customer from DAL DB to Hashmap
        if (customerDetails.size() == 0) {
            assertTrue("MDN is not present in DAL DB " + CustomerDetails.customerData.get("MDN") + "", false);
        }
        CustomerDetails.customerData.putAll(customerDetails.get(0));
        System.out.println(CustomerDetails.customerData);
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("TELCEL")) {
            String[] employeeDetails;
            String customerName = CustomerDetails.customerData.get("FIRSTNAME");
            String customerFullName = CustomerDetails.customerData.get("CUSTOMERNAME");
            if (customerName.contains(" ")) {
                employeeDetails = customerName.split(" ");
                System.out.println("First name :: " + employeeDetails[0]);
                System.out.println("Last  name :: " + employeeDetails[1]);
            } else {
                employeeDetails = customerFullName.split(" ");
            }
            if (employeeDetails.length > 2) {
                System.out.println("Last  name :: " + employeeDetails[2]);
                employeeDetails[1] = employeeDetails[2];
            }
            if (employeeDetails.length < 2)
                if (!customerFullName.contains(" "))
                    CustomerDetails.customerData.put("LASTNAME", customerFullName);
        }

        if (driver.checkObjectExists(searchField, ApplicationConfiguration.getWaitForElementTimeout())) {
            CommonUtilities.waitTime(10);
            // driver.waitElementToBeClickable(searchBtn);
            driver.type(searchField, mdn);
        } else
            Assert.assertTrue("searchField is not found on identity customer page", false);

        System.out.println("Mdn : " + mdn);
        // CommonUtilities.waitTime(100);*/
        driver.javaScriptClick(searchBtn);

    }

    public void searchMDN(String mdn) throws Exception{
        if (driver.checkObjectExists(searchField, ApplicationConfiguration.getWaitForElementTimeout())) {
       // CommonUtilities.waitTime(10);
        driver.type(searchField, mdn);
    } else
            Assert.assertTrue("searchField is not found on identity customer page", false);

        System.out.println("Mdn : " + mdn);
        driver.javaScriptClick(searchBtn);
    }


    public void continueClaim() throws Exception {
        CommonUtilities.waitTime(15);
        if (driver.waitForElementPresenceWithTimeOut(continueBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueBtn);
        } else {
            Assert.assertTrue("continue button not found on identify customer page", false);
        }

        CommonUtilities.waitTime(7);
    }

    // Author: Nandini  Created On: 13/07/2016
    public void verifyCallerNameAndAddress() throws Exception {
        CommonUtilities.waitTime(5);

        if (driver.waitForElementPresenceWithTimeOut(customersOnAccount, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptScrollAndClick(customersOnAccount);
        } else {
            Assert.assertTrue("Account Holder not found on Identify customer page", false);
        }
        CommonUtilities.waitTime(10);
        if (driver.waitForElementPresenceWithTimeOut(verifyEnrolled, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(verifyEnrolled);
        } else {
            Assert.assertTrue("Enrolled Address not found on customer info validation", false);
        }


    }

    //Account holder
    public void verifyCaller(String callerData, String testType) throws Exception {

        CommonUtilities.waitTime(1);

        if (callerData.equalsIgnoreCase("Account Holder")) {
            if (driver.waitForElementPresenceWithTimeOut(customersOnAccount, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptScrollAndClick(customersOnAccount);
            } else {
                Assert.assertTrue("Account Holder not found on Identify customer page", false);
            }
        } else if (callerData.equalsIgnoreCase("Authorised User")) {
            if (driver.waitForElementPresenceWithTimeOut(authorisedUserTitle, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptScrollAndClick(authorisedUserTitle);
            } else {
                Assert.assertTrue("Authorised User not found on Identify customer page", false);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(otherAccount, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptScrollAndClick(otherAccount);
            } else {
                Assert.assertTrue("otherAccount Holder not found on Identify customer page", false);
            }
            if (driver.waitForElementPresenceWithTimeOut(firstName, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.type(firstName, callerData.split(" ")[0]);
            } else {
                Assert.assertTrue("first Name not found on Identify customer page", false);
            }
            if (driver.waitForElementPresenceWithTimeOut(lastName, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(lastName);
                CommonUtilities.waitTime(1);
                driver.type(lastName, callerData.split(" ")[1]);
            } else {
                Assert.assertTrue("last Name not found on Identify customer page", false);
            }
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("kpn")) {
                driver.click(verifyByPrimaryHolder);

            }

        }
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Sprint")) {
            if (driver.waitForElementPresenceWithTimeOut(securityPIN, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(securityPIN);
                driver.type(answerPIN, "1234");

            } else {
               Assert.assertTrue("Enrolled Address not found on customer info validation", false);
               // System.out.println("Security PIN not found on customer info validation");
            }
        }
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("NTELOS") || ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers") || ApplicationConfiguration.getClient().equalsIgnoreCase("Fido") || ApplicationConfiguration.getClient().equalsIgnoreCase("Freedom")|| ApplicationConfiguration.getClient().equalsIgnoreCase("Tracfone")||ApplicationConfiguration.getClient().equalsIgnoreCase("Cricket")||ApplicationConfiguration.getClient().equalsIgnoreCase("TELUS")||ApplicationConfiguration.getClient().equalsIgnoreCase("KOODO")) {
            CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(verifyEnrolled, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(verifyEnrolled);
            } else {
                Assert.assertTrue("Enrolled Address not found on customer info validation", false);
            }
        }
    }

    public void verifyCallerAfterResume() throws Exception {

        CommonUtilities.waitTime(4);


        if (driver.waitForElementPresenceWithTimeOut(customersAccountHolder, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptScrollAndClick(customersAccountHolder);
        } else {
            Assert.assertTrue("Account Holder not found on Identify customer page", false);
        }
    }

    public void selectClientAndCountryAndSearchEnrolledMDNEU(String country, String client) throws Exception {
            CommonUtilities.waitTime(10);
            driver.switchToDefaultContent();
            driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
            driver.switchToFrame(diaction);
            CommonUtilities.waitTime(10);
            if (driver.waitForElementPresenceWithTimeOut(listClient, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.select(listClient, "3UK");
                CommonUtilities.waitTime(3);
                driver.select(listClient, client);
                System.out.println("Selected client " + client);
            } else {
                System.out.println("Client list box is not displayed");
                org.junit.Assert.assertTrue("Client list box is not displayed", false);
            }

            if (client.equalsIgnoreCase("kpn")) {
                CommonUtilities.waitTime(5);
                driver.switchToDefaultContent();
                driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
                driver.switchToFrame(diaction);
                if (driver.elementExists(listCountryCode)) {
                    driver.select(listCountryCode, country);
                    System.out.println("Selected country code " + country);
                } else {
                    System.out.println("country code list is not displayed");
//                    org.junit.Assert.assertTrue("country code list is not displayed", false);
                }
            }

            if (driver.elementExists(searchField)) {
              //  String mdn="05554120694";
                String mdn = Generic.getValuesFromGlobals("DAL_MDN");
                System.out.println("MDN for 3UK : "+mdn);
                driver.type(searchField, mdn);
            } else {
                System.out.println("Text Box MDN is not displayed");
                org.junit.Assert.assertTrue("Text Box MDN is not displayed", false);
            }

            CommonUtilities.waitTime(2);
            if (driver.elementExists(searchBtnEU)) {
                driver.javaScriptClick(searchBtnEU);
                System.out.println("Clicked button Search");
            } else {
                System.out.println("Search button is not displayed");
                org.junit.Assert.assertTrue("Search button is not displayed", false);
            }
    }

    public void waitAndCheckForServiceRequestStatusComplete_EU() throws Exception {
        String status = "SHIP";
        CommonUtilities.waitTime(10);
        String deviceID = Generic.getValuesFromGlobals("MDN");
        //String trackingNumber = Generic.getValuesFromGlobals("TRACKINGNUMBER");
        String salesId = Generic.getValuesFromGlobals("SALESORDERNUMBER");
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String query = "select * from customer.shipping_order inner join asset.asset on shipping_order.asset_id=asset.asset_id where  DAX_SALES_ORDER_ID = '" + salesId + "' and SHIPPING_STATUS_CODE = '" + status + "'";
        System.out.println("The Query is - " + query);
        CommonUtilities.waitTime(120);
        statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        int i = 0;
        while ((statusData.size() == 0) && i < 200) {
            CommonUtilities.waitTime(15);
            driver.click(listClient);
            statusData = EUDBHandler.executeSQLQuery(EUDBHandler.getDBConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
            System.out.println("In DAL, CaseStatus is not '" + status + "' yet, Querying since " + ((120) + (i * 3)) + " seconds.");
            i++;
            CommonUtilities.waitTime(3);
            if (i == 200) {
                System.out.println("In DAL, No record found  for MDN - " + deviceID + " with status " + status);
                assertTrue("In DAL, No record found  for MDN - " + deviceID + " with status " + status, false);
            }
        }
        System.out.println("Record found in Shipping Order table for MDN - " + deviceID + " with status " + status);
    }

    /**
     * Created by Nandini Mujudmar.
     * Method is use to refresh page to avoid session timeout.
     * Wait for request to be completed by clicking on My Work Refresh icon
     */
    public void waitAndCheckForRequestToBeCompleted(){
        CommonUtilities.waitTime(3);
        System.out.println("Refreshing Session");
        driver.click(myWorkRefresh);
    }



}