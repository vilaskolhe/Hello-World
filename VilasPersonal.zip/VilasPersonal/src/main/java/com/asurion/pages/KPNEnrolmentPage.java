package com.asurion.pages;

import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.DateUtil;
import com.asurion.util.Generic;
import com.opencsv.CSVWriter;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Jitendra Kumar Tiwary on 22nd April 2016
 */
public class KPNEnrolmentPage {

    private static String CurrentFile;
    private static String currentDate = getCurrentTimeStampDate();
    private static String currentDateTime = getCurrentTimeStamp();
    public static String[] Input = new String[110];
    public static LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();

    public static void getKPNDefaultData() {
        hm.put("CUSTOMERNUMBER", getUniqueCUSTOMERNUMBER_EU());
        hm.put("COUNTRYCODE", "+31");
        hm.put("MDN", getUniqueMDN_EU());
        hm.put("CLIENTBRAND", "KPN");
        hm.put("CUSTOMERTYPE", "CM");
        hm.put("KVKNUMBER", Generic.getValuesFromGlobals("MDN") + "1");
        hm.put("BUSINESSNAME", "MONEY PLANT");
        hm.put("GENDER", "M");
        hm.put("INITIALS", "E");
        hm.put("MAIDENMIDDLENAME", "MM");
        hm.put("MAIDENLASTNAME", "ML");
        hm.put("MIDDLENAME", "EUQA");
        hm.put("LASTNAME", "Automation");
        hm.put("EMAIL", "kpn666@test.com");
        hm.put("DOB", "19830128");
        hm.put("GENDERAUTHORISEDUSER", "M");
        hm.put("INITIALSAUTHORISEDUSER", "J");
        hm.put("MIDDLENAMEAUTHUSER", "SUPER");
        hm.put("LASTNAMEAUTHUSER", "USER");
        hm.put("AUTHEMAIL", "super.user@email.com");
        hm.put("STREET", "Maanplein");
        hm.put("HOUSENUMBER", "323");
        hm.put("SUFFIX", "1F");
        hm.put("POSTALCODE", "6211PL"); //	"5162CK"
        hm.put("CITY", "Den Haag");
        hm.put("COUNTRY", "NL");
        hm.put("ENROLLMENTDATE", DateUtil.getFormattedDatetime("yyyyMMdd", DateUtil.getModifiedDateTime("DAY", -365)));
        hm.put("CONTRACTSTARTDATE", DateUtil.getFormattedDatetime("yyyyMMdd", DateUtil.getModifiedDateTime("DAY", -365)));
        hm.put("INSURANCEPRODUCTS", "Schade2");
        hm.put("ASSETSKU", "872843");
        hm.put("IMEI", getUniqueIMEI_EU());
        hm.put("ISINSUREDDEVICE", "Y");
        hm.put("ASSETPURCHASEDATE", DateUtil.getFormattedDatetime("yyyyMMdd", DateUtil.getModifiedDateTime("DAY", -365)));
        hm.put("SIMTYPE", "DUO");
        hm.put("TRANSACTIONTYPE", "Add");
        hm.put("PORTINGSTATUS", "N");
        hm.put("BILLINGCYCLE", "12");
        hm.put("ACCOUNTIDFR", "Y");
        hm.put("SALESCHANNEL", "ONLINE");
        hm.put("DEALERCODE", "RETAIL");
        hm.put("SALESPERSON", "WEB310");
        hm.put("SCOMMSCONSENT", "N");


        hm.put("SNAPITERATIONNUMBER", "1");
        hm.put("CANCEL_CUSTOMERNUMBER", Generic.getValuesFromGlobals("CUSTOMERNUMBER"));
        hm.put("CANCEL_COUNTRYCODE", "+31");
        hm.put("CANCEL_MDN", Generic.getValuesFromGlobals("MDN"));
        hm.put("CANCEL_CLIENTBRAND", "KPN");
        hm.put("CANCEL_CUSTOMERTYPE", "CM");
        hm.put("CANCEL_INSURANCESTARTDATE", "");
        hm.put("CANCEL_ASSURIONAGREEMENTE", "");
        hm.put("CANCEL_ASSETSKU", "872843");
        hm.put("CANCEL_CANCELLATIONRESAON", "1");
        hm.put("CANCEL_CANCELDATE", currentDate);
        //hm.put("CANCEL_CANCELDATE",	DateUtil.getFormattedDatetime("yyyyMMdd", DateUtil.getModifiedDateTime("DAY", -1)));


    }

    public static void getKPNMultiDefaultData() {

        //MCCS - Data setup
        hm.put("CUSTOMERNUMBER-MCCS", getUniqueCUSTOMERNUMBER_EU());
        Generic.setGlobals("CUSTOMERNUMBER-MCCS", Generic.getValuesFromGlobals("CUSTOMERNUMBER"));
        hm.put("COUNTRYCODE-MCCS", "+31");
        hm.put("MDN-MCCS", getUniqueMDN_EU());
        Generic.setGlobals("MDN-MCCS", Generic.getValuesFromGlobals("MDN"));
        hm.put("CLIENTBRAND-MCCS", "KPN");
        hm.put("CUSTOMERTYPE-MCCS", "CM");
        hm.put("KVKNUMBER-MCCS", Generic.getValuesFromGlobals("MDN") + "1");
        hm.put("BUSINESSNAME-MCCS", "MONEY PLANT");
        hm.put("GENDER-MCCS", "M");
        hm.put("INITIALS-MCCS", "E");
        hm.put("MAIDENMIDDLENAME-MCCS", "MM");
        hm.put("MAIDENLASTNAME-MCCS", "ML");
        hm.put("MIDDLENAME-MCCS", "EUQA");
        hm.put("LASTNAME-MCCS", "Automation");
        hm.put("EMAIL-MCCS", "kpn666@test.com");
        hm.put("DOB-MCCS", "19830128");
        hm.put("GENDERAUTHORISEDUSER-MCCS", "M");
        hm.put("INITIALSAUTHORISEDUSER-MCCS", "J");
        hm.put("MIDDLENAMEAUTHUSER-MCCS", "SUPER");
        hm.put("LASTNAMEAUTHUSER-MCCS", "USER");
        hm.put("AUTHEMAIL-MCCS", "super.user@email.com");
        hm.put("STREET-MCCS", "Maanplein");
        hm.put("HOUSENUMBER-MCCS", "323");
        hm.put("SUFFIX-MCCS", "1F");
        hm.put("POSTALCODE-MCCS", "6211PL"); //	"5162CK"
        hm.put("CITY-MCCS", "Den Haag");
        hm.put("COUNTRY-MCCS", "NL");
        hm.put("ENROLLMENTDATE-MCCS", DateUtil.getFormattedDatetime("yyyyMMdd", DateUtil.getModifiedDateTime("DAY", -365)));
        hm.put("CONTRACTSTARTDATE-MCCS", DateUtil.getFormattedDatetime("yyyyMMdd", DateUtil.getModifiedDateTime("DAY", -365)));
        hm.put("INSURANCEPRODUCTS-MCCS", "Schade2");
        hm.put("ASSETSKU-MCCS", "872736");//872843
        hm.put("IMEI-MCCS", getUniqueIMEI_EU());
        Generic.setGlobals("IMEI-MCCS", Generic.getValuesFromGlobals("IMEI"));
        hm.put("ISINSUREDDEVICE-MCCS", "Y");
        hm.put("ASSETPURCHASEDATE-MCCS", DateUtil.getFormattedDatetime("yyyyMMdd", DateUtil.getModifiedDateTime("DAY", -365)));
        hm.put("SIMTYPE-MCCS", "DUO");
        hm.put("TRANSACTIONTYPE-MCCS", "Add");
        hm.put("PORTINGSTATUS-MCCS", "N");
        hm.put("BILLINGCYCLE-MCCS", "12");
        hm.put("ACCOUNTIDFR-MCCS", "Y");
        hm.put("SALESCHANNEL-MCCS", "ONLINE");
        hm.put("DEALERCODE-MCCS", "RETAIL");
        hm.put("SALESPERSON-MCCS", "WEB310");
        hm.put("SCOMMSCONSENT-MCCS", "N");


        hm.put("SNAPITERATIONNUMBER-MCCS", "1");
        hm.put("CANCEL_CUSTOMERNUMBER-MCCS", Generic.getValuesFromGlobals("CUSTOMERNUMBER"));
        hm.put("CANCEL_COUNTRYCODE-MCCS", "+31");
        hm.put("CANCEL_MDN-MCCS", Generic.getValuesFromGlobals("MDN"));
        hm.put("CANCEL_CLIENTBRAND-MCCS", "KPN");
        hm.put("CANCEL_CUSTOMERTYPE-MCCS", "CM");
        hm.put("CANCEL_INSURANCESTARTDATE-MCCS", "");
        hm.put("CANCEL_ASSURIONAGREEMENTE-MCCS", "");
        hm.put("CANCEL_ASSETSKU-MCCS", "872843");
        hm.put("CANCEL_CANCELLATIONRESAON-MCCS", "1");
        hm.put("CANCEL_CANCELDATE-MCCS", currentDate);


        //BOSS - Data setup
        hm.put("CUSTOMERNUMBER-BOSS", getUniqueCUSTOMERNUMBERBOSS_EU());
        Generic.setGlobals("CUSTOMERNUMBER-BOSS", Generic.getValuesFromGlobals("CUSTOMERNUMBERBOSS"));
        hm.put("COUNTRYCODE-BOSS", "+31");
        hm.put("MDN-BOSS", getUniqueMDN_EU());
        Generic.setGlobals("MDN-BOSS", Generic.getValuesFromGlobals("MDN"));
        hm.put("CLIENTBRAND-BOSS", "KPN");
        hm.put("CUSTOMERTYPE-BOSS", "CM");
        hm.put("KVKNUMBER-BOSS", Generic.getValuesFromGlobals("MDN") + "1");
        hm.put("BUSINESSNAME-BOSS", "MONEY PLANT");
        hm.put("GENDER-BOSS", "M");
        hm.put("INITIALS-BOSS", "E");
        hm.put("MAIDENMIDDLENAME-BOSS", "MM");
        hm.put("MAIDENLASTNAME-BOSS", "ML");
        hm.put("MIDDLENAME-BOSS", "EUQA");
        hm.put("LASTNAME-BOSS", "Automation");
        hm.put("EMAIL-BOSS", "kpn666@test.com");
        hm.put("DOB-BOSS", "19830128");
        hm.put("GENDERAUTHORISEDUSER-BOSS", "M");
        hm.put("INITIALSAUTHORISEDUSER-BOSS", "J");
        hm.put("MIDDLENAMEAUTHUSER-BOSS", "SUPER");
        hm.put("LASTNAMEAUTHUSER-BOSS", "USER");
        hm.put("AUTHEMAIL-BOSS", "super.user@email.com");
        hm.put("STREET-BOSS", "Maanplein");
        hm.put("HOUSENUMBER-BOSS", "323");
        hm.put("SUFFIX-BOSS", "1F");
        hm.put("POSTALCODE-BOSS", "6211PL"); //	"5162CK"
        hm.put("CITY-BOSS", "Den Haag");
        hm.put("COUNTRY-BOSS", "NL");
        hm.put("ENROLLMENTDATE-BOSS", DateUtil.getFormattedDatetime("yyyyMMdd", DateUtil.getModifiedDateTime("DAY", -365)));
        hm.put("CONTRACTSTARTDATE-BOSS", DateUtil.getFormattedDatetime("yyyyMMdd", DateUtil.getModifiedDateTime("DAY", -365)));
        hm.put("INSURANCEPRODUCTS-BOSS", "Schade2");
        hm.put("ASSETSKU-BOSS", "872736");// 872843
        hm.put("IMEI-BOSS", getUniqueIMEI_EU());
        Generic.setGlobals("IMEI-BOSS", Generic.getValuesFromGlobals("IMEI"));
        hm.put("ISINSUREDDEVICE-BOSS", "Y");
        hm.put("ASSETPURCHASEDATE-BOSS", DateUtil.getFormattedDatetime("yyyyMMdd", DateUtil.getModifiedDateTime("DAY", -365)));
        hm.put("SIMTYPE-BOSS", "DUO");
        hm.put("TRANSACTIONTYPE-BOSS", "Add");
        hm.put("PORTINGSTATUS-BOSS", "N");
        hm.put("BILLINGCYCLE-BOSS", "12");
        hm.put("ACCOUNTIDFR-BOSS", "Y");
        hm.put("SALESCHANNEL-BOSS", "ONLINE");
        hm.put("DEALERCODE-BOSS", "RETAIL");
        hm.put("SALESPERSON-BOSS", "WEB310");
        hm.put("SCOMMSCONSENT-BOSS", "N");


        hm.put("SNAPITERATIONNUMBER-BOSS", "1");
        hm.put("CANCEL_CUSTOMERNUMBER-BOSS", Generic.getValuesFromGlobals("CUSTOMERNUMBERBOSS"));
        hm.put("CANCEL_COUNTRYCODE-BOSS", "+31");
        hm.put("CANCEL_MDN-BOSS", Generic.getValuesFromGlobals("MDN"));
        hm.put("CANCEL_CLIENTBRAND-BOSS", "KPN");
        hm.put("CANCEL_CUSTOMERTYPE-BOSS", "CM");
        hm.put("CANCEL_INSURANCESTARTDATE-BOSS", "");
        hm.put("CANCEL_ASSURIONAGREEMENTE-BOSS", "");
        hm.put("CANCEL_ASSETSKU-BOSS", "872843");
        hm.put("CANCEL_CANCELLATIONRESAON-BOSS", "1");
        hm.put("CANCEL_CANCELDATE-BOSS", currentDate);

    }

    public static String getUniqueCUSTOMERNUMBER_EU() {

        String mdn = Generic.RandomNumber();
        String ban = mdn + "-11";
        Generic.setGlobals("CUSTOMERNUMBER", ban);

        return (ban);
    }

    public static String getUniqueCUSTOMERNUMBERBOSS_EU() {

        String customerNumberBoss = Generic.RandomNumber() + "11";

        Generic.setGlobals("CUSTOMERNUMBERBOSS", customerNumberBoss);

        return (customerNumberBoss);
    }

    public static String getUniqueIMEI_EU() {

        String IMEI = Generic.RandomNumber() + "12345";
        Generic.setGlobals("IMEI", IMEI);

        return (IMEI);
    }

    public static String getUniqueMDN_EU() {

        String mdn = Generic.RandomNumber() + "10";
        Generic.setGlobals("MDN", mdn);

        return (mdn);
    }

    public static String getUniqueCRMID_EU() {

        String mdn = Generic.RandomNumber();
        String CRMID = "92" + mdn;
        Generic.setGlobals("CRMID", CRMID);

        return (CRMID);
    }

    public static void setDifferentDataForEnrollment(String param, String value) {
        hm.put(param, value);

    }


    public static void kpnInitializeFileData() {
        // System.out.println("INSIDE initialize : " + ExecSequence.Parameter);


        Map mp = new LinkedHashMap<String, String>(hm);
        String sValue, sParam;


        Iterator it = mp.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            //System.out.println(pair.getKey() + " = " + pair.getValue());

            sParam = pair.getKey().toString();
            sValue = pair.getValue().toString().trim();

            //DEBUG POINT	        System.out.println("Parameter :" + sParam + "Value :" + sValue);

            System.out.println("Paramater and value :- " + sParam + " and " + sValue);
            switch (sParam.trim()) {
                case "CUSTOMERNUMBER":
                    Input[0] = sValue;
                    break;
                case "COUNTRYCODE":
                    Input[1] = sValue;
                    break;
                case "MDN":
                    Input[2] = sValue;
                    break;
                case "CLIENTBRAND":
                    Input[3] = sValue;
                    break;
                case "CUSTOMERTYPE":
                    Input[4] = sValue;
                    break;
                case "KVKNUMBER":
                    Input[5] = sValue;
                    break;
                case "BUSINESSNAME":
                    Input[6] = sValue;
                    break;
                case "GENDER":
                    Input[7] = sValue;
                    break;
                case "INITIALS":
                    Input[8] = sValue;
                    break;
                case "MAIDENMIDDLENAME":
                    Input[9] = sValue;
                    break;
                case "MAIDENLASTNAME":
                    Input[10] = sValue;
                    break;
                case "MIDDLENAME":
                    Input[11] = sValue;
                    break;
                case "LASTNAME":
                    Input[12] = sValue;
                    break;
                case "EMAIL":
                    Input[13] = sValue;
                    break;
                case "DOB":
                    Input[14] = sValue;
                    break;
                case "GENDERAUTHORISEDUSER":
                    Input[15] = sValue;
                    break;
                case "INITIALSAUTHORISEDUSER":
                    Input[16] = sValue;
                    break;
                case "MIDDLENAMEAUTHUSER":
                    Input[17] = sValue;
                    break;
                case "LASTNAMEAUTHUSER":
                    Input[18] = sValue;
                    break;
                case "AUTHEMAIL":
                    Input[19] = sValue;
                    break;
                case "STREET":
                    Input[20] = sValue;
                    break;
                case "HOUSENUMBER":
                    Input[21] = sValue;
                    break;
                case "SUFFIX":
                    Input[22] = sValue;
                    break;
                case "POSTALCODE":
                    Input[23] = sValue;
                    break;
                case "CITY":
                    Input[24] = sValue;
                    break;
                case "COUNTRY":
                    Input[25] = sValue;
                    break;
                case "ENROLLMENTDATE":
                    Input[26] = sValue;
                    break;
                case "CONTRACTSTARTDATE":
                    Input[27] = sValue;
                    break;
                case "INSURANCEPRODUCTS":
                    Input[28] = sValue;
                    break;
                case "ASSETSKU":
                    Input[29] = sValue;
                    break;
                case "IMEI":
                    Input[30] = sValue;
                    break;
                case "ISINSUREDDEVICE":
                    Input[31] = sValue;
                    break;
                case "ASSETPURCHASEDATE":
                    Input[32] = sValue;
                    break;
                case "SIMTYPE":
                    Input[33] = sValue;
                    break;
                case "TRANSACTIONTYPE":
                    Input[34] = sValue;
                    break;
                case "PORTINGSTATUS":
                    Input[35] = sValue;
                    break;
                case "BILLINGCYCLE":
                    Input[36] = sValue;
                    break;
                case "ACCOUNTIDFR":
                    Input[37] = sValue;
                    break;
                case "SALESCHANNEL":
                    Input[38] = sValue;
                    break;
                case "DEALERCODE":
                    Input[39] = sValue;
                    break;
                case "SALESPERSON":
                    Input[40] = sValue;
                    break;
                case "SCOMMSCONSENT":
                    Input[41] = sValue;
                    break;
                case "CANCEL_CUSTOMERNUMBER":
                    Input[42] = sValue;
                    break;
                case "CANCEL_COUNTRYCODE":
                    Input[43] = sValue;
                    break;
                case "CANCEL_MDN":
                    Input[44] = sValue;
                    break;
                case "CANCEL_CLIENTBRAND":
                    Input[45] = sValue;
                    break;
                case "CANCEL_CUSTOMERTYPE":
                    Input[46] = sValue;
                    break;
                case "CANCEL_INSURANCESTARTDATE":
                    Input[47] = sValue;
                    break;
                case "CANCEL_ASSURIONAGREEMENTE":
                    Input[48] = sValue;
                    break;
                case "CANCEL_ASSETSKU":
                    Input[49] = sValue;
                    break;
                case "CANCEL_CANCELLATIONRESAON":
                    Input[50] = sValue;
                    break;
                case "CANCEL_CANCELDATE":
                    Input[51] = sValue;
                    break;

            }
        }
    }

    public static void kpnInitializeMultiFileData() {
        // System.out.println("INSIDE initialize : " + ExecSequence.Parameter);


        Map mp = new LinkedHashMap<String, String>(hm);
        String sValue, sParam;


        Iterator it = mp.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            //System.out.println(pair.getKey() + " = " + pair.getValue());

            sParam = pair.getKey().toString();
            sValue = pair.getValue().toString().trim();

            //DEBUG POINT	        System.out.println("Parameter :" + sParam + "Value :" + sValue);

            System.out.println("Paramater and value :- " + sParam + " and " + sValue);
            switch (sParam.trim()) {
                case "CUSTOMERNUMBER-MCCS":
                    Input[0] = sValue;
                    break;
                case "COUNTRYCODE-MCCS":
                    Input[1] = sValue;
                    break;
                case "MDN-MCCS":
                    Input[2] = sValue;
                    break;
                case "CLIENTBRAND-MCCS":
                    Input[3] = sValue;
                    break;
                case "CUSTOMERTYPE-MCCS":
                    Input[4] = sValue;
                    break;
                case "KVKNUMBER-MCCS":
                    Input[5] = sValue;
                    break;
                case "BUSINESSNAME-MCCS":
                    Input[6] = sValue;
                    break;
                case "GENDER-MCCS":
                    Input[7] = sValue;
                    break;
                case "INITIALS-MCCS":
                    Input[8] = sValue;
                    break;
                case "MAIDENMIDDLENAME-MCCS":
                    Input[9] = sValue;
                    break;
                case "MAIDENLASTNAME-MCCS":
                    Input[10] = sValue;
                    break;
                case "MIDDLENAME-MCCS":
                    Input[11] = sValue;
                    break;
                case "LASTNAME-MCCS":
                    Input[12] = sValue;
                    break;
                case "EMAIL-MCCS":
                    Input[13] = sValue;
                    break;
                case "DOB-MCCS":
                    Input[14] = sValue;
                    break;
                case "GENDERAUTHORISEDUSER-MCCS":
                    Input[15] = sValue;
                    break;
                case "INITIALSAUTHORISEDUSER-MCCS":
                    Input[16] = sValue;
                    break;
                case "MIDDLENAMEAUTHUSER-MCCS":
                    Input[17] = sValue;
                    break;
                case "LASTNAMEAUTHUSER-MCCS":
                    Input[18] = sValue;
                    break;
                case "AUTHEMAIL-MCCS":
                    Input[19] = sValue;
                    break;
                case "STREET-MCCS":
                    Input[20] = sValue;
                    break;
                case "HOUSENUMBER-MCCS":
                    Input[21] = sValue;
                    break;
                case "SUFFIX-MCCS":
                    Input[22] = sValue;
                    break;
                case "POSTALCODE-MCCS":
                    Input[23] = sValue;
                    break;
                case "CITY-MCCS":
                    Input[24] = sValue;
                    break;
                case "COUNTRY-MCCS":
                    Input[25] = sValue;
                    break;
                case "ENROLLMENTDATE-MCCS":
                    Input[26] = sValue;
                    break;
                case "CONTRACTSTARTDATE-MCCS":
                    Input[27] = sValue;
                    break;
                case "INSURANCEPRODUCTS-MCCS":
                    Input[28] = sValue;
                    break;
                case "ASSETSKU-MCCS":
                    Input[29] = sValue;
                    break;
                case "IMEI-MCCS":
                    Input[30] = sValue;
                    break;
                case "ISINSUREDDEVICE-MCCS":
                    Input[31] = sValue;
                    break;
                case "ASSETPURCHASEDATE-MCCS":
                    Input[32] = sValue;
                    break;
                case "SIMTYPE-MCCS":
                    Input[33] = sValue;
                    break;
                case "TRANSACTIONTYPE-MCCS":
                    Input[34] = sValue;
                    break;
                case "PORTINGSTATUS-MCCS":
                    Input[35] = sValue;
                    break;
                case "BILLINGCYCLE-MCCS":
                    Input[36] = sValue;
                    break;
                case "ACCOUNTIDFR-MCCS":
                    Input[37] = sValue;
                    break;
                case "SALESCHANNEL-MCCS":
                    Input[38] = sValue;
                    break;
                case "DEALERCODE-MCCS":
                    Input[39] = sValue;
                    break;
                case "SALESPERSON-MCCS":
                    Input[40] = sValue;
                    break;
                case "SCOMMSCONSENT-MCCS":
                    Input[41] = sValue;
                    break;
                case "CANCEL_CUSTOMERNUMBER-MCCS":
                    Input[42] = sValue;
                    break;
                case "CANCEL_COUNTRYCODE-MCCS":
                    Input[43] = sValue;
                    break;
                case "CANCEL_MDN-MCCS":
                    Input[44] = sValue;
                    break;
                case "CANCEL_CLIENTBRAND-MCCS":
                    Input[45] = sValue;
                    break;
                case "CANCEL_CUSTOMERTYPE-MCCS":
                    Input[46] = sValue;
                    break;
                case "CANCEL_INSURANCESTARTDATE-MCCS":
                    Input[47] = sValue;
                    break;
                case "CANCEL_ASSURIONAGREEMENTE-MCCS":
                    Input[48] = sValue;
                    break;
                case "CANCEL_ASSETSKU-MCCS":
                    Input[49] = sValue;
                    break;
                case "CANCEL_CANCELLATIONRESAON-MCCS":
                    Input[50] = sValue;
                    break;
                case "CANCEL_CANCELDATE-MCCS":
                    Input[51] = sValue;
                    break;
                case "CUSTOMERNUMBER-BOSS":
                    Input[52] = sValue;
                    break;
                case "COUNTRYCODE-BOSS":
                    Input[53] = sValue;
                    break;
                case "MDN-BOSS":
                    Input[54] = sValue;
                    break;
                case "CLIENTBRAND-BOSS":
                    Input[55] = sValue;
                    break;
                case "CUSTOMERTYPE-BOSS":
                    Input[56] = sValue;
                    break;
                case "KVKNUMBER-BOSS":
                    Input[57] = sValue;
                    break;
                case "BUSINESSNAME-BOSS":
                    Input[58] = sValue;
                    break;
                case "GENDER-BOSS":
                    Input[59] = sValue;
                    break;
                case "INITIALS-BOSS":
                    Input[60] = sValue;
                    break;
                case "MAIDENMIDDLENAME-BOSS":
                    Input[61] = sValue;
                    break;
                case "MAIDENLASTNAME-BOSS":
                    Input[62] = sValue;
                    break;
                case "MIDDLENAME-BOSS":
                    Input[63] = sValue;
                    break;
                case "LASTNAME-BOSS":
                    Input[64] = sValue;
                    break;
                case "EMAIL-BOSS":
                    Input[65] = sValue;
                    break;
                case "DOB-BOSS":
                    Input[66] = sValue;
                    break;
                case "GENDERAUTHORISEDUSER-BOSS":
                    Input[67] = sValue;
                    break;
                case "INITIALSAUTHORISEDUSER-BOSS":
                    Input[68] = sValue;
                    break;
                case "MIDDLENAMEAUTHUSER-BOSS":
                    Input[69] = sValue;
                    break;
                case "LASTNAMEAUTHUSER-BOSS":
                    Input[70] = sValue;
                    break;
                case "AUTHEMAIL-BOSS":
                    Input[71] = sValue;
                    break;
                case "STREET-BOSS":
                    Input[72] = sValue;
                    break;
                case "HOUSENUMBER-BOSS":
                    Input[73] = sValue;
                    break;
                case "SUFFIX-BOSS":
                    Input[74] = sValue;
                    break;
                case "POSTALCODE-BOSS":
                    Input[75] = sValue;
                    break;
                case "CITY-BOSS":
                    Input[76] = sValue;
                    break;
                case "COUNTRY-BOSS":
                    Input[77] = sValue;
                    break;
                case "ENROLLMENTDATE-BOSS":
                    Input[78] = sValue;
                    break;
                case "CONTRACTSTARTDATE-BOSS":
                    Input[79] = sValue;
                    break;
                case "INSURANCEPRODUCTS-BOSS":
                    Input[80] = sValue;
                    break;
                case "ASSETSKU-BOSS":
                    Input[81] = sValue;
                    break;
                case "IMEI-BOSS":
                    Input[82] = sValue;
                    break;
                case "ISINSUREDDEVICE-BOSS":
                    Input[83] = sValue;
                    break;
                case "ASSETPURCHASEDATE-BOSS":
                    Input[84] = sValue;
                    break;
                case "SIMTYPE-BOSS":
                    Input[85] = sValue;
                    break;
                case "TRANSACTIONTYPE-BOSS":
                    Input[86] = sValue;
                    break;
                case "PORTINGSTATUS-BOSS":
                    Input[87] = sValue;
                    break;
                case "BILLINGCYCLE-BOSS":
                    Input[88] = sValue;
                    break;
                case "ACCOUNTIDFR-BOSS":
                    Input[89] = sValue;
                    break;
                case "SALESCHANNEL-BOSS":
                    Input[90] = sValue;
                    break;
                case "DEALERCODE-BOSS":
                    Input[91] = sValue;
                    break;
                case "SALESPERSON-BOSS":
                    Input[92] = sValue;
                    break;
                case "SCOMMSCONSENT-BOSS":
                    Input[93] = sValue;
                    break;
                case "CANCEL_CUSTOMERNUMBER-BOSS":
                    Input[94] = sValue;
                    break;
                case "CANCEL_COUNTRYCODE-BOSS":
                    Input[95] = sValue;
                    break;
                case "CANCEL_MDN-BOSS":
                    Input[96] = sValue;
                    break;
                case "CANCEL_CLIENTBRAND-BOSS":
                    Input[97] = sValue;
                    break;
                case "CANCEL_CUSTOMERTYPE-BOSS":
                    Input[98] = sValue;
                    break;
                case "CANCEL_INSURANCESTARTDATE-BOSS":
                    Input[99] = sValue;
                    break;
                case "CANCEL_ASSURIONAGREEMENTE-BOSS":
                    Input[100] = sValue;
                    break;
                case "CANCEL_ASSETSKU-BOSS":
                    Input[101] = sValue;
                    break;
                case "CANCEL_CANCELLATIONRESAON-BOSS":
                    Input[102] = sValue;
                    break;
                case "CANCEL_CANCELDATE-BOSS":
                    Input[103] = sValue;
                    break;
            }
        }
    }

    public static void createETLfiles(String ScenarioType) throws Exception {
        for (int i = 0; i < 41; i++) {
            System.out.println(Input[i]);

        }
        String ClientName = ApplicationConfiguration.getClient();
        String[] fileList = new String[2];
        String[] fileList1 = new String[1];
        File file2 = new File("\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\kpn_enrollment\\inbound");
        //File file2 = new File("C:\\Users\\sandeep.supekar\\ETL\\sftp\\");


        if (ClientName.contains("kpn") && ScenarioType.equalsIgnoreCase("ADD")) {

            fileList[0] = "KPN_SNAP";

        } else if (ClientName.contains("kpn") && ScenarioType.equalsIgnoreCase("BM_ADD")) {

            fileList[0] = "KPN_BM_SNAP";

        } else if (ClientName.contains("kpn") && ScenarioType.equalsIgnoreCase("BM_CANCEL")) {

            fileList[0] = "KPN_MCCS_CANCEL";
            fileList[1] = "KPN_MCCS_SNACANC_B";

        } else if (ClientName.contains("kpn") && ScenarioType.equalsIgnoreCase("BM_CANCELWITHPSFTYESANDSCYES")) {

            fileList[0] = "KPN_MCCS_CANCEL";
            fileList[1] = "KPN_BM_CANWITHPSFTYES";

        }


        int k = 0;
//        Wait for other files to get processed and then continue
        //while(file2.list().length>0 && k < 10){
        // try{
        //     Thread.sleep(50);
        //  }
        //   catch(InterruptedException ex){
        //       Thread.currentThread().interrupt();
        //  }
        //   k++;
        // }
        for (int i = 0; i < fileList.length; i++) {
            // Write hashmap data to file and then drop the file on temp location
            // Get the file names from below method

            if (fileList[i] != null) {
                CurrentFile = fileList[i];
                //System.out.println(CurrentFile);
                String eFile = getFileName(fileList[i]) + ".txt";
                writeToCSV(eFile, fileList[i]);


                System.out.println("File Created for : " + getFileName(fileList[i]));
            }
        }

    }

    public static void createETLMultifiles(String ScenarioType) throws Exception {
        for (int i = 0; i < 104; i++) {
            System.out.println(Input[i]);

        }
        String ClientName = ApplicationConfiguration.getClient();
        String[] fileList = new String[4];
        String[] fileList1 = new String[1];
        File file2 = new File("\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\kpn_enrollment\\inbound");


        if (ClientName.contains("kpn") && ScenarioType.equalsIgnoreCase("ADD")) {

            fileList[0] = "KPN_SNAP";
            fileList[1] = "KPN_BM_SNAP";

        } else if (ClientName.contains("kpn") && ScenarioType.equalsIgnoreCase("ADDMULTIFILE")) {

            fileList[0] = "KPN_BOSS_SNAP";
            fileList[1] = "KPN_MCCS_SNAP";
            fileList[2] = "KPN_MCCS_MULTI_CANCEL_B";
            fileList[3] = "KPN_BOSS_MULTI_CANCEL_B";
        } else if (ClientName.contains("kpn") && ScenarioType.equalsIgnoreCase("CANCEL")) {

            fileList[0] = "KPN_MCCS_CANCEL";
            fileList[1] = "KPN_MCCS_SNACANC_B";
            fileList[2] = "KPN_BOSS_CANCEL";
            fileList[3] = "KPN_BOSS_SNACANC_B";

        } else if (ClientName.contains("kpn") && ScenarioType.equalsIgnoreCase("BM_CANCELWITHPSFTYESANDSCYES")) {

            fileList[0] = "KPN_MCCS_CANCEL";
            fileList[1] = "KPN_BM_CANWITHPSFTYES";
            fileList[2] = "KPN_BOSS_CANCEL";
            fileList[3] = "KPN_CM_CANWITHPSFTYES";

        }

        for (int i = 0; i < fileList.length; i++) {
            if (fileList[i] != null) {
                CurrentFile = fileList[i];
                String eFile = getFileName(fileList[i]) + ".txt";
                writeToCSV(eFile, fileList[i]);
                System.out.println("File Created for : " + getFileName(fileList[i]));
            }
        }

    }

    public static void writeToCSV(String efile, String fileName) throws Exception {

        String sftpLocation;

        if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizondevinteu")) {
            sftpLocation = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\DevInt\\KPN_enrollment\\inbound";
        } else {
            sftpLocation = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\kpn_enrollment\\inbound";
        }

        String tempLocation = "\\\\ndcsqafp401\\IT_QA_Test\\QATest_Horizon_Enrollment\\EU\\KPN\\";
        //String tempLocation = "C:\\Asurion\\";
        File file1 = new File(sftpLocation);
        int i = 0;
        String csv = tempLocation + efile; // Temp Folder location and file name


//        Wait for other files to get processed and then continue
        // while(file1.list().length>0 && i < 3){
        //    try{
        // Thread.sleep(50);
        //   }
        //   catch(InterruptedException ex){
        //       Thread.currentThread().interrupt();
        //   }
        //  i++;
        // }


        if (i == 3 && file1.list().length > 0) {
            System.out.println("Stage enrollment failed. There is a file stuck at sftp location \\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\3uk_enrollment\\inbound\\.");
            //ExecSequence.exitTest("ENROLLMENT Failed as previous enrollment are stuck at SFTP");
            // Assert.assertTrue("Stage enrollment failed. There is a file stuck at sftp location \\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\3uk_enrollment\\inbound\\.", false);
        } else {

            try {
                System.out.println(csv);
                CSVWriter writer = new CSVWriter(new FileWriter(csv), '|', '"', CSVWriter.NO_ESCAPE_CHARACTER, System.getProperty("line.separator"));
                //writer = new CSVWriter(new FileWriter(csv));
                String[] headerText = null, footerText = null, dataText = null;

                if (CurrentFile.contains("KPN")) {
                    headerText = new String[]{"Header", getCurrentTimeStamp(), efile.replaceAll(".txt", "")};

                    if (CurrentFile.contains("SNAP")) {
                        // Get the String array for Peoplesoft
                        dataText = getClientFileData(CurrentFile);
                        footerText = new String[]{"Footer", "1"};
                        //System.out.println("PeopleSoft File Created !");
                    }
                    if (CurrentFile.contains("MCCS_CANCEL")) {
                        // Get the String array for Peoplesoft
                        dataText = getClientFileData(CurrentFile);
                        footerText = new String[]{"Footer", "1"};
                        //System.out.println("PeopleSoft File Created !");
                    }

                    // Common Snapshot file for KPN BM Cancellation
                    if (CurrentFile.contains("MCCS_SNACANC_B")) {
                        // Get the String array for Peoplesoft
                        dataText = getClientFileData(CurrentFile);
                        footerText = new String[]{"Footer", "0"};
                        //System.out.println("PeopleSoft File Created !");
                    }

                    if (CurrentFile.contains("BM_CANWITHPSFTYES")) {
                        // Get the String array for Peoplesoft
                        dataText = getClientFileData(CurrentFile);
                        footerText = new String[]{"Footer", "1"};
                        //System.out.println("PeopleSoft File Created !");
                    }
                    if (CurrentFile.contains("CM_CANWITHPSFTYES")) {
                        // Get the String array for Peoplesoft
                        dataText = getClientFileData(CurrentFile);
                        footerText = new String[]{"Footer", "1"};
                        //System.out.println("PeopleSoft File Created !");
                    }
                    if (CurrentFile.contains("BOSS_CANCEL")) {
                        // Get the String array for Peoplesoft
                        dataText = getClientFileData(CurrentFile);
                        footerText = new String[]{"Footer", "1"};
                        //System.out.println("PeopleSoft File Created !");
                    }
                    if (CurrentFile.contains("BOSS_MULTI_CANCEL")) {
                        // Get the String array for Peoplesoft
                        dataText = getClientFileData(CurrentFile);
                        footerText = new String[]{"Footer", "0"};
                        //System.out.println("Balnk cancel BOSS file for multifile injestion !");
                    }
                    if (CurrentFile.contains("MCCS_MULTI_CANCEL")) {
                        // Get the String array for Peoplesoft
                        dataText = getClientFileData(CurrentFile);
                        footerText = new String[]{"Footer", "0"};
                        //System.out.println("Balnk cancel MCCS file for multifile injestion !");
                    }
                    if (CurrentFile.contains("BOSS_SNACANC_B")) {
                        // Get the String array for Peoplesoft
                        dataText = getClientFileData(CurrentFile);
                        footerText = new String[]{"Footer", "0"};
                        //System.out.println("PeopleSoft File Created !");
                    }


                }


                List<String[]> data = new ArrayList<String[]>();
                data.add(headerText);
                data.add(dataText);
                data.add(footerText);

                writer.writeAll(data);

                writer.close();


                moveFiletoDir(csv, sftpLocation);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }


    public static String[] getClientFileData(String clientFileName) {
        String[] fileDataHeader = null;

//DEBUG POINTER System.out.println("Input Array : " + Arrays.asList(Input));
        switch (clientFileName) {
            case "KPN_SNAP":
            case "KPN_CM_CANWITHPSFTYES":
            case "KPN_BOSS_SNAP":
                fileDataHeader = Arrays.copyOfRange(Input, 52, 94);
                //fileDataHeader = new String[]{"20",Input[1],Input[2],Input[3],Input[4],Input[5],Input[6],Input[7],Input[8],Input[9],Input[10],Input[11],Input[12],Input[13],Input[14],Input[15],Input[16]};
                break;

            case "KPN_BM_SNAP":
            case "KPN_BM_CANWITHPSFTYES":
            case "KPN_MCCS_SNAP":
                fileDataHeader = Arrays.copyOfRange(Input, 0, 42);
                //fileDataHeader = new String[]{"20",Input[1],Input[2],Input[3],Input[4],Input[5],Input[6],Input[7],Input[8],Input[9],Input[10],Input[11],Input[12],Input[13],Input[14],Input[15],Input[16]};
                break;

            case "KPN_MCCS_CANCEL":
                fileDataHeader = Arrays.copyOfRange(Input, 42, 52);
                //fileDataHeader = new String[]{"20",Input[1],Input[2],Input[3],Input[4],Input[5],Input[6],Input[7],Input[8],Input[9],Input[10],Input[11],Input[12],Input[13],Input[14],Input[15],Input[16]};

                break;

            case "KPN_BOSS_CANCEL":
                fileDataHeader = Arrays.copyOfRange(Input, 94, 104);
                //fileDataHeader = new String[]{"20",Input[1],Input[2],Input[3],Input[4],Input[5],Input[6],Input[7],Input[8],Input[9],Input[10],Input[11],Input[12],Input[13],Input[14],Input[15],Input[16]};

                break;

            case "KPN_MCCS_SNACANC_B":
            case "KPN_BOSS_SNACANC_B": //Common snapshot file for KPN cancel BM with Blank data
                fileDataHeader = null;
                //fileDataHeader = new String[]{"20",Input[1],Input[2],Input[3],Input[4],Input[5],Input[6],Input[7],Input[8],Input[9],Input[10],Input[11],Input[12],Input[13],Input[14],Input[15],Input[16]};

                break;
            case "KPN_MCCS_MULTI_CANCEL_B":
            case "KPN_BOSS_MULTI_CANCEL_B": //Common snapshot file for KPN cancel BM with Blank data
                fileDataHeader = null;
                //fileDataHeader = new String[]{"20",Input[1],Input[2],Input[3],Input[4],Input[5],Input[6],Input[7],Input[8],Input[9],Input[10],Input[11],Input[12],Input[13],Input[14],Input[15],Input[16]};

                break;

//            case "KPN_BM_SNAP":
//                fileDataHeader = Arrays.copyOfRange(Input, 0, 42);
//                break;

        }
        return fileDataHeader;
    }

    public static String getFileName(String etlFileType) {
        String etlFName = null;

        if (etlFileType == "KPN_SNAP" || etlFileType == "KPN_BOSS_SNAP") {
            etlFName = "KPN_InsuredCustomer_Snapshot_" + currentDate + "_" + hm.get("SNAPITERATIONNUMBER-BOSS");
        }
        if (etlFileType == "KPN_BM_CANWITHPSFTYES") {
            etlFName = "KPN_BM_InsuredCustomer_Snapshot_" + currentDate + "_" + hm.get("SNAPITERATIONNUMBER-MCCS");
        }
        if (etlFileType == "KPN_CM_CANWITHPSFTYES") {
            etlFName = "KPN_InsuredCustomer_Snapshot_" + currentDate + "_" + hm.get("SNAPITERATIONNUMBER-BOSS");
        }

        if (etlFileType == "KPN_BM_SNAP" || etlFileType == "KPN_MCCS_SNAP") {
            etlFName = "KPN_BM_InsuredCustomer_Snapshot_" + currentDate + "_" + hm.get("SNAPITERATIONNUMBER-MCCS");
        }
        if (etlFileType == "KPN_MCCS_SNACANC_B") {
            etlFName = "KPN_BM_InsuredCustomer_Snapshot_" + currentDate + "_" + hm.get("SNAPITERATIONNUMBER-MCCS");
        }
        if (etlFileType == "KPN_MCCS_CANCEL" || etlFileType == "KPN_MCCS_MULTI_CANCEL_B") {
            etlFName = "KPN_BM_Cancellation_Delta_" + currentDate + "_" + hm.get("SNAPITERATIONNUMBER-MCCS");
        }
        if (etlFileType == "KPN_BOSS_CANCEL" || etlFileType == "KPN_BOSS_MULTI_CANCEL_B") {
            etlFName = "KPN_Cancellation_Delta_" + currentDate + "_" + hm.get("SNAPITERATIONNUMBER-BOSS");
        }
        if (etlFileType == "KPN_BOSS_SNACANC_B") {
            etlFName = "KPN_InsuredCustomer_Snapshot_" + currentDate + "_" + hm.get("SNAPITERATIONNUMBER-BOSS");
        }
        return etlFName;
    }


    public static void moveFiletoDir(String SourceFileLocation, String DestinationDirectory) {
        try {
            File dir1 = new File(SourceFileLocation);
            File dir2 = new File(DestinationDirectory);

            //Before moving the files check if file already present at the SFTP location . If file is present then wait for 3 mins and then proceed with moving the files .
            FileUtils.moveFileToDirectory(dir1, dir2, false);
//            FileUtils.copyFileToDirectory(dir1,dir2,false);
            System.out.println("Files Transferred to SFTP Location : " + DestinationDirectory);

            //Check if the files are getting picked up from SFTP

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getCurrentTimeStampDate() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd");
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }

    public static String getCurrentTimeStamp() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMddHHmmss");
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }

    public static String getValuesFromKPNMAP(String variableName) {
        return hm.get(variableName);
    }

    public static void updateDifferentDataForEnrollment(String param, String value) {
        hm.put(param, value);
    }
}


