package com.asurion.pages;

import com.asurion.common.core.driver.TestDriver;
import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.util.ApplicationConfiguration;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public abstract class BasePage {
    protected TestDriver driver;
    protected UIElement spinner = new UIElement(UIType.Image, UILocatorType.CSS, "img[alt='loading']");
    static String noEnrolledMDN;
    static String enrollmentRequestNumber;
    static String customerName;
    static String holdNumber;
    static String assetDeatils;
    static String emailAddress;
    static String capture_EmailID;
    static String ZipcodeClaroClient;
    public static String sPaymentCard;
    public static StringBuffer verificationErrors = new StringBuffer("Asset details : ");
    public static ArrayList holdNumbers = new ArrayList();
    public static String autoCorrectAddress = "";
    public static String CorrelationID = "";
    public static String refundReqNo;
    public static String userRole;

    public BasePage() {
        driver = TestDriver.getDriver(ApplicationConfiguration.getBrowser(), ApplicationConfiguration.getRunType(), ApplicationConfiguration.getBrowserVersion());

    }

    public void goToHomePage() throws Exception {

        driver.navigate(getHomePageURL());
        if(driver.isAlertPresent()){
            driver.acceptAlert();
        }
        CaptureIncidentPage.casenumbers = new HashMap<>();
    }

    private String getHomePageURL() {
        return ApplicationConfiguration.getApplicationURl();
    }

    public void waitForPageNavigation() {
        if (driver.waitForElementPresenceWithTimeOut(spinner, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.waitForElementAbsence(spinner, ApplicationConfiguration.getWaitForElementTimeout());

    }

    public static void moveFiletoDir(String SourceFileLocation, String DestinationDirectory) {
        try {
            File dir1 = new File(SourceFileLocation);
            File dir2 = new File(DestinationDirectory);


            //Before moving the files check if file already present at the SFTP location . If file is present then wait for 3 mins and then proceed with moving the files .
            FileUtils.moveFileToDirectory(dir1, dir2, false);
//            FileUtils.copyFileToDirectory(dir1,dir2,false);
            System.out.println("Files Transferred to SFTP Location : " + DestinationDirectory);

            //Check if the files are getting picked up from SFTP

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void navigateLowestLevelFrame(UIElement frameName) {


        // List<WebElement> inputs = (List<WebElement>) ((JavascriptExecutor)driver).executeScript("return document.getElementByName('DIACTION');");

        //  List<WebElement> inputs= driver.getFramesByJavaScript("DIACTION","name");
        //Get initial frame count
        List<WebElement> ele = driver.findElements(frameName);

        List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
        List<WebElement> frames = driver.findElements(By.tagName("frame"));

        if (ele.size() == 0) {
            for (int j = 0; j == 100; j++) {
                ele = driver.findElements(By.tagName("frame"));
                if (ele.size() >= 1) {
                    break;
                }
            }

        }


        int counter = 0;
        while (ele.size() > 0) {
            driver.switchToFrame(frameName);
            //After Switching to lower frame level get new frame count
            counter++;
            if (counter == 2) {
                break;
            }
            ele = driver.findElements(frameName);
        }

        for (int i = 0; i < ele.size(); i++) {
            String name = ele.get(i).getAttribute("name");

            UIElement diaction = new UIElement(UIType.Frame, UILocatorType.Name, name);

            driver.switchToFrame(diaction);
        }
    }

    public boolean waitForPageLoaded(int timeToWaitInSeconds) {
        int i = 0;
        Boolean loaded = false;
        do {
            loaded = driver.executeJavaScript("return document.readyState",null).equals("complete");
            i++;
        } while (i < timeToWaitInSeconds && loaded == false);
        return loaded;
    }
    public boolean waitForPageLoaded() {
        return waitForPageLoaded(10);
    }


}