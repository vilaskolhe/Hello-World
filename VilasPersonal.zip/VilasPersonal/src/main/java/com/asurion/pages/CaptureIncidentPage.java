package com.asurion.pages;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import com.asurion.util.DateUtil;
import com.asurion.util.Generic;
import org.junit.Assert;

import java.util.HashMap;

import static org.junit.Assert.assertTrue;

public class CaptureIncidentPage extends BasePage {

    // private UIElement verMobileNumber = new UIElement(UIType.TextBox, UILocatorType.Xpath, "/html/body/div[2]/form/div[3]/div[2]/table/tbody/tr/td/div/div/table/tbody/tr/td[3]/div/table/tbody/tr/td/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/table/tbody/tr[2]/td[2]/nobr");
    // private UIElement verMobileNumber = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div/div/div/div[1]/div/div/span[@class='boldtext']");
    private UIElement verMobileNumber = new UIElement(UIType.Label, UILocatorType.Xpath, "//table[@id='hoz_layout_tables']//div[@id='RULE_KEY']//div[@id='RULE_KEY']/div[1]/div/div/div[2]/div/div");
    private UIElement incidentDescription = new UIElement(UIType.TextBox, UILocatorType.ID, "IncidentDescription");
    // private UIElement incidentDateToday = new UIElement(UIType.Link, UILocatorType.Name, "SelectIncidentAsset_pyWorkPage_14");
    private UIElement incidentDateToday = new UIElement(UIType.Link, UILocatorType.Link, "Today");
    //  private UIElement incidentDateToday = new UIElement(UIType.Link, UILocatorType.CSS, "a[name=SelectIncidentAsset_pyWorkPage_10]");
    //private UIElement incidentDateYesterday = new UIElement(UIType.Link, UILocatorType.Xpath, "/html/body/div[2]/form/div[3]/div/table/tbody/tr/td/div/div/span/div/div/table/tbody/tr[2]/td/div/table[2]/tbody/tr[2]/td/table/tbody/tr/td/div/span/table/tbody/tr/td[2]/div/table/tbody/tr[3]/td/nobr/span/a");
    private UIElement incidentDateYesterday = new UIElement(UIType.Link, UILocatorType.Link, "Yesterday");
    private UIElement continueButtonIncident = new UIElement(UIType.Button, UILocatorType.CSS, "button.InFormContinueButton.pzhc");
    //private UIElement continueButtonAsset = new UIElement(UIType.Button, UILocatorType.Xpath, "//table[@id='pyActionArea']//table//div[@id='pyFlowActionHTML']//table//tbody//div[@id='RULE_KEY']/div[1]//button");
    //private UIElement continueButtonAsset = new UIElement(UIType.Button, UILocatorType.CSS, "table[id='pyActionArea'] table:nth-of-type(1) div[id='pyFlowActionHTML'] table:nth-of-type(1) div[id='RULE_KEY']>div>div>div>div>div>div>div>div>div>div>div:nth-of-type(1)>span>button");
    private UIElement continueButtonAsset = new UIElement(UIType.Button, UILocatorType.CSS, ".Hoz_New_Continue_Btn.pzhc");
    private UIElement claimMessageReturned = new UIElement(UIType.TextBox, UILocatorType.Xpath, "/html/body/div[2]/form/div[3]/div[1]/table/tbody/tr/td/div/div/span/div/div/table/tbody/tr[2]/td/div/table[2]/tbody/tr[2]/td/table/tbody/tr/td/div/span/table/tbody/tr[1]/td[2]/div/div/div/div/div/div/div/div[1]/div/div/div[2]/div/div/div/div/div/div/div");
    private UIElement cpmInteractionDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmInteractionDivFrame");
    private UIElement cpmTabbedNavigationDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    private UIElement diaction = new UIElement(UIType.Frame, UILocatorType.Name, "DIACTION");
    private UIElement incidentType = new UIElement(UIType.ListBox, UILocatorType.ID, "FailureCategoryTypeCode");
    private UIElement coveredEventCode = new UIElement(UIType.ListBox, UILocatorType.ID, "CoveredEventCode");
    private UIElement AssetMake = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedAssetMakeID");
    private UIElement AssetModel = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedAssetModelID");
    private UIElement AssetColor = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedAssetCatalogID");
    private UIElement overrideEligibility = new UIElement(UIType.CheckBox, UILocatorType.ID, "OverrideEligibility");
    private UIElement eligibilityVoid = new UIElement(UIType.CheckBox, UILocatorType.ID, "EligibilityNextActionVoid");
    private UIElement continueButton = new UIElement(UIType.Button, UILocatorType.CSS, "table.buttonMainTable.InFormContinueButton tbody tr td:nth-child(2)");
    private UIElement overrideEligibilityMsg = new UIElement(UIType.Label, UILocatorType.ID, "pyFlowActionHTML");
    private UIElement calender = new UIElement(UIType.Label, UILocatorType.ID, "Pega_Cal_Cont");
    private UIElement OverrideReason = new UIElement(UIType.ListBox, UILocatorType.ID, "EscalationOverrideReason");
    //private UIElement caseNumber = new UIElement(UIType.Label,UILocatorType.CSS,"table>tbody>tr>div:nth-child(7)>div>span");
    //private UIElement caseNumber = new UIElement(UIType.Label,UILocatorType.Xpath,"//table[@id='hoz_mainHeader']/tbody/tr[2]/td[5]/nobr/span");
    //ORIGINAL private UIElement caseNumber = new UIElement(UIType.Label,UILocatorType.Xpath,"//div[@id='RULE_KEY']/div[1]//div[7]/div//span");
    private UIElement caseNumber = new UIElement(UIType.Label, UILocatorType.CSS, "div:nth-child(1)>div>div>div.content-item.content-field.item-9.hoz_customerCaseNumber>div>div>span");
    private UIElement emailAddress = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='RULE_KEY']/table[2]//td[2]/nobr/span");
    private UIElement caseNumberEU = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-test-id='2015081013593405235772']");
    private UIElement claimVoidReason = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-test-id='2015061615245305163547']");
    private UIElement eligibilityMsg = new UIElement(UIType.Label, UILocatorType.Xpath, "//span/div/div/table/tbody/tr[2]/td/div/table[2]/tbody/tr[2]/td/table/tbody/tr/td/div/span/table/tbody/tr[1]/td[2]/div/div/div/div/div/div/div/div/div/div[1]");
    private UIElement inWarrantyYes = new UIElement(UIType.Label, UILocatorType.ID, "DeviceInOEMWarrantyY");
    private UIElement inWarrantyNo = new UIElement(UIType.Label, UILocatorType.ID, "DeviceInOEMWarrantyN");
    private UIElement testiframe = new UIElement(UIType.Frame, UILocatorType.ID, "testiframe");
    private UIElement todaysIncidentDate = new UIElement(UIType.TextBox, UILocatorType.ID, "IncidentDate");
    private UIElement assertModel = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedAssetModelID");
    private UIElement assertMake = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedAssetMakeID");
    private UIElement assertColur = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedAssetCatalogID");
    private UIElement textIncidenOccurredOn = new UIElement(UIType.Label, UILocatorType.Xpath, "//label[contains(text(),'Incident Occurred On')]");
    private UIElement textIncidenOccurred = new UIElement(UIType.Label, UILocatorType.ID, "hoz_selectIncidentAsset");
    //    private UIElement incidentDateTodayEU = new UIElement(UIType.Link, UILocatorType.Xpath,".//*[@id='RULE_KEY']/div/div/div/div[2]/div/div/div/div/div[2]/div/div/div/div/div[1]/div/div/span/a");
    private UIElement incidentDateTodayEU = new UIElement(UIType.Link, UILocatorType.Xpath, "//*[@data-test-id='20150623110846007714959']");
    private UIElement incidentDateYesterdayEU = new UIElement(UIType.Link, UILocatorType.Xpath, "//*[@data-test-id='20150623110846008220473']");
    private UIElement continueButtonAssetEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='20151020105923044361874']");
    //asset details select boxes
    //Override third claim
    private UIElement claimOverrideAction = new UIElement(UIType.RadioButton, UILocatorType.CSS, "#EligibilityNextActionOverride");
    private UIElement claimOverrideEscalationReason = new UIElement(UIType.ListBox, UILocatorType.CSS, "#EscalationOverrideReason");
    private UIElement claimOverrideContinueButton = new UIElement(UIType.Button, UILocatorType.CSS, "td.buttonTdMiddle");
    private UIElement deviceInOEMWarrantyYes = new UIElement(UIType.RadioButton, UILocatorType.ID, "DeviceInOEMWarrantyYes");
    private UIElement deviceInOEMWarrantyNo = new UIElement(UIType.RadioButton, UILocatorType.ID, "DeviceInOEMWarrantyNo");
    private UIElement manufacturerWarrantyMessage = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='HARNESS_CONTENT']//div[@id='RULE_KEY']//div[1]/div/div/span");
    private UIElement countinueButton = new UIElement(UIType.Label, UILocatorType.CSS, "button.buttonTdButton");
    private UIElement PerilOutsideAgreementError_LA = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='HARNESS_CONTENT']//div[@id='RULE_KEY']/div[1]/div/div/div[1]/div/div/div/div/div[1]/div/div/span");
    private UIElement ID_LA = new UIElement(UIType.Label, UILocatorType.ID, "CT");
    private UIElement CorrelationID_LA = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='_popOversContainer']//div[@id='RULE_KEY']//div/div/div/div/span");
    private UIElement closeCorrelationPopup = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='_popOversContainer']/div/ul/li/div[2]/div/div[1]/span[@id='SinfoCloseIcon']");
    private UIElement LateReportedError_LA = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='pyFlowActionHTML']//div[@id='RULE_KEY']//div[@class='field-item dataValueRead'] ");
    private UIElement errorMsgText_LA = new UIElement(UIType.Label, UILocatorType.CSS, "[node_name=DisplayErrorMessage]>.layout.layout-none .dataValueRead>span");

    /**
     * This method is used to select incident type
     * * @author Sachin
     *
     * @param incident eg. Damage
     */
    public void select_Incident_Type(String incident) throws Exception {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Incident details page.", false);
        }
        driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        // driver.switchToFrame(cpmTabbedNavigationDivFrame);
         CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(incidentType, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(incidentType, incident);
        } else {
            Assert.assertTrue("Incident Type is not found on Incident details listbox.", false);
        }

    }


    public void select_Covered_Event(String coveredEvent) throws Exception {
        //Covered event must load after Incident Type is selected
         CommonUtilities.waitTime(7);
        //Check for element - covered event.
          driver.click(incidentDescription);
        if (driver.waitForElementPresenceWithTimeOut(coveredEventCode, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(coveredEventCode, coveredEvent);
        } else {
            Assert.assertTrue("Incident sub type is not found on Incident details page.", false);
        }
        //CommonUtilities.waitTime(3);
        driver.type(incidentDescription, "Covered Event = " + coveredEvent);

    }

    public void select_inWarrnty_condition(String condition) throws Exception {
        if (condition.equalsIgnoreCase("yes")) {
            // driver.checkObjectExists(inWarrantyYes, 30);
            driver.click(inWarrantyYes);
        } else {
            //    driver.checkObjectExists(inWarrantyNo, 30);
            driver.click(inWarrantyNo);
        }


    }

    /**
     * This method used to capture case number
     *
     * @author Sachin
     * Modified by prabhat.das on 02/26/2016
     * Modification: changed the logic for handling Casenumbers
     * Updated By: prabhat.das [updated code to handel upto 6 claims]
     */
    public static String claimId = null;  //null   SNR Charge-148308663062
    public static HashMap<String, String> casenumbers;

    public void capture_case_number() throws Exception {
        //String claimId =null;
        CommonUtilities.waitTime(7);
        driver.switchToDefaultContent();

        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }
        //driver.navigateToFrame(cpmInteractionDivFrame);
        //driver.switchToFrame(diaction);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Incident details page.", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(caseNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            claimId = driver.getText(caseNumber);
        } else {
            Assert.assertTrue("Case Number is not found on Capture Incident page.", false);
        }

        if (!casenumbers.containsKey("CASENUMBER1")) {
            if (casenumbers.containsKey("CASENUMBER")) {
                if (!casenumbers.get("CASENUMBER").equalsIgnoreCase(claimId)) {
                    casenumbers.put("CASENUMBER1", claimId);
                    System.out.println("CaseNumber1: " + claimId);
                }
            } else {
                casenumbers.put("CASENUMBER", claimId);
                System.out.println("CaseNumber: " + claimId);
            }
        } else if (!casenumbers.containsKey("CASENUMBER3")) {
            if (!casenumbers.containsKey("CASENUMBER2") && !casenumbers.containsKey("CASENUMBER3")) {
                if (casenumbers.containsKey("CASENUMBER1") && !casenumbers.get("CASENUMBER1").equalsIgnoreCase(claimId)) {
                    casenumbers.put("CASENUMBER2", claimId);
                    System.out.println("CaseNumber2: " + claimId);
                }
            } else {
                if (casenumbers.containsKey("CASENUMBER2") && !casenumbers.get("CASENUMBER2").equalsIgnoreCase(claimId)) {
                    casenumbers.put("CASENUMBER3", claimId);
                    System.out.println("CaseNumber3: " + claimId);
                }
            }
        }
        if (!casenumbers.containsKey("CASENUMBER4")) {
            if (casenumbers.containsKey("CASENUMBER3") && !casenumbers.get("CASENUMBER3").equalsIgnoreCase(claimId)) {
                casenumbers.put("CASENUMBER4", claimId);
                System.out.println("CaseNumber4: " + claimId);
            }
        } else {
            if (casenumbers.containsKey("CASENUMBER4") && !casenumbers.get("CASENUMBER4").equalsIgnoreCase(claimId)) {
                casenumbers.put("CASENUMBER5", claimId);
                System.out.println("CaseNumber5: " + claimId);
            }
        }

        CustomerDetails.customerData.putAll(casenumbers);


    }

    /*
     * This method used to capture Correlation ID which will help in getting DB logs for particular interaction
     * @author Kapil Gonjari
     * Date: 25/05/2016
     */

    public void capture_CorrelationID() throws Exception {
        CommonUtilities.waitTime(7);
        driver.switchToDefaultContent();

        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Incident details page.", false);
        }


        if (driver.checkObjectExists(ID_LA, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(ID_LA);
        } else {
            Assert.assertTrue("Correlation ID is not found.", false);
        }


        if (driver.checkObjectExists(CorrelationID_LA, ApplicationConfiguration.getWaitForElementTimeout())) {
            BasePage.CorrelationID = driver.getText(CorrelationID_LA);
            driver.click(closeCorrelationPopup);
        } else {
            Assert.assertTrue("Correlation ID Lablel popup is not found.", false);
        }
        System.out.println("Correlation ID is : " + BasePage.CorrelationID);


    }

    public void enter_incident_date(String incidentDateString) throws Exception {
        CommonUtilities.waitTime(10);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, 60);
        navigateLowestLevelFrame(diaction);
        driver.switchToFrame(cpmTabbedNavigationDivFrame);

        CommonUtilities.waitTime(8);
        //Check incident date.
        if (incidentDateString.equalsIgnoreCase("Today")) {
            //  driver.waitForElementPresence(incidentDateToday);
            if (driver.waitForElementPresenceWithTimeOut(incidentDateToday, ApplicationConfiguration.getWaitForElementTimeout()))
                //driver.click(incidentDateToday);
                driver.javaScriptClick(incidentDateToday);
            else {
                Assert.assertTrue("Today link is not found on Incident details Page.", false);
            }

            capture_case_number();
        } else if (incidentDateString.equalsIgnoreCase("Yesterday")) {
            //  driver.waitForElementPresence(incidentDateYesterday);

            //Check for element exists-incidentDateYesterday and click on same element.
            if (driver.checkObjectExists(incidentDateYesterday, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(incidentDateYesterday);
            } else {
                Assert.assertTrue("Yesterday link is not found on Incident details Page.", false);
            }

            //driver.click(incidentDateYesterday); // commented and added in checkobject exists.

            capture_case_number();
        }

    }

    public void verify_default_asset() throws Exception {
        // Add Logic to Wait for spinning graphic to not be present
//        driver.navigateToFrame(cpmInteractionDivFrame);
//        navigateLowestLevelFrame(diaction);
//        driver.switchToFrame(cpmTabbedNavigationDivFrame);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }


        driver.waitForElementPresence(AssetMake);
        if (driver.checkWebList("VALUE", CustomerDetails.customerData.get("MAKE"), AssetMake))
            assertTrue(true);
        else
            assertTrue(false);

        if (driver.checkWebList("VALUE", CustomerDetails.customerData.get("MODEL"), AssetModel))
            assertTrue(true);
        else
            assertTrue(false);
       /* if(   driver.checkWebList("VALUE",expectedValue,AssetColor))
            assertTrue(true);
        else
            assertTrue(false);*/


    }

    public void select_incident_asset(HashMap<String, String> assetInfo) throws Exception {
        // Add Logic to Wait for spinning graphic to not be present


//            driver.navigateToFrame(cpmInteractionDivFrame);
//            navigateLowestLevelFrame(diaction);
//            driver.switchToFrame(cpmTabbedNavigationDivFrame);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        driver.waitForElementPresence(AssetMake);
        driver.select(AssetMake, assetInfo.get("make"));
        CommonUtilities.waitTime(1);
        // driver.waitForElementPresence(AssetModel);
        driver.select(AssetModel, assetInfo.get("model"));
        CommonUtilities.waitTime(1);
        //driver.waitForElementPresence(AssetMake);
        driver.select(AssetColor, assetInfo.get("color"));
        CommonUtilities.waitTime(1);
        driver.waitAndClick(continueButtonAsset);


    }

    public void accept_default_asset() throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        //Check the frame.
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }
        //Check for diaction to load.
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Incident details page.", false);
        }
        //Check for second diaction to load.
        //     if(ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
           /*if(!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())){
               Assert.assertTrue("Diaction 1 is not found on Incident details page.", false);
           }*/
        //    }

        //navigateLowestLevelFrame(diaction);
        System.out.println(driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()));
        // driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame,30);
        //Check Continue button.
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(continueButtonAsset, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueButtonAsset);
        } else {
            Assert.assertTrue("Continue Button is not found on Incident details page.", false);
        }


    }

    public void submit_incident_information() throws Exception {
        //Check continue button.
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        //Check the frame.
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }
        //Check for diaction to load.
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Incident details page.", false);
        }
        System.out.println(driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()));
        //Check Continue button.
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(continueButtonAsset, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueButtonAsset);
        } else {
            Assert.assertTrue("Continue Button is not found on Incident details page.", false);
        }

    }

    public String verify_claim_message() throws Exception {
//            driver.navigateToFrame(cpmInteractionDivFrame);
//            navigateLowestLevelFrame(diaction);
//            driver.switchToFrame(cpmTabbedNavigationDivFrame);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        driver.waitForElementPresence(claimMessageReturned);
        return (driver.getText(claimMessageReturned));


    }

    public void override_eligiblity(String reason) throws Exception {
        CommonUtilities.waitTime(1);
           /* driver.navigateToFrame(cpmInteractionDivFrame);
            navigateLowestLevelFrame(diaction);
            CommonUtilities.waitTime(1);
            driver.switchToFrame(cpmTabbedNavigationDivFrame);*/

        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }
        CommonUtilities.waitTime(1);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
         /*  driver.click(overrideEligibility);
           driver.selectListBox(OverrideReason, reason);
           driver.click(continueButton);*/
        if (driver.waitForElementPresenceWithTimeOut(claimOverrideAction, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(claimOverrideAction);
        } else {
            Assert.assertTrue("claimOverrideAction is not found on Incident details Page.", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(claimOverrideEscalationReason, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.selectListBox(claimOverrideEscalationReason, reason);
        } else {
            Assert.assertTrue("claimOverrideEscalationReason is not found on Incident details Page.", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(claimOverrideContinueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(claimOverrideContinueButton);
        } else {
            Assert.assertTrue("claimOverrideEscalationReason is not found on Incident details Page.", false);
        }


    }

    public void selectVoid() throws Exception {
        // driver.checkObjectExists(eligibilityVoid,50);
        driver.click(eligibilityVoid);

    }

    public String verify_override_eligiblity_msg() throws Exception {
        CommonUtilities.waitTime(1);
//            driver.navigateToFrame(cpmInteractionDivFrame);
//            navigateLowestLevelFrame(diaction);
//            CommonUtilities.waitTime(1);
//            driver.switchToFrame(cpmTabbedNavigationDivFrame);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }

        CommonUtilities.waitTime(1);

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        System.out.print(driver.getText(overrideEligibilityMsg));
        return driver.getText(overrideEligibilityMsg);


    }

    public String verify_eligiblity_msg() throws Exception {
        //   driver.checkObjectExists(eligibilityMsg,50);

        System.out.print(driver.getText(eligibilityMsg));
        return driver.getText(eligibilityMsg);


    }

    public void enter_previous_incident_date(int incidentDateString) throws Exception {
      /*  driver.navigateToFrame(cpmInteractionDivFrame);
       // driver.waitForFrameToLoad(cpmInteractionDivFrame,60);
        navigateLowestLevelFrame(diaction);
        driver.switchToFrame(cpmTabbedNavigationDivFrame);*/
        //Check for indicent date today.
        CommonUtilities.waitTime(3);

        if (!driver.waitForElementPresenceWithTimeOut(incidentDateToday, ApplicationConfiguration.getWaitForElementTimeout())) {

            Assert.assertTrue("Today Link is not found on Incident details Page.", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(todaysIncidentDate, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(todaysIncidentDate, DateUtil.getFormattedDatetime("MM/dd/yyyy", DateUtil.getModifiedDateTime("Day", -incidentDateString)));
            driver.tabOutOf(todaysIncidentDate);
        } else {
            Assert.assertTrue("Incident Date Text Box is not found on Incident details Page.", false);
        }

        /*System.out.println("incidentDateToday    " + driver.getAttribute(todaysIncidentDate,"value"));
        driver.javaScriptClick(textIncidenOccurredOn);
        driver.javaScriptClick(textIncidenOccurred);
        List<WebElement> e=driver.findElements(By.id("hoz_selectIncidentAsset"));
        for(WebElement e1:e)
        {
            e1.click();
        }
*/


    }

    public void selectSpecifiedAssetWithDetails(String sMake, String sModel, String sColor) throws Exception {
//            driver.navigateToFrame(cpmInteractionDivFrame);
//            navigateLowestLevelFrame(diaction);
//            driver.switchToFrame(cpmTabbedNavigationDivFrame);

        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        //Check for assert make element.
        if (driver.checkObjectExists(assertMake, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(assertMake, sMake);
        } else {
            Assert.assertTrue("Asset Make is not found on Incident details Page.", false);
        }
        CommonUtilities.waitTime(1);
        //Check for element - assert Model.
        if (driver.checkObjectExists(assertModel, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(assertModel, sModel);
        } else {
            Assert.assertTrue("Asset Model is not found on Incident details Page.", false);
        }
        CommonUtilities.waitTime(1);
        //Check for elemt -assert color.
        if (driver.checkObjectExists(assertColur, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(assertColur, sColor);
        } else {
            Assert.assertTrue("Assert Color is not found on Incident details Page.", false);
        }
        CommonUtilities.waitTime(1);
        //Check for element continue button.
        if (driver.checkObjectExists(continueButtonAssetEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(continueButtonAssetEU);
        } else {
            Assert.assertTrue("Continue Button is not found on Incident details Page.", false);
        }


    }

    public void capture_case_number_eu() {
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());

        if (driver.elementExists(caseNumberEU)) {
            String claimId = driver.getText(caseNumberEU);
            System.out.println("caseNumber: " + claimId);
            CustomerDetails.customerData.put("CASENUMBER", claimId);
            Generic.setGlobals("CASENUMBER", claimId);
        } else {
            Assert.assertTrue("Case number is not displayed", false);
        }

    }

    /**
     * This method is used to capture email address from UI
     * * @author Shweta
     */
    public void capture_email_address_fromUI() throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        //Check for load the element-cpmInteractionDivFrame.
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on contact details page.", false);
        }
        //Check for load the element-diaction.
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Incident details page.", false);
        }
        //Check for client.
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            //Check for load the element.
            if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
                Assert.assertTrue("Diaction 1 is not found on Incident details page.", false);
            }
        }
        //Check for element presence and get the text.
        if (driver.waitForElementPresenceWithTimeOut(emailAddress, ApplicationConfiguration.getWaitForElementTimeout())) {
            String emailID = driver.getText(emailAddress);
            System.out.println("Email Address: " + emailID);
            BasePage.capture_EmailID = emailID;
            BasePage.emailAddress = emailID;
        } else {
            Assert.assertTrue("Email Address is not found on header of contact details Page.", false);
        }
    }

    public void enter_incident_date_EU() {

        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, 60);
        driver.waitForFrameToLoad(diaction, 60);
        driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, 50);
        CommonUtilities.waitTime(5);
        if (driver.waitForElementPresenceWithTimeOut(incidentDateToday, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(incidentDateToday);
            System.out.println("Clicked on incident date Today link");
        } else {
            System.out.println("Incident date Today link is not displayed");
            Assert.assertTrue("Incident date Today link is not displayed", false);
        }


    }

    public void enter_incident_date_yesterday_EU() {

        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, 60);
        driver.waitForFrameToLoad(diaction, 60);
        driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, 50);
        CommonUtilities.waitTime(5);
        if (driver.waitForElementPresenceWithTimeOut(incidentDateYesterdayEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(incidentDateYesterdayEU);
            System.out.println("Clicked on incident date Yesterday link");
        } else {
            System.out.println("Incident date Yesterday link is not displayed");
            Assert.assertTrue("Incident date Yesterday link is not displayed", false);
        }


    }

    public void accept_default_asset_EU() {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());
        System.out.println(driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()));
        CommonUtilities.waitTime(5);
        if (driver.elementExists(continueButtonAssetEU)) {
            driver.javaScriptClick(continueButtonAssetEU);
            System.out.println("Clicked on Asset confirmation Continue");
        } else {
            System.out.println("Asset confirmation Continue button is not displayed");
            Assert.assertTrue("Asset confirmation Continue button is not displayed", false);
        }
    }

    public void select_Incident_TypeEU(String incident) throws Exception {
        driver.switchToDefaultContent();

        //Check for frame loaded or not.
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }

        //Check for frame loaded or not.
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Incident details page.", false);
        }

        driver.switchToFrame(cpmTabbedNavigationDivFrame);

        // Check for element present or not.
        if (driver.waitForElementPresenceWithTimeOut(incidentType, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(incidentType, incident);
            System.out.println("Selected  Incudent type -" + incident);
        } else {
            System.out.println("Incident Type is not found on Incident details listbox.");
            Assert.assertTrue("Incident Type is not found on Incident details listbox.", false);
        }


    }

    public void deviceInManufacturalWarranty(String sYesNo) throws Exception {


        if (sYesNo.equalsIgnoreCase("yes")) {
            if (driver.waitForElementPresenceWithTimeOut(deviceInOEMWarrantyYes, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.click(deviceInOEMWarrantyYes);
            else
                Assert.assertTrue("device In OEM Warranty Yes radio button is not found on Incident details Page.", false);
        } else {
            if (driver.waitForElementPresenceWithTimeOut(deviceInOEMWarrantyNo, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.click(deviceInOEMWarrantyNo);
            else
                Assert.assertTrue("device In OEM Warranty No radio button is not found on Incident details Page.", false);
        }


    }

    /**
     * This method is used for verification of Incident Not Covered Or Manufacturer Warranty Message
     *
     * @param message
     * @author Priyanka
     */
    public void verificationIncidentNotCoveredOrManufacturerWarrantyMessage(String message) throws Exception {
        String sApplicatioMessage = "";
        if (message.toLowerCase().contains("Incident type is not covered by agreement".toLowerCase())) {
            if (driver.waitForElementPresenceWithTimeOut(manufacturerWarrantyMessage, ApplicationConfiguration.getWaitForElementTimeout())) {
                sApplicatioMessage = driver.getText(manufacturerWarrantyMessage);
                Assert.assertTrue("Incident type is not covered by agreement message verification : ", sApplicatioMessage.toLowerCase().contains("Incident type is not covered by agreement".toLowerCase()));
            } else
                Assert.assertTrue("Incident type is not covered by agreement message not found ", false);
        } else if (message.toLowerCase().contains("Asset under manufacturer warranty, please refer to store".toLowerCase())) {
            if (driver.waitForElementPresenceWithTimeOut(manufacturerWarrantyMessage, ApplicationConfiguration.getWaitForElementTimeout())) {
                sApplicatioMessage = driver.getText(manufacturerWarrantyMessage);
                Assert.assertTrue("device In OEM Warranty message verification : ", sApplicatioMessage.toLowerCase().contains("Asset under manufacturer warranty, please refer to store".toLowerCase()));
            } else
                Assert.assertTrue("device In OEM Warranty mssage not found ", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(countinueButton, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.click(countinueButton);
        else
            Assert.assertTrue("countinue button not found ", false);


    }

    /**
     * This method is used for verification of message script when peril date seleected is ouside enrollment date
     *
     * @author Kapil Gonjari
     */
    public void Perildate_outsideEnrollmentDate_LA() {
        driver.switchToDefaultContent();
        //Check for frame loaded or not.
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }

        //Check for frame loaded or not.
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Incident details page.", false);
        }


        driver.switchToFrame(cpmTabbedNavigationDivFrame);
        CommonUtilities.waitTime(6);
        if (driver.waitForElementPresenceWithTimeOut(PerilOutsideAgreementError_LA, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.getText(PerilOutsideAgreementError_LA);
            System.out.println("text is" + driver.getText(PerilOutsideAgreementError_LA));        //Assert.assertTrue("Incident date outside Enrollment start date :", driver.getText(PerilOutsideAgreementError_LA).contains("Agreement not active at time of incident".toLowerCase()));
            Assert.assertTrue(driver.getText(PerilOutsideAgreementError_LA).contentEquals("Agreement not active at time of incident"));
            // Assert.assertTrue("Incident type is not covered by agreement message verification : ", sApplicatioMessage.toLowerCase().contains("Incident type is not covered by agreement".toLowerCase()));
        } else
            Assert.assertTrue("Perildate outside Agreementdate Error script not found.", false);

    }

    public void LateReportedClaim_LA() {
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        //Check for frame loaded or not.
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }

        //Check for frame loaded or not.
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Incident details page.", false);
        }


        driver.switchToFrame(cpmTabbedNavigationDivFrame);
        CommonUtilities.waitTime(6);
        if (driver.waitForElementPresenceWithTimeOut(LateReportedError_LA, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.getText(LateReportedError_LA);
            System.out.println("text is" + driver.getText(LateReportedError_LA));
            Assert.assertTrue(driver.getText(LateReportedError_LA).contentEquals("Claim not filed within reporting period"));
        } else
            Assert.assertTrue("Claim not filed within reporting period Error script not found.", false);
    }


    //@Author - Shahabuddin Ansari
    //To check the error messages of the suspended or terminated agreements

    public void verifyErrorMessageScript(String errorScript) {
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        //Check for frame loaded or not.
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }
        //Check for frame loaded or not.
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Incident details page.", false);
        }

        driver.switchToFrame(cpmTabbedNavigationDivFrame);
        CommonUtilities.waitTime(6);
        if (driver.waitForElementPresenceWithTimeOut(errorMsgText_LA, ApplicationConfiguration.getWaitForElementTimeout())) {

            String textMsg = driver.getText(errorMsgText_LA);

            switch (errorScript) {
                case "Agreement Suspended":
                    System.out.println("Text of the Error Message is : " + textMsg);
                    Assert.assertTrue(textMsg.contentEquals("Agreement Suspended At Time Of Loss"));
                    break;

                case "Agreement Termination":
                    System.out.println("Text of the Error Message is : " + textMsg);
                    Assert.assertTrue(textMsg.contentEquals("Agreement not active at time of incident"));
                    break;

                case "Incident date outside enrollment period":
                    System.out.println("Text of the Error Message is : " + textMsg);
                    Assert.assertTrue(textMsg.contentEquals("Agreement not active at time of incident"));
                    break;
            }

        } else
            Assert.assertTrue("Error message for " + errorScript + " is not found ", false);
    }

}
