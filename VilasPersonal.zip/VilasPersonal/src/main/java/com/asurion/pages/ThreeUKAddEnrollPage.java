package com.asurion.pages;

import com.asurion.util.ApplicationConfiguration;
import com.asurion.common.core.driver.TestDriver;
import com.asurion.util.DateUtil;
import com.asurion.util.Generic;
import com.opencsv.CSVWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
//

/**
 * Created by cwr.rohit.aher on 2/17/2016.
 */
public class ThreeUKAddEnrollPage extends BasePage {

    private static String CurrentFile;
    private static String currentDate = getCurrentTimeStampDate();
    private static String currentDateTime = getCurrentTimeStamp();
    public static String[] input = new String[60];
    public static LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();

    public static void getDefaultDataIntoHashmap() throws Exception {
        // TODO Auto-generated method stub
        hm.put("Record Identifier", "20");
        hm.put("BAN", getUniqueBAN_EU());
        hm.put("CRMID", getUniqueCRMID_EU());
        hm.put("Gender", "M");
        hm.put("Title", "MR");
        hm.put("First_name", "EUQA");
        hm.put("Last_name", "Automation");
        hm.put("Date_of_birth", "01/01/1983");
        hm.put("House_number", "Flat 12");
        hm.put("House_name", "");
        hm.put("Flat_number", "");
        hm.put("Billing_address_line1", "Gillray House");
        hm.put("Billing_address_line2", "");
        hm.put("Billing_address_line3", "");
        hm.put("Billing_address_line4", "");
        hm.put("Postal_town", "Sutton Grove");
        hm.put("County", "Sutton");
        hm.put("Post_code", "SM1 4TQ");
        hm.put("Country", "GBR");
        hm.put("Email Address", "test"+Generic.getValuesFromGlobals("BAN")+"@asurion.com");
        hm.put("Customer Type", "UK_CONS_SERVICE");
        hm.put("H3G Relationship Start Date", "20161010000000");
        hm.put("H3G Relationship End Date", "20191010000000");
        hm.put("Contract Start Date", "20161010000000");
        hm.put("Contract End Date", "20201231000000");
        hm.put("Collections Indicator", "N");
        hm.put("F&S Indicator", "N");
        hm.put("Suspended Account Indicator", "ACT");
        hm.put("Insurance_add_on_id", "CTA0344");
        hm.put("Insurance Add-on Installed Date", "20161010000000");
        hm.put("MSISDN", getUniqueMDN_EU());
        hm.put("ICCID", "44744791000001");
        hm.put("Device_product_id", "11810");
        hm.put("IMEI", getUniqueIMEI_EU());
        hm.put("IMEI_on_blacklist_indicator", "N");
        hm.put("Insurance_Cancellation_date", "");
        hm.put("Suspend Collection Code", "N");
        hm.put("Suspend Collection Reason Code", "");
        hm.put("SIM Barred Indicator", "");
        hm.put("Insurance Cancellation Reason Code", "");
        hm.put("Pending_Device_Product_ID", "");
        //        Data for S&C;
        hm.put("Cancel_Record_Identifier", "10");
        hm.put("Cancel_BAN", Generic.getValuesFromGlobals("BAN"));
        hm.put("Cancel_Insurance_add_on_id", "CTA0344");
        hm.put("Cancel_Insurance_start_date", "10/10/2016 00:00:00");
        hm.put("Cancel_Sales_channel", "RETAIL");
        hm.put("Cancel_Dealer_code", "CGP01");
        hm.put("Cancel_Selling_agent_id", "DEVD");
        hm.put("Cancel_Insurance_end_date", "");
        hm.put("Cancel_Cancellation_reason_code", "");
        hm.put("Cancel_Sales_override_reason_code", "");
        hm.put("Cancel_Deposit", "0");
        //        Data for Billing;
        hm.put("Billing_Record_Identifier", "");
        hm.put("Billing_BAN", Generic.getValuesFromGlobals("BAN"));
        hm.put("Billing_day_of_month", "02");
        hm.put("Billing_Outstanding_Balance", "0");

        ////incidentDate for Null enrollment
        hm.put("INCIDENTDATE", DateUtil.getFormattedDatetime("yyyyMMdd", DateUtil.getModifiedDateTime("DAY", -0)));
        hm.put("BILINGSTATUS", "Active");
        hm.put("ASSETMAKE", "BlackBerry");
        hm.put("ASSETMODEL", "9320");
        hm.put("ASSETCOLOR", "White");
        // SKU Code Description For Null Enrollment
        hm.put("Insurance_add_on_id_Description","3 UK Full Peril GBP 6");



        setUniqueENROLMENT_FOLDERS();    }

    public static void setUniqueENROLMENT_FOLDERS() throws Exception {

        String sftpLocationInbound = "";
        String sftpLinuxPathInbound = "";
        if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizondevinteu")) {
            sftpLocationInbound = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\DevInt\\3uk_enrollment\\inbound";
            //sftpLinuxPathInbound = "/opt/sftprepo/3uk_enrollment/inbound";
            throw new Exception("3UK is not currently configured on " + ApplicationConfiguration.getEnvironment());
        } else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa")) {
            sftpLocationInbound = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\euqa01\\3uk_enrollment\\inbound";
            sftpLinuxPathInbound = "/opt/sftprepo/euqa01/euqa01/3uk_enrollment/inbound";
//            throw new Exception("3UK is not currently configured on " + ApplicationConfiguration.getEnvironment());
        } else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqaeu")) {
            sftpLocationInbound = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\3uk_enrollment\\inbound";
            sftpLinuxPathInbound = "/opt/sftprepo/3uk_enrollment/inbound";
        } else {

        }


        String sftpLocationArchive= "";
        String sftpLinuxPathArchive = "";
        if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizondevinteu")) {
            sftpLocationArchive = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\DevInt\\3uk_enrollment\\archive";
            //sftpLinuxPathArchive = "/opt/sftprepo/3uk_enrollment/archive";
            throw new Exception("3UK is not currently configured on " + ApplicationConfiguration.getEnvironment());
        } else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa")) {
            sftpLocationArchive = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\euqa01\\3uk_enrollment\\archive";
            sftpLinuxPathArchive = "/opt/sftprepo/euqa01/euqa01/3uk_enrollment/archive";
//            throw new Exception("3UK is not currently configured on " + ApplicationConfiguration.getEnvironment());
        } else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqaeu")) {
            sftpLocationArchive = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\3uk_enrollment\\archive";
            sftpLinuxPathArchive = "/opt/sftprepo/3uk_enrollment/archive";
        }else {

        }

        String sftpLocationDone= "";
        String sftpLinuxPathDone = "";
        if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizondevinteu")) {
            sftpLocationDone = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\DevInt\\3uk_enrollment\\done";
            //sftpLinuxPathDone = "/opt/sftprepo/3uk_enrollment/done";
            throw new Exception("3UK is not currently configured on " + ApplicationConfiguration.getEnvironment());
        } else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa")) {
            sftpLocationDone = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\euqa01\\3uk_enrollment\\done";
            sftpLinuxPathDone = "/opt/sftprepo/euqa01/euqa01/3uk_enrollment/done";
//            throw new Exception("3UK is not currently configured on " + ApplicationConfiguration.getEnvironment());
        } else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqaeu")) {
            sftpLocationDone = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\3uk_enrollment\\done";
            sftpLinuxPathDone = "/opt/sftprepo/3uk_enrollment/done";
        }
        else {

        }


        String folderID = null;
        while  (true)
        {
            folderID = Generic.RandomNumber();
            String completeSftpLocationInbound = sftpLocationInbound + '\\' + folderID;
            String completeSftpLocationArchive = sftpLocationArchive + '\\' + folderID;
            String completeSftpLocationDone = sftpLocationDone + '\\' + folderID;

            String completeSftpPathInbound = sftpLinuxPathInbound + '/' + folderID + '/';
            String completeSftpPathArchive = sftpLinuxPathArchive + '/' + folderID + '/';
            String completeSftpPathDone = sftpLinuxPathDone + '/' + folderID + '/';


            boolean sftpLocationInboundExists = new File(completeSftpLocationInbound).exists();
            boolean sftpLocationArchiveExists = new File(completeSftpLocationArchive).exists();;
            boolean sftpLocationDoneExists = new File(completeSftpLocationDone).exists();;

            if (!sftpLocationInboundExists && !sftpLocationArchiveExists && !sftpLocationDoneExists) {

                boolean sftpLocationInboundCreated = (new File(completeSftpLocationInbound)).mkdirs();
                boolean sftpLocationArchiveCreated = (new File(completeSftpLocationArchive)).mkdirs();
                boolean sftpLocationDoneCreated = (new File(completeSftpLocationDone)).mkdirs();

                hm.put("ENROLMENT_INBOUND_FOLDER", completeSftpLocationInbound);
                hm.put("ENROLMENT_ARCHIVE_FOLDER", completeSftpLocationArchive);
                hm.put("ENROLMENT_DONE_FOLDER", completeSftpLocationDone);
                hm.put("ENROLMENT_INBOUND_PATH", completeSftpPathInbound);
                hm.put("ENROLMENT_ARCHIVE_PATH", completeSftpPathArchive);
                hm.put("ENROLMENT_DONE_PATH", completeSftpPathDone);

                break;
            }
        }
        hm.put("ENROLMENT_FOLDERID", folderID );

    }

    public static String getUniqueBAN_EU() {
        String mdn = Generic.RandomNumber();
        String ban = mdn + "11";
        Generic.setGlobals("BAN", ban);
        return (ban);
    }

    public static String getUniqueIMEI_EU() {
        String mdn = Generic.RandomNumber();
        String IMEI = mdn + "12345";
        Generic.setGlobals("IMEI", IMEI);
        return (IMEI);
    }

    public static String getUniqueMDN_EU() {
        String mdn = Generic.RandomNumber();
        Generic.setGlobals("DAL_MDN","0"+mdn);
        mdn="44"+mdn;
        Generic.setGlobals("MDN", mdn);
        return (mdn);
    }

    public static String getUniqueCRMID_EU() {
        String mdn = Generic.RandomNumber();
        String CRMID = "92" + mdn;
        Generic.setGlobals("CRMID", CRMID);
        return (CRMID);
    }

    public static void setDifferentDataForEnrollment(String param, String value) {
        hm.put(param, value);
        Generic.setGlobals(param, value);
        System.out.println("'"+param+"' is set to value '"+value+"'");
    }
    public static void setDifferentDataForMDNCRMIDBANEnrollment() {
        hm.put("BAN", getUniqueBAN_EU());
        hm.put("CRMID", getUniqueCRMID_EU());
        hm.put("MSISDN", getUniqueMDN_EU());

    }
    public static void setDifferentDataForMDNEnrollment() {

        hm.put("MSISDN", getUniqueMDN_EU());

    }
    public static void setDifferentDataForIMEICRMIDBANEnrollment() {
        hm.put("BAN", getUniqueBAN_EU());
        hm.put("CRMID", getUniqueCRMID_EU());
        hm.put("IMEI", getUniqueIMEI_EU());

    }
    public static void threeinitializeFileData() {
        // System.out.println("INSIDE initialize : " + ExecSequence.Parameter);
        Map mp = new LinkedHashMap<String, String>(hm);
        String sValue, sParam;
        //String[] input = new String[53];

		    	   /* for(int index = 0; index < input.length; index++){
                        input[index] = "";
		    	    }*/
        Iterator it = mp.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            //System.out.println(pair.getKey() + " = " + pair.getValue());
            sParam = pair.getKey().toString();
            sValue = pair.getValue().toString().trim();
            //DEBUG POINT	        System.out.println("Parameter :" + sParam + "Value :" + sValue);
            System.out.println("Paramater and value :- '" + sParam + "' and '" + sValue+"'");
            switch (sParam.trim()) {
                case "Record Identifier":
                    input[0] = sValue;
                    break;
                case "BAN":
                    input[1] = sValue;
                    break;
                case "CRMID":
                    input[2] = sValue;
                    break;
                case "Gender":
                    input[3] = sValue;
                    break;
                case "Title":
                    input[4] = sValue;
                    break;
                case "First_name":
                    input[5] = sValue;
                    break;
                case "Last_name":
                    input[6] = sValue;
                    break;
                case "Date_of_birth":
                    input[7] = sValue;
                    break;
                case "House_number":
                    input[8] = sValue;
                    break;
                case "House_name":
                    input[9] = sValue;
                    break;
                case "Flat_number":
                    input[10] = sValue;
                    break;
                case "Billing_address_line1":
                    input[11] = sValue;
                    break;
                case "Billing_address_line2":
                    input[12] = sValue;
                    break;
                case "Billing_address_line3":
                    input[13] = sValue;
                    break;
                case "Billing_address_line4":
                    input[14] = sValue;
                    break;
                case "Postal_town":
                    input[15] = sValue;
                    break;
                case "County":
                    input[16] = sValue;
                    break;
                case "Post_code":
                    input[17] = sValue;
                    break;
                case "Country":
                    input[18] = sValue;
                    break;
                case "Email Address":
                    input[19] = sValue;
                    break;
                case "Customer Type":
                    input[20] = sValue;
                    break;
                case "H3G Relationship Start Date":
                    input[21] = sValue;
                    break;
                case "H3G Relationship End Date":
                    input[22] = sValue;
                    break;
                case "Contract Start Date":
                    input[23] = sValue;
                    break;
                case "Contract End Date":
                    input[24] = sValue;
                    break;
                case "Collections Indicator":
                    input[25] = sValue;
                    break;
                case "F&S Indicator":
                    input[26] = sValue;
                    break;
                case "Suspended Account Indicator":
                    input[27] = sValue;
                    break;
                case "Insurance_add_on_id":
                    input[28] = sValue;
                    break;
                case "Insurance Add-on Installed Date":
                    input[29] = sValue;
                    break;
                case "MSISDN":
                    input[30] = sValue;
                    break;
                case "ICCID":
                    input[31] = sValue;
                    break;
                case "Device_product_id":
                    input[32] = sValue;
                    break;
                case "IMEI":
                    input[33] = sValue;
                    break;
                case "IMEI_on_blacklist_indicator":
                    input[34] = sValue;
                    break;
                case "Insurance_Cancellation_date":
                    input[35] = sValue;
                    break;
                case "Suspend Collection Code":
                    input[36] = sValue;
                    break;
                case "Suspend Collection Reason Code":
                    input[37] = sValue;
                    break;
                case "SIM Barred Indicator":
                    input[38] = sValue;
                    break;
                case "Insurance Cancellation Reason Code":
                    input[39] = sValue;
                    break;
                case "Pending_Device_Product_ID":
                    input[40] = sValue;
                    break;
                case "Cancel_Record_Identifier":
                    input[41] = sValue;
                    break;
                case "Cancel_BAN":
                    input[42] = Generic.getValuesFromGlobals("BAN");
                    break;
                case "Cancel_Insurance_add_on_id":
                    input[43] = sValue;
                    break;
                case "Cancel_Insurance_start_date":
                    input[44] = sValue;
                    break;
                case "Cancel_Sales_channel":
                    input[45] = sValue;
                    break;
                case "Cancel_Dealer_code":
                    input[46] = sValue;
                    break;
                case "Cancel_Selling_agent_id":
                    input[47] = sValue;
                    break;
                case "Cancel_Insurance_end_date":
                    input[48] = sValue;
                    break;
                case "Cancel_Cancellation_reason_code":
                    input[49] = sValue;
                    break;
                case "Cancel_Sales_override_reason_code":
                    input[50] = sValue;
                    break;
                case "Cancel_Deposit":
                    input[51] = sValue;
                    break;
                case "Billing_Record_Identifier":
                    input[52] = sValue;
                    break;
                case "Billing_BAN":
                    input[53] = sValue;
                    break;
                case "Billing_day_of_month":
                    input[54] = sValue;
                    break;
                case "Billing_Outstanding_Balance":
                    input[55] = sValue;
                    break;
            }
        }
    }

    public static void denialThreeInitilizeFileData() {
        Map mp = new LinkedHashMap<String, String>(hm);
        String sValue, sParam;
        Iterator it = mp.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            //System.out.println(pair.getKey() + " = " + pair.getValue());
            sParam = pair.getKey().toString();
            sValue = pair.getValue().toString().trim();
            //DEBUG POINT	        System.out.println("Parameter :" + sParam + "Value :" + sValue);
            System.out.println("Paramater and value :- " + sParam + " -- " + sValue);
            switch (sParam.trim()) {
                case "Record Identifier":
                    input[0] = sValue;
                    break;
                case "BAN":
                    input[1] = getUniqueBAN_EU();
                    break;
                case "CRMID":
                    input[2] = getUniqueCRMID_EU();
                    break;
                case "Gender":
                    input[3] = sValue;
                    break;
                case "Title":
                    input[4] = sValue;
                    break;
                case "First_name":
                    input[5] = sValue;
                    break;
                case "Last_name":
                    input[6] = sValue;
                    break;
                case "Date_of_birth":
                    input[7] = sValue;
                    break;
                case "House_number":
                    input[8] = sValue;
                    break;
                case "House_name":
                    input[9] = sValue;
                    break;
                case "Flat_number":
                    input[10] = sValue;
                    break;
                case "Billing_address_line1":
                    input[11] = sValue;
                    break;
                case "Billing_address_line2":
                    input[12] = sValue;
                    break;
                case "Billing_address_line3":
                    input[13] = sValue;
                    break;
                case "Billing_address_line4":
                    input[14] = sValue;
                    break;
                case "Postal_town":
                    input[15] = sValue;
                    break;
                case "County":
                    input[16] = sValue;
                    break;
                case "Post_code":
                    input[17] = sValue;
                    break;
                case "Country":
                    input[18] = sValue;
                    break;
                case "Email Address":
                    input[19] = sValue;
                    break;
                case "Customer Type":
                    input[20] = sValue;
                    break;
                case "H3G Relationship Start Date":
                    input[21] = sValue;
                    break;
                case "H3G Relationship End Date":
                    input[22] = sValue;
                    break;
                case "Contract Start Date":
                    input[23] = sValue;
                    break;
                case "Contract End Date":
                    input[24] = sValue;
                    break;
                case "Collections Indicator":
                    input[25] = sValue;
                    break;
                case "F&S Indicator":
                    input[26] = sValue;
                    break;
                case "Suspended Account Indicator":
                    input[27] = sValue;
                    break;
                case "Insurance_add_on_id":
                    input[28] = sValue;
                    break;
                case "Insurance Add-on Installed Date":
                    input[29] = sValue;
                    break;
                case "MSISDN":
                    input[30] = getUniqueMDN_EU();
                    break;
                case "ICCID":
                    input[31] = sValue;
                    break;
                case "Device_product_id":
                    input[32] = sValue;
                    break;
                case "IMEI":
                    input[33] = Generic.getValuesFromGlobals("IMEI");
                    break;
                case "IMEI_on_blacklist_indicator":
                    input[34] = sValue;
                    break;
                case "Insurance_Cancellation_date":
                    input[35] = sValue;
                    break;
                case "Suspend Collection Code":
                    input[36] = sValue;
                    break;
                case "Suspend Collection Reason Code":
                    input[37] = sValue;
                    break;
                case "SIM Barred Indicator":
                    input[38] = sValue;
                    break;
                case "Insurance Cancellation Reason Code":
                    input[39] = sValue;
                    break;
                case "Pending_Device_Product_ID":
                    input[40] = sValue;
                    break;
                case "Cancel_Record_Identifier":
                    input[41] = sValue;
                    break;
                case "Cancel_BAN":
                    input[42] = Generic.getValuesFromGlobals("BAN");
                    break;
                case "Cancel_Insurance_add_on_id":
                    input[43] = sValue;
                    break;
                case "Cancel_Insurance_start_date":
                    input[44] = sValue;
                    break;
                case "Cancel_Sales_channel":
                    input[45] = sValue;
                    break;
                case "Cancel_Dealer_code":
                    input[46] = sValue;
                    break;
                case "Cancel_Selling_agent_id":
                    input[47] = sValue;
                    break;
                case "Cancel_Insurance_end_date":
                    input[48] = sValue;
                    break;
                case "Cancel_Cancellation_reason_code":
                    input[49] = sValue;
                    break;
                case "Cancel_Sales_override_reason_code":
                    input[50] = sValue;
                    break;
                case "Cancel_Deposit":
                    input[51] = sValue;
                    break;
            }
        }
    }

    public static void createETLfiles(String ScenarioType) throws Exception {

        String ClientName = "3UK";
        String[] fileList = new String[4];
        String[] fileList1 = new String[1];

        if (ClientName.contains("3UK") && ScenarioType.toUpperCase().equalsIgnoreCase("ADD")) {
            fileList[0] = "3UK_PS";
            fileList[1] = "3UK_CL";
            fileList[2] = "3UK_BL";
        }else if (ClientName.contains("3UK") && ScenarioType.toUpperCase().equalsIgnoreCase("AD1PSFTYesSCYesBillingNo")) {
            fileList[0] = "3UK_PS";
            fileList[1] = "3UK_CL";
            fileList[2] = "3UK_CNLB";
        }else if (ClientName.contains("3UK") && ScenarioType.toUpperCase().equalsIgnoreCase("AD2PSFTYesSCNoBillingNo")) {
            fileList[0] = "3UK_PS";
            fileList[1] = "3UK_UPD";
            fileList[2] = "3UK_CNLB";
        }
        else if (ClientName.contains("3UK") && ScenarioType.toUpperCase().equalsIgnoreCase("AD3PSFTYesSCNoBillingYes")) {
            fileList[0] = "3UK_PS";
            fileList[1] = "3UK_UPD";
            fileList[2] = "3UK_BL";
        }
        else if (ClientName.contains("3UK") && ScenarioType.equalsIgnoreCase("UPDATE")) {
            fileList[0] = "3UK_PS";
            fileList[1] = "3UK_UPD";
            fileList[2] = "3UK_BL";
        } else if (ClientName.contains("3UK") && ScenarioType.equalsIgnoreCase("CANCEL")) {
            fileList[0] = "3UK_CNLP";
            fileList[1] = "3UK_CNLCL";
            fileList[2] = "3UK_CNLB";
        } else if (ClientName.contains("3UK") && ScenarioType.equalsIgnoreCase("CANCELWITHYESBLNOPSFT")) {
            fileList[0] = "3UK_CNLP";
            fileList[1] = "3UK_CNLCL";
            fileList[2] = "3UK_BL";
        } else if (ClientName.contains("3UK") && ScenarioType.toUpperCase().equalsIgnoreCase("RECORDWITHCANCELRESONCODE")) {
            fileList[0] = "3UK_PS";
            fileList[1] = "3UK_CNLCL";
            fileList[2] = "3UK_BL";
        } else if (ClientName.contains("3UK") && ScenarioType.toUpperCase().equalsIgnoreCase("CANCELPSFTYESBILLINGNO")) {
            fileList[0] = "3UK_PS";
            fileList[1] = "3UK_CNLCL";
            fileList[2] = "3UK_CNLB";
        } else if (ClientName.contains("3UK") && ScenarioType.toUpperCase().equalsIgnoreCase("CANCELPSFTYESBILLINGYESS&CNO")) {
            fileList[0] = "3UK_PS";
            fileList[1] = "3UK_UPD";
            fileList[2] = "3UK_BL";
        } else if (ClientName.contains("3UK") && ScenarioType.toUpperCase().equalsIgnoreCase("CANCELPSFTYESBILLINGNOS&CNO")) {
            fileList[0] = "3UK_PS";
            fileList[1] = "3UK_UPD";
            fileList[2] = "3UK_CNLB";
        }else if (ClientName.contains("3UK") && ScenarioType.toUpperCase().equalsIgnoreCase("CANCELPSFTNOBILLINGNOS&CYES")) {
            fileList[0] = "3UK_CNLP";
            fileList[1] = "3UK_CNLCL";
            fileList[2] = "3UK_CNLB";
        }
        else if (ClientName.contains("3UK") && ScenarioType.toUpperCase().equalsIgnoreCase("NORECORD")) {
            fileList[0] = "3UK_CNLP";
            fileList[1] = "3UK_UPD";
            fileList[2] = "3UK_CNLB";
        } else if (ClientName.contains("3UK") && ScenarioType.toUpperCase().equalsIgnoreCase("MONTHLYBILLING")) {
            fileList1[0] = "3UK_MB";
        }
        if (ScenarioType.toUpperCase().equalsIgnoreCase("MONTHLYBILLING")) {
            for (int i = 0; i < fileList1.length; i++) {
                // Write hashmap data to file and then drop the file on temp location
                // Get the file names from below method
                if (fileList1[i] != null) {
                    CurrentFile = fileList1[i];
                    //System.out.println(CurrentFile);
                    String eFile = getFileName(fileList1[i]) + ".csv";
                    writeToCSV(eFile, hm.get("ENROLMENT_INBOUND_FOLDER"));
                    System.out.println("File Created for : " + getFileName(fileList1[i]));
                }
            }
        } else {
            for (int i = 0; i < fileList.length; i++) {
                // Write hashmap data to file and then drop the file on temp location
                // Get the file names from below method
                if (fileList[i] != null) {
                    CurrentFile = fileList[i];
                    //System.out.println(CurrentFile);
                    String eFile = getFileName(fileList[i]) + ".csv";
                    writeToCSV(eFile, hm.get("ENROLMENT_INBOUND_FOLDER"));
                    System.out.println("File Created for : " + getFileName(fileList[i]));
                }
            }
        }
    }

    public static void writeToCSV(String efile, String sftpLocation) throws Exception {
//        String sftpLocation = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\3uk_enrollment\\inbound";
//        String tempLocation = "\\\\ndcsqafp401\\IT_QA_Test\\QATest_Horizon_Enrollment\\EU\\3UK\\";
        String tempLocation = "C:\\Asurion\\";
        String csv = tempLocation + efile; // Temp Folder location and file name
        String ghcsv= tempLocation + efile + ".gz";
        try {
            System.out.println(csv);
            CSVWriter writer = new CSVWriter(new FileWriter(csv), ',', '"', CSVWriter.NO_ESCAPE_CHARACTER, System.getProperty("line.separator"));
            //writer = new CSVWriter(new FileWriter(csv));
            String[] headerText = null, footerText = null, dataText = null;
            if (CurrentFile.contains("3UK")) {
                headerText = new String[]{"01", "20140113762945", efile.replaceAll(".csv", "").replaceAll("omer", "").replaceAll("lations", "").replaceAll("_and", "")};
                if (CurrentFile.contains("PS")) {
                    // Get the String array for Peoplesoft
                    dataText = getClientFileData(CurrentFile);
                    footerText = new String[]{"99", "1"};
                    //System.out.println("PeopleSoft File Created !");
                } else if (CurrentFile.contains("CNLP")) {
                    // Get the String array for Peoplesoft
                    //dataText = Enrollment.getClientFileData(CurrentFile);
                    footerText = new String[]{"99", "000000000000"};
                    //System.out.println("PeopleSoft File Created !");
                } else if (CurrentFile.contains("BL")) {
                    // Get the String array for Billing
                    dataText = getClientFileData(CurrentFile);
                    footerText = new String[]{"99", "1"};
                    //System.out.println("Billing File Created !");
                } else if (CurrentFile.contains("CNLB")) {
                    // Get the String array for Billing
                    //dataText = Enrollment.getClientFileData(CurrentFile);
                    footerText = new String[]{"99", "000000000000"};
                    //System.out.println("Billing File Created !");
                } else if (CurrentFile.contains("UPD")) {
                    // Get the String array for Cancellation
                    //dataText = Enrollment.getClientFileData(CurrentFile);
                    footerText = new String[]{"99", "000000000000"};
                    //System.out.println("Cancellation EMPTY File Created !");
                } else if (CurrentFile.contains("CL")) {
                    // Get the String array for Cancellation
                    dataText = getClientFileData(CurrentFile);
                    footerText = new String[]{"99", "1"};
                    //System.out.println("Cancellation File Created !");
                } else if (CurrentFile.contains("MB")) {
                    headerText = new String[]{"01", "20131202062945", "ASURION_MONTHLY_BILLING"};
                    dataText = getClientFileData(CurrentFile);
                    footerText = new String[]{"99", "000000000001"};
                }
            }
            List<String[]> data = new ArrayList<String[]>();
            data.add(headerText);
            data.add(dataText);
            data.add(footerText);
            writer.writeAll(data);
            writer.close();
            GZCompress.gzipIt(csv,ghcsv);
            GZCompress.deleteFile(csv);
            moveFiletoDir(ghcsv, sftpLocation);
//            moveFiletoDir(csv, sftpLocation);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    //    }


    public static String[] getClientFileData(String clientFileName) {
        String[] fileDataHeader = null;
//DEBUG POINTER System.out.println("input Array : " + Arrays.asList(input));
        switch (clientFileName) {
            case "3UK_PS":
                //PSFTData,BAN,CRMID,Gender,Title,FirstName,LastName,DOB,HouseNumber,HouseName,FlatNumber,BillingAddress1,BillingAddress2,BillingAddress3,BillingAddress4
                //,PostalTown,County,PostCode,Country,EmailAddress,CustomerType,RelationshipStartDate,RelationshipEndDate,ContractStartDate,ContractEndDate,CollectionsIndicator
                //,FSIndicator,SAIndicator,InsuranceAddOnId,InsuranceAddOnDate,MSISDN,ICCID,DeviceProductId,IMEI,IMEIBlacklistIndicator,InsuranceCancelDate,SuspendCollectCode
                //,SuspendCollectReason,SIMBarredIndicator,InsuranceCancelCode,PendingDeviceProductId
                fileDataHeader = Arrays.copyOfRange(input, 0, 41);
                //fileDataHeader = new String[]{"20",input[1],input[2],input[3],input[4],input[5],input[6],input[7],input[8],input[9],input[10],input[11],input[12],input[13],input[14],input[15],input[16]};
                break;
            case "3UK_BL":
                //BillingData,BAN,BillingDayOfMonth,Balance
                fileDataHeader = new String[]{"30", input[1], input[54], input[55]};
                break;
            case "3UK_CL":
                //BillingData,BAN,InsuranceAddOnId,InsuranceStartDate,SalesChannel,DealerCode,SellingAgentId,InsuranceEndDate,CancelReasonCode,SalesOverrideReasonCode,Deposit
//                fileDataHeader = new String[]{"10",input[1],"CTA0252","10/01/2016 00:00:00","RETAIL","CGP01","DEVD","","","","0"};
//                fileDataHeader = new String[]{"10",input[1],"CTA0252","10/01/2016 00:00:00","RETAIL","CGP01","DEVD","","","","0"};
                fileDataHeader = Arrays.copyOfRange(input, 41, 52);
// DEBUGPOINTER			System.out.println("input 47 : " + input[47]);
                break;
            case "3UK_CNLCL":
                //BillingData,BAN,InsuranceAddOnId,InsuranceStartDate,SalesChannel,DealerCode,SellingAgentId,InsuranceEndDate,CancelReasonCode,SalesOverrideReasonCode,Deposit
//                fileDataHeader = new String[]{"10",input[1],"CTA0118","10/02/2014 00:00:00","RETAIL","CGP01","Soni_AMA",input[54],input[55],"","28"};//input[54],input[55],"","28"};
//                fileDataHeader = Arrays.copyOfRange(input, 41, 51);
//                fileDataHeader = new String[]{input[41],input[42],input[43],input[44],input[45],input[46],input[47],"13/04/2016 00:00:00","MNPMBBEMI",input[50],input[51]};
                fileDataHeader = new String[]{input[41], input[42], input[43], input[44], input[45], input[46], input[47], hm.get("Cancel_Insurance_end_date"), hm.get("Cancel_Cancellation_reason_code"), input[50], input[51]};
                break;
            case "3UK_MB":
                fileDataHeader = new String[]{"50", input[1], input[56], input[57], input[58], input[59]};
                break;
//		case "VM_INS": case "VM_UPD": case "VM_CNL":
//			fileDataHeader = Arrays.copyOfRange(Input1, 0, 37);
//			break;
//		case "TESCO_INS":
//			fileDataHeader = Arrays.copyOfRange(Input2, 0, 30);
//			break;
        }
        return fileDataHeader;
    }

    public static String getFileName(String etlFileType) {
        String etlfname = null;
        if (etlFileType == "3UK_PS" || etlFileType == "3UK_CNLP") {
            etlfname = "Asurion_Customer_Snapshot_PeopleSoft_" + currentDate;
        } else if (etlFileType == "3UK_BL" || etlFileType == "3UK_CNLB") {
            etlfname = "Asurion_Customer_Snapshot_Billing_" + currentDate;
        } else if (etlFileType == "3UK_CL" || etlFileType == "3UK_UPD" || etlFileType == "3UK_CNLCL") {
            etlfname = "Asurion_Sales_and_Cancellations_" + currentDate;
        } else if (etlFileType == "3UK_MB") {
            etlfname = "Asurion_Monthly_Billing_" + currentDate;
        } else if (etlFileType == "VM_INS") {
            etlfname = currentDate + "_VIRGINMEDIA_INS_ADD_" + currentDateTime;
        } else if (etlFileType == "VM_UPD") {
            etlfname = currentDate + "_VIRGINMEDIA_INS_" + currentDateTime;
        } else if (etlFileType == "VM_ECF") {
            etlfname = currentDate + "_V2_VIRGIN_ContractData_EXC_" + currentDateTime;
        } else if (etlFileType == "VM_CNL") {
            etlfname = currentDate + "_VIRGINMEDIA_INS_" + currentDateTime;
        } else if (etlFileType == "TESCO_INS") {
            etlfname = "TM_HUB_ENRDD_" + currentDateTime;
        }
        return etlfname;
    }

    //    public static void moveFiletoDir(String SourceFileLocation, String DestinationDirectory) {
//        try {
//            File dir1 = new File(SourceFileLocation);
//            File dir2 = new File(DestinationDirectory);
//
//            //Before moving the files check if file already present at the SFTP location . If file is present then wait for 3 mins and then proceed with moving the files .
//            FileUtils.moveFileToDirectory(dir1, dir2, false);
////            FileUtils.copyFileToDirectory(dir1,dir2,false);
//            System.out.println("Files Transfered to SFTP Location : " + DestinationDirectory);
//
//            //Check if the files are getting picked up from SFTP
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
    public static String getCurrentTimeStampDate() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd");
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }

    public static String getCurrentTimeStamp() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMddHHmmss");
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }

    public static String getValuesFromMAP(String variableName) {
        return hm.get(variableName);
    }
}


