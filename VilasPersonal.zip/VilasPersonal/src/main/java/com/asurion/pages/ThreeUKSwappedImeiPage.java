package com.asurion.pages;

import com.asurion.common.core.driver.TestDriver;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.Generic;
import com.asurion.qa.util.CommonUtilities;
import com.opencsv.CSVWriter;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by NANDINI.MUJUMDAR on 6/22/2017.
 */
public class ThreeUKSwappedImeiPage {
    private static String CurrentFile;
    private static String currentDate = getCurrentTimeStampDate();
    private static String currentDateTime = getCurrentTimeStamp();
    private static String currentDate1 = getCurrentDate();
    public static String[] input = new String[60];
    static String first3TrackingNumberDigit;
    public static LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();

    public static void get3UKDefaultDataDeliveryConfirm() throws Exception {
        System.out.println("Parcel Number: "+Generic.getValuesFromGlobals("TRACKINGNUMBER"));
        hm.put("PARCELNUMBER",Generic.getValuesFromGlobals("TRACKINGNUMBER"));
        hm.put("LOGTYPE", "001");
        hm.put("EVENTDATE", getCurrentDate());
//        hm.put("SHIPMENTTRACKINGNUMBER", "1Z897AR90400007850");
        hm.put("EVENTTIME", getCurrentTimeStampTime());
//        hm.put("SALESORDERNUMBER", "12345678");
        hm.put("EVENTLOCATION", "London");
        hm.put("EVENTDECRIPTION", "DELIVERY");
        hm.put("ConsignmentNumber", "");
        hm.put("ConsignmentLine", "");
        hm.put("AccountNumber", "12345");
        hm.put("SendersRef", "12345678");
        hm.put("CHECKLISTQUESTION(CODE)", "");
        hm.put("CHECKLISTQUESTION(DECRIPTION)", "");
        hm.put("ChecklistResponse", "");

    }

    public static void initializeFileDataDeliveryConfirm3UK() {
        // System.out.println("INSIDE initialize : " + ExecSequence.Parameter);
        Map mp = new LinkedHashMap<String, String>(hm);
        String sValue, sParam;
        Iterator it = mp.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            System.out.println(pair.getKey() + " = " + pair.getValue());
            sParam = pair.getKey().toString();
            sValue = pair.getValue().toString().trim();
            //DEBUG POINT	        System.out.println("Parameter :" + sParam + "Value :" + sValue);
            System.out.println("Paramater and value :- " + sParam + " and " + sValue);
            switch (sParam.trim()) {
                case "PARCELNUMBER":
                    input[0] = sValue;
                    break;
                case "LOGTYPE":
                    input[1] = sValue;
                    break;
                case "EVENTDATE":
                    input[2] = sValue;
                    break;
                case "EVENTTIME":
                    input[3] = sValue;
                    break;
                case "EVENTLOCATION":
                    input[4] = sValue;
                    break;
                case "EVENTDECRIPTION":
                    input[5] = sValue;
                    break;
                case "ConsignmentNumber":
                    input[6] = sValue;
                    break;
                case "ConsignmentLine":
                    input[7] = sValue;
                    break;
                case "AccountNumber":
                    input[8] = sValue;
                    break;
                case "SendersRef":
                    input[9] = sValue;
                    break;
                case "CHECKLISTQUESTION(CODE)":
                    input[10] = sValue;
                    break;
                case "CHECKLISTQUESTION(DECRIPTION)":
                    input[11] = sValue;
                    break;
                case "ChecklistResponse":
                    input[12] = sValue;
                    break;

            }
        }
    }

    public static void createFilesDeliveryConfirm3UK(String ScenarioType) throws Exception {
        for (int i = 0; i < 10; i++) {
            System.out.println(input[i]);
        }
        String ClientName = ApplicationConfiguration.getClient();
        String[] fileList = new String[1];
//        String[] fileList1 = new String[1];
        File file2 = new File("\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\3uk_enrollment\\dpd");

        int k = 0;
        while ((file2.listFiles().length > 0) && k < 40) {
            CommonUtilities.waitTime(1); //Please do not delete this wait time it waits for the file to be processed.
            k++;
            if (k == 40) {
                for (File file : file2.listFiles()) file.delete();
                System.out.println("\nUnprocessed files are deleted from the SFTP location for DPD files");
            }
        }
        if (ScenarioType.equalsIgnoreCase("DeliveryConfirm")){ //{ClientName.contains("3uk")
            fileList[0] = "DeliveryConfirm";
        }

        for (int i = 0; i < fileList.length; i++) {
            // Write hashmap data to file and then drop the file on temp location
            // Get the file names from below method
            if (fileList[i] != null) {
                CurrentFile = fileList[i];
                //System.out.println(CurrentFile);
                String eFile = getFileName(fileList[i]) + ".pcg";

                writeToCSV(eFile, fileList[i]);
                System.out.println("File Created for : " + getFileName(fileList[i]));
            }
        }
    }

    public static void writeToCSV(String efile, String fileName) throws Exception {
        String sftpLocation = "\\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\3uk_enrollment\\dpd\\";
        String tempLocation = "\\\\ndcsqafp401\\IT_QA_Test\\QATest_Horizon_Enrollment\\EU\\KPN\\";
//        String tempLocation = "C:\\Asurion\\";
        File file1 = new File(sftpLocation);
        int i = 0;
        String csv = tempLocation + efile; // Temp Folder location and file name
//        Wait for other files to get processed and then continue
        // while(file1.list().length>0 && i < 3){
        //    try{
        // Thread.sleep(50);
        //   }
        //   catch(InterruptedException ex){
        //       Thread.currentThread().interrupt();
        //   }
        //  i++;
        // }
        if (i == 1 && file1.list().length > 0) {
            System.out.println("Stage enrollment failed. There is a file stuck at sftp location \\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\3uk_enrollment\\inbound\\.");
            //ExecSequence.exitTest("ENROLLMENT Failed as previous enrollment are stuck at SFTP");
            // Assert.assertTrue("Stage enrollment failed. There is a file stuck at sftp location \\\\SDCQASSIS501\\Warehouse\\Horizon_EU_Enrollments\\3uk_enrollment\\inbound\\.", false);
        } else {
            try {
                System.out.println(csv);
                char separator = ';';
                if (CurrentFile.contains("Delivery")) separator = ',';
                CSVWriter writer = new CSVWriter(new FileWriter(csv), separator, CSVWriter.NO_ESCAPE_CHARACTER, System.getProperty("line.separator"));
                //writer = new CSVWriter(new FileWriter(csv));
                String[] headerText = null, footerText = null, dataText = null;
                if (CurrentFile.contains("Delivery")) {
//                    headerText = new String[]{"H" + currentDate1};
                    if (CurrentFile.contains("Confirm")) {
                        // Get the String array for Peoplesoft
                        dataText = getClientFileData(CurrentFile);
                        footerText = new String[]{"1"};
                        //System.out.println("PeopleSoft File Created !");
                    }
                }
//                if (CurrentFile.contains("STATUSDATA")) {
//                    headerText = new String[]{"PARCELNO;SCAN_CODE;DEPOT_CODE;DEPOTNAME;EVENT_DATE_TIME;ROUTE;TOUR;PCODE;SERVICE;CONSIGNEE_COUNTRY_CODE;CONSIGNEE_ZIP;ADD_SERVICE_1;ADD_SERVICE_2;ADD_SERVICE_3;WEIGHT;CUSTOMER_REFERENCE;POD_IMAGE_REF;RECEIVER_NAME;INFO_TEXT;LOCATION;"};
//                    dataText = getClientFileData(CurrentFile);
//                }
//                if (CurrentFile.contains("CONFMFILE")) {
//                    headerText = new String[]{"OK"};
//                }
                List<String[]> data = new ArrayList<String[]>();
//                data.add(headerText);
                data.add(dataText);
                data.add(footerText);
                writer.writeAll(data);
                writer.close();
                moveFiletoDir(csv, sftpLocation);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static String getTrackingNumber() throws Exception {
        String trackingNumber = Generic.getTrackingNumber(Generic.getValuesFromGlobals("MDN"), "NEW");
        Generic.setGlobals("TrackingNumber", trackingNumber);
        first3TrackingNumberDigit=trackingNumber.substring(0,2);
        return trackingNumber;
    }

    public static String getSalesNumber() throws Exception {
        String salesNumber = Generic.getSalesNumber(Generic.getValuesFromGlobals("MDN"));
        Generic.setGlobals("salesNumber", salesNumber);
        return salesNumber;
    }

    public static String[] getClientFileData(String clientFileName) {
        String[] fileDataHeader = null;
//DEBUG POINTER System.out.println("input Array : " + Arrays.asList(input));
        switch (clientFileName) {
            case "ShipmentStatus":
                fileDataHeader = Arrays.copyOfRange(input, 0, 10);
                //fileDataHeader = new String[]{"20",input[1],input[2],input[3],input[4],input[5],input[6],input[7],input[8],input[9],input[10],input[11],input[12],input[13],input[14],input[15],input[16]};
                break;
            case "DeliveryConfirm":
                fileDataHeader = Arrays.copyOfRange(input, 0, 13);
//                fileDataHeader = new String[]{input[11],input[12],input[13],input[14],input[15],input[16],input[17],input[18],input[19],input[20],input[21],input[22],input[23],input[24],input[25],input[26],input[27],input[28],input[28],input[30],""};
                break;
        }
        return fileDataHeader;
    }

    public static String getFileName(String etlFileType) {
        String etlFName = null;
        if (etlFileType == "DeliveryConfirm") {
            etlFName = "P"+"567" +"1234" +getCurrentTimeStamp();//first3TrackingNumberDigit
        }
        return etlFName;
    }

    public static void moveFiletoDir(String SourceFileLocation, String DestinationDirectory) {
        try {
            File dir1 = new File(SourceFileLocation);
            File dir2 = new File(DestinationDirectory);
            //Before moving the files check if file already present at the SFTP location . If file is present then wait for 3 mins and then proceed with moving the files .
            FileUtils.moveFileToDirectory(dir1, dir2, false);
//            FileUtils.copyFileToDirectory(dir1,dir2,false);
            System.out.println("Files Transferred to SFTP Location : " + DestinationDirectory);
            //Check if the files are getting picked up from SFTP
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getCurrentTimeStampDate() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }

    public static String getCurrentDate() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy");
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }

    public static String getCurrentTimeStamp() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("MMddyyyy_HHmmss");
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }

    public static String getCurrentTimeStampTime() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("HH:mm");
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate.replace(":", "");
    }
    public static void updateDifferentDataForEnrollment(String param, String value) {
        hm.put(param, value);
        Generic.setGlobals(param, value);
    }
}


