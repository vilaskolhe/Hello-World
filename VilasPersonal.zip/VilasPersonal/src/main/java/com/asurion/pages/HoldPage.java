package com.asurion.pages;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.horizon.generic.DataBaseHandler;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import org.junit.Assert;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class HoldPage extends BasePage {

    private UIElement holdButton = new UIElement(UIType.Button, UILocatorType.Link, "Hold");
    private UIElement navigationDivFrame = new UIElement(UIType.Button, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    private UIElement createHoldButton = new UIElement(UIType.Button, UILocatorType.Name, "HoldModal_HoldTempPage_11");
    private UIElement continueButton = new UIElement(UIType.Button, UILocatorType.Xpath, "(//button[@type='button'])[5]");
    private UIElement shippingAddressValidation = new UIElement(UIType.CheckBox, UILocatorType.ID, "pyRowSelected4");
    private UIElement adjuster = new UIElement(UIType.CheckBox, UILocatorType.ID, "pyRowSelected1");
    private UIElement document = new UIElement(UIType.CheckBox, UILocatorType.ID, "pyRowSelected2");
    private UIElement instantVerification = new UIElement(UIType.CheckBox, UILocatorType.ID, "pyRowSelected3");
    private UIElement cpmInteractionDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmInteractionDivFrame");
    private UIElement cpmTabbedNavigationDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    private UIElement diaction = new UIElement(UIType.Frame, UILocatorType.Name, "DIACTION");
    private UIElement addNote = new UIElement(UIType.CheckBox, UILocatorType.ID, "AddNote");
    private UIElement noteType = new UIElement(UIType.ListBox, UILocatorType.ID, "NoteType");
    private UIElement noteDescription = new UIElement(UIType.CheckBox, UILocatorType.ID, "NoteDescription");
    private UIElement saveNote = new UIElement(UIType.CheckBox, UILocatorType.CSS, "div#CT button.SearchButtons.pzhc");
    private UIElement getnoteType = new UIElement(UIType.Label, UILocatorType.Xpath, "//table[@id='bodyTbl_right']//tr[starts-with(@id,'$PD_CustomerNotes_pa')]/td[1]");
    private UIElement lockSymbol = new UIElement(UIType.Image, UILocatorType.Xpath, "//table[@id='bodyTbl_right']//tr[starts-with(@id,'$PD_CustomerNotes_pa')]/td[2]//div[@id='CT']/span/i/img");
    private UIElement getNoteDescription = new UIElement(UIType.Label, UILocatorType.Xpath, "//table[@id='bodyTbl_right']//tr[starts-with(@id,'$PD_CustomerNotes_pa')]/td[3]//span");
    private UIElement notesOpenCloseArrow = new UIElement(UIType.Button, UILocatorType.CSS, ".icon.icon-openclose");
    private UIElement instantMessage = new UIElement(UIType.Label, UILocatorType.CSS, "div[id='RULE_KEY']>table>tbody>tr:nth-child(1)>td[class='dataValueRead']>nobr>span");

    private UIElement generatedHoldNumber = new UIElement(UIType.Label, UILocatorType.Xpath, "//table[@id='hoz_ModalWIndows']//div[@id='RULE_KEY']/div[1]//span[contains(text(),'Hold created for this hold type:')]");
    private UIElement holdTypeVerification = new UIElement(UIType.Label, UILocatorType.Xpath, "//table[@id='hoz_ProcessHoldWrapper']/tbody/tr[1]/td[4]/label");
    private UIElement checkHoldExisting = new UIElement(UIType.Label, UILocatorType.Xpath, "//span[@id='headerlabel6638']");
    private UIElement getHoldType = new UIElement(UIType.Label, UILocatorType.Xpath, "//table[@id='EXPAND-OUTERFRAME']//table[@id='gridLayoutTable']//table[@id='bodyTbl_right']//tr[2]/td[3]/div");
    private UIElement getHoldNumber = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='RULE_KEY']//span[2]//table[@id='gridLayoutTable']//table[@id='bodyTbl_right']/tbody/tr[2]/td[3]");
    private UIElement getIAVHoldDetails = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='RULE_KEY']/table/tbody/tr[1]/td/nobr/span");  //(//div[@id='RULE_KEY']//span[2]//table//span)[1]
    private UIElement getSecondHoldNumber = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='RULE_KEY']//span[2]//table[@id='gridLayoutTable']//table[@id='bodyTbl_right']/tbody/tr[3]/td[3]");
    //Next action
    private UIElement nextActionVoid = new UIElement(UIType.CheckBox, UILocatorType.ID, "EligibilityNextActionVoid");
    private UIElement nextActionOverride = new UIElement(UIType.CheckBox, UILocatorType.ID, "EligibilityNextActionOverride");
    private UIElement escalationOverrideReason = new UIElement(UIType.ListBox, UILocatorType.ID, "EscalationOverrideReason");
    private UIElement tdContinueButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[@class='buttonTdButton']");
    private UIElement holdProcessingAction = new UIElement(UIType.ListBox, UILocatorType.ID, "HoldsAction");
    private UIElement holdContinueButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[@class='layout layout-none float-right set-width-auto']//button");
    private UIElement releaseHoldTypeVerification = new UIElement(UIType.Label, UILocatorType.Xpath, "//table[@id='hoz_ProcessHoldWrapper']/tbody/tr[1]/td[5]");
    private UIElement releaseHoldSubTypeVerification = new UIElement(UIType.Label, UILocatorType.Xpath, "//table[@id='hoz_ProcessHoldWrapper']/tbody//div[@id='CT']/nobr");
    private UIElement holdSubType = new UIElement(UIType.ListBox, UILocatorType.ID, "HoldSubType");
    private UIElement manualHoldNotes = new UIElement(UIType.TextBox, UILocatorType.ID, "ManualHoldNotes");
    private UIElement documentHoldForNtelos = new UIElement(UIType.CheckBox, UILocatorType.ID, "pyRowSelected3");
    private UIElement advancedClaimReview = new UIElement(UIType.CheckBox, UILocatorType.ID, "pyRowSelected2");
    private UIElement OutboundFlag = new UIElement(UIType.CheckBox, UILocatorType.ID, "OutboundFlag");

    private ActionPage actionPage;
    private HomePage homePage;
    private IdentifyCustomerPage identifyCustomerPage;
    private IncidentPathPage incidentPathPage;
    private EndCallPage EndCallPage;
    private MyWorkPage myWorkPage;

    public HoldPage() {

        actionPage = new ActionPage();
        homePage = new HomePage();
        identifyCustomerPage = new IdentifyCustomerPage();
        incidentPathPage = new IncidentPathPage();
        EndCallPage = new EndCallPage();
        myWorkPage = new MyWorkPage();
    }

    /**
     * This method is used to create hold
     * click on Hold button, select the specified hold, add hold type and note
     *
     * @param holdType eg.Adjuster , Instant Verification & document
     * @author Sachin
     */
    public void createHold(String holdType) throws Exception {
        driver.switchToDefaultContent();
        CommonUtilities.waitTime(1);
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);

        CommonUtilities.waitTime(1);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction is not found on hold page", false);

        if (driver.waitForElementPresenceWithTimeOut(holdButton, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.javaScriptClick(holdButton);
        else
            Assert.assertTrue("holdButton is not found on hold page", false);

        if (holdType.equalsIgnoreCase("shipping address validation")) {
            if (driver.waitForElementPresenceWithTimeOut(shippingAddressValidation, ApplicationConfiguration.getWaitForElementTimeout()))
                // driver.click(shippingAddressValidation);
                driver.javaScriptClick(shippingAddressValidation);
            else
                Assert.assertTrue("shippingAddressValidation is not found on hold page", false);

        }
        if (holdType.equalsIgnoreCase("Adjuster")) {
            if (driver.waitForElementPresenceWithTimeOut(adjuster, ApplicationConfiguration.getWaitForElementTimeout()))
                //driver.click(adjuster);
                driver.javaScriptClick(adjuster);
            else
                Assert.assertTrue("shippingAddressValidation is not found on hold page", false);

        }
        if (holdType.equalsIgnoreCase("Document")) {
            if (!driver.waitForElementPresenceWithTimeOut(document, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("document is not found on hold page", false);
            // driver.click(document);
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
                driver.javaScriptClick(document);
            } else {
                driver.javaScriptClick(documentHoldForNtelos);
            }

        }
        if (holdType.equalsIgnoreCase("Instant Verification")) {
            if (driver.waitForElementPresenceWithTimeOut(instantVerification, ApplicationConfiguration.getWaitForElementTimeout()))
                // driver.click(instantVerification);
                driver.javaScriptClick(instantVerification);
            else
                Assert.assertTrue("instantVerification is not found on hold page", false);

        }
        if (holdType.equalsIgnoreCase("Instant Verification & document")) {
            if (driver.waitForElementPresenceWithTimeOut(document, ApplicationConfiguration.getWaitForElementTimeout()))
                // driver.click(document);
                driver.javaScriptClick(document);
            else
                Assert.assertTrue("document is not found on hold page", false);


            if (driver.waitForElementPresenceWithTimeOut(instantVerification, ApplicationConfiguration.getWaitForElementTimeout()))
                //  driver.click(instantVerification);
                driver.javaScriptClick(instantVerification);
            else
                Assert.assertTrue("instantVerification is not found on hold page", false);

        }
        if (holdType.equalsIgnoreCase("shipping address validation & Adjuster")) {
            if (driver.waitForElementPresenceWithTimeOut(adjuster, ApplicationConfiguration.getWaitForElementTimeout()))
                // driver.waitForElementPresence(adjuster);
                // driver.click(adjuster);
                // driver.click(shippingAddressValidation);
                driver.javaScriptClick(adjuster);
            else
                Assert.assertTrue("adjuster is not found on hold page", false);

            if (driver.waitForElementPresenceWithTimeOut(shippingAddressValidation, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(shippingAddressValidation);
            else
                Assert.assertTrue("shippingAddressValidation is not found on hold page", false);

        }
        if (holdType.equalsIgnoreCase("Advanced Claim Review")) {
            if (driver.waitForElementPresenceWithTimeOut(advancedClaimReview, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(advancedClaimReview);
            else
                Assert.assertTrue("advancedClaimReview is not found on hold page", false);


        }
        if (holdType.equalsIgnoreCase("Advanced Claim Review & Adjuster")) {
            if (driver.waitForElementPresenceWithTimeOut(adjuster, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(adjuster);
            else
                Assert.assertTrue("adjuster is not found on hold page", false);

            if (driver.waitForElementPresenceWithTimeOut(advancedClaimReview, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(advancedClaimReview);
            else
                Assert.assertTrue("advancedClaimReview is not found on hold page", false);
        }
        if (holdType.equalsIgnoreCase("Advanced Claim Review & document")) {
            if (driver.waitForElementPresenceWithTimeOut(advancedClaimReview, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(advancedClaimReview);
            else
                Assert.assertTrue("advancedClaimReview is not found on hold page", false);
            CommonUtilities.waitTime(1);

            if (driver.waitForElementPresenceWithTimeOut(documentHoldForNtelos, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(documentHoldForNtelos);
            else
                Assert.assertTrue("documentHoldForNtelos is not found on hold page", false);

        }


        if (driver.waitForElementPresenceWithTimeOut(holdSubType, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(holdSubType, "Other");
            driver.tabOutOf(holdSubType);
        } else
            Assert.assertTrue("holdSubType is not found on hold page", false);

        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(manualHoldNotes, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(manualHoldNotes, "Manual Hold Note");
            driver.tabOutOf(manualHoldNotes);
        } else {
            CommonUtilities.waitTime(1);
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("claro") || ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos")) {
                driver.select(holdSubType, "Other");
                driver.tabOutOf(holdSubType);
                driver.type(manualHoldNotes, "Manual Hold Note");
                driver.tabOutOf(manualHoldNotes);
            } else
                Assert.assertTrue("manualHoldNotes is not found on hold page", false);
        }


    }

    /**
     * This method is used to submit the hold
     *
     * @author Sachin
     */
    public void submitHold() throws Exception {
        if (driver.waitForElementPresenceWithTimeOut(createHoldButton, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.javaScriptClick(createHoldButton);
        else
            Assert.assertTrue("createHoldButton button is not found on hold page", false);
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
            if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("diaction is not found on hold page", false);
        }
        if (!driver.waitForElementPresenceWithTimeOut(generatedHoldNumber, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("generatedHoldNumber is not found on hold page", false);
        String sHoldNumber = driver.getText(generatedHoldNumber);
        //Hold created for this hold type:
        String arrHoldNumber[] = sHoldNumber.split(":");
        String sTemp = arrHoldNumber[2];
        BasePage.holdNumber = sTemp;
        System.out.println("Hold number is :   " + holdNumber);
        if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.click(continueButton);
        else
            Assert.assertTrue("continueButton is not found on hold page", false);

    }

    /**
     * This method is used to add note and verify UI reflect propely or not
     *
     * @author Sachin
     */
    public void addnoteToHold(String noteDesText, String TypeOfNote) throws Exception {

        if (driver.waitForElementPresenceWithTimeOut(addNote, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.javaScriptClick(addNote);
        else
            Assert.assertTrue("addNote is not found on hold page", false);

      /*  try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/


     /*   //navigateLowestLevelFrame(diaction);
        driver.waitForFrameToLoad(diaction, 60);
        driver.waitForFrameToLoad(diaction, 60);*/

        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(noteType, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.select(noteType, TypeOfNote);
        else
            Assert.assertTrue("noteType is not found on hold page", false);

        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(noteDescription, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(noteDescription, noteDesText);
            driver.tabOutOf(noteDescription);
        } else
            Assert.assertTrue("noteDescription is not found on hold page", false);

        CommonUtilities.waitTime(1);

        if (driver.waitForElementPresenceWithTimeOut(saveNote, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.javaScriptClick(saveNote);
        else
            Assert.assertTrue("saveNote is not found on hold page", false);

        //navigateLowestLevelFrame(diaction);
        CommonUtilities.waitTime(2);
        if (!driver.checkObjectExists(getNoteDescription, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (driver.waitForElementPresenceWithTimeOut(notesOpenCloseArrow, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(notesOpenCloseArrow);
            else
                Assert.assertTrue("notesOpenCloseArrow is not found on hold page", false);
        }
        if (!driver.waitForElementPresenceWithTimeOut(getNoteDescription, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("getNoteDescription is not found on hold page", false);

        String noteDes = driver.getText(getNoteDescription);

        assertTrue("Checking note text entered is added to hold or not :", noteDes.toLowerCase().contains(noteDesText.toLowerCase()));

        if (!driver.waitForElementPresenceWithTimeOut(getnoteType, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("getnoteType is not found on hold page", false);
        // System.out.println(driver.getText(getnoteType));
        assertTrue("Checking note type entered is added to hold or not :", TypeOfNote.equalsIgnoreCase(driver.getText(getnoteType).trim()));
        //lock symbol only for Confidential note
        if (TypeOfNote.equalsIgnoreCase("Confidential")) {
            assertTrue("Checking key lock symbol for note text added  :", driver.checkObjectExists(lockSymbol, ApplicationConfiguration.getWaitForElementTimeout()));
        } else if (TypeOfNote.equalsIgnoreCase("Review")) {
            if (!driver.waitForElementAbsence(lockSymbol, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("lockSymbol is not found on hold page", false);
        }
        if (driver.checkObjectExists(manualHoldNotes, 10)) {
            driver.click(manualHoldNotes);
            driver.tabOutOf(manualHoldNotes);
        }


    }

    public boolean checkHold() throws Exception {

        Boolean isHold = false;
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
        //driver.navigateToFrame(cpmInteractionDivFrame);
        // navigateLowestLevelFrame(cpmInteractionDivFrame);
        //navigateLowestLevelFrame(diaction);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction is not found on hold page", false);
        //  if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction 1 is not found on hold page", false);
        //  }
        driver.switchToFrame(cpmTabbedNavigationDivFrame);

        String claimId;

        if (CustomerDetails.customerData.containsKey("CASENUMBER1")) {
            claimId = CustomerDetails.customerData.get("CASENUMBER1");
        } else {
            claimId = CustomerDetails.customerData.get("CASENUMBER");
        }
        if (driver.checkObjectExists(getHoldNumber, ApplicationConfiguration.getWaitForElementTimeout())) {

            String checkQuery = "select * from CUSTOMER_CASE_HOLD where Customer_Case_NBR='" + claimId + "'";
            int i = 0;
            do {


                if (DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), checkQuery).size() > 0) {
                    isHold = true;
                    break;
                } else
                    i++;
            } while (i <= 700);

        } else {
            Assert.assertTrue("getHoldNumber is not found on hold page", false);
        }
        return isHold;


    }

    //Added by Brian Samson
    public String iavMessage() throws Exception {
        {
            driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);

            if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("Diaction is not found on Hold page", false);

            if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);


            driver.waitForElementPresence(instantMessage);
            return (driver.getText(instantMessage)).trim();


        }

    }


    /**
     * This method is used to release the hold from UI and resume incident
     *
     * @author Sachin
     */
    public void releaseHoldAndResume() throws Exception {
        String holdNumber, holdType;
        String[] arrHoldNumber;
        String[] aHoldNumber;

        // CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);

        // navigateLowestLevelFrame(diaction);
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());
        //  if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction 1 is not found on hold page", false);
        //  }
        driver.switchToFrame(cpmTabbedNavigationDivFrame);
        if (driver.checkObjectExists(checkHoldExisting, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.checkObjectExists(getHoldNumber, ApplicationConfiguration.getWaitForElementTimeout());
            holdNumber = driver.getText(getHoldNumber);
            System.out.println("driver.getText(getHoldNumber)  " + holdNumber);

            arrHoldNumber = holdNumber.split("Hold#");
            String sNumber = arrHoldNumber[1];
            aHoldNumber = sNumber.split(" ");
            holdNumber = aHoldNumber[0].trim();
            BasePage.holdNumber = holdNumber;
            homePage.switchUserAccount("AdvancedAgent");
            CommonUtilities.waitTime(1);

            myWorkPage.searchHoldForApproval();
            myWorkPage.holdProcessAction("Continue with Customer Interaction");

            myWorkPage.releaseHoldResolutionReason("Approved", "Verified in Billing System");
            myWorkPage.continueChargeProcess();

            EndCallPage.endCall("Holds", "System Placed Hold");
            homePage.checkCallButton();
            homePage.pressStart();
            identifyCustomerPage.searchUsingMDN(CustomerDetails.customerData.get("MDN"));
            identifyCustomerPage.verifyCaller("Account Holder", "valid");
            identifyCustomerPage.continueClaim();
            incidentPathPage.select_incident_path("Resume Incident");
        } else {
            System.out.println("Hold does not exit");
        }


    }

    /**
     * This method is used to check hold type on UI
     *
     * @param sHoldType
     * @author Sachin
     */
    public void checkHoldType(String sHoldType) throws Exception {
        String holdDesc = null;
        // CommonUtilities.waitTime(2);
            /*driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
            navigateLowestLevelFrame(diaction);
            driver.switchToFrame(cpmTabbedNavigationDivFrame);*/
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }


        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        //Code added for client check.
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers") || ApplicationConfiguration.getClient().equalsIgnoreCase("Fido")) {
            if (!driver.waitForElementPresenceWithTimeOut(getIAVHoldDetails, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("getIAVHoldDetails is not found on hold page", false);
            holdDesc = driver.getText(getIAVHoldDetails);
            holdDesc = holdDesc.toLowerCase();
        } else {
            if (!driver.waitForElementPresenceWithTimeOut(getHoldNumber, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("getHoldNumber is not found on hold page", false);
            // driver.waitForElementPresenceWithTimeOut(getHoldNumber, ApplicationConfiguration.getWaitForElementTimeout());
            holdDesc = driver.getText(getHoldNumber);
            holdDesc = holdDesc.toLowerCase();

            if (!holdDesc.toLowerCase().contains(sHoldType.toLowerCase())) {
                holdDesc = driver.getText(getSecondHoldNumber);
                holdDesc = holdDesc.toLowerCase();
            }
        }


        //System.out.println("driver.getText(getHoldNumber)  "+ holdDesc);
        assertTrue("Verify Hold Type :", holdDesc.contains(sHoldType.toLowerCase()));

//        driver.checkObjectExists(getHoldType,60);
//         String holdType = driver.getText(getHoldType);
//         holdType = holdType.trim();
//         System.out.println("driver.getText(holdType)  "+ holdType);
//
//        assertEquals("Verify Hold Type ",holdType.toLowerCase(),sHoldType.toLowerCase());


    }

    /**
     * This method is used to release the hold from UI and verify hold type and subtype at the time of release
     * (telcel)
     *
     * @param holdType,subtype
     * @author Priyanka
     */
    public void releaseHoldWithSubType(String holdType, String subtype) throws Exception {
        String holdNumber;
        String[] arrHoldNumber;
        String[] aHoldNumber;

        // CommonUtilities.waitTime(5);
            /*driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
            navigateLowestLevelFrame(diaction);
//            if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
//                Assert.assertTrue("diaction is not found on hold page", false);
//           // if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
//                if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
//                    Assert.assertTrue("diaction 1 is not found on hold page", false);
           // }
            driver.switchToFrame(cpmTabbedNavigationDivFrame);*/
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }


        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }

        if (driver.checkObjectExists(getHoldNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            holdNumber = driver.getText(getHoldNumber);
            System.out.println("driver.getText(getHoldNumber)  " + holdNumber);
            arrHoldNumber = holdNumber.split("Hold#");
            String sNumber = arrHoldNumber[1];
            aHoldNumber = sNumber.split(" ");
            holdNumber = aHoldNumber[0].trim();
            BasePage.holdNumber = holdNumber;
        } else
            Assert.assertTrue("getHoldNumber is not found on hold page", false);

        homePage.switchUserAccount("AdvancedAgent");
        myWorkPage.searchHoldForApproval();
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
        //navigateLowestLevelFrame(diaction);
        if (driver.checkObjectExists(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.switchToFrame(diaction);

        if (!driver.checkObjectExists(holdTypeVerification, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("holdTypeVerification is not found on hold page", false);
        if (!driver.checkObjectExists(releaseHoldTypeVerification, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("releaseHoldTypeVerification is not found on hold page", false);


        assertEquals("Verify hold type", driver.getText(releaseHoldTypeVerification).toLowerCase().trim(), holdType.toLowerCase().trim());
        assertEquals("Verify sub hold type", driver.getText(releaseHoldSubTypeVerification).toLowerCase().trim(), subtype.toLowerCase().trim());

        myWorkPage.holdProcessAction("Continue with Customer Interaction");
        myWorkPage.releaseHoldResolutionReason("Approved", "Verified in Billing System");
        myWorkPage.continueChargeProcess();


    }

    public void checkHoldNotApply(String sHoldType) throws Exception {
        // CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction is not found on hold page", false);
        //if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
        //  if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
        //       Assert.assertTrue("diaction 1 is not found on hold page", false);
        // }
        assertTrue("Verify Hold Type :", !driver.checkObjectExists(getHoldNumber, ApplicationConfiguration.getWaitForElementTimeout()));


    }


    public void overridNextActionReason(String reason) throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction is not found on hold page", false);
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos")) {
            if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("diaction 1 is not found on hold page", false);
        }
        //driver.switchToFrame(cpmTabbedNavigationDivFrame);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found on hold page", false);
        //CommonUtilities.waitTime(1);
        if (reason.equalsIgnoreCase("Void")) {
            if (driver.waitForElementPresenceWithTimeOut(nextActionVoid, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.click(nextActionVoid);
            else
                Assert.assertTrue("Action Void radio button is not found", false);
        } else {
            if (driver.waitForElementPresenceWithTimeOut(nextActionOverride, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.click(nextActionOverride);
            else
                Assert.assertTrue("Action override radio button is not found", false);
            if (driver.waitForElementPresenceWithTimeOut(escalationOverrideReason, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(escalationOverrideReason, reason);
            else
                Assert.assertTrue("Override Reason dropdown is not found", false);

        }
        driver.click(tdContinueButton);

        // CommonUtilities.waitTime(1);
        if (reason.equalsIgnoreCase("Void")) {
            if (driver.waitForElementPresenceWithTimeOut(nextActionVoid, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(nextActionVoid);
                //driver.select(escalationOverrideReason, reason);
                driver.click(tdContinueButton);
            } else {
                if (!ApplicationConfiguration.getClient().equalsIgnoreCase("Claro"))
                    Assert.assertTrue("nextActionOverride is not found on hold page", false);
            }
        } else {
            if (driver.checkObjectExists(nextActionOverride, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(nextActionOverride);
                driver.select(escalationOverrideReason, reason);
                driver.click(tdContinueButton);
            } else
                Assert.assertTrue("nextActionOverride is not found on hold page", false);
        }

    }

    /**
     * This method is used to release the hold from UI and verify hold type and subtype at the time of release
     * (nTelos)
     *
     * @param holdType,subtype
     * @author Priyanka
     */
    public void releaseHoldWithSubTypehold(String holdType, String subtype) throws Exception {
        String holdNumber;
        String[] arrHoldNumber;
        String[] aHoldNumber;

        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction is not found on hold page", false);
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
            if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("diaction 1 is not found on hold page", false);
        }
        driver.switchToFrame(cpmTabbedNavigationDivFrame);

        if (driver.checkObjectExists(getHoldNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            holdNumber = driver.getText(getHoldNumber);
            System.out.println("driver.getText(getHoldNumber)  " + holdNumber);

            arrHoldNumber = holdNumber.split("Hold#");
            String sNumber = arrHoldNumber[1];
            aHoldNumber = sNumber.split(" ");
            holdNumber = aHoldNumber[0].trim();
            BasePage.holdNumber = holdNumber;
        } else
            Assert.assertTrue("getHoldNumber is not found on hold page", false);

        homePage.switchUserAccount("NACSATAdvancedAgent");
        myWorkPage.searchHoldForApproval();
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction is not found on hold page", false);
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
            if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("diaction 1 is not found on hold page", false);
        }
        if (!driver.checkObjectExists(holdTypeVerification, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("holdTypeVerification is not found on hold page", false);
        if (!driver.checkObjectExists(releaseHoldTypeVerification, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("releaseHoldTypeVerification is not found on hold page", false);

        assertEquals("Verify hold type", driver.getText(releaseHoldTypeVerification).toLowerCase().trim(), holdType.toLowerCase().trim());
        assertEquals("Verify sub hold type", driver.getText(releaseHoldSubTypeVerification).toLowerCase().trim(), subtype.toLowerCase().trim());

        myWorkPage.holdProcessAction("Continue with Customer Interaction");
        myWorkPage.releaseHoldResolutionReason("Approve", "Approve");
        myWorkPage.continueChargeProcess();


    }

    public void release_holdAndCancelIncidentFornTelos(String holdType, String user) throws Exception {
        String holdNumber;
        String[] arrHoldNumber;
        String[] aHoldNumber;

        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction is not found on hold page", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction 1 is not found on hold page", false);

        driver.switchToFrame(cpmTabbedNavigationDivFrame);

        if (driver.checkObjectExists(getHoldNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            holdNumber = driver.getText(getHoldNumber);

            arrHoldNumber = holdNumber.split("Hold#");
            String sNumber = arrHoldNumber[1];
            aHoldNumber = sNumber.split(" ");
            holdNumber = aHoldNumber[0].trim();
            BasePage.holdNumber = holdNumber;
        } else
            Assert.assertTrue("getHoldNumber is not found on hold page", false);


        homePage.switchUserAccount("NACSATAdvancedAgent");

        myWorkPage.searchHoldForApproval();

        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction is not found on hold page", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction 1 is not found on hold page", false);

        if (!driver.checkObjectExists(holdTypeVerification, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("holdTypeVerification is not found on hold page", false);
        if (!driver.checkObjectExists(releaseHoldTypeVerification, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("releaseHoldTypeVerification is not found on hold page", false);

        assertEquals("Verify hold type", driver.getText(releaseHoldTypeVerification).toLowerCase().trim(), holdType.toLowerCase().trim());

        myWorkPage.holdProcessAction("Continue with Customer Interaction");

        myWorkPage.releaseHoldResolutionReason("Approve", "Approve");
        myWorkPage.continueChargeProcess();

        EndCallPage.endCallWithIntentAreaAndOutcome("Call Handling", "Status Inquiry", "Claim History");
        //EndCallPage.endCall("Holds","System Placed Hold");
        homePage.checkCallButton();
        homePage.pressStart();
        identifyCustomerPage.searchUsingMDN(CustomerDetails.customerData.get("MDN"));
        identifyCustomerPage.verifyCaller("Account Holder", "valid");
        identifyCustomerPage.continueClaim();
        incidentPathPage.cancelIncident();

    }

    /**
     * This method is used to used to release hold from UI
     * Param : none.
     * Created By: Sachin
     * Modified by: Priyanka
     * Modifications: handle multiple hold to release from UI
     * Date:17/02/2016
     */
    public void release_HoldFromUI() throws Exception {
        String holdNumber;
        String[] arrHoldNumber;
        String[] aHoldNumber;
        if (actionPage.checkHold()) {
            for (int i = 2; i < 6; i++) {
                UIElement getHoldNumber1 = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='RULE_KEY']//span[2]//table[@id='gridLayoutTable']//table[@id='bodyTbl_right']/tbody/tr[" + i + "]/td[3]");
                if (driver.checkObjectExists(getHoldNumber1, 20)) {
                    holdNumber = driver.getText(getHoldNumber1);
                    System.out.println("driver.getText(getHoldNumber)  " + holdNumber);
                    arrHoldNumber = holdNumber.split("Hold#");
                    String sNumber = arrHoldNumber[1];
                    aHoldNumber = sNumber.split(" ");
                    holdNumber = aHoldNumber[0].trim();
                    BasePage.holdNumber = holdNumber;

                    if (!BasePage.holdNumbers.contains(holdNumber)) {
                        BasePage.holdNumbers.add(holdNumber);

                        if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
                            EndCallPage.endCall("Holds", "System Placed Hold");
                        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos") || ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers") || ApplicationConfiguration.getClient().equalsIgnoreCase("Fido")) {
                            EndCallPage.endCallWithIntentAreaAndOutcome("Call Handling", "Status Inquiry", "Claim History");
                        }

                        if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                            homePage.switchUserAccount("NAASG");
                            myWorkPage.searchHoldForApprovalUsing_MDN();
                            myWorkPage.releaseHoldResolutionReason("Approve", "Approve");
                            myWorkPage.continueChargeProcess();
                            //homePage.closeCallButton();
                            homePage.switchUserAccount("NACST");
                        } else {
                            homePage.checkCallButton();
                            myWorkPage.searchHoldForApproval();
                            driver.switchToDefaultContent();
                            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                                Assert.assertTrue("cpmInteractionDivFrame is not found on hold page", false);
                            navigateLowestLevelFrame(diaction);
                            if (!driver.checkObjectExists(holdTypeVerification, ApplicationConfiguration.getWaitForElementTimeout()))
                                Assert.assertTrue("holdTypeVerification is not found on hold page", false);
                            if (!driver.checkObjectExists(releaseHoldTypeVerification, ApplicationConfiguration.getWaitForElementTimeout()))
                                Assert.assertTrue("releaseHoldTypeVerification is not found on hold page", false);
                            myWorkPage.holdProcessAction("Continue with Customer Interaction");
                            myWorkPage.releaseHoldResolutionReason("Approved", "Verified in Billing System");
                            myWorkPage.continueChargeProcess();

                /*if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
                    EndCallPage.endCall("Holds", "System Placed Hold");
                } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                    EndCallPage.endCallWithIntentAreaAndOutcome("Call Handling", "Status Inquiry", "Claim History");
                }*/
                            homePage.closeCallButton();
                        }

//            homePage.checkCallButton();

                        CommonUtilities.waitTime(2);
                        homePage.pressStart();
                        CommonUtilities.waitTime(2);
                        if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
                            homePage.selectClient("Telcel Mexico");
                        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                            homePage.selectClient("nTelos");
                        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro")) {
                            homePage.selectClient("Claro Colombia");
                        }

                        identifyCustomerPage.searchUsingMDN(CustomerDetails.customerData.get("MDN"));
                        if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("Claro"))
                            identifyCustomerPage.verifyCallerAfterResume();
                        else
                            identifyCustomerPage.verifyCaller("Account Holder", "valid");
                        identifyCustomerPage.continueClaim();
                        incidentPathPage.select_incident_path("Resume Incident");
                        // CommonUtilities.waitTime(3);
                    }
                }
            }
        }
    }

    /**
     * This method is used to select Create Out bound Call check box
     * * @author: priyanka
     * * @param : none
     */
    public void selectCreateOutboundCall() throws Exception {
        if (driver.waitForElementPresenceWithTimeOut(OutboundFlag, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.click(OutboundFlag);
        else
            Assert.assertTrue("OutboundFlag is not found on hold release page", false);


    }


    public void checkRiskisON() throws SQLException, ClassNotFoundException {

        String Client = null;
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
            Client = "Claro";

        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
            Client = "Telcel";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            Client = "nTelos";
        }


        String RiskQuery = "Select CPRE.RISK_ENABLED_IND from \n " +
                "HRZ_RULES.CLIENT_PREFERENCES CPRE,HRZ_RULES.CLIENT_PROFILE CPRO \n" +
                "where CPRO.CLIENT_PROFILE_ID = CPRE.CLIENT_PROFILE_ID \n" +
                "and CPRO.CLIENT_NAME like '%" + Client + "%' \n" +
                "and CPRO.CHANNEL_NAME like '%Agent%'";

        String RiskStatus = (DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), RiskQuery)).toString();

        if (RiskStatus.contains("Y"))
            Assert.assertTrue("Risk is ON for " + Client, true);
        else
            Assert.assertTrue("Risk is OFF for " + Client, false);


    }

    public void checkRuleisON(String RuleName, String RuleStatus) throws SQLException, ClassNotFoundException {
        String RuleQuery = "select ActionMode,Status from business_rules where RuleName like '%" + RuleName + "%'";
        ArrayList<HashMap<String, String>> aRowsList = (DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), RuleQuery));

        String ActionMode = aRowsList.get(0).get("ACTIONMODE");
        String Status = aRowsList.get(0).get("STATUS");
        if ((ActionMode.equalsIgnoreCase("ON") || ActionMode.equalsIgnoreCase("SIM")) && (Status.equals("DEPLOYED"))) {
            Assert.assertTrue("Rule ==" + RuleName + "  ActionMode == " + ActionMode + "  and Status ==" + Status, true);
        } else
            Assert.assertTrue("Rule ==" + RuleName + "  ActionMode == " + ActionMode + "  and Status ==" + Status + "..Please Turn it ON", false);


    }


}