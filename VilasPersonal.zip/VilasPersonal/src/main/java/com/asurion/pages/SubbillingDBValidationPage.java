package com.asurion.pages;

import com.asurion.common.core.driver.TestDriver;
import com.asurion.common.core.util.Database;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.DatabaseUtils;
import org.junit.Assert;

import java.util.*;

import com.asurion.pages.SubBillingPortalPages;
import com.asurion.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Created by NANDINI.MUJUMDAR on 10/9/2017.
 */
public class SubbillingDBValidationPage {
    final String ANSI_RED = "\u001B[31m";
    final String ANSI_RESET = "\u001B[0m";
    boolean flag = true;

    public void displayValidationReport() {
        boolean temp;
        temp = flag;
        flag = true;
        Assert.assertTrue(temp);
    }

    // Method is used to verify Systematic Settlement option is ON or OFF in DB
    public void verifySystematicSettlementInDatabase(String systemOption, String mop, String selectedOption, String client) throws Exception {
        if (SubBillingPortalPages.isSystematicSettlemntPresent == true) {
            Thread.sleep(1000);
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            if (mop.equalsIgnoreCase("CRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Systematic Settlement%' and ([option] like '%" + systemOption + "%') and Tender_ValueListEntryID = 598\n");
            } else if (mop.equalsIgnoreCase("CHK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Systematic Settlement%' and ([option] like '%" + systemOption + "%') and Tender_ValueListEntryID = 932\n");
            } else if (mop.equalsIgnoreCase("ECK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Systematic Settlement%' and ([option] like '%" + systemOption + "%') and Tender_ValueListEntryID = 574\n");
            } else if (mop.equalsIgnoreCase("BTA")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Systematic Settlement%' and ([option] like '%" + systemOption + "%') and Tender_ValueListEntryID = 407\n");
            } else if (mop.equalsIgnoreCase("ISP")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Systematic Settlement%' and ([option] like '%" + systemOption + "%') and Tender_ValueListEntryID = 727\n");
            } else if (mop.equalsIgnoreCase("COD")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Systematic Settlement%' and ([option] like '%" + systemOption + "%') and Tender_ValueListEntryID = 2364\n");
            } else if (mop.equalsIgnoreCase("3PCRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Systematic Settlement%' and ([option] like '%" + systemOption + "%') and Tender_ValueListEntryID = 49746\n");
            }
            int SelectedOptionDB = Integer.parseInt(result.get(0).get("SELECTEDOPTION"));
            System.out.println("\nValue of SELECTEDOPTION : " + SelectedOptionDB);
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (SelectedOptionDB == 1)
                    System.out.println("SELECTEDOPTION is set correct in DB.");
                else {
                    System.out.println(ANSI_RED + "Expected : 1  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            } else {
                if (SelectedOptionDB == 0)
                    System.out.println("SELECTEDOPTION is set correct in DB .");
                else {
                    System.out.println(ANSI_RED + "Expected : 0  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            }
        } else {
            System.out.println(systemOption + " is not set for " + mop + " MOP for " + client);
            SubBillingPortalPages.isSystematicSettlemntPresent = true;
        }
    }

    public void validateDAXintegration(String client, String mop, String selectedOption) throws Exception {
        Thread.sleep(1000);
        if (SubBillingPortalPages.isDAXOptionPresent == true) {
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            if (mop.equalsIgnoreCase("CRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '%" + client + "%' and ValueListid =7)\n" +
                        "        and category like '%DAX Integration%' and Tender_ValueListEntryID = 598");
            } else if (mop.equalsIgnoreCase("ECK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '%" + client + "%' and ValueListid =7)\n" +
                        "        and category like '%DAX Integration%' and Tender_ValueListEntryID = 574");
            } else if (mop.equalsIgnoreCase("CHK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '%" + client + "%' and ValueListid =7)\n" +
                        "        and category like '%DAX Integration%' and Tender_ValueListEntryID = 923");
            } else if (mop.equalsIgnoreCase("BTA")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '%" + client + "%' and ValueListid =7)\n" +
                        "        and category like '%DAX Integration%' and Tender_ValueListEntryID = 407");
            } else if (mop.equalsIgnoreCase("ISP")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '%" + client + "%' and ValueListid =7)\n" +
                        "        and category like '%DAX Integration%' and Tender_ValueListEntryID = 727");
            } else if (mop.equalsIgnoreCase("COD")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '%" + client + "%' and ValueListid =7)\n" +
                        "        and category like '%DAX Integration%' and Tender_ValueListEntryID = 2364");
            } else if (mop.equalsIgnoreCase("3PCRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '%" + client + "%' and ValueListid =7)\n" +
                        "        and category like '%DAX Integration%' and Tender_ValueListEntryID = 49746");
            }
            // Verifing actaul System Option value with expected
            int SelectedOptionDB = Integer.parseInt(result.get(0).get("SELECTEDOPTION"));
            System.out.println("\nValue of SELECTEDOPTION : " + SelectedOptionDB);
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (SelectedOptionDB == 1)
                    System.out.println("SELECTEDOPTION is set correct in DB.");
                else {
                    System.out.println(ANSI_RED + "Expected : 1  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            } else {
                if (SelectedOptionDB == 0)
                    System.out.println("SELECTEDOPTION is set correct in DB .");
                else {
                    System.out.println(ANSI_RED + "Expected : 0  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            }

        } else {
            System.out.println("DAX Integration is not set for " + mop + " MOP for " + client);
        }
    }

    // Method is used to verify Aggregate Analysis system option is ON or OFF in DB for Refund Adjudication
    public void verifySystemOptionForAggregateAnalysisInDatabase(String selectedOption, String mop, String client) throws Exception {
        if (SubBillingPortalPages.isAggregateOptionPresent == true) {
            Thread.sleep(1000);
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            if (mop.equalsIgnoreCase("CRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Aggregate Analysis%') and Tender_ValueListEntryID = 598\n");
            } else if (mop.equalsIgnoreCase("CHK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Aggregate Analysis%') and Tender_ValueListEntryID = 932\n");
            } else if (mop.equalsIgnoreCase("ECK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Aggregate Analysis%') and Tender_ValueListEntryID = 574\n");
            } else if (mop.equalsIgnoreCase("BTA")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Aggregate Analysis%') and Tender_ValueListEntryID = 407\n");
            } else if (mop.equalsIgnoreCase("ISP")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Aggregate Analysis%') and Tender_ValueListEntryID = 727\n");
            } else if (mop.equalsIgnoreCase("COD")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Aggregate Analysis%') and Tender_ValueListEntryID = 2364\n");
            } else if (mop.equalsIgnoreCase("3PCRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Aggregate Analysis%') and Tender_ValueListEntryID = 49746\n");
            }

            int SelectedOptionDB = Integer.parseInt(result.get(0).get("SELECTEDOPTION"));
            System.out.println("\nValue of SELECTEDOPTION : " + SelectedOptionDB);
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (SelectedOptionDB == 1)
                    System.out.println("SELECTEDOPTION is set correct in DB.");
                else {
                    System.out.println(ANSI_RED + "Expected : 1  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            } else {
                if (SelectedOptionDB == 0)
                    System.out.println("SELECTEDOPTION is set correct in DB .");
                else {
                    System.out.println(ANSI_RED + "Expected : 0  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            }
        } else {
            System.out.println("\nAggregate Analysis is not set for " + mop + " MOP for " + client);
            SubBillingPortalPages.isAggregateOptionPresent = true;
        }
    }

    // Method is used to verify Check Settlement system option is ON or OFF in DB for Refund Adjudication
    public void verifySystemOptionForCheckSettlementInDatabase(String selectedOption, String mop, String client) throws Exception {
        if (SubBillingPortalPages.isSettlementOptionPresent == true) {
            Thread.sleep(1000);
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            if (mop.equalsIgnoreCase("CRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Settlement%') and Tender_ValueListEntryID = 598\n");
            } else if (mop.equalsIgnoreCase("CHK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Settlement%') and Tender_ValueListEntryID = 932\n");
            } else if (mop.equalsIgnoreCase("ECK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Settlement%') and Tender_ValueListEntryID = 574\n");
            } else if (mop.equalsIgnoreCase("BTA")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Settlement%') and Tender_ValueListEntryID = 407\n");
            } else if (mop.equalsIgnoreCase("ISP")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Settlement%') and Tender_ValueListEntryID = 727\n");
            } else if (mop.equalsIgnoreCase("COD")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Settlement%') and Tender_ValueListEntryID = 2364\n");
            } else if (mop.equalsIgnoreCase("3PCRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Settlement%') and Tender_ValueListEntryID = 49746\n");
            }
            int SelectedOptionDB = Integer.parseInt(result.get(0).get("SELECTEDOPTION"));
            System.out.println("\nValue of SELECTEDOPTION : " + SelectedOptionDB);
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (SelectedOptionDB == 1)
                    System.out.println("SELECTEDOPTION is set correct in DB.");
                else {
                    System.out.println(ANSI_RED + "Expected : 1  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            } else {
                if (SelectedOptionDB == 0)
                    System.out.println("SELECTEDOPTION is set correct in DB .");
                else {
                    System.out.println(ANSI_RED + "Expected : 0  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            }
        } else {
            System.out.println("\nCheck Settlement is not set for " + mop + " MOP for " + client);
            SubBillingPortalPages.isSettlementOptionPresent = true;
        }
    }

    // Method is used to verify Settlement Initiated system pption is ON or OFF in DB for Refund Adjudication
    public void verifySystemOptionForSettlementInitiatedInDatabase(String selectedOption, String mop, String client) throws Exception {
        if (selectedOption.equalsIgnoreCase("NA")) {
            System.out.println("\nSettlement Initiated is not present as Check Settlement is not checked.");
            SubBillingPortalPages.isAggregateOptionPresent = true;
        } else if (SubBillingPortalPages.isInitiatedSettlementOptionPresent == true) {
            Thread.sleep(1000);
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            if (mop.equalsIgnoreCase("CRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - Initiated%') and Tender_ValueListEntryID = 598\n");
            } else if (mop.equalsIgnoreCase("CHK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - Initiated%') and Tender_ValueListEntryID = 932\n");
            } else if (mop.equalsIgnoreCase("ECK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - Initiated%') and Tender_ValueListEntryID = 574\n");
            } else if (mop.equalsIgnoreCase("BTA")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - Initiated%') and Tender_ValueListEntryID = 407\n");
            } else if (mop.equalsIgnoreCase("ISP")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - Initiated%') and Tender_ValueListEntryID = 727\n");
            } else if (mop.equalsIgnoreCase("COD")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - Initiated%') and Tender_ValueListEntryID = 2364\n");
            } else if (mop.equalsIgnoreCase("3PCRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - Initiated%') and Tender_ValueListEntryID = 49746\n");
            }
            int SelectedOptionDB = Integer.parseInt(result.get(0).get("SELECTEDOPTION"));
            System.out.println("\nValue of SELECTEDOPTION : " + SelectedOptionDB);
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (SelectedOptionDB == 1)
                    System.out.println("SELECTEDOPTION is set correct in DB.");
                else {
                    System.out.println(ANSI_RED + "Expected : 1  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            } else {
                if (SelectedOptionDB == 0)
                    System.out.println("SELECTEDOPTION is set correct in DB .");
                else {
                    System.out.println(ANSI_RED + "Expected : 0  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            }
        } else {
            System.out.println("\nSettlement Initiated is not set for " + mop + " MOP for " + client);
            SubBillingPortalPages.isInitiatedSettlementOptionPresent = true;
        }
    }

    // Method is used to verify Setllement In Process system pption is ON or OFF in DB for Refund Adjudication
    public void verifySystemOptionForSettlementInProcessInDatabase(String selectedOption, String mop, String client) throws Exception {
        if (selectedOption.equalsIgnoreCase("NA")) {
            System.out.println("\nSettlement In Process is not present as Check Settlement is not checked.");
            SubBillingPortalPages.isAggregateOptionPresent = true;
        } else if (SubBillingPortalPages.isInProcessSettlementOptionPresent == true) {
            Thread.sleep(1000);
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            if (mop.equalsIgnoreCase("CRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - In Process%') and Tender_ValueListEntryID = 598\n");
            } else if (mop.equalsIgnoreCase("CHK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - In Process%') and Tender_ValueListEntryID = 932\n");
            } else if (mop.equalsIgnoreCase("ECK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - In Process%') and Tender_ValueListEntryID = 574\n");
            } else if (mop.equalsIgnoreCase("BTA")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - In Process%') and Tender_ValueListEntryID = 407\n");
            } else if (mop.equalsIgnoreCase("ISP")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - In Process%') and Tender_ValueListEntryID = 727\n");
            } else if (mop.equalsIgnoreCase("COD")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - In Process%') and Tender_ValueListEntryID = 2364\n");
            } else if (mop.equalsIgnoreCase("3PCRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Settlement - In Process%') and Tender_ValueListEntryID = 49746\n");
            }
            int SelectedOptionDB = Integer.parseInt(result.get(0).get("SELECTEDOPTION"));
            System.out.println("\nValue of SELECTEDOPTION : " + SelectedOptionDB);
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (SelectedOptionDB == 1)
                    System.out.println("SELECTEDOPTION is set correct in DB.");
                else {
                    System.out.println(ANSI_RED + "Expected : 1  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            } else {
                if (SelectedOptionDB == 0)
                    System.out.println("SELECTEDOPTION is set correct in DB .");
                else {
                    System.out.println(ANSI_RED + "Expected : 0  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            }
        } else {
            System.out.println("\n Settlement In Process is not set for " + mop + " MOP for " + client);
            SubBillingPortalPages.isInProcessSettlementOptionPresent = true;
        }
    }

    // Method is used to verify Check Refund system pption is ON or OFF in DB for Refund Adjudication
    public void verifySystemOptionForCheckRefundInDatabase(String selectedOption, String mop, String client) throws Exception {
        if (SubBillingPortalPages.isCheckRefundOptionPresent == true) {
            Thread.sleep(1000);
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            if (mop.equalsIgnoreCase("CRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Refund%') and Tender_ValueListEntryID = 598\n");
            } else if (mop.equalsIgnoreCase("CHK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Refund%') and Tender_ValueListEntryID = 932\n");
            } else if (mop.equalsIgnoreCase("ECK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Refund%') and Tender_ValueListEntryID = 574\n");
            } else if (mop.equalsIgnoreCase("BTA")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Refund%') and Tender_ValueListEntryID = 407\n");
            } else if (mop.equalsIgnoreCase("ISP")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Refund%') and Tender_ValueListEntryID = 727\n");
            } else if (mop.equalsIgnoreCase("COD")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Refund%') and Tender_ValueListEntryID = 2364\n");
            } else if (mop.equalsIgnoreCase("3PCRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Refund%') and Tender_ValueListEntryID = 49746\n");
            }
            int SelectedOptionDB = Integer.parseInt(result.get(0).get("SELECTEDOPTION"));
            System.out.println("\nValue of SELECTEDOPTION : " + SelectedOptionDB);
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (SelectedOptionDB == 1)
                    System.out.println("SELECTEDOPTION is set correct in DB.");
                else {
                    System.out.println(ANSI_RED + "Expected : 1  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            } else {
                if (SelectedOptionDB == 0)
                    System.out.println("SELECTEDOPTION is set correct in DB .");
                else {
                    System.out.println(ANSI_RED + "Expected : 0  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            }
        } else {
            System.out.println("\nCheck Refund is not set for " + mop + " MOP for " + client);
            SubBillingPortalPages.isCheckRefundOptionPresent = true;
        }
    }

    // Method is used to verify Refund Initiated system pption is ON or OFF in DB for Refund Adjudication
    public void verifySystemOptionForRefundInitiatedInDatabase(String selectedOption, String mop, String client) throws Exception {
        if (selectedOption.equalsIgnoreCase("NA")) {
            System.out.println("\nRefund Initiated is not present as Check Refund is not checked.");
            SubBillingPortalPages.isAggregateOptionPresent = true;
        } else if (SubBillingPortalPages.isInitiatedRefundOptionPresent == true) {
            Thread.sleep(1000);
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            if (mop.equalsIgnoreCase("CRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - Initiated%') and Tender_ValueListEntryID = 598\n");
            } else if (mop.equalsIgnoreCase("CHK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - Initiated%') and Tender_ValueListEntryID = 932\n");
            } else if (mop.equalsIgnoreCase("ECK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - Initiated%') and Tender_ValueListEntryID = 574\n");
            } else if (mop.equalsIgnoreCase("BTA")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - Initiated%') and Tender_ValueListEntryID = 407\n");
            } else if (mop.equalsIgnoreCase("ISP")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - Initiated%') and Tender_ValueListEntryID = 727\n");
            } else if (mop.equalsIgnoreCase("COD")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - Initiated%') and Tender_ValueListEntryID = 2364\n");
            } else if (mop.equalsIgnoreCase("3PCRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - Initiated%') and Tender_ValueListEntryID = 49746\n");
            }
            int SelectedOptionDB = Integer.parseInt(result.get(0).get("SELECTEDOPTION"));
            System.out.println("\nValue of SELECTEDOPTION : " + SelectedOptionDB);
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (SelectedOptionDB == 1)
                    System.out.println("SELECTEDOPTION is set correct in DB.");
                else {
                    System.out.println(ANSI_RED + "Expected : 1  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            } else {
                if (SelectedOptionDB == 0)
                    System.out.println("SELECTEDOPTION is set correct in DB .");
                else {
                    System.out.println(ANSI_RED + "Expected : 0  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            }
        } else {
            System.out.println("\nRefund Initiated is not set for " + mop + " MOP for " + client);
            SubBillingPortalPages.isInitiatedRefundOptionPresent = true;
        }
    }

    // Method is used to verify Refund In Process system pption is ON or OFF in DB for Refund Adjudication
    public void verifySystemOptionForRefundInProcessInDatabase(String selectedOption, String mop, String client) throws Exception {
        if (selectedOption.equalsIgnoreCase("NA")) {
            System.out.println("\nRefund In Process is not present as Check Refund is not checked.");
            SubBillingPortalPages.isAggregateOptionPresent = true;
        } else if (SubBillingPortalPages.isInProcessRefundOptionPresent == true) {
            Thread.sleep(1000);
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            if (mop.equalsIgnoreCase("CRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - In Process%') and Tender_ValueListEntryID = 598\n");
            } else if (mop.equalsIgnoreCase("CHK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - In Process%') and Tender_ValueListEntryID = 932\n");
            } else if (mop.equalsIgnoreCase("ECK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - In Process%') and Tender_ValueListEntryID = 574\n");
            } else if (mop.equalsIgnoreCase("BTA")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - In Process%') and Tender_ValueListEntryID = 407\n");
            } else if (mop.equalsIgnoreCase("ISP")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - In Process%') and Tender_ValueListEntryID = 727\n");
            } else if (mop.equalsIgnoreCase("COD")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - In Process%') and Tender_ValueListEntryID = 2364\n");
            } else if (mop.equalsIgnoreCase("3PCRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Refund - In Process%') and Tender_ValueListEntryID = 49746\n");
            }
            int SelectedOptionDB = Integer.parseInt(result.get(0).get("SELECTEDOPTION"));
            System.out.println("\nValue of SELECTEDOPTION : " + SelectedOptionDB);
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (SelectedOptionDB == 1)
                    System.out.println("SELECTEDOPTION is set correct in DB.");
                else {
                    System.out.println(ANSI_RED + "Expected : 1  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            } else {
                if (SelectedOptionDB == 0)
                    System.out.println("SELECTEDOPTION is set correct in DB .");
                else {
                    System.out.println(ANSI_RED + "Expected : 0  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            }
        } else {
            System.out.println("\nRefund In Process is not set for " + mop + " MOP for " + client);
            SubBillingPortalPages.isInProcessRefundOptionPresent = true;
        }
    }

    // Method is used to verify Check Chargeback system pption is ON or OFF in DB for Refund Adjudication
    public void verifySystemOptionForCheckChargebackInDatabase(String selectedOption, String mop, String client) throws Exception {
        if (SubBillingPortalPages.isChargebackOptionPresent == true) {
            Thread.sleep(1000);
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            if (mop.equalsIgnoreCase("CRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Chargeback%') and Tender_ValueListEntryID = 598\n");
            } else if (mop.equalsIgnoreCase("CHK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Chargeback%') and Tender_ValueListEntryID = 932\n");
            } else if (mop.equalsIgnoreCase("ECK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Chargeback%') and Tender_ValueListEntryID = 574\n");
            } else if (mop.equalsIgnoreCase("BTA")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Chargeback%') and Tender_ValueListEntryID = 407\n");
            } else if (mop.equalsIgnoreCase("ISP")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Chargeback%') and Tender_ValueListEntryID = 727\n");
            } else if (mop.equalsIgnoreCase("COD")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Chargeback%') and Tender_ValueListEntryID = 2364\n");
            } else if (mop.equalsIgnoreCase("3PCRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Check Chargeback%') and Tender_ValueListEntryID = 49746\n");
            }
            int SelectedOptionDB = Integer.parseInt(result.get(0).get("SELECTEDOPTION"));
            System.out.println("\nValue of SELECTEDOPTION : " + SelectedOptionDB);
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (SelectedOptionDB == 1)
                    System.out.println("SELECTEDOPTION is set correct in DB.");
                else {
                    System.out.println(ANSI_RED + "Expected : 1  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            } else {
                if (SelectedOptionDB == 0)
                    System.out.println("SELECTEDOPTION is set correct in DB .");
                else {
                    System.out.println(ANSI_RED + "Expected : 0  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            }
        } else {
            System.out.println("\nCheck ChargeBack is not set for " + mop + " MOP for " + client);
            SubBillingPortalPages.isChargebackOptionPresent = true;
        }
    }

    // Method is used to verify Chargeback Initiated system pption is ON or OFF in DB for Refund Adjudication
    public void verifySystemOptionForChargebackInitiatedInDatabase(String selectedOption, String mop, String client) throws Exception {
        if (selectedOption.equalsIgnoreCase("NA")) {
            System.out.println("\nRefund Initiated is not present as Check ChargeBack is not checked.");
            SubBillingPortalPages.isAggregateOptionPresent = true;
        } else if (SubBillingPortalPages.isInitaitedChargebackOptionPresent == true) {
            Thread.sleep(1000);
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            if (mop.equalsIgnoreCase("CRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Chargeback - Initiated%') and Tender_ValueListEntryID = 598\n");
            } else if (mop.equalsIgnoreCase("CHK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Chargeback - Initiated%') and Tender_ValueListEntryID = 932\n");
            } else if (mop.equalsIgnoreCase("ECK")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Chargeback - Initiated%') and Tender_ValueListEntryID = 574\n");
            } else if (mop.equalsIgnoreCase("BTA")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Chargeback - Initiated%') and Tender_ValueListEntryID = 407\n");
            } else if (mop.equalsIgnoreCase("ISP")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Chargeback - Initiated%') and Tender_ValueListEntryID = 727\n");
            } else if (mop.equalsIgnoreCase("COD")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Chargeback - Initiated%') and Tender_ValueListEntryID = 2364\n");
            } else if (mop.equalsIgnoreCase("3PCRE")) {
                result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), " Select SelectedOption from Basics.ConfigurationData.systemoptions where Client_valuelistentryid = (select ValueListEntryID from Basics.BillingAnalytics.ValueListEntry where Value like '" + client + "' and ValueListid =7)\n" +
                        "        and category like '%Refund Adjudication%' and ([option] like '%Chargeback - Initiated%') and Tender_ValueListEntryID = 49746\n");
            }
            int SelectedOptionDB = Integer.parseInt(result.get(0).get("SELECTEDOPTION"));
            System.out.println("\nValue of SELECTEDOPTION : " + SelectedOptionDB);
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (SelectedOptionDB == 1)
                    System.out.println("SELECTEDOPTION is set correct in DB.");
                else {
                    System.out.println(ANSI_RED + "Expected : 1  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            } else {
                if (SelectedOptionDB == 0)
                    System.out.println("SELECTEDOPTION is set correct in DB .");
                else {
                    System.out.println(ANSI_RED + "Expected : 0  and   Actual : " + SelectedOptionDB + ANSI_RESET);
                    flag = false;
                }
            }
        } else {
            System.out.println("\nChargeBack Initiated is not set for " + mop + " MOP for " + client);
            SubBillingPortalPages.isInitaitedChargebackOptionPresent = true;
        }
    }

    public void verifyPortalData(String transactionType) throws Exception {
        Thread.sleep(1000);
        String client = ApplicationConfiguration.getClient();
        if (client.equalsIgnoreCase("Freedom")) {
            client = "Freedom Mobile";
        }
        String caseNumber = CaptureIncidentPage.claimId;
        System.out.println("\nFor client " + client + " verifing poratl value into BASICS");
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        //Getting  Intenet Values
        List<WebElement> webElements = TestDriver.getWebDriver().findElements(By.xpath("//div[@class='panel window']//div[@class='ui-grid-row ng-scope']/div/div"));   //Xpath:  //div[@class='panel window']//div[@class='ui-grid-row ng-scope']/div/div
        ArrayList<String> intentData = new ArrayList<String>();
        for (WebElement rowData : webElements) {
            String data = rowData.getText();
            intentData.add(data);
        }
        Iterator itr = intentData.iterator();
        while (itr.hasNext()) {
            System.out.println("Table Data: " + itr.next());
        }
        // Fetching DB values
        if (client.equalsIgnoreCase("Tracfone") && transactionType.equalsIgnoreCase("DED ESC")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select Client, IntentReference, IntentType, MethodofPayment, Amount, DAXCompanyID, AdditionalInfo, CreatedDTM from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%'  and IntentType like '%ServiceRequest%' and Items like '%CWPF%'");
        } else {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "select Client, IntentReference, IntentType, MethodofPayment, Amount, DAXCompanyID, AdditionalInfo, CreatedDTM from Basics.IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%' and client like '%" + client + "%'  and IntentType like '%ServiceRequest%' and Items like '%DED%'");
        }
        if (result.size() > 0) {
            String additionalInfoColValue = result.get(0).get("ADDITIONALINFO");
            String addtionalInfo[] = additionalInfoColValue.split(",");
            // Validating Values
            if (intentData.get(1).equalsIgnoreCase(result.get(0).get("CLIENT")))
                System.out.println("Expected Client : " + result.get(0).get("CLIENT") + " and Actual : " + intentData.get(1));
            else {
                System.out.println(ANSI_RED + "Expected Client : " + result.get(0).get("CLIENT") + " Actual Client : " + intentData.get(1) + ANSI_RESET);
                flag = false;
            }
            if (intentData.get(2).equalsIgnoreCase(result.get(0).get("INTENTREFERENCE")))
                System.out.println("Expected INTENT REFERENCE : " + result.get(0).get("INTENTREFERENCE") + " and Actual  : " + intentData.get(2));
            else {
                System.out.println(ANSI_RED + "Expected INTENT REFERENCE : " + result.get(0).get("INTENTREFERENCE") + " Actual INTENT REFERENCE : " + intentData.get(2) + ANSI_RESET);
                flag = false;
            }
            if (intentData.get(3).equalsIgnoreCase(addtionalInfo[1]))
                System.out.println("Expected CASE NUMBER : " + addtionalInfo[1] + " and Actual : " + intentData.get(3));
            else {
                System.out.println(ANSI_RED + "Expected CASE NUMBER : " + addtionalInfo[1] + " Actual CASE NUMBER : " + intentData.get(3) + ANSI_RESET);
                flag = false;
            }
            if (intentData.get(4).equalsIgnoreCase(addtionalInfo[3]))
                System.out.println("Expected SERVICE REQUEST NUMBER : " + addtionalInfo[3] + " and Actual : " + intentData.get(4));
            else {
                System.out.println(ANSI_RED + "Expected SERVICE REQUEST NUMBER : " + addtionalInfo[3] + " Actual SERVICE REQUEST NUMBER : " + intentData.get(4) + ANSI_RESET);
                flag = false;
            }
            if (intentData.get(5).equalsIgnoreCase(addtionalInfo[5]))
                System.out.println("Expected SERVICE ORDER NUMBER : " + addtionalInfo[3] + " and Actual : " + intentData.get(5));
            else {
                System.out.println(ANSI_RED + "Expected SERVICE ORDER NUMBER : " + addtionalInfo[3] + " Actual SERVICE ORDER NUMBER : " + intentData.get(5) + ANSI_RESET);
                flag = false;
            }
            if (intentData.get(6).equalsIgnoreCase(result.get(0).get("INTENTTYPE")))
                System.out.println("Expected INTENT TYPE : " + result.get(0).get("INTENTTYPE") + " and Actual : " + intentData.get(6));
            else {
                System.out.println(ANSI_RED + "Expected INTENT TYPE : " + result.get(0).get("INTENTTYPE") + " Actual INTENT TYPE : " + intentData.get(6) + ANSI_RESET);
                flag = false;
            }
            if (intentData.get(7).equalsIgnoreCase(result.get(0).get("METHODOFPAYMENT")))
                System.out.println("Expected METHOD OF PAYMENT : " + result.get(0).get("METHODOFPAYMENT") + " and Actual : " + intentData.get(7));
            else {
                System.out.println(ANSI_RED + "Expected METHOD OF PAYMENT : " + result.get(0).get("METHODOFPAYMENT") + " Actual METHOD OF PAYMENT : " + intentData.get(7) + ANSI_RESET);
                flag = false;
            }
            if (intentData.get(8).equalsIgnoreCase(result.get(0).get("AMOUNT")))
                System.out.println("\nExpected AMOUNT: " + result.get(0).get("AMOUNT") + " and Actual : " + intentData.get(8));
            else {
                System.out.println(ANSI_RED + "Expected AMOUNT : " + result.get(0).get("AMOUNT") + " Actual AMOUNT : " + intentData.get(8) + ANSI_RESET);
                flag = false;
            }
            if (intentData.get(9).equalsIgnoreCase(result.get(0).get("DAXCOMPANYID")))
                System.out.println("Expected DAX COMPANY ID : " + result.get(0).get("DAXCOMPANYID") + " and Actual : " + intentData.get(9));
            else {
                System.out.println(ANSI_RED + "Expected DAX COMPANY ID : " + result.get(0).get("DAXCOMPANYID") + " Actual DAX COMPANY ID : " + intentData.get(9) + ANSI_RESET);
                flag = false;
            }
                /*if (intentData.get(13).equalsIgnoreCase(result.get(0).get("CREATEDDTM")))
                    System.out.println("Expected CREATED DTM : " + result.get(0).get("CREATEDDTM") + " and Actual : " + intentData.get(13));
                else {
                    System.out.println(ANSI_RED + "Expected CREATED DTM : " + result.get(0).get("CREATEDDTM") + " Actual CREATED DTM : " + intentData.get(13) + ANSI_RESET);
                    flag = false;
                }*/
        }
    }

    public void verifyupdatedportalDataInDB(String updatedValue) throws Exception {
        Thread.sleep(1000);
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        if (updatedValue.equalsIgnoreCase("Amount")) {
            result = DatabaseUtils.executeSQLQuery(DatabaseUtils.getConnection(), "SELECT Amount FROM Basics.BillingAnalytics.Intent WHERE IntentID='" + SubBillingPortalPages.intentIDOnPortal + "'");
           // System.out.println("\n After updating, Amount in Database: "+result.get(0).get("AMOUNT"));
            String amountOnPortal = TestDriver.getWebDriver().findElement(By.xpath("//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]")).getText();
            if(amountOnPortal.equalsIgnoreCase(result.get(0).get("AMOUNT"))){
                System.out.println("\nAmount is successfully updated in Database as " + result.get(0).get("AMOUNT"));
            }else
                Assert.assertTrue("Expected AMOUNT : " + amountOnPortal + " and Actual : " + result.get(0).get("AMOUNT"), false);
        }
    }
}
