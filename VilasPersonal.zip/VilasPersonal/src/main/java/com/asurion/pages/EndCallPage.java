package com.asurion.pages;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.util.ApplicationConfiguration;
import org.junit.Assert;

public class EndCallPage extends BasePage {

    private UIElement cpmInteractionDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmInteractionDivFrame");
    private UIElement cpmTabbedNavigationDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    private UIElement diaction = new UIElement(UIType.Frame, UILocatorType.Name, "DIACTION");
    private UIElement endCallHeaderButton = new UIElement(UIType.Button, UILocatorType.Link, "End Call");
    private UIElement navigationDivFrame = new UIElement(UIType.Button, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    private UIElement selectReason = new UIElement(UIType.ListBox, UILocatorType.ID, "ResolutionAction");
    private UIElement endCallReasonResult = new UIElement(UIType.ListBox, UILocatorType.ID, "ResolutionResult");
    //private UIElement endCallButton = new UIElement(UIType.Button, UILocatorType.CSS, "table>tbody>tr:nth-child(2)>td:nth-child(4)>nobr>span>button");
    // private UIElement endCallButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[3]//div[2]//button");
   // private UIElement endCallButton = new UIElement(UIType.Button, UILocatorType.CSS, "button.InFormContinueButton.pzhc");
    private UIElement endCallButton = new UIElement(UIType.Button, UILocatorType.CSS, "button[class*=Hoz_New_Continue_Btn] div[class=pzbtn-mid]");
    private UIElement endCalloutcome = new UIElement(UIType.ListBox, UILocatorType.ID, "CallDispositionResult");
    private UIElement endCallButtonEU = new UIElement(UIType.Button, UILocatorType.CSS, ".InteractionHeaderLinkWrap");
    private UIElement buttonEndCallEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='2015081111183803312678']");
    private UIElement endCallReasonEU = new UIElement(UIType.Button, UILocatorType.ID, "ResolutionAction");
    private UIElement endCallResultEU = new UIElement(UIType.Button, UILocatorType.ID, "ResolutionResult");
    private UIElement buttonCancel = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='20150811111838033125135']");
    private UIElement callTab = new UIElement(UIType.Button, UILocatorType.CSS, "button.InteractionCloseTabButton");


    /**
     * This method is used for end call and select reason and result
     * (Telcel and claro)
     *
     * @param reason,subReasonResult eg.Claim , Submitted Claim
     * @author Sachin
     */
    public void endCall(String reason, String subReasonResult) throws Exception {
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmInteractionDiv frame is not found on end call Page", false);
        }
        // driver.switchToFrame(diaction);
        // navigateLowestLevelFrame(diaction);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("diaction frame is not found on end call Page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(endCallHeaderButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(endCallHeaderButton);
        } else {
            Assert.assertTrue("endCall Button is not found on end call Page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(selectReason, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(selectReason, reason);
        } else {
            Assert.assertTrue("selectReason dropdown not found on end call Page", false);
        }
        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(endCallReasonResult, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.waitForElementPresence(endCallReasonResult);
            driver.select(endCallReasonResult, subReasonResult);
        } else {
            Assert.assertTrue("EndCallReasonResult dropdown not found on end call Page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(endCallButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(endCallButton);
        } else {
            Assert.assertTrue("EndCall Button not found on end call Page", false);
        }
    }

    /**
     * This method is used for end call and select intent,area,outcome
     * (nTelos)
     *
     * @param intent,area,outcome eg.Call Handling,Status Inquiry,Claim History
     * @author Sachin
     */
    public void endCallWithIntentAreaAndOutcome(String intent, String area, String outcome) throws Exception {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmInteractionDiv frame is not found on end call Page", false);
        }
        if (driver.checkObjectExists(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.switchToFrame(diaction);
        }

        if (driver.checkObjectExists(endCallHeaderButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(endCallHeaderButton);
        } else {
            Assert.assertTrue("EndCall Button is not found on end call Page", false);
        }
        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(endCallButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(endCallButton);
        } else {
            Assert.assertTrue("endCall Button not found on end call page", false);
        }

    }

    /**
     * This method is used for end call and select intent,area,outcome
     * (nTelos)
     *
     * @param intent,area,outcome eg.Call Handling,Status Inquiry,Claim History
     * @author Sachin
     */
    public void endCallWithIntentAreaAndOutcomeForReleaseHold(String intent, String area, String outcome) throws Exception {
        CommonUtilities.waitTime(4);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmInteractionDiv frame is not found on end call Page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("diaction frame is not found on end call Page", false);
        }
           /* if(!driver.waitForFrameToLoad(diaction,ApplicationConfiguration.getWaitForElementTimeout())){
                Assert.assertTrue("diaction frame is not found on end call Page",false);
            }*/


        if (driver.checkObjectExists(endCallHeaderButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(endCallHeaderButton);
        } else {
            Assert.assertTrue("EndCall Button is not found on end call Page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(selectReason, ApplicationConfiguration.getWaitForElementTimeout())) {
            //driver.waitForElementPresence(selectReason);
            driver.select(selectReason, intent);
        } else {
            Assert.assertTrue("selectReason dropdown not found on end call page", false);
        }
        CommonUtilities.waitTime(12);
        if (driver.waitForElementPresenceWithTimeOut(endCallReasonResult, ApplicationConfiguration.getWaitForElementTimeout())) {   //driver.waitForElementPresence(endCallReasonResult);
            driver.doubleClick(endCallReasonResult);
            driver.select(endCallReasonResult, area);
            driver.select(endCallReasonResult, area);
        } else {
            Assert.assertTrue("EndCallReasonResult dropdown not found on end call Page", false);
        }
        CommonUtilities.waitTime(9);
        if (driver.waitForElementPresenceWithTimeOut(endCalloutcome, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(endCalloutcome, outcome);
        } else {
            Assert.assertTrue("endCalloutcome dropdown not found on end call Page", false);
        }

        if (driver.checkObjectExists(endCallButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(endCallButton);
        } else {
            Assert.assertTrue("endCall Button not found on end call page", false);
        }


    }

    public void endCallEU() {
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());

        if (driver.waitForElementPresenceWithTimeOut(buttonEndCallEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(buttonEndCallEU);
            System.out.println("Clicked button EndCall on end call page");
        } else {
            System.out.println("End Call button not found on end call page");
            //Assert.assertTrue("End Call button not found on end call page", false);
        }

    }

    public void verifyEndCallLocObjectsEU() {
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        System.out.println(driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()));

        if (driver.getText(buttonEndCallEU).contentEquals("[End Call]")) {
            System.out.println("End Call button is displayed on order review page with text" + driver.getText(buttonEndCallEU));
        } else {
            System.out.println("Localized End Call button is not displayed on End Call popup");
            Assert.assertTrue("Localized End Call button is not displayed on End Call popup", false);
        }
    }

    public void selectEndCallEU() {
        CommonUtilities.waitTime(4);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());

        if (driver.waitForElementPresenceWithTimeOut(endCallButtonEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(endCallButtonEU);
            System.out.println("Clicked button EndCall on end call page");
        } else {
            System.out.println("End Call button not found on end call page");
            Assert.assertTrue("End Call button not found on end call page", false);
        }

    }

    public void endCallWithReasonEU(String reason, String endCallResult) {
        CommonUtilities.waitTime(4);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());


        if (driver.waitForElementPresenceWithTimeOut(endCallReasonEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(endCallReasonEU, reason);
            System.out.println("Selected end call reason");
        } else {
            System.out.println("End call reason drop down not found on end call popup");
            Assert.assertTrue("End call reason drop down not found on end call popup", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(endCallResultEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(endCallResultEU, endCallResult);
            System.out.println("Selected end call result");
        } else {
            System.out.println("End call result drop down not found on end call popup");
            Assert.assertTrue("End call result drop down not found on end call popup", false);
        }
    }

    public void selectEndCallConfirmationButtonEU() {
        CommonUtilities.waitTime(4);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());

        if (driver.waitForElementPresenceWithTimeOut(buttonEndCallEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(buttonEndCallEU);
            System.out.println("Cicked on end call confirmation button");
        } else {
            System.out.println("End call confirmation button not found on end call popup");
            Assert.assertTrue("End call confirmation button not found on end call popup", false);
        }
        CommonUtilities.waitTime(8);
    }

    public void clickCancelEndCallEU() {
        CommonUtilities.waitTime(3);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());

        if (driver.waitForElementPresenceWithTimeOut(buttonCancel, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(buttonCancel);
            System.out.println("Cancelled the End Call reason window");
        } else {
            System.out.println("Cancel button is not displayed in End Call reason window");
            Assert.assertTrue("Cancel button is not displayed in End Call reason window", false);
        }
    }

    public void closeCallButton(){
        CommonUtilities.waitTime(2);
        driver.click(callTab);
        if (driver.isAlertPresent())
            driver.acceptAlert();
    }
}