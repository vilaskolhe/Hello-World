package com.asurion.pages;

import com.asurion.common.core.driver.TestDriver;
import org.openqa.selenium.WebElement;
import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.database.DatabaseValidationUtil;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.DatabaseUtils;
import cucumber.api.java.gl.E;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.Keys;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.interactions.Actions;

import java.io.*;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.*;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;


/**
 * Created by vilas.kolhe on 5/3/2017.
 */
public class SubBillingPortalPages extends BasePage {
    public static boolean isDAXOptionPresent = true;
    public static boolean isAggregateOptionPresent = true;
    public static boolean isSettlementOptionPresent = true;
    public static boolean isInitiatedSettlementOptionPresent = true;
    public static boolean isInProcessSettlementOptionPresent = true;
    public static boolean isCheckRefundOptionPresent = true;
    public static boolean isInitiatedRefundOptionPresent = true;
    public static boolean isInProcessRefundOptionPresent = true;
    public static boolean isChargebackOptionPresent = true;
    public static boolean isInitaitedChargebackOptionPresent = true;
    public static boolean isSystematicSettlemntPresent = true;
    public static boolean isRecordPresent = true;
    public static boolean isAPSIntegrationPresent = true;
    public static String intentIDOnPortal="";
    public static String amount;


    //To execute query
    private DatabaseValidationUtil databaseValidationUtil = DatabaseValidationUtil.getDatabaseValidationUtil();
    private DatabaseUtils databaseUtils = new DatabaseUtils();

    String caseNumber = driver.getUniqueStringOfReqLength(11, true);
    String intentReference = driver.getUniqueStringOfReqLength(31, false);
    String referencesString = "";
    public static String sbClient = null;

    //For uploading a file into SB portal
    private Robot robot;
    private UIElement intentChargeUpload = new UIElement(UIType.Link, UILocatorType.Xpath, "//a[contains(text(),'Intent Charge Upload') and contains(@href,'IntentChargeUpload')]");
    private UIElement intentChargeResubmit = new UIElement(UIType.Link, UILocatorType.Xpath, "//a[contains(text(),'Intent Charge Resubmit') and contains(@href,'IntentChargeResubmit')]");
    //  private UIElement systemOption = new UIElement(UIType.Link, UILocatorType.Xpath, "//a[contains(text(),'System Option') and contains(@href,' SystemOption')]");
    private UIElement systemOption = new UIElement(UIType.Link, UILocatorType.Xpath, ".//*[@id='collapse0']/div/a[3]");


    private UIElement search = new UIElement(UIType.Link, UILocatorType.Xpath, "//a[contains(text(),'Search') and contains(@href,'SearchRecords')]");
    private UIElement systematicSettlement = new UIElement(UIType.Link, UILocatorType.Xpath, "//a[contains(text(),'Systematic Settlement') and contains(@href,'SystematicSettlement')]");
    private UIElement settlementSearch = new UIElement(UIType.Link, UILocatorType.Xpath, "//a[contains(text(),'Settlement Search') and contains(@href,'SearchSettlementRecords')]");
    private UIElement manageRole = new UIElement(UIType.Link, UILocatorType.Xpath, "//a[contains(text(),'Manage Role') and contains(@href,'ManageRole')]");
    private UIElement manageUserRole = new UIElement(UIType.Link, UILocatorType.Xpath, "//a[contains(text(),'Manage User Role') and contains(@href,'ManageUserRole')]");
    private UIElement manageModulePermission = new UIElement(UIType.Link, UILocatorType.Xpath, "//a[contains(text(),'Manage Module Permission') and contains(@href,'ModulePermission')]");

    private UIElement browseButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//input[@id='FileUpload' or @name='FileUpload']");

    private UIElement intentRadioButton = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "//label/input[@value='Intent']");
    private UIElement chargeRadioButton = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "//label/input[@value='Charge']");
    private UIElement intentLineItemRadioButton = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "//label/input[@value='IntentLineItem']");
    private UIElement newRadioButton = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "//label/input[@value='Create']");
    private UIElement updateRadioButton = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "//label/input[@value='Update']");

    private UIElement intentChargeUploadButton = new UIElement(UIType.Button, UILocatorType.ID, "IntentChargeUploadButton");
    private UIElement intentChargeUploadedFile = new UIElement(UIType.Label, UILocatorType.Xpath, "//span[@ng-class='msgClass' and @ng-bind='selectFileMsg']");

    //Intent Charge Resubmit
    private UIElement intentChargeResubmitLabel = new UIElement(UIType.Label, UILocatorType.Xpath, "//label[contains(text(),'Method Of Payment')]");
    private UIElement methodOfPayment = new UIElement(UIType.ListBox, UILocatorType.Xpath, "//select[@name='MOP']");
    private UIElement clientSelection = new UIElement(UIType.ListBox, UILocatorType.Xpath, "//select[@name='batchstatus']");
    private UIElement recordTypeSelection = new UIElement(UIType.ListBox, UILocatorType.Xpath, "//select[@name='source']");
    private UIElement selectStartDate = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//input[@name='startDate']");
    private UIElement selectEndDate = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//input[@name='endDate']");
    private UIElement searchOnSBPortal = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[@type='submit' and contains(text(),'Search')]");
    private UIElement resubmitTableHeader = new UIElement(UIType.Link, UILocatorType.Xpath, "//table//th/a[contains(text(),'Batch Number')]");
    private UIElement intentChargeResubmitTableAllRows = new UIElement(UIType.Link, UILocatorType.Xpath, "//table//th/a[contains(text(),'Batch Number')]/ancestor::table/tbody/tr");
    private UIElement intentChargeResubmitTableHeaderRowElements = new UIElement(UIType.Link, UILocatorType.Xpath, "//table//th/a[contains(text(),'Batch Number')]/ancestor::tr/th");
    private UIElement resubmitToDAX = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[@type='submit' and contains(text(),'Resubmit To Dax')]");
    private UIElement checkBoxTransactionTable = new UIElement(UIType.Link, UILocatorType.Xpath, "//table//th/a[contains(text(),'Batch Number')]/ancestor::table/tbody");
    private UIElement loadingSpinner = new UIElement(UIType.Link, UILocatorType.Xpath, "//div[@class='loader-body']/img");
    private UIElement fileUploadMessage = new UIElement(UIType.Label, UILocatorType.Xpath, "//span[@ng-bind='fileUploadMsg' and contains(text(),'File processed successfully,')]");

    //System Option for Refund Adjudication
    private UIElement selectType = new UIElement(UIType.ListBox, UILocatorType.Xpath, "//select[@name='Types']");
    private UIElement selectPaymentMethod = new UIElement(UIType.ListBox, UILocatorType.Xpath, "//select[@name='MOP' and @ng-model='MOP.selected']");
    private UIElement selectCategory = new UIElement(UIType.ListBox, UILocatorType.Xpath, "//select[@name='MOP' and @ng-model='Category.selected']");
    private UIElement searchButton = new UIElement(UIType.ListBox, UILocatorType.Xpath, ".//*[@id='ng-view']/div[3]/div/div/form/div/div/div/div[5]/a");
    private UIElement aggregateAnalysisBtn = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//td[contains(text(),'Aggregate Analysis')]/following-sibling::td[@class='ng-scope']//input[contains(@ng-change,'changeSystemOptionVal')]");
    private UIElement checkSettlementBtn = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//td[contains(text(),'Check Settlement')]/following-sibling::td[@class='ng-scope']//input[contains(@ng-change,'changeSystemOptionVal')]");
    private UIElement checkRefundBtn = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//td[contains(text(),'Check Refund')]/following-sibling::td[@class='ng-scope']//input[contains(@ng-change,'changeSystemOptionVal')]");
    private UIElement checkChargebackBtn = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//td[contains(text(),'Check ChargeBack')]/following-sibling::td[@class='ng-scope']//input[contains(@ng-change,'changeSystemOptionVal')]");
    private UIElement initiatedSettlementBtn = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//td[contains(text(),'Settlement - Initiated')]/following-sibling::td[@class='ng-scope']//input[contains(@ng-change,'changeSystemOptionVal')]");
    private UIElement inProgressSettlementBtn = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//td[contains(text(),'Settlement - In Process')]/following-sibling::td[@class='ng-scope']//input[contains(@ng-change,'changeSystemOptionVal')]");
    private UIElement initiatedRefundBtn = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//td[contains(text(),'Refund - Initiated')]/following-sibling::td[@class='ng-scope']//input[contains(@ng-change,'changeSystemOptionVal')]");
    private UIElement inProgressRefundBtn = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//td[contains(text(),'Refund - In Process')]/following-sibling::td[@class='ng-scope']//input[contains(@ng-change,'changeSystemOptionVal')]");
    private UIElement initiatedChargebackBtn = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//td[contains(text(),'Chargeback - Initiated')]/following-sibling::td[@class='ng-scope']//input[contains(@ng-change,'changeSystemOptionVal')]");
    private UIElement paginationNextPage = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='ng-view']/div[3]/div/div/form/div/div/div/div[6]/div[2]/ul/li[5]/a");
    //System Option for DAX Integration
    private UIElement daxIntegrationBtn = new UIElement(UIType.CheckBox, UILocatorType.CSS.Xpath, "//td[contains(text(),'Dax Integration Check')]/following-sibling::td[@class='ng-scope']//input[contains(@ng-change,'changeSystemOptionVal')]");

    // System Option for Systematic Settlement
    private UIElement systematicSettlementBtn = new UIElement(UIType.CheckBox, UILocatorType.CSS.Xpath, "//td[contains(text(),'Systematic Settlement')]/following-sibling::td[@class='ng-scope']//input[contains(@ng-change,'changeSystemOptionVal')]");

    private UIElement saveButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@id='SystemOption_update']/a");
    private UIElement successMsg = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='ng-view']/div[2]/div/span[2]");
    private UIElement selectedOptionsCol = new UIElement(UIType.ListBox, UILocatorType.Xpath, "//table//tr//td[6]/label/div");
    private UIElement systemOptionCol = new UIElement(UIType.ListBox, UILocatorType.Xpath, "//table//tr//td[4]");
    private UIElement noSearchResult = new UIElement(UIType.TextBox, UILocatorType.CSS, ".box-container>h4");
    private UIElement searchResult = new UIElement(UIType.TextBox, UILocatorType.Xpath, ".//*[@id='GridRows0']/td[3]");

    // Search Option
    private UIElement searchTextbox = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//div[@class='panel window']//input[@id='omniSearch']");
    private UIElement searchBtn = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@class='panel window']//button[@type='submit' and contains(text(),'Search')]");
    private UIElement intentReferenceLink = new UIElement(UIType.Link, UILocatorType.Xpath, "//div[@class='panel window']//tbody/tr/td[1]/a");
    private UIElement intentReferenceRecord = new UIElement(UIType.Link, UILocatorType.Xpath, "//div[@class='panel window']//tbody/tr[3]/td[4]");
    private UIElement intentPanel = new UIElement(UIType.Link, UILocatorType.Xpath, "//div[@class='panel window']//div[@class='panel-group']/div[1]//a");
    private UIElement chargePanel = new UIElement(UIType.Link, UILocatorType.Xpath, "//div[@class='panel window']//div[@class='panel-group']/div[2]//a");
    private UIElement settlementPanel = new UIElement(UIType.Link, UILocatorType.Xpath, "//div[@class='panel window']//div[@class='panel-group']/div[3]//a");
    private UIElement editButton = new UIElement(UIType.Button, UILocatorType.Xpath, " //div[@class='panel window']//*[@id='SearchRecords_update']");
    private UIElement editAmount = new UIElement(UIType.TextBox, UILocatorType.CSS, "//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]//div[contains(@class,'ui-grid-cell-contents-hidden')]");
    private UIElement amountField = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[9]");
    private UIElement customerRefField = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[11]");
    private UIElement paymentMethodField = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[8]");
    private UIElement editPaymentMethod = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[8]/div");
    private UIElement intentId = new UIElement(UIType.Link, UILocatorType.Xpath, "//div[@class='panel window'][last()]/div//div[@class='RecordSearchAccord panel ng-isolate-scope panel-default panel-open']//div[@id='intentGrid']/div/div/div[2]//div[@class='ui-grid-row ng-scope']/div/div[1]");

    private String xpathIntentChargeResubmitTableAllRows = "//table//th/a[contains(text(),'Batch Number')]/ancestor::table/tbody/tr";

    ////div[@class='panel window']//div[@class='ui-grid-row ng-scope']
    private UIElement loadingSpinner(String fileName) {
        return new UIElement(UIType.Link, UILocatorType.Xpath, "//span[contains(text(),'" + fileName + "')]");

    }


    public void checkFileUploaded(String fileName) {
        driver.waitForElementPresence(loadingSpinner(fileName));
    }

    public String getCaseNumFromReferencesString(String references) {
        return references.substring(references.indexOf("CaseNumber") + 11, references.indexOf("CaseNumber") + 23);
    }

    public void compareExcelDataWithDB(Map<String, String> DataMap) {

        System.out.println("Case num : " + DataMap.get("References"));
        System.out.println("Case num : " + getCaseNumFromReferencesString(DataMap.get("References")));
        String oldCaseNumber = getCaseNumFromReferencesString(DataMap.get("References"));
        DataMap.get("References").replaceAll(oldCaseNumber, caseNumber);
        String query = "Use BASICS Select * from IncomingData.Event_Intent_Stage where AdditionalInfo like '%" + caseNumber + "%'";

        ResultSet resultSet = executeQueryOfSB(query);
        //Compare client name
        try {
            while (resultSet.next()) {
                System.out.println("Give Client : " + DataMap.get("Client"));
                System.out.println("DB Client   : " + resultSet.getString("Client"));

                System.out.println("Given type: " + DataMap.get("Type"));
                System.out.println("DB type   : " + resultSet.getString("IntentType"));

                System.out.println("Give References  : " + referencesString);
                System.out.println("DB AdditionalInfo: " + resultSet.getString("AdditionalInfo"));

                System.out.println("Given Ref: " + referencesString);
                System.out.println("DB Items : " + resultSet.getString("Items"));

                System.out.println("Given Culture: " + DataMap.get("Culture"));
                System.out.println("DB Culture : " + resultSet.getString("Culture"));

                System.out.println("Given IntentReference: " + referencesString);
                System.out.println("DB IntentReference   : " + resultSet.getString("IntentReference"));

                System.out.println("Given Amount: " + DataMap.get("Amount"));
                System.out.println("DB Amount   : " + resultSet.getString("Amount"));

                System.out.println("Given MethodOfPayment: " + DataMap.get("MethodOfPayment"));
                System.out.println("DB MethodOfPayment   : " + resultSet.getString("MethodOfPayment"));

                System.out.println("Given DAXCompanyID: " + DataMap.get("DAXCompanyID"));
                System.out.println("DB DAXCompanyID   : " + resultSet.getString("DAXCompanyID"));

                System.out.println("Given LineOfBusiness: " + DataMap.get("LineOfBusiness"));
                System.out.println("DB LineOfBusiness   : " + resultSet.getString("LineOfBusiness"));


                DataMap.get("Client").equalsIgnoreCase(resultSet.getString("Client"));
                DataMap.get("Culture").equalsIgnoreCase(resultSet.getString("Culture"));
                DataMap.get("Type").equalsIgnoreCase(resultSet.getString("IntentType"));
                DataMap.get("IntentReference").equalsIgnoreCase(resultSet.getString("IntentReference"));
                DataMap.get("Amount").equalsIgnoreCase(resultSet.getString("Amount"));
                DataMap.get("Currency").equalsIgnoreCase(resultSet.getString("Currency"));
                DataMap.get("MethodOfPayment").equalsIgnoreCase(resultSet.getString("MethodOfPayment"));
                DataMap.get("DAXCompanyID").equalsIgnoreCase(resultSet.getString("DAXCompanyID"));
                DataMap.get("LineOfBusiness").equalsIgnoreCase(resultSet.getString("LineOfBusiness"));
                referencesString.contains(resultSet.getString("AdditionalInfo"));
                referencesString.contains(resultSet.getString("Items"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    public int getColNumberOfHeaderFromTable(String header, UIElement elementToFindNumber) {
        //Get header row of table
        int colNumber = 1;
        driver.waitForElementPresenceWithTimeOut(elementToFindNumber, ApplicationConfiguration.getWaitForElementTimeout());
        List<WebElement> webElement = driver.findElements(elementToFindNumber);
        for (WebElement element : webElement) {
            System.out.println("element.getText() : " + element.getText());
            if (element.getText().equalsIgnoreCase(header)) {
                return colNumber;
            }
            colNumber++;
        }
        return -1;
    }

    public void clickOnResubmitToDAX() {
        //driver.javaScriptClick(resubmitToDAX);
    }

    public void selectTransactionToSendToDAX(String batchStatusToSendToDAX) {
        int rowNumOfHeader = getColNumberOfHeaderFromTable("Batch Status", intentChargeResubmitTableHeaderRowElements);
        System.out.println("getColNumberOfHeaderFromTable : " + rowNumOfHeader);
        driver.waitForElementPresenceWithTimeOut(intentChargeResubmitTableAllRows, ApplicationConfiguration.getWaitForElementTimeout());
        List<WebElement> webElements = TestDriver.getWebDriver().findElements(By.xpath(xpathIntentChargeResubmitTableAllRows));
        //            try {
//
//                System.out.println("element.getSize()" + webElements.size());
//                System.out.println("element.findElemen : " + driver.findElements(checkBoxTransactionTable).get(0).findElement(By.xpath("//tr[" + i + 1 + "]/td[" + rowNumOfHeader + "]")).getText());
//                System.out.println("element.findElemen : " + driver.findElements(checkBoxTransactionTable).get(0).findElement(By.xpath("//tr[" + i + 1 + "]/td[" + 2 + "]")).getText());
//                System.out.println("element.findElemen : " + driver.findElements(checkBoxTransactionTable).get(0).findElement(By.xpath("//tr[" + i + 1 + "]/td[" + 3 + "]")).getText());
//                System.out.println("element.findElemen : " + driver.findElements(checkBoxTransactionTable).get(0).findElement(By.xpath("//tr[" + i + 1 + "]/td[" + 4 + "]")).getText());
//
//                if (driver.findElements(checkBoxTransactionTable).get(0).findElement(By.xpath("//tr[" + i + 1 + "]/td[" + rowNumOfHeader + "]")).getText().equalsIgnoreCase(batchStatusToSendToDAX)) {
////                new Actions(TestDriver.getWebDriver()).moveByOffset(element.findElement(By.xpath("//td[1]")).getRect().getX()+10,element.findElement(By.xpath("/td[1]")).getRect().getY()+10);
//                    //              new Actions(TestDriver.getWebDriver()).moveToElement(element.findElement(By.xpath("//td[1]")));
//                    driver.findElements(checkBoxTransactionTable).get(0).findElement(By.xpath("//tr[" + i + 1 + "]/td[1]")).click();
//                    //webElements.get(i).findElement(By.xpath("//td[1]")).click();
//                }
//            }catch (NoSuchElementException e){
//                System.out.println("In catch");
//                System.out.println(e);
//            }
        for (int i = 0; i < webElements.size(); i++) {
            try {

                System.out.println("Size" + webElements.size());
                System.out.println(TestDriver.getWebDriver().findElement(By.xpath(xpathIntentChargeResubmitTableAllRows + "[" + i + 1 + "]/td[" + 2 + "]")).getText());
                System.out.println(TestDriver.getWebDriver().findElement(By.xpath(xpathIntentChargeResubmitTableAllRows + "[" + i + 1 + "]/td[" + 3 + "]")).getText());
                System.out.println(TestDriver.getWebDriver().findElement(By.xpath(xpathIntentChargeResubmitTableAllRows + "[" + i + 1 + "]/td[" + 4 + "]")).getText());
                System.out.println(TestDriver.getWebDriver().findElement(By.xpath(xpathIntentChargeResubmitTableAllRows + "[" + i + 1 + "]/td[" + 6 + "]")).getText());

                WebElement element = TestDriver.getWebDriver().findElement(By.xpath(xpathIntentChargeResubmitTableAllRows + "[" + i + 1 + "]/td[" + rowNumOfHeader + "]"));

                if (element.getText().equalsIgnoreCase(batchStatusToSendToDAX)) {
                    TestDriver.getWebDriver().findElement(By.xpath(xpathIntentChargeResubmitTableAllRows + "[" + i + 1 + "]/td[1]")).click();
                }
            } catch (NoSuchElementException e) {
                System.out.println(e);
            }
        }
    }

    //Wait for spinner to disappears
    public void waitForLoadingSpinner() {
        driver.waitForAllElementsToDisappear(ApplicationConfiguration.getWaitForElementTimeout(), loadingSpinner);
    }

    public void clickOnSearchonSBPortal() {
        driver.javaScriptClick(searchOnSBPortal);
    }

    public void verifyResubmitTableisDisplayed() {
        driver.waitForElementPresence(resubmitTableHeader);
    }

    public void enterStartDate(String date) {
        if (date.toLowerCase().equals("today"))
            driver.type(selectStartDate, new SimpleDateFormat("MM/dd/yyyy").format(new Date()).toString());
        else
            driver.type(selectStartDate, date);
    }

    public void enterEndDate(String date) {
        if (date.toLowerCase().equals("today"))
            driver.type(selectEndDate, new SimpleDateFormat("MM/dd/yyyy").format(new Date()).toString());
        else
            driver.type(selectEndDate, date);
    }


    public void verifyIntentChargeResubmitPageIsDisplayed() {
        driver.waitForElementPresence(intentChargeResubmitLabel);
    }

    public void selectMethodOfPayment(String paymentMethod) {
        driver.select(methodOfPayment, paymentMethod);
    }

    public void selectClient(String client) {
        driver.select(clientSelection, client);
    }

    public void selectRecordType(String recordType) {
        driver.select(recordTypeSelection, recordType);
    }

    public void selectStartDate(String startDate) {
        driver.type(selectStartDate, "05/09/2017");
    }


    public void copyContaintsToClipBoard(String filePath) {
        StringSelection stringSelection = new StringSelection(filePath);
        Clipboard clpbrd = Toolkit.getDefaultToolkit().getSystemClipboard();
        clpbrd.setContents(stringSelection, null);
    }

    public void pasteClipBoardContaintsByKeyPress() {
        try {
            robot = new Robot();
            CommonUtilities.waitTime(5);
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            //CommonUtilities.waitTime(01);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyRelease(KeyEvent.VK_V);
            //CommonUtilities.waitTime(1);
            robot.keyPress(KeyEvent.VK_ENTER);
            //CommonUtilities.waitTime(1);
            robot.keyRelease(KeyEvent.VK_ENTER);
            CommonUtilities.waitTime(2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void pickTheFileFromLocation(String filePath) {

        driver.type(browseButton, filePath);
        File f = new File(filePath);
        String fullPath = f.getAbsolutePath();
        System.out.println("FullPath" + fullPath);
//        copyContaintsToClipBoard(filePath);
//        pasteClipBoardContaintsByKeyPress();

    }

    public void navigateToSBPortal() {

        driver.navigate("http://lqasedcobui001v:8080/SubBillingPortal/index.htm#/home");
        waitForPageLoaded();
    }

    public void selectBasicsAmendmentFromHomePage(String basicsAmendment) {
        waitForPageLoaded();
        waitForLoadingSpinner();
        if (basicsAmendment.toLowerCase().contains("upload")) {
            driver.waitAndClick(intentChargeUpload);
        } else if (basicsAmendment.toLowerCase().contains("resubmit")) {
            driver.waitAndClick(intentChargeResubmit);
        } else if (basicsAmendment.toLowerCase().contains("system option")) {
            driver.waitAndClick(systemOption);
        } else if (basicsAmendment.toLowerCase().equals("search")) {
            driver.waitAndClick(search);
        } else if (basicsAmendment.toLowerCase().equals("settlement")) {
            driver.waitAndClick(systematicSettlement);
        } else if (basicsAmendment.toLowerCase().contains("settlement search")) {
            driver.waitAndClick(settlementSearch);
        } else if (basicsAmendment.toLowerCase().contains("manage role")) {
            driver.waitAndClick(manageRole);
        } else if (basicsAmendment.toLowerCase().contains("manage user role")) {
            driver.waitAndClick(manageUserRole);
        } else if (basicsAmendment.toLowerCase().contains("manage module permission")) {
            driver.waitAndClick(manageModulePermission);
        }
        waitForPageLoaded();
        waitForLoadingSpinner();
    }

    public void browseButtonIsVisible() {
        driver.checkObjectExists(browseButton, ApplicationConfiguration.getWaitForElementTimeout());
    }

    public void clickOnBrowseButton() {
        //driver.type(browseButton, "C:\\Intent.xlsx");
        driver.doubleClick(browseButton);
    }

    public void selectFileType(String fileType) {
        waitForPageLoaded();
        if (fileType.toLowerCase().contains("intent")) {
            driver.waitAndClick(intentRadioButton);
        } else if (fileType.toLowerCase().contains("charge")) {
            driver.waitAndClick(chargeRadioButton);
        } else if (fileType.toLowerCase().contains("intent line item")) {
            driver.waitAndClick(intentLineItemRadioButton);
        }
    }

    public void selectOperationType(String operationType) {

        if (operationType.toLowerCase().contains("new")) {
            driver.waitAndClick(newRadioButton);
        } else if (operationType.toLowerCase().contains("update")) {
            driver.waitAndClick(updateRadioButton);
        }
    }

    public void clickOnIntentChargeUploadButton() {
        driver.waitAndClick(intentChargeUploadButton);
        driver.waitForElementPresenceWithTimeOut(fileUploadMessage, ApplicationConfiguration.getWaitForElementTimeout());
    }


    public ResultSet executeQueryOfSB(String query) {
        try {
            ResultSet resultSet = databaseUtils.getResultSet("Use BASICS Select * from IncomingData.Event_Intent_Stage where AdditionalInfo like '%999028799435%'");
            return resultSet;

//            while (resultSet.next()) {
//                System.out.println(resultSet.getString("ID"));
//                System.out.println(resultSet.getString("SourceSystem"));
//                System.out.println(resultSet.getString("IntentType"));
//            }
//
//            ResultSetMetaData resultSetMetaData= resultSet.getMetaData();
//
////            while (resultSet.next()) {
////                System.out.println("!-"+resultSet);
////
////            }
//
//            while (resultSet.next()) {
//                for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
//                    if (i > 1) System.out.print(",  ");
//                    String columnValue = resultSet.getString(i);
//                    System.out.print(columnValue);
//                }
//                System.out.println("");
//            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void updateSheetforSB(String filePath, Map<String, String> dataTable) {
        setCellDataNew(filePath, dataTable);
    }


    public FileInputStream fis = null;
    public FileOutputStream fileOut = null;
    private XSSFWorkbook workbook = null;
    private XSSFSheet sheet = null;
    private XSSFRow row = null;
    private XSSFCell cell = null;
    private int rowNum = 0;
    private String path = null;
    String sheetName = null;

    public boolean setCellDataNew(String path, Map<String, String> dataTable) {
        try {
            this.path = path;
            fis = new FileInputStream(path);

            workbook = new XSSFWorkbook(fis);

            //Only first time, need to create first row.
            if (ApplicationConfiguration.overAllVariable == 0)
                createExcelFirstRow(workbook, dataTable);

            int sizeList1 = dataTable.size();

            System.out.println("sizeList" + sizeList1);
            // for (int i = 0; i < sizeList1; i++) {

            // System.out.println("In loop " + i);
            // {
            rowNum = ++ApplicationConfiguration.overAllVariable + 1;
            if (rowNum <= 0)
                return false;

            int colNum = -1;

            sheet = workbook.getSheetAt(0);
            Row rowZero = sheet.getRow(0);
            System.out.println("row.getLastCellNum(): " + rowZero.getLastCellNum());
            //Used for increasing the excel sheet row value, to enter data in new row.
            for (int j = 0; j < rowZero.getLastCellNum(); j++) {
                //System.out.println(row.getCell(i).getStringCellValue().trim());

                for (Map.Entry<String, String> entry : dataTable.entrySet()) {
                    String temp1 = entry.getKey();
                    String temp2 = entry.getValue();

                    if (rowZero.getCell(j).getStringCellValue().trim().equals(entry.getKey())) {
                        colNum = j;
                        //sheet.autoSizeColumn(colNum);
                        row = sheet.getRow(rowNum - 1);
                        if (row == null)
                            row = sheet.createRow(rowNum - 1);
                        cell = row.getCell(colNum);
                        if (cell == null)
                            cell = row.createCell(colNum);

                        if (entry.getKey().equals("IntentReference")) {
                            System.out.println("Value to set : " + intentReference);
                            cell.setCellValue(intentReference);
                        } else if (entry.getKey().equals("References")) {
                            String oldCaseNumber = getCaseNumFromReferencesString(entry.getValue());
                            referencesString = entry.getValue().replaceAll(oldCaseNumber, caseNumber);
                            System.out.println("Value to set : " + referencesString);
                            cell.setCellValue(referencesString);
                        } else {
                            System.out.println("Value to set : " + entry.getValue());
                            cell.setCellValue(entry.getValue());
                        }
                        fileOut = new FileOutputStream(path);

                        workbook.write(fileOut);
                        break;
                    }
                }
            }
            fileOut.close();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public void createExcelFirstRow(Workbook workbook, Map<String, String> dataTable) {
        try {
            Sheet sheet = workbook.getSheetAt(0);
            System.out.println("sheet.getLastRowNum() : " + sheet.getLastRowNum());
            for (int j = 0; j <= sheet.getLastRowNum(); j++) {
                if (sheet.getRow(j) != null)
                    sheet.removeRow(sheet.getRow(j));
            }
            Row rowZero = sheet.getRow(0);
            if (rowZero == null)
                rowZero = sheet.createRow(0);
            int i = 0;
            for (Map.Entry<String, String> entry : dataTable.entrySet()) {
                String temp1 = entry.getKey();
                String temp2 = entry.getValue();

                if (rowZero.getCell(i) == null)
                    rowZero.createCell(i);

                rowZero.getCell(i).setCellValue(entry.getKey());
                fileOut = new FileOutputStream(path);

                workbook.write(fileOut);
                i++;
            }
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

    public void systemOption_selectType(String type) {
        if (driver.waitForElementPresenceWithTimeOut(selectType, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(selectType, type);
        } else {
            Assert.assertTrue("Type is not found on System Option page.", false);
        }
    }

    public void systemOption_selectClient(String client) {
        sbClient = client;
        if (driver.waitForElementPresenceWithTimeOut(clientSelection, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(clientSelection, sbClient);
        } else {
            Assert.assertTrue("Client is not found on System Option page.", false);
        }
    }

    public void systemOption_selectMOP(String mop) {
        if (driver.waitForElementPresenceWithTimeOut(selectPaymentMethod, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(selectPaymentMethod, mop);
        } else {
            Assert.assertTrue("Payment Method is not found on System Option page.", false);
        }
    }

    public void systemOption_selectCategory(String category) {
        if (driver.waitForElementPresenceWithTimeOut(selectCategory, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(selectCategory, category);
        } else {
            Assert.assertTrue("\nCategory is not found on System Option page.", false);
        }
    }

    public void systemOption_search() throws Exception {
        if (driver.waitForElementPresenceWithTimeOut(searchButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(searchButton);
        } else {
            Assert.assertTrue("Search Button is not found on System Option page.", false);
        }
    }

    public void clickOnSave() throws Exception {
        if (driver.waitForElementPresenceWithTimeOut(saveButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(saveButton);
            CommonUtilities.waitTime(5);
        } else {
            System.out.println("\nNo Search Results found for given input.");
            assertEquals("Verifying Search result", "No Search Results found for given input.", driver.getText(noSearchResult).trim());
        }
    }

    // Set Aggregate Analysis option
    public void setAggregateAnalysis(String selectedOption) throws Exception {
        CommonUtilities.waitTime(5);
        if (driver.waitForElementPresenceWithTimeOut(aggregateAnalysisBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (!driver.isSelected(aggregateAnalysisBtn))
                    driver.javaScriptClick(aggregateAnalysisBtn);
                else
                    System.out.println("Option is already ON");
            } else if (selectedOption.equalsIgnoreCase("OFF")) {
                if (!driver.isSelected(aggregateAnalysisBtn))
                    System.out.println("Option is already OFF");
                else
                    driver.javaScriptClick(aggregateAnalysisBtn);
            }
        } else {
            isAggregateOptionPresent = false;
            System.out.println("Aggregate Analysis system option in not applicable for this client.");
        }
    }

    // Set System Option for Check Settlement and its sub options
    public void setCheckSettlement(String selectedOption, String settlementInitiated, String settlementInProcess) {
        if (driver.waitForElementPresenceWithTimeOut(checkSettlementBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (!driver.isSelected(checkSettlementBtn))
                    driver.javaScriptClick(checkSettlementBtn);
                else
                    System.out.println("Check Settlement is already ON");
                // Set Initiated Settlemnt option
                if (driver.waitForElementPresenceWithTimeOut(initiatedSettlementBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    String initiated[] = settlementInitiated.split(":");
                    if (initiated[1].equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(initiatedSettlementBtn))
                            driver.javaScriptClick(initiatedSettlementBtn);
                        else
                            System.out.println("Initiated Settlement is already ON");
                    } else if (initiated[1].equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(initiatedSettlementBtn))
                            System.out.println("Initiated Settlement is already OFF");
                        else
                            driver.javaScriptClick(initiatedSettlementBtn);
                    }
                } else {
                    isInitiatedSettlementOptionPresent = false;
                    System.out.println("\nInitiated Settlemt is not set for this client.");
                }
                // Set In Process Settlemnt option
                if (driver.waitForElementPresenceWithTimeOut(inProgressSettlementBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    String inProcess[] = settlementInProcess.split(":");
                    if (inProcess[1].equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(inProgressSettlementBtn))
                            driver.javaScriptClick(inProgressSettlementBtn);
                        else
                            System.out.println("In Process Settlement is already ON");
                    } else if (inProcess[1].equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(inProgressSettlementBtn))
                            System.out.println("In Process Settlement is already OFF");
                        else
                            driver.javaScriptClick(inProgressSettlementBtn);
                    }
                } else {
                    isInProcessSettlementOptionPresent = false;
                    System.out.println("\nIn Process Settlement is not set for this client.");
                }
            } else if (selectedOption.equalsIgnoreCase("OFF")) {
                if (!driver.isSelected(checkSettlementBtn))
                    System.out.println("Check Settlement is already OFF");
                else
                    driver.javaScriptClick(checkSettlementBtn);
            }
        } else {
            isSettlementOptionPresent = false;
            System.out.println("Check Settlement option is not applicable for this client");
        }
    }

    // Set System Option for Check Refund and its sub options
    public void setCheckRefund(String selectedOption, String refundInitiated, String refundInProcess) {
        if (driver.waitForElementPresenceWithTimeOut(checkRefundBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (!driver.isSelected(checkRefundBtn))
                    driver.javaScriptClick(checkRefundBtn);
                else
                    System.out.println("Check Refund is already ON");
                // Set Initiated Refund option
                if (driver.waitForElementPresenceWithTimeOut(initiatedRefundBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    String initiated[] = refundInitiated.split(":");
                    if (initiated[1].equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(initiatedRefundBtn))
                            driver.javaScriptClick(initiatedRefundBtn);
                        else
                            System.out.println("Initiated Refund is already ON");
                    } else if (initiated[1].equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(initiatedRefundBtn))
                            System.out.println("Initiated Refund is already OFF");
                        else
                            driver.javaScriptClick(initiatedRefundBtn);
                    }
                } else {
                    isInitiatedRefundOptionPresent = false;
                    System.out.println("\nInitiated Refund is not set for this client.");
                }
                // Set In Process Refund option
                if (driver.waitForElementPresenceWithTimeOut(inProgressRefundBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    String inProcess[] = refundInProcess.split(":");
                    if (inProcess[1].equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(inProgressRefundBtn))
                            driver.javaScriptClick(inProgressRefundBtn);
                        else
                            System.out.println("In Process Refund is already ON");
                    } else if (inProcess[1].equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(inProgressRefundBtn))
                            System.out.println("In Process Refund is already OFF");
                        else
                            driver.javaScriptClick(inProgressRefundBtn);
                    }
                } else {
                    isInProcessRefundOptionPresent = false;
                    System.out.println("\nIn Process Settlemt is not set for this client.");
                }
            } else if (selectedOption.equalsIgnoreCase("OFF")) {
                if (!driver.isSelected(checkRefundBtn))
                    System.out.println("Check Refund is already OFF");
                else
                    driver.javaScriptClick(checkRefundBtn);
            }
        } else {
            isCheckRefundOptionPresent = false;
            System.out.println("Check Refund option is not applicable for this client");
        }
    }

    // Set System Option for Check Chargeback and its sub option
    public void setCheckChargeBack(String selectedOption, String chrgBckInitiated) {
        if (driver.waitForElementPresenceWithTimeOut(checkChargebackBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (!driver.isSelected(checkChargebackBtn))
                    driver.javaScriptClick(checkChargebackBtn);
                else
                    System.out.println("Check Refund is already ON");
                // Set Initiated Refund option
                if (driver.waitForElementPresenceWithTimeOut(paginationNextPage, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.javaScriptClick(paginationNextPage);
                }
                if (driver.waitForElementPresenceWithTimeOut(initiatedChargebackBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    String initiated[] = chrgBckInitiated.split(":");
                    if (initiated[1].equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(initiatedChargebackBtn))
                            driver.javaScriptClick(initiatedChargebackBtn);
                        else
                            System.out.println("Initiated Refund is already ON");
                    } else if (initiated[1].equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(initiatedChargebackBtn))
                            System.out.println("Initiated Refund is already OFF");
                        else
                            driver.javaScriptClick(initiatedChargebackBtn);
                    }
                } else {
                    isInitaitedChargebackOptionPresent = false;
                    System.out.println("\n Chargeback Initiated is not set for this client.");
                }
            } else if (selectedOption.equalsIgnoreCase("OFF")) {
                if (!driver.isSelected(checkChargebackBtn))
                    System.out.println("Check ChargeBack is already OFF");
                else
                    driver.javaScriptClick(checkChargebackBtn);
            }
        } else {
            isChargebackOptionPresent = false;
            System.out.println("Check Refund option is not applicable for this client");
        }
    }

    // Method is used to verify APS Integration for clients having Check functionality.
    public void searchResult() throws Exception {
        CommonUtilities.waitTime(5);
        if (sbClient.equalsIgnoreCase("Freedom Mobile") || sbClient.equalsIgnoreCase("Telcel") || sbClient.equalsIgnoreCase("Rogers") || sbClient.equalsIgnoreCase("Fido") || sbClient.equalsIgnoreCase("Claro Peru") || sbClient.equalsIgnoreCase("Claro") || sbClient.equalsIgnoreCase("Claro Chile")) {
            assertEquals("Verifying Search result", "No Search Results found for given input.", driver.getText(noSearchResult).trim());
            System.out.println(ApplicationConfiguration.getClient() + " : " + driver.getText(noSearchResult).trim());
            isAPSIntegrationPresent = false;
        } else {
            System.out.println(driver.getText(searchResult).trim() + " system option is present for " + ApplicationConfiguration.getClient());
            assertEquals("APS Integration Configuration is present for " + sbClient, "APS Integration", driver.getText(searchResult).trim());
        }
    }

    // Method to print No Search Search Result message
    public void printResult() throws Exception {
    }

    public void setSystemOptionForDAXIntegration(String selectedOption) throws Exception {
        CommonUtilities.waitTime(3);
        if (driver.waitForElementPresenceWithTimeOut(daxIntegrationBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (!driver.isSelected(daxIntegrationBtn)) {
                    driver.javaScriptClick(daxIntegrationBtn);
                    clickOnSave();
                } else
                    System.out.println("Option is already ON");
            } else if (selectedOption.equalsIgnoreCase("OFF")) {
                if (!driver.isSelected(daxIntegrationBtn))
                    System.out.println("Option is already OFF");
                else {
                    driver.javaScriptClick(daxIntegrationBtn);
                    clickOnSave();
                }
            }

        } else {
            isDAXOptionPresent = false;
            assertEquals("Verifying Search result", "No Search Results found for given input.", driver.getText(noSearchResult).trim());
        }
    }

    public void setSystematicSettlement(String selectedOption) throws Exception {
        CommonUtilities.waitTime(3);
        if (driver.waitForElementPresenceWithTimeOut(systematicSettlementBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (selectedOption.equalsIgnoreCase("ON")) {
                if (!driver.isSelected(systematicSettlementBtn)) {
                    driver.javaScriptClick(systematicSettlementBtn);
                    clickOnSave();
                } else
                    System.out.println("Option is already ON");
            } else if (selectedOption.equalsIgnoreCase("OFF")) {
                if (!driver.isSelected(systematicSettlementBtn))
                    System.out.println("Option is already OFF");
                else {
                    driver.javaScriptClick(systematicSettlementBtn);
                    clickOnSave();
                }
            }
        } else {
            isSystematicSettlemntPresent = false;
            assertEquals("Verifying Search result", "No Search Results found for given input.", driver.getText(noSearchResult).trim());
        }
    }

    public void selectGivenSystemOption(String systemOption, String selectedOption) {
        CommonUtilities.waitTime(5);
        switch (systemOption) {
            case "Aggregate Analysis":
                // CommonUtilities.waitTime(5);
                if (selectedOption.equalsIgnoreCase("NA"))
                    System.out.println("\n" + systemOption + " is not applicable for this client.");
                else if (driver.waitForElementPresenceWithTimeOut(aggregateAnalysisBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    if (selectedOption.equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(aggregateAnalysisBtn))
                            driver.javaScriptClick(aggregateAnalysisBtn);
                        else
                            System.out.println("\n Option is already ON");
                    } else if (selectedOption.equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(aggregateAnalysisBtn))
                            System.out.println("\n Option is already OFF");
                        else
                            driver.javaScriptClick(aggregateAnalysisBtn);
                    }
                } else {
                    isAggregateOptionPresent = false;
                    System.out.println("\nAggregate Analysis system option in not found for this client.");
                }
                break;
            case "Check Settlement":
                //  CommonUtilities.waitTime(5);
                if (selectedOption.equalsIgnoreCase("NA"))
                    System.out.println("\n" + systemOption + " is not applicable for this client.");
                else if (driver.waitForElementPresenceWithTimeOut(checkSettlementBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    if (selectedOption.equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(checkSettlementBtn))
                            driver.javaScriptClick(checkSettlementBtn);
                        else
                            System.out.println("\n Option is already ON");
                    } else if (selectedOption.equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(checkSettlementBtn))
                            System.out.println("\n Option is already OFF");
                        else
                            driver.javaScriptClick(checkSettlementBtn);
                    }
                } else {
                    isSettlementOptionPresent = false;
                    System.out.println("\nCheck Settlement system option in not found for this client.");
                }
                break;
            case "Settlement Initiated":
                // CommonUtilities.waitTime(5);
                if (selectedOption.equalsIgnoreCase("NA")) {
                    System.out.println("\n" + systemOption + " is not present as Check Settlement is not checked.");
                } else if (driver.waitForElementPresenceWithTimeOut(initiatedSettlementBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    if (selectedOption.equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(initiatedSettlementBtn))
                            driver.javaScriptClick(initiatedSettlementBtn);
                        else
                            System.out.println("\n Option is already ON");
                    } else if (selectedOption.equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(initiatedSettlementBtn))
                            System.out.println("\n Option is already OFF");
                        else
                            driver.javaScriptClick(initiatedSettlementBtn);
                    }
                } else {
                    isInitiatedSettlementOptionPresent = false;
                    System.out.println("\nSettlement Initiated system option in not found for this client.");
                }
                break;
            case "Settlement InProcess":
                // CommonUtilities.waitTime(5);
                if (selectedOption.equalsIgnoreCase("NA")) {
                    System.out.println("\n" + systemOption + " is not present as Check Settlement is not checked");
                } else if (driver.waitForElementPresenceWithTimeOut(inProgressSettlementBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    if (selectedOption.equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(inProgressSettlementBtn))
                            driver.javaScriptClick(inProgressSettlementBtn);
                        else
                            System.out.println("\n Option is already ON");
                    } else if (selectedOption.equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(inProgressSettlementBtn))
                            System.out.println("\n Option is already OFF");
                        else
                            driver.javaScriptClick(inProgressSettlementBtn);
                    }
                } else {
                    isInProcessSettlementOptionPresent = false;
                    System.out.println("\nSettlement In Process system option in not found for this client.");
                }
                break;
            case "Check Refund":
                // CommonUtilities.waitTime(5);
                if (selectedOption.equalsIgnoreCase("NA")) {
                    System.out.println("\n" + systemOption + " is not applicable for this client.");
                } else if (driver.waitForElementPresenceWithTimeOut(checkRefundBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    if (selectedOption.equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(checkRefundBtn))
                            driver.javaScriptClick(checkRefundBtn);
                        else
                            System.out.println("\n Option is already ON");
                    } else if (selectedOption.equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(checkRefundBtn))
                            System.out.println("\n Option is already OFF");
                        else
                            driver.javaScriptClick(checkRefundBtn);
                    }
                } else {
                    isCheckRefundOptionPresent = false;
                    System.out.println("\nCheck Refund system option in not found for this client.");
                }
                break;
            case "Refund Initiated":
                // CommonUtilities.waitTime(5);
                if (selectedOption.equalsIgnoreCase("NA")) {
                    System.out.println("\n" + systemOption + " is not present as Check Refund option is not checked.");
                } else if (driver.waitForElementPresenceWithTimeOut(initiatedRefundBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    if (selectedOption.equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(initiatedRefundBtn))
                            driver.javaScriptClick(initiatedRefundBtn);
                        else
                            System.out.println("\n Option is already ON");
                    } else if (selectedOption.equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(initiatedRefundBtn))
                            System.out.println("\n Option is already OFF");
                        else
                            driver.javaScriptClick(initiatedRefundBtn);
                    }
                } else {
                    isInitiatedRefundOptionPresent = false;
                    System.out.println("\nRefund Initiated system option in not found for this client.");
                }
                break;
            case "Refund InProcess":
                //CommonUtilities.waitTime(5);
                if (selectedOption.equalsIgnoreCase("NA")) {
                    System.out.println("\n" + systemOption + " is not present as Check Refund option is not checked.");
                } else if (driver.waitForElementPresenceWithTimeOut(inProgressRefundBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    if (selectedOption.equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(inProgressRefundBtn))
                            driver.javaScriptClick(inProgressRefundBtn);
                        else
                            System.out.println("\n Option is already ON");
                    } else if (selectedOption.equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(inProgressRefundBtn))
                            System.out.println("\n Option is already OFF");
                        else
                            driver.javaScriptClick(inProgressRefundBtn);
                    }
                } else {
                    isInProcessRefundOptionPresent = false;
                    System.out.println("\nRefund In Process system option in not found for this client.");
                }
                break;
            case "Check Chargeback":
                // CommonUtilities.waitTime(5);
                if (selectedOption.equalsIgnoreCase("NA")) {
                    System.out.println("\n" + systemOption + " is not applicable for this client.");
                } else if (driver.waitForElementPresenceWithTimeOut(checkChargebackBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    if (selectedOption.equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(checkChargebackBtn))
                            driver.javaScriptClick(checkChargebackBtn);
                        else
                            System.out.println("\n Option is already ON");
                    } else if (selectedOption.equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(checkChargebackBtn))
                            System.out.println("\n Option is already OFF");
                        else
                            driver.javaScriptClick(checkChargebackBtn);
                    }
                } else if (driver.waitForElementPresenceWithTimeOut(paginationNextPage, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.javaScriptClick(paginationNextPage);
                    if (driver.waitForElementPresenceWithTimeOut(checkChargebackBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                        if (selectedOption.equalsIgnoreCase("ON")) {
                            if (!driver.isSelected(checkChargebackBtn))
                                driver.javaScriptClick(checkChargebackBtn);
                            else
                                System.out.println("\n Option is already ON");
                        } else if (selectedOption.equalsIgnoreCase("OFF")) {
                            if (!driver.isSelected(checkChargebackBtn))
                                System.out.println("\n Option is already OFF");
                            else
                                driver.javaScriptClick(checkChargebackBtn);
                        }
                    }
                } else {
                    isChargebackOptionPresent = false;
                    System.out.println("\nCheck ChargeBack system option in not found for this client.");
                }
                break;
            case "Chargeback Initiated":
                //CommonUtilities.waitTime(5);
                if (selectedOption.equalsIgnoreCase("NA")) {
                    System.out.println("\n" + systemOption + " is not present as Check ChargeBack is not checked");
                } else if (driver.waitForElementPresenceWithTimeOut(initiatedChargebackBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    if (selectedOption.equalsIgnoreCase("ON")) {
                        if (!driver.isSelected(initiatedChargebackBtn))
                            driver.javaScriptClick(initiatedChargebackBtn);
                        else
                            System.out.println("\n Option is already ON");
                    } else if (selectedOption.equalsIgnoreCase("OFF")) {
                        if (!driver.isSelected(initiatedChargebackBtn))
                            System.out.println("\n Option is already OFF");
                        else
                            driver.javaScriptClick(initiatedChargebackBtn);
                    }
                } else if (driver.waitForElementPresenceWithTimeOut(paginationNextPage, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.javaScriptClick(paginationNextPage);
                    if (driver.waitForElementPresenceWithTimeOut(initiatedChargebackBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
                        if (selectedOption.equalsIgnoreCase("ON")) {
                            if (!driver.isSelected(initiatedChargebackBtn))
                                driver.javaScriptClick(initiatedChargebackBtn);
                            else
                                System.out.println("\n Option is already ON");
                        } else if (selectedOption.equalsIgnoreCase("OFF")) {
                            if (!driver.isSelected(initiatedChargebackBtn))
                                System.out.println("\n Option is already OFF");
                            else
                                driver.javaScriptClick(initiatedChargebackBtn);
                        }
                    }
                } else {
                    isInitaitedChargebackOptionPresent = false;
                    System.out.println("\nChargeback Initiated system option in not found for this client.");
                }
                break;
        }
    }

    public void verifyRecordIsFoundORNotForGivenClient(String mop, String client) throws Exception {
        CommonUtilities.waitTime(5);
        if (!driver.waitForElementPresenceWithTimeOut(searchResult, ApplicationConfiguration.getWaitForElementTimeout())) {
            assertEquals("Verifying Search result", "No Search Results found for given input.", driver.getText(noSearchResult).trim());
            System.out.println("No Search Result found for client " + client + " with MOP as " + mop);
            isRecordPresent = false;
        } else {
            System.out.println("Select System Option");
        }
    }

    public void getPortalIntentID() throws Exception{
        if (driver.waitForElementPresenceWithTimeOut(intentId, ApplicationConfiguration.getWaitForElementTimeout())) {
            intentIDOnPortal = driver.getText(intentId);
        } else {
            Assert.assertTrue("Intent Id is not found on Portal page.", false);
        }
    }

    public void searchCaseNumber() throws Exception {
        CommonUtilities.waitTime(5);
        if (driver.waitForElementPresenceWithTimeOut(searchTextbox, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(searchTextbox, CaptureIncidentPage.claimId);  //CaptureIncidentPage.claimId
        } else
            Assert.assertTrue("Search textbox not found on Search Page.", false);
        driver.javaScriptClick(searchBtn);
        CommonUtilities.waitTime(30);
        if (!driver.elementExists(intentReferenceRecord)) {
            int i = 0;
            do {
                driver.javaScriptClick(searchBtn);
                waitForPageLoaded();
                CommonUtilities.waitTime(20);
                if (driver.waitForElementPresenceWithTimeOut(intentReferenceRecord, ApplicationConfiguration.getWaitForElementTimeout())) {
                    if (driver.getText(intentReferenceRecord).equalsIgnoreCase("ServiceRequest")) ;
                    System.out.println(driver.getText(intentReferenceRecord) + " record is present on Portal");
                    break;
                } else
                    i++;
            } while (i <= 10);
            if (i == 11) {
                Assert.assertTrue("Intent Reference for Service Request not displayed on Portal", false);
            }
        } else
            System.out.println("Intent Reference for Service Request displayed on Portal");
    }

    public void selectIntentRef() throws Exception {
        if (driver.waitForElementPresenceWithTimeOut(intentReferenceLink, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(intentReferenceLink);
            CommonUtilities.waitTime(10);
        } else
            Assert.assertTrue("No Search Results found for given input.", false);
    }

    public void selectGivenPanel(String panel) throws Exception {
        CommonUtilities.waitTime(2);
        switch (panel) {
            case "Intent Detail":
                if (driver.waitForElementPresenceWithTimeOut(intentPanel, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.click(intentPanel);
                } else {
                    Assert.assertTrue("Intent Detail panel is not found.", false);
                }
                break;
            case "Charge Detail":
                if (driver.waitForElementPresenceWithTimeOut(chargePanel, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.javaScriptClick(chargePanel);
                } else
                    Assert.assertTrue("Charge Detail panel is not found.", false);
                break;
            case "Settlement Detail":
                if (driver.waitForElementPresenceWithTimeOut(settlementPanel, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.javaScriptClick(settlementPanel);
                } else
                    Assert.assertTrue("Charge Detail panel is not found.", false);
                break;
        }
    }

    public void clickOnEditBtn() throws Exception {
        CommonUtilities.waitTime(5);
        if (driver.waitForElementPresenceWithTimeOut(editButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(editButton);
        } else
            Assert.assertTrue("Edit button not found on Record Detail page", false);
    }

    public void updateGivenData(String columnValue, String amount) throws Exception {
        CommonUtilities.waitTime(5);
        this.amount=amount;
        if (columnValue.equalsIgnoreCase("Amount")){
            if (driver.waitForElementPresenceWithTimeOut(amountField, ApplicationConfiguration.getWaitForElementTimeout())) {
                System.out.println("\nAmount display on Portal: " + driver.getText(amountField));
                driver.click(customerRefField);
                driver.doubleClick(amountField);
                CommonUtilities.waitTime(2);
                driver.actionType(amountField,amount);
                CommonUtilities.waitTime(2);
                driver.acceptAlert();
            } else
                Assert.assertTrue("\nAmount field is not editable", false);
        } else if (columnValue.equalsIgnoreCase("CRE")) {
            if (driver.waitForElementPresenceWithTimeOut(paymentMethodField, ApplicationConfiguration.getWaitForElementTimeout())) {
                System.out.println("Payment Method on Portal: " + driver.getText(paymentMethodField));
                driver.doubleClick(paymentMethodField);
                driver.type(editPaymentMethod, "BTA");

            } else
                Assert.assertTrue("MOP field is not editable", false);
        }
    }
}

