package com.asurion.pages;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.horizon.generic.DataBaseHandler;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;

public class ActionPage extends BasePage {
    private UIElement actionsButton = new UIElement(UIType.Button, UILocatorType.Link, "Actions");
    // private UIElement processRefund = new UIElement(UIType.Button, UILocatorType.ID, "ASR-CCO-Work-IT-Incident_CreateRefundRequest");
    private UIElement processRefund = new UIElement(UIType.Button, UILocatorType.Xpath, "(//*[@id='ASR-CCO-Work-IT-Incident_CreateRefundRequest'])[2]");
    private UIElement launch = new UIElement(UIType.Button, UILocatorType.CSS, "button.SearchButtons.pzhc");
    private UIElement refundReason = new UIElement(UIType.ListBox, UILocatorType.ID, "RefundReason");
    // private UIElement refundReason = new UIElement(UIType.Button, UILocatorType.CSS, "#RefundReason");

    private UIElement refundAmount = new UIElement(UIType.Button, UILocatorType.ID, "TotalRefundAmount");
    private UIElement coreDeviceRequiredYes = new UIElement(UIType.RadioButton, UILocatorType.CSS, "#CoreDeviceRequiredYes");
    private UIElement coreDeviceRequiredNo = new UIElement(UIType.RadioButton, UILocatorType.CSS, "#CoreDeviceRequiredNo");
    //  private UIElement coreDeviceNotReqdRsn = new UIElement(UIType.ListBox, UILocatorType.ID, "CoreDeviceNotReqdRsn");
    private UIElement envelopeRequiredYes = new UIElement(UIType.RadioButton, UILocatorType.CSS, "#EnvelopeRequiredYes");
    private UIElement envelopeRequiredNo = new UIElement(UIType.RadioButton, UILocatorType.CSS, "#EnvelopeRequiredNo");
    private UIElement coreDeviceNotReqdRsn = new UIElement(UIType.ListBox, UILocatorType.ID, "CoreDeviceNotReqdRsn");
    private UIElement verifyRefund = new UIElement(UIType.Button, UILocatorType.Name, "RefundEligibilySection_pyWorkPage_1");
    // private UIElement escalate = new UIElement(UIType.CheckBox, UILocatorType.ID, "RefundEligibilityOverriden");
    private UIElement escalate = new UIElement(UIType.CheckBox, UILocatorType.Xpath, "//*[@id='RefundEligibilityOverriden']");
    private UIElement escalateReason = new UIElement(UIType.ListBox, UILocatorType.ID, "RefundEligibilityOverrideReasonCode");
    //  private UIElement continueButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@id='CT']//*[text()='Continue']");
    private UIElement continueButton = new UIElement(UIType.Button, UILocatorType.CSS, "div[id='pyFlowActionHTML'] table:nth-of-type(1) td:nth-of-type(2) div[id='RULE_KEY'] div[id='CT'] button.InFormContinueButton.pzhc");
    // private UIElement continueButton = new UIElement(UIType.Button, UILocatorType.CSS, ".InFormContinueButton.pzhc");
    private UIElement refundSuccessMessage = new UIElement(UIType.Label, UILocatorType.CSS, "table[id='hoz_ModalWIndows'] table:nth-of-type(1) td:nth-of-type(2) div[id='RULE_KEY'] div.field-item.dataValueRead > span");
    private UIElement cpmInteractionDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmInteractionDivFrame");
    private UIElement diaction = new UIElement(UIType.Frame, UILocatorType.Name, "DIACTION");
    private UIElement testiFrame = new UIElement(UIType.Frame, UILocatorType.ID, "testiframe");
    private UIElement navigationiframe = new UIElement(UIType.Frame, UILocatorType.ID, "navigationiframe");
    private UIElement cpmTabbedNavigationDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    private UIElement sHoldExist = new UIElement(UIType.Label, UILocatorType.CSS, "div>span.header-element.header-title");
    private UIElement closeTab = new UIElement(UIType.Label, UILocatorType.CSS, "button.navigationCloseTabButton");
    private UIElement refundAddNote = new UIElement(UIType.CheckBox, UILocatorType.ID, "AddNote");
    private UIElement refundNoteDescription = new UIElement(UIType.TextBox, UILocatorType.ID, "NoteDescription");
    private UIElement eligibilityDeniedMeassge = new UIElement(UIType.Label, UILocatorType.ID, "PegaRULESErrorFlag");
    private UIElement envelopRequest = new UIElement(UIType.Label, UILocatorType.ID, "ASR-CCO-Work-IT-Incident_CreateEnvelopeRequest");
    private UIElement envelopRequestMessage = new UIElement(UIType.Label, UILocatorType.CSS, "div[node_name=CreateEnvelopeRequest]>table>tbody>tr>td>nobr");
    private UIElement verbalRadioButton = new UIElement(UIType.RadioButton, UILocatorType.ID, "SendAffidavitVERBAL");
    private UIElement continueButtonReleasehold = new UIElement(UIType.Button, UILocatorType.CSS, "table[id='pyActionArea'] table:nth-of-type(1) div[id='pyFlowActionHTML'] div[id='RULE_KEY'] button.buttonTdButton");
    private UIElement IPDnReleasehold = new UIElement(UIType.Button, UILocatorType.ID, "ASR-CCO-Work-IT-Incident_IncidentPathDetermination");
    private UIElement changeOrderType = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='$PpyWorkPage$pRefundServiceRequestList$l1']/td[4]/div");
    private UIElement refundTypeRadioButton = new UIElement(UIType.RadioButton, UILocatorType.Xpath, ".//*[@id='$PpyWorkPage$pRefundServiceRequestList$l2']/td[1]/div");
    private UIElement continueBtnUK = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@id='CT']//*[text()='Continue']");
    private UIElement FeeType = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "//div[contains(text(),'SNR Fee')]//../preceding-sibling::td[3]/div/input[@type=\"radio\"]");
    private UIElement ServiceFeeType = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "//div[contains(text(),'Service Fee')]//../preceding-sibling::td[3]/div/input[@type=\"radio\"]");
    private UIElement pnrFeeType = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "//div[contains(text(),'PNR Fee')]//../preceding-sibling::td[3]/div/input[@type=\"radio\"]");

    HomePage homePage = new HomePage();
    MyWorkPage myWorkPage = new MyWorkPage();

    public void startRefundProcess() throws Exception {

        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        // driver.waitForFrameToLoad(testiFrame, 60);
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(closeTab, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.click(closeTab);
        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(actionsButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(actionsButton);
        } else {
            Assert.assertTrue("Action button is not found Refund Process", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(processRefund, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(processRefund);
        } else {
            Assert.assertTrue("Process Refund button is not found Refund Process", false);
        }


    }


    public void processRefundRequest(String reason, String withCoreDevice, String envelope) throws Exception {
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        if (driver.checkObjectExists(refundReason, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(refundReason, reason);
        } else {
            Assert.assertTrue("Refund Reason Dropdown is not found on  Refund Request Page", false);
        }
        CommonUtilities.waitTime(4);
        if (withCoreDevice.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(coreDeviceRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(coreDeviceRequiredYes))
                    driver.click(coreDeviceRequiredYes);
            } else {
                Assert.assertTrue("Core Device Required Yes Radio button is not found on  Refund Request Page", false);
            }
        } else {
            CommonUtilities.waitTime(2);
            String arrWithCoreDevice[] = withCoreDevice.split(":");
            if (driver.waitForElementPresenceWithTimeOut(coreDeviceRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(coreDeviceRequiredNo);
                if (driver.waitForElementPresenceWithTimeOut(coreDeviceNotReqdRsn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(coreDeviceNotReqdRsn, arrWithCoreDevice[1]);
                } else {
                    Assert.assertTrue("Core Device Not Required Reasondropdown is not found on Refund Request Page", false);
                }
            } else {
                Assert.assertTrue("Core Device Required No Radio button is not found on  Refund Request Page", false);
            }
        }
        if (envelope.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(envelopeRequiredYes))
                    driver.javaScriptClick(envelopeRequiredYes);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(envelopeRequiredNo))
                    driver.javaScriptClick(envelopeRequiredNo);
            }
        }
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueButton);
        } else {
            Assert.assertTrue("continue Button button is not found on  Refund Request Page", false);
        }
        CommonUtilities.waitTime(3);
        if (driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (!driver.isSelected(escalate)) {
                driver.javaScriptClick(escalate);
                if (driver.checkObjectExists(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(escalateReason, "Escalate to Finance");
                    CommonUtilities.waitTime(4);
                    driver.javaScriptClick(continueButton);
                    verifyRefundIsSubmitted();
                    homePage.switchUserAccount("NAFinance");
                    myWorkPage.approveDEDRefundFromFinanceWorkQueue("Approve:Submit");
                }
            }
        } else
            verifyRefundIsSubmitted();

    }

    public void processRefundRequestForDuplicateFee(String reason, String withCoreDevice, String deviceReason) throws Exception {

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDiv Frame is not found on  Refund Request Page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(refundReason, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(refundReason, reason);
        } else {
            Assert.assertTrue("Refund Reason is not found on  Refund Request Page", false);
        }
       /* if(driver.waitForElementPresenceWithTimeOut(verifyRefund, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(verifyRefund);
        }else {
            Assert.assertTrue("Verify Refund button is not found on  Refund Request Page", false);
        }
        if(driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(escalate);
        }else {
            Assert.assertTrue("Escalate button is not found on  Refund Request Page", false);
        }*/
        if (withCoreDevice.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(coreDeviceRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(coreDeviceRequiredYes))
                    driver.click(coreDeviceRequiredYes);
            } else {
                Assert.assertTrue("Core Device Required Yes Radio button is not found on  Refund Request Page", false);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(coreDeviceRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(coreDeviceRequiredNo);
            } else {
                Assert.assertTrue("Core Device Required No Radio button is not found on  Refund Request Page", false);
            }
            if (driver.waitForElementPresenceWithTimeOut(coreDeviceNotReqdRsn, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.select(coreDeviceNotReqdRsn, deviceReason);
            } else {
                Assert.assertTrue("Core Device Not Required Reason button is not found on Refund Request Page", false);
            }
        }

       /* if(ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            if (driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(escalate);
            } else {
                Assert.assertTrue("Escalate button is not found on  Refund Request Page", false);
            }
            if (driver.waitForElementPresenceWithTimeOut(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(escalateReason);
            } else {
                Assert.assertTrue("Escalate Reason Listbox is not found on  Refund Request Page", false);
            }
        }*/
/*
        if(envelope.equalsIgnoreCase("YES"))
        {
            if(!driver.isSelected(envelopeRequiredYes))
                driver.click(envelopeRequiredYes);
        }
        else
        {
            driver.click(envelopeRequiredNo);
        }*/
        driver.click(continueButton);

    }

   /* public void refundRequestForDuplicateFee(String reason1, String deviceReason1) throws Exception {
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on refund request page", false);
        }
        if (driver.checkObjectExists(refundReason, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(refundReason, reason1);
        } else {
            Assert.assertTrue("Refund Reason is not found on  Refund Request Page", false);
        }
        CommonUtilities.waitTime(2);

        if (driver.waitForElementPresenceWithTimeOut(coreDeviceNotReqdRsn, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(coreDeviceNotReqdRsn, deviceReason1);
        } else {
            Assert.assertTrue("Core Device Not Required Reason button is not found on Refund Request Page", false);
        }
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptScrollAndClick(continueButton);
        } else {
            Assert.assertTrue("ContinueButton button is not found on Refund Request Page", false);
        }
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("Diaction is not found on Hold page", false);

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);

        if (driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (!driver.isSelected(escalate)) {
                driver.click(escalate);
                if (driver.checkObjectExists(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(escalateReason, "Escalate to Finance");
                    driver.click(continueButton);
                }
            }
        }


    }*/

    public void verifyRefundIsSubmitted() throws Exception {
        CommonUtilities.waitTime(5);
        String refundConfirm = "";
        String requestNumber = "";
        CommonUtilities.waitTime(5);
        if (driver.checkObjectExists(refundSuccessMessage, ApplicationConfiguration.getWaitForElementTimeout())) {
            refundConfirm = driver.getText(refundSuccessMessage);
            System.out.println("Refund Success Message: " + refundConfirm);
            if (refundConfirm.contains(":")) {
                String arrRefundConfirm[] = refundConfirm.split(":");
                BasePage.refundReqNo = arrRefundConfirm[1].trim();
            }
            System.out.println("\n***************Refund Number: " + BasePage.refundReqNo);
        } else {
            Assert.assertTrue("Refund Success Message is not found on Refund Request Page", false);
        }
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos") || ApplicationConfiguration.getClient().equalsIgnoreCase("Telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers") || ApplicationConfiguration.getClient().equalsIgnoreCase("Fido")) {
            if (refundConfirm.contains(":")) {
                requestNumber = refundConfirm.substring(refundConfirm.indexOf(":") + 1);
                assertEquals("Checking expected confirmation message", "The refund request has been submitted successfully.Refund request number:" + requestNumber, driver.getText(refundSuccessMessage));
            } else {
                assertEquals("Checking expected confirmation message", "The refund request has been submitted successfully.", refundConfirm);
            }

        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("CLARO")) {
//            requestNumber=requestNumber.substring(requestNumber.indexOf("."));
            assertEquals("Checking expected confirmation message", "The refund request has been submitted successfully.", driver.getText(refundSuccessMessage).substring(0, refundConfirm.indexOf(".") + 1));
        }
    }

    public void verifyRefundIsSubmittedEU() throws Exception {
        CommonUtilities.waitTime(5);
        String refundConfirm = "";
        CommonUtilities.waitTime(5);
        if (driver.checkObjectExists(refundSuccessMessage, ApplicationConfiguration.getWaitForElementTimeout())) {
            refundConfirm = driver.getText(refundSuccessMessage);
            System.out.println("Refund Success Message: " + refundConfirm);

        } else {
            Assert.assertTrue("Refund Success Message is not found on Refund Request Page", false);
        }
    }

    /**
     * This method is used to check Hold from backend(DAL)
     * * @author Sachin
     */
    public boolean checkHold() throws Exception {

        // CommonUtilities.waitTime(1);
        Boolean isHold = false;

       /* String claimId;
        if(CustomerDetails.customerData.containsKey("CASENUMBER1")){
            claimId= CustomerDetails.customerData.get("CASENUMBER1");
        }
        else
        {
            claimId= CustomerDetails.customerData.get("CASENUMBER");
        }*/
        //String checkQuery="select * from CUSTOMER_CASE_HOLD where Customer_Case_NBR='"+ CustomerDetails.customerData.get("CASENUMBER")+"'";
//        String checkQuery="select * from Customer.CUSTOMER_CASE_HOLD inner join Customer.service_request on service_request.service_request_nbr=CUSTOMER_CASE_HOLD.service_request_nbr inner join asset.asset on service_request.asset_id=asset.asset_id  \n" +
//                "where  MOBILE_DEVICE_NBR='"+CustomerDetails.customerData.get("MDN")+"'  and customer_case_hold_status_code not like '%CMPLTD%'";
//
//        int i=0;
//    do {
//         if (DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(),"dal"), checkQuery).size() > 0) {
//            isHold = true;
//                break;
//         }
//         else
//             i++;
//        }while(i<=1200);

        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Hold page", false);
        }
        //navigateLowestLevelFrame(diaction);
        // if(ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro") )        {
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }
           /* if(!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())){
                Assert.assertTrue("Diaction 1 is not found on Hold page", false);
            }*/
        /*}else if(ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos")){
            if(!driver.waitForFrameToLoad(diaction,ApplicationConfiguration.getWaitForElementTimeout())){
                Assert.assertTrue("Diaction is not found on Hold page", false);
            }
        }*/
        driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        // System.out.println(driver.waitForElementPresenceWithTimeOut(sHoldExist, ApplicationConfiguration.getWaitForElementTimeout()));
        if (driver.waitForElementPresenceWithTimeOut(sHoldExist, 40)) {
            isHold = true;
        }

        return isHold;

    }

    /**
     * This method is used to release Hold from backend(DAL)
     * * @author Sachin
     *
     * @param mdn
     */
    public void releaseHold(String mdn) throws Exception {
//        String sQuery = "UPDATE \n" +
//                "Customer.SERVICE_REQUEST\n" +
//                "SET\n" +
//                "Service_Request_Status_Code = 'WORKNG'\n" +
//                "WHERE\n" +
//                "Service_Request_ID IN (SELECT Service_Request_ID from (Select Service_Request_ID from Customer.SERVICE_REQUEST where Agreement_ID in \n" +
//                "(SELECT Agreement_id from ASSET.AGREEMENT_ASSET_XREF where Asset_ID in\n" +
//                "(SELECT Asset_ID from Asset.Asset where MOBILE_DEVICE_NBR = '"+CustomerDetails.customerData.get("MDN")+"'))order by Created_date desc) dual where ROWNUM =1)";
//
//        String sQuery1  = "Update Customer.Customer_Case_Hold Set Customer_Case_Hold_Status_Code='CMPLTD',\n" +
//                "                CUSTOMER_CASE_HOLD_RSLTN_CODE='APPROVE',\n" +
//                "                HOLD_RELEASE_TIME=systimestamp,\n" +
//                "                HOLD_RELEASED_BY='svc.US_q_Horizon_A',\n" +
//                "                Updated_date=systimestamp,\n" +
//                "                CASE_HOLD_RELEASE_REASON_CODE='DOCVRF'\n" +
//                "WHERE\n" +
//                "Customer_Case_NBR in \n" +
//                "(SELECT Customer_Case_NBR from Customer.Customer_Case where Agreement_ID in \n" +
//                "(SELECT Agreement_ID from ASSET.AGREEMENT_ASSET_XREF where Asset_ID in\n" +
//                "(SELECT Asset_ID from ASSET.Asset where MOBILE_DEVICE_NBR = '"+CustomerDetails.customerData.get("MDN")+"')))\n" +
//                "and customer_case_hold_status_code not like '%CMPLTD%'";
        String sQuery = "UPDATE customer.SERVICE_REQUEST \n" +
                "SET Service_Request_Status_Code = 'WORKNG' \n" +
                "WHERE customer_case_id IN (SELECT customer_case_id from (Select customer_case_id from Customer.SERVICE_REQUEST where Agreement_ID in \n" +
                "(SELECT Agreement_id from ASSET.AGREEMENT_ASSET_XREF where Asset_ID in\n" +
                "(SELECT Asset_ID from Asset.Asset where MOBILE_DEVICE_NBR = '" + CustomerDetails.customerData.get("MDN") + "'))order by Created_date desc) dual where ROWNUM =1)";

        String sQuery1 = "UPDATE customer.HOLD set HOLD_STATUS_CODE = 'CMPLTD', HOLD_RESOLUTION_CODE='APPROVE',RELEASE_TIME=systimestamp,RELEASED_BY='svc.US_q_Horizon_A',Updated_date=systimestamp,HOLD_RELEASE_SUB_REASON_CODE='DOCVRF'\n" +
                "WHERE Customer_Case_NBR in (SELECT Customer_Case_NBR from Customer.Customer_Case where Agreement_ID in  \n" +
                "(SELECT Agreement_ID from ASSET.AGREEMENT_ASSET_XREF where Asset_ID in (SELECT Asset_ID from ASSET.Asset where MOBILE_DEVICE_NBR = '" + CustomerDetails.customerData.get("MDN") + "'))) and HOLD_STATUS_CODE not like '%CMPLTD%'";

        DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), sQuery);
        DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), sQuery1);
    }

    public void refundRequestWithCodeDeviceDetails(String reason, String withCoreDevice) throws Exception {
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }


        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        if (driver.checkObjectExists(refundReason, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(refundReason, reason);
        } else {
            Assert.assertTrue("Refund Reason Dropdown is not found on  Refund Request Page", false);
        }
        CommonUtilities.waitTime(4);
        if (withCoreDevice.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(coreDeviceRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(coreDeviceRequiredYes))
                    driver.javaScriptClick(coreDeviceRequiredYes);
            } else {
                Assert.assertTrue("Core Device Required Yes Radio button is not found on  Refund Request Page", false);
            }
        } else {
            CommonUtilities.waitTime(2);
            String arrWithCoreDevice[] = withCoreDevice.split(":");
            if (driver.waitForElementPresenceWithTimeOut(coreDeviceRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(coreDeviceRequiredNo);
                if (driver.waitForElementPresenceWithTimeOut(coreDeviceNotReqdRsn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(coreDeviceNotReqdRsn, arrWithCoreDevice[1]);
                } else {
                    Assert.assertTrue("Core Device Not Required Reasondropdown is not found on Refund Request Page", false);
                }
            } else {
                Assert.assertTrue("Core Device Required No Radio button is not found on  Refund Request Page", false);
            }
        }
    }

    public void handleEnvelopeAndEscalateCheck(String envelopeYesOrNo, String errorMessage) throws Exception {
        CommonUtilities.waitTime(1);
        if (envelopeYesOrNo.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(envelopeRequiredYes))
                    driver.javaScriptClick(envelopeRequiredYes);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(envelopeRequiredNo);
            }
        }
        CommonUtilities.waitTime(5);
        if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueButton);
        } else {
            Assert.assertTrue("ContinueButton button is not found on Refund Request Page", false);
        }
        CommonUtilities.waitTime(8);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("Diaction is not found on Hold page", false);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on refund request page", false);

        if (driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
            CommonUtilities.waitTime(2);
            if (!driver.isSelected(escalate)) {
                driver.javaScriptClick(escalate);
                if (driver.checkObjectExists(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(escalateReason, "Escalate to Finance");
                    System.out.println("\nEligibility check is found on Refund Request Page.");
                    driver.javaScriptClick(continueButton);
                }
            }
        }
        verifyRefundIsSubmitted();
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro") || ApplicationConfiguration.getClient().equalsIgnoreCase("Telcel")) {
            CommonUtilities.waitTime(8);
            homePage.switchUserAccount("Finance");
            myWorkPage.approveRefundRequestFromNAFinanceWorkbasket("Approve:Submit:Customer Escalation");
        }
    }

    public void envelopeAndEscalate(String envelopeYesOrNo, String errorMessage) throws Exception {
        CommonUtilities.waitTime(1);
        if (envelopeYesOrNo.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(envelopeRequiredYes))
                    driver.javaScriptClick(envelopeRequiredYes);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(envelopeRequiredNo);
            }
        }
        CommonUtilities.waitTime(5);
        if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueButton);
        } else {
            Assert.assertTrue("ContinueButton button is not found on Refund Request Page", false);
        }
        CommonUtilities.waitTime(3);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("Diaction is not found on Hold page", false);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on refund request page", false);

        if (driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
            CommonUtilities.waitTime(2);
            if (!driver.isSelected(escalate)) {
                driver.javaScriptClick(escalate);
                if (driver.checkObjectExists(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(escalateReason, "Escalate to Finance");
                    System.out.println("\nEligibility check is found on Refund Request Page.");
                    CommonUtilities.waitTime(2);
                    driver.javaScriptClick(continueButton);
                    verifyRefundIsSubmitted();
                    homePage.switchUserAccount("NAFinance");
                    System.out.println("I approve refund request from Finance Workbasket");
                    myWorkPage.approveRefundFromFinanceWorkQueue("Approve:Submit:Customer Escalation");
                }
            }
        } else {
            verifyRefundIsSubmitted();
            CommonUtilities.waitTime(2);
            homePage.switchUserAccount("NACST");
            System.out.println("I login as NACST and approve refund from Refund Workbasket");
            myWorkPage.approveRefundFromWorkBasket("Approve:Submit:Customer Escalation");
        }
    }


    public void envelopeAddNoteAndEscalate(String envelopeYesOrNo, String sNote, String errorMessage) throws Exception {

        String sScreenMessage = "";
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        // String query = "select device_expected_ind from Customer.RETURN_LOGISTICS where Service_request_id in (Select Service_request_id from Customer.service_request where Customer_Case_id in (Select Customer_Case_id from Customer.Customer_case where Customer_case_nbr = '"+CustomerDetails.customerData.get("CASENUMBER")+"'))";
        //System.out.println(query);
        //result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        CommonUtilities.waitTime(1);
        // if(result.get(0).get("DEVICE_EXPECTED_IND").equalsIgnoreCase("Y")) {
        if (envelopeYesOrNo.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(envelopeRequiredYes))
                    driver.click(envelopeRequiredYes);
            }
//                    else {
//                        Assert.assertTrue("Envelope Required Yes Radio button is not found on  Refund Request Page", false);
//                    }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(envelopeRequiredNo);
            }
//                    else {
//                        Assert.assertTrue("Envelope Required No Radio button is not found on  Refund Request Page", false);
//                    }
        }
        // }
        if (driver.waitForElementPresenceWithTimeOut(refundAddNote, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(refundAddNote);
            if (driver.waitForElementPresenceWithTimeOut(refundNoteDescription, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.type(refundNoteDescription, sNote);
            else
                Assert.assertTrue("NoteDescription Text Area is not found on  Refund Request Page", false);
        } else {
            Assert.assertTrue("refundAddNote radio button is not found on  Refund Request Page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (!driver.isSelected(escalate)) {
                if (driver.waitForElementPresenceWithTimeOut(eligibilityDeniedMeassge, ApplicationConfiguration.getWaitForElementTimeout())) {
                    sScreenMessage = driver.getText(eligibilityDeniedMeassge);
                    Assert.assertTrue("Verification of eligibility denied meassge :", sScreenMessage.toLowerCase().contains(errorMessage.toLowerCase()));
                }
                driver.javaScriptClick(escalate);
                CommonUtilities.waitTime(2);
                if (driver.checkObjectExists(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(escalateReason, "Escalate to Finance");
                    driver.click(continueButton);
                }
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.waitAndClick(continueButton);
            } else {
                Assert.assertTrue("ContinueButton button is not found on Refund Request Page", false);
            }
        }

    }

    // @Author : Shahabuddin  Ansari
    // Adding method for the Envelop Request message (Latam _Claro Peru)

    public void selectEnvelopRequest() throws Exception {

        //CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();

        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(closeTab, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.click(closeTab);
        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(actionsButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(actionsButton);
        } else {
            Assert.assertTrue("Action button is not found Refund Process", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(envelopRequest, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.doubleClick(envelopRequest);
/*

                String envelopReqMsg = driver.getText(envelopRequestMessage);
                System.out.println("The Envelop Requst Message is : " + envelopReqMsg);

*/
        } else {
            Assert.assertTrue("Envelop Request link is not found on the Action Menu", false);
        }


    }

    public void verifyEnvelopRequestMsg() {

        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        if (driver.checkObjectExists(envelopRequestMessage, ApplicationConfiguration.getWaitForElementTimeout())) {
            String envelopReqMsg = driver.getText(envelopRequestMessage);
            System.out.println("The Envelop Requst Message is : " + envelopReqMsg);

        } else {
            Assert.assertTrue("Envelop Request Message not found", false);
        }


    }

    /**
     * This method is used to to resume claim from action tab after release Hold
     */
    public void continueRelasehold() throws Exception {

        if (driver.waitForElementPresenceWithTimeOut(verbalRadioButton, 15)) {
            driver.click(verbalRadioButton);
        }
        if (driver.waitForElementPresenceWithTimeOut(continueButtonReleasehold, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(continueButtonReleasehold);
        } else {
            Assert.assertTrue(" continueButtonReleasehold is not nRelease hold ", false);
        }


        driver.switchToDefaultContent();
        // driver.waitForFrameToLoad(testiFrame, 60);
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(actionsButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(actionsButton);
        } else {
            Assert.assertTrue("Action button is not found Refund Process", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(IPDnReleasehold, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.doubleClick(IPDnReleasehold);
        } else {
            Assert.assertTrue("Process Refund button is not found Refund Process", false);
        }

    }

    /**
     * Author- Nandini Mujumdar
     * This method is used select radio button for SNR Fee
     */
    public void selectCaseNumberForRefundProcess() throws Exception {
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        if (driver.getText(changeOrderType).equalsIgnoreCase("Service Fee")) {
            if (driver.waitForElementPresenceWithTimeOut(refundTypeRadioButton, 15)) {
                driver.javaScriptClick(refundTypeRadioButton);
            } else {
                Assert.assertTrue("SNR Refund radio button is not found on Refund Request Page", false);
            }
        } else {
            Assert.assertTrue("Service Fee option is not displayed", true);
        }
    }

    // Method in use

    /**
     * Author- Nandini Mujumdar
     * This method is check availability of Escalate Eligibility Check
     */
    public void envelopeAndVerifyEscalateCheckAvailability(String envelopeYesOrNo, String errorMsg, String eligibiltyCheck) throws Exception {

        CommonUtilities.waitTime(1);
        if (envelopeYesOrNo.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(envelopeRequiredYes))
                    driver.click(envelopeRequiredYes);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(envelopeRequiredNo);
            }

        }
        CommonUtilities.waitTime(30);
        if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueButton);
        } else {
            Assert.assertTrue("ContinueButton button is not found on Refund Request Page", false);
        }
        CommonUtilities.waitTime(15);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("Diaction is not found on Hold page", false);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on refund request page", false);

        boolean flag = false;
        if (driver.checkObjectExists(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
            System.out.println("escalate object is present");
            if (!driver.isSelected(escalate)) {
                System.out.println("escalate checkbox is not checked");
                flag = true;
                driver.javaScriptClick(escalate);
                System.out.println("escalate checkbox checked");
                CommonUtilities.waitTime(3);
                if (driver.checkObjectExists(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(escalateReason, "Escalate to Finance");
                    if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout()))
                        driver.javaScriptClick(continueButton);
                    else
                        Assert.assertTrue("ContinueButton button is not found on Refund Request Page", false);
                } else {
                    Assert.fail("Escalate reason dropdown is not found on Refund Request Page");
                }
            }
        }
        CommonUtilities.waitTime(2);
        if (flag == true)
            System.out.println("Eligibility check is found on Refund Request Page.");
        else {
            if (flag == false) {
                System.out.println("Eligibility check is not found on Refund Request Page.");
            }
        }
        /*if (eligibiltyCheck.equalsIgnoreCase("Approve")) {
            Assert.assertFalse("Eligibility check is found on Refund Request Page.", flag);
        } else {
            if (eligibiltyCheck.equalsIgnoreCase("Decline")) {
                Assert.assertTrue("Eligibility check is not found on Refund Request Page.", flag);
            }
        }*/
    }

    public void closeBrowser() {
        CommonUtilities.waitTime(50);
        driver.quit();
    }

    public void approveRefundRequestFromNAFinanceWorkBasket(String envelopeYesOrNoOption) throws Exception {
        CommonUtilities.waitTime(1);
        if (envelopeYesOrNoOption.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(envelopeRequiredYes))
                    driver.javaScriptClick(envelopeRequiredYes);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(envelopeRequiredNo);
            }
        }
        CommonUtilities.waitTime(5);
        if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueButton);
        } else {
            Assert.assertTrue("ContinueButton button is not found on Refund Request Page", false);
        }
        CommonUtilities.waitTime(3);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("Diaction is not found on Hold page", false);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on refund request page", false);

        if (driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
            CommonUtilities.waitTime(2);
            if (!driver.isSelected(escalate)) {
                driver.javaScriptClick(escalate);
                CommonUtilities.waitTime(2);
                if (driver.checkObjectExists(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(escalateReason, "Escalate to Finance");
                    System.out.println("\nEligibility check is found on Refund Request Page.");
                    driver.javaScriptClick(continueButton);
                    verifyRefundIsSubmitted();
                    homePage.switchUserAccount("NAFinance");
                    System.out.println("I approve refund request from Finance Workbasket");
                    myWorkPage.approveRefundRequestFromNAFinanceWorkbasket("Approve:Submit:Customer Escalation");
                }
            }
        } else {
            verifyRefundIsSubmitted();
            CommonUtilities.waitTime(2);
            homePage.switchUserAccount("NACST");
            System.out.println("I login as NACST and approve refund from Refund Workbasket");
            myWorkPage.approveRefundFromWorkBasket("Approve:Submit:Customer Escalation");
        }
    }

    public void processRefundRequestfor3UK(String reason, String withCoreDevice, String envelope) throws Exception {
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        if (driver.checkObjectExists(refundReason, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(refundReason, reason);
        } else {
            Assert.assertTrue("Refund Reason Dropdown is not found on  Refund Request Page", false);
        }
        CommonUtilities.waitTime(4);
        if (withCoreDevice.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(coreDeviceRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(coreDeviceRequiredYes))
                    driver.click(coreDeviceRequiredYes);
            } else {
                Assert.assertTrue("Core Device Required Yes Radio button is not found on  Refund Request Page", false);
            }
        } else {
            CommonUtilities.waitTime(2);
            String arrWithCoreDevice[] = withCoreDevice.split(":");
            if (driver.waitForElementPresenceWithTimeOut(coreDeviceRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(coreDeviceRequiredNo);
                if (driver.waitForElementPresenceWithTimeOut(coreDeviceNotReqdRsn, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(coreDeviceNotReqdRsn, arrWithCoreDevice[1]);
                } else {
                    Assert.assertTrue("Core Device Not Required Reasondropdown is not found on Refund Request Page", false);
                }
            } else {
                Assert.assertTrue("Core Device Required No Radio button is not found on  Refund Request Page", false);
            }
        }
        if (envelope.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(envelopeRequiredYes))
                    driver.click(envelopeRequiredYes);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(envelopeRequiredNo))
                    driver.javaScriptClick(envelopeRequiredNo);
            }
        }

        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(continueBtnUK, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(continueBtnUK);
        } else {
            Assert.assertTrue("continue Button button is not found on  Refund Request Page", false);
        }
        CommonUtilities.waitTime(3);
        if (driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (!driver.isSelected(escalate)) {
                driver.javaScriptClick(escalate);
                CommonUtilities.waitTime(2);
                if (driver.checkObjectExists(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(escalateReason, "Escalate to EU Finance");
                    CommonUtilities.waitTime(1);
                    driver.waitAndClick(continueButton);
                    verifyRefundIsSubmittedEU();
                    homePage.switchUserAccountEU("HorizonEUFinance");
                    myWorkPage.approveDEDRefundFromEUFinanceWorkQueue("Approve:Submit");
                }
            }
        } else {
            verifyRefundIsSubmitted();
        }
    }

    /**
     * Author :Nandini Mujumdar
     * This method is used to select Refund fee(SNR, PNR or Service)
     * Param : fee type
     */
    public void selectFeeForRefund(String feeType) {
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(ServiceFeeType, 15)) {
            if(feeType.contains("SNR Fee"))
                driver.javaScriptClick(FeeType);
            else if(feeType.contains("Service Fee"))
                driver.javaScriptClick(ServiceFeeType);
            else if(feeType.contains("PNR Fee"))
                driver.javaScriptClick(pnrFeeType);
        } else {
            Assert.assertTrue(feeType + " Fee option is not displayed", true);
        }
    }

    /* This method is used to DED Refund for 3UK client */
    public void process3UKRefundRequestForDEDRefund(String reason, String withCoreDevice, String envelope) throws Exception {
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found Refund Process", false);
        }

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Hold page", false);
        }


        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame frame is not found on Refund Request Page", false);
        }
        if (driver.checkObjectExists(refundReason, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(refundReason, reason);
        } else {
            Assert.assertTrue("Refund Reason Dropdown is not found on  Refund Request Page", false);
        }
        CommonUtilities.waitTime(1);
        if (withCoreDevice.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(coreDeviceRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(coreDeviceRequiredYes))
                    driver.click(coreDeviceRequiredYes);
            } else {
                Assert.assertTrue("Core Device Required Yes Radio button is not found on  Refund Request Page", false);
            }
        } else {
            CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(coreDeviceRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(coreDeviceRequiredNo);
            } else {
                Assert.assertTrue("Core Device Required No Radio button is not found on  Refund Request Page", false);
            }
        }
        if (envelope.equalsIgnoreCase("YES")) {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(envelopeRequiredYes))
                    driver.click(envelopeRequiredYes);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(envelopeRequiredNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(envelopeRequiredNo);
            }
        }
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            //driver.waitAndClick(continueButton);
            driver.click(continueButton);
        } else {
            Assert.assertTrue("continue Button button is not found on  Refund Request Page", false);
        }
        CommonUtilities.waitTime(3);
        if (driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (!driver.isSelected(escalate)) {
                driver.javaScriptClick(escalate);
                CommonUtilities.waitTime(2);
                if (driver.checkObjectExists(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(escalateReason, "Escalate to EU Finance");
                    CommonUtilities.waitTime(1);
                    driver.waitAndClick(continueButton);
                    verifyRefundIsSubmittedEU();
                    homePage.switchUserAccountEU("HorizonEUFinance");
                    myWorkPage.approveDEDRefundFromEUFinanceWorkQueue("Approve:Submit");
                }
            }
        } else
            verifyRefundIsSubmittedEU();
    }
}
