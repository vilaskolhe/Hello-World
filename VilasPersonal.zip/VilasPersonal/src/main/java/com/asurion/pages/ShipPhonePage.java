package com.asurion.pages;

import com.asurion.horizon.generic.DataBaseHandler;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.soap.*;

import com.asurion.util.CustomerDetails;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;

import static org.junit.Assert.assertTrue;

/**
 * Created by _sachinn.more on 9/16/2015.
 * Modified by prabhat.das on 02/26/2016
 * Modification: changed the logic for handling Casenumbers
 * Modified by Priyanka on 05/10/2016
 * Modification: changed shipping XML and hitting soap1 req 2 times
 */
public class ShipPhonePage {

    public void shipPhone() throws Exception {
        //try {
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String claimId = "";


        if (!CaptureIncidentPage.casenumbers.containsKey("CASENUMBER1")) {
            if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER")) {
                if (!CaptureIncidentPage.casenumbers.get("CASENUMBER").equalsIgnoreCase(CaptureIncidentPage.claimId)) {
                    claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
                } else {
                    claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER");
                }
            }
        } else {
            if (CaptureIncidentPage.casenumbers.get("CASENUMBER1").equalsIgnoreCase(CaptureIncidentPage.claimId))
                claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
            else
                claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER2");
        }
        if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER3") && !CaptureIncidentPage.casenumbers.containsKey("CASENUMBER4")) {
            if (CaptureIncidentPage.casenumbers.get("CASENUMBER3").equalsIgnoreCase(CaptureIncidentPage.claimId))
                claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER3");
        }

        if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER4") || CaptureIncidentPage.casenumbers.containsKey("CASENUMBER5")) {
            if (CaptureIncidentPage.casenumbers.get("CASENUMBER4").equalsIgnoreCase(CaptureIncidentPage.claimId))
                claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER4");
            else {
                claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER5");
            }
        }

        System.out.println(" Shipping Case Number: " + claimId);
        try {
            System.out.println("Ship status :" + com.asurion.soap.SoapRequest.shipDevice(CustomerDetails.customerData.get("MDN"), claimId));
            if (!(com.asurion.soap.SoapRequest.shipDevice(CustomerDetails.customerData.get("MDN"), claimId))) {
                assertTrue("Asset could not be shipped ", false);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    /**
     * Created by _priyanka.pawar on 29/04/2016.
     * Description: This function is used to trigger the delivery event
     */
    public void deliveryEvent() throws Exception {
        // try {
        ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
        String claimId = "";

        if (!CaptureIncidentPage.casenumbers.containsKey("CASENUMBER1")) {
            if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER")) {
                if (!CaptureIncidentPage.casenumbers.get("CASENUMBER").equalsIgnoreCase(CaptureIncidentPage.claimId)) {
                    claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
                } else {
                    claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER");
                }
            }
        } else {
            if (CaptureIncidentPage.casenumbers.get("CASENUMBER1").equalsIgnoreCase(CaptureIncidentPage.claimId))
                claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
            else
                claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER2");
        }

        System.out.println("Deliver Case Number: " + claimId);
        CommonUtilities.waitTime(10);
        try {
            System.out.println("Deliver status :" + com.asurion.soap.SoapRequest.deliverDevice(CustomerDetails.customerData.get("MDN"), claimId));

            if (!(com.asurion.soap.SoapRequest.deliverDevice(CustomerDetails.customerData.get("MDN"), claimId)))
                assertTrue("Asset could not be delivered ", false);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    //

    /**
     * Created by _priyanka.pawar on 12/06/2016.
     * Description: This function is used to trigger the release Backordered Device event
     */
    public void releaseBackorderedDevice() throws Exception {
        try {
            ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
            String claimId = "";

            if (!CaptureIncidentPage.casenumbers.containsKey("CASENUMBER1")) {
                if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER")) {
                    if (!CaptureIncidentPage.casenumbers.get("CASENUMBER").equalsIgnoreCase(CaptureIncidentPage.claimId))
                        claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
                    else
                        claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER");
                }
            } else {
                if (CaptureIncidentPage.casenumbers.get("CASENUMBER1").equalsIgnoreCase(CaptureIncidentPage.claimId))
                    claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
                else
                    claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER2");
            }
            String getOrderStatus = "select Service_order_status_code as ORDERSTATUS from Customer.Service_order inner join asset.asset on Service_order.asset_id=asset.asset_id \n" +
                    "where  MOBILE_DEVICE_NBR = '" + CustomerDetails.customerData.get("MDN") + "'  order by Service_order.created_date desc";

            for (int i = 0; i <= 100; i++) {
                statusData = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), getOrderStatus);
                if (!(statusData.size() == 0) && statusData.get(0).get("ORDERSTATUS").equalsIgnoreCase("BORD")) {

                    Publisher.publishRequestForReleaseBackorderedDevice(SoapRequest.backOrderReleaseEvent(CustomerDetails.customerData.get("MDN"), claimId));
                    break;

                }
            }

            try {
                Thread.sleep(5000);
            } catch (Exception e) {
                throw new Exception(e.getMessage());
            }

            ArrayList<HashMap<String, String>> data = new ArrayList<>();
            boolean delivered = false;
            for (int j = 0; j <= 300; j++) {
                data = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), getOrderStatus);

                if (data.size() == 0) {

                    assertTrue("Service Request is not returned from DAL DB.Query used is : " + getOrderStatus + "", false);
                }

                System.out.println(data.get(0).get("ORDERSTATUS"));

                if (data.get(0).get("ORDERSTATUS").equalsIgnoreCase("BORDREL")) {
                    assertTrue("Asset is back in stock status : " + data.get(0).get("ORDERSTATUS") + "", true);
                    delivered = true;
                    break;
                }

            }
            if (delivered == false) {
                assertTrue("Asset is not delivered as order status is : " + data.get(0).get("ORDERSTATUS") + "", false);
            }
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    /**
     * Created by _priyanka.pawar
     * Description: This function is used to submit Salvage Return Event
     * Date 27/06/2016.
     */
    public void submitSalvageReturnEvent() throws Exception {
        try {
            ArrayList<HashMap<String, String>> statusData = new ArrayList<>();
            String claimId = "";

            if (!CaptureIncidentPage.casenumbers.containsKey("CASENUMBER1")) {
                if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER")) {
                    if (!CaptureIncidentPage.casenumbers.get("CASENUMBER").equalsIgnoreCase(CaptureIncidentPage.claimId))
                        claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
                    else
                        claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER");
                }
            } else {
                if (CaptureIncidentPage.casenumbers.get("CASENUMBER1").equalsIgnoreCase(CaptureIncidentPage.claimId))
                    claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
                else
                    claimId = CaptureIncidentPage.casenumbers.get("CASENUMBER2");
            }
//            String getOrderStatus ="select Service_order_status_code as ORDERSTATUS from Customer.Service_order inner join asset.asset on Service_order.asset_id=asset.asset_id \n" +
//                    "where  MOBILE_DEVICE_NBR = '"+CustomerDetails.customerData.get("MDN")+"'  order by Service_order.created_date desc";
//
            String getOrderStatus = "select shipping_status_code as ORDERSTATUS from customer.shipping_order inner join asset.asset on shipping_order.asset_id=asset.asset_id\n" +
                    "where  MOBILE_DEVICE_NBR = '" + CustomerDetails.customerData.get("MDN") + "'  order by shipping_order.created_date desc";


            for (int i = 0; i <= 100; i++) {
                statusData = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), getOrderStatus);
                if (!(statusData.size() == 0) && statusData.get(0).get("ORDERSTATUS").equalsIgnoreCase("DLVRD")) {
                    //if (!(statusData.size() == 0) && statusData.get(0).get("ORDERSTATUS").equalsIgnoreCase("SHIPPED")) {

                    Publisher.publishRequestForProductReturned(SoapRequest.productReturnedEvent(CustomerDetails.customerData.get("MDN"), claimId));
                    break;

                }
            }

            try {
                Thread.sleep(2000);
            } catch (Exception e) {
                throw new Exception(e.getMessage());
            }

            ArrayList<HashMap<String, String>> data = new ArrayList<>();
            boolean delivered = false;
            for (int j = 0; j <= 300; j++) {
                data = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), getOrderStatus);

                if (data.size() == 0) {

                    assertTrue("Service Request is not returned from DAL DB.Query used is : " + getOrderStatus + "", false);
                }

                System.out.println(data.get(0).get("ORDERSTATUS"));

                // if (data.get(0).get("ORDERSTATUS").equalsIgnoreCase("RETURNED")) {
                if (data.get(0).get("ORDERSTATUS").equalsIgnoreCase("PRDRTN")) {
                    assertTrue("Asset is back in stock status : " + data.get(0).get("ORDERSTATUS") + "", true);
                    delivered = true;
                    break;
                }

            }
            if (delivered == false) {
                assertTrue("Asset is not delivered as order status is : " + data.get(0).get("ORDERSTATUS") + "", false);
            }
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

}
