package com.asurion.pages;

import com.asurion.horizon.generic.DataBaseHandler;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.Asset;
import com.asurion.util.CustomerDetails;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class AssetVerificationPage {

    static String CLIENT_CHANNEL_ID = null;
    static String CLIENT_CHANNEL_ID_1 = null;
    static String CLIENT_CHANNEL_ID_2 = null;
    static String ASSET_CATALOG_ID = null;
    static String PRODUCT_FEATURE_ID = null;
    public static StringBuffer verificationErrors = new StringBuffer("Asset details : ");
    static ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();


    public static boolean getAssetCatalogID(String NSKU, String PSKU, String SSKU, String environment, String dbName) throws Exception {

        boolean flag = true;

        String q = "select ACCCAX.asset_catalog_id, CCA.client_asset_sku_nbr, CAT.asset_catalog_name," +
                "CCA.base_item_ind, CCA.sku_start_date, CCA.sku_end_date," +
                "COLOR.ASSET_COLOR_NAME,MAKE.asset_make_name,AMODEL.asset_model_nbr, CCA.client_channel_id" +
                " from ASSET.ASSET_CTLG_CLNT_CHNL_AST_XREF ACCCAX, ASSET.CLIENT_CHANNEL_ASSET CCA, ASSET.ASSET_CATALOG CAT, ASSET.ASSET_MAKE MAKE, ASSET.ASSET_MODEL AMODEL, ASSET.ASSET_COLOR COLOR" +
                " where CCA.client_channel_asset_id = ACCCAX.client_channel_asset_id" +
                " and ACCCAX.asset_catalog_id = CAT.asset_catalog_id" +
                " and MAKE.ASSET_MAKE_ID=CAT.asset_make_id " +
                " and AMODEL.ASSET_MODEL_ID=CAT.asset_model_id" +
                " and color.asset_color_id = CAT.asset_color_id" +
                " and CCA.client_asset_sku_nbr in('" + NSKU + "','" + PSKU + "','" + SSKU + "')" +
                " order by CCA.client_asset_sku_nbr";


        data = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(environment, dbName), q);

        if (data.size() == 0) {
            System.out.println("expected number of rows not found.Query Used is :\n " + q);
            flag = false;
        } else {
            if (!data.get(0).get("CLIENT_CHANNEL_ID").isEmpty() && data.size() == 3) {

                CLIENT_CHANNEL_ID = data.get(0).get("CLIENT_CHANNEL_ID");
                ASSET_CATALOG_ID = data.get(0).get("ASSET_CATALOG_ID");
            } else {
                System.out.println("Either Client Channel ID is empty or expected number of rows not found");
                flag = false;
            }
        }


        return flag;
    }


    public static void validateServiceFee(String clientOfferName, String region, String incidentType, String serviceFees, String environment, String dbName) throws Exception {

        boolean flag = true;
        if (clientOfferName.equalsIgnoreCase("Tier 3") || clientOfferName.equalsIgnoreCase("Tier3")) {
            clientOfferName = "Protección Móvil Telcel Tier 3";
        }

        String q = "SELECT FAM.INCIDENT_TYPE_CODE AS \"INCIDENT TYPE\",  FA.ATTRIBUTE_VALUE AS \"DEDUCTIBLE\" " +
                "FROM ASSET.ASSET_CATALOG CAT \n" +
                "INNER JOIN PRODUCT.FEATURE_ATTRIBUTE_MAP FAM          ON (FAM.ASSET_CATALOG_ID          = CAT.ASSET_CATALOG_ID)\n" +
                "INNER JOIN PRODUCT.FEATURE_ATTRIBUTE_XREF FAX         ON (FAM.FEATURE_ATTRIBUTE_MAP_ID  = FAX.FEATURE_ATTRIBUTE_MAP_ID)\n" +
                "INNER JOIN PRODUCT.FEATURE_ATTRIBUTE FA               ON (FAX.FEATURE_ATTRIBUTE_ID      = FA.FEATURE_ATTRIBUTE_ID)\n" +
                "INNER JOIN PRODUCT.PRODUCT_FEATURE PF                 ON (FAM.PRODUCT_FEATURE_ID        = PF.PRODUCT_FEATURE_ID)\n" +
                "INNER JOIN PRODUCT.PRODUCT_FEATURE_XREF PFX           ON (PFX.FEATURE_ID                = PF.PRODUCT_FEATURE_ID)\n" +
                "INNER JOIN PRODUCT.PRODUCT P                          ON (P.PRODUCT_ID                  = PFX.PRODUCT_ID)\n" +
                "INNER JOIN PRODUCT.SOLUTION_PRODUCT_XREF SPX          ON (SPX.PRODUCT_ID                = PFX.PRODUCT_ID)\n" +
                "INNER JOIN PRODUCT.SOLUTION S                         ON (S.SOLUTION_ID                 = SPX.SOLUTION_ID)\n" +
                "INNER JOIN PRODUCT.CLIENT_OFFER_SOLUTION_XREF COSX    ON (COSX.SOLUTION_ID              = SPX.SOLUTION_ID)\n" +
                "INNER JOIN PRODUCT.CLIENT_OFFER CO                    ON (CO.CLIENT_OFFER_ID            = COSX.CLIENT_OFFER_ID)\n" +
                "INNER JOIN CLIENT.CLIENT_CHANNEL CC                   ON (CO.CLIENT_CHANNEL_ID          = CC.CLIENT_CHANNEL_ID)\n" +
                "INNER JOIN CLIENT.CLIENT C                            ON (CC.CLIENT_ID                  = C.CLIENT_ID)\n" +
                "WHERE C.NAME                        = 'América Móvil' \n" +
                "AND   CC.NAME                       = 'Telcel México' \n" +
                "AND   PF.FEATURE_TYPE_CODE          = 'Service Fee'\n" +
                "AND   FA.ATTRIBUTE_NAME             <> 'UOM'\n" +
                "AND   CO.REGION_CODE                IN ('" + region + "')\n" +
                "AND   FAM.INCIDENT_TYPE_CODE        = '" + incidentType + "'" +
                "AND   CAT.ASSET_CATALOG_ID          = '" + ASSET_CATALOG_ID + "'";

        data = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(environment, dbName), q);

        if (data.size() == 0) {
            System.out.println("expected number of rows not found.Query Used is:\n " + q);
            Assert.assertTrue("No data found in DB.Query Used is:\n" +
                    " \"+q", false);
        } else {
            if (data.get(0).get("INCIDENT TYPE").equalsIgnoreCase(incidentType)) {
                Assert.assertEquals("Verify service Fess :", data.get(0).get("DEDUCTIBLE"), serviceFees);

            }
        }
    }

    /**
     * This method is used for validate the Asset Details for TelCel
     *
     * @param clientOfferName,assetStartDate,color,assetCatlogName,region,environment,dbName Last modified by: Priyanka
     * @author Sachin
     */
    public static boolean validateAssetDetailsForTelCel(String clientOfferName, String assetStartDate, String color, String assetCatlogName, String region, String environment, String dbName) throws Exception {
        boolean flag = true;
        boolean bPassFailFlag = true;
        BasePage.verificationErrors.delete(0, BasePage.verificationErrors.length());

        if (region.equalsIgnoreCase("R09")) {
            PRODUCT_FEATURE_ID = "'Horizon'";
        } else {
            PRODUCT_FEATURE_ID = "<> 'NEWCOFOR-R1TO8'";
        }

        String query = "select  ASSET_CATALOG_NAME, ASSET_CATALOG_DESC,ACTL.ASSET_COLOR_NAME,CLIENT_ASSET_SKU_NAME, CLIENT_ASSET_SKU_NBR,SKU_START_DATE,TIER.TIER_TYPE_CODE,TIER_TYPE_DESC\n" +
                "from    ASSET.ASSET_CATALOG CAT, \n" +
                "        ASSET.ASSET_COLOR ACO,\n" +
                "        ASSET.ASSET_COLOR_TL ACTL,\n" +
                "        ASSET.CLIENT_CHANNEL_ASSET CCA, \n" +
                "        PRODUCT.TIER TIER, \n" +
                "        PRODUCT.TIER_ASSET_CATALOG_XREF TX, \n" +
                "        PRODUCT.TIER_TYPE TT, \n" +
                "        ASSET.ASSET_CTLG_CLNT_CHNL_AST_XREF CCCAX\n" +
                "where   CAT.ASSET_CATALOG_ID  = TX.ASSET_CATALOG_ID\n" +
                "and     TX.TIER_ID            = TIER.TIER_ID\n" +
                "and     TT.TIER_TYPE_CODE     = TIER.TIER_TYPE_CODE\n" +
                "and     cca.client_channel_asset_id = CCCAX.client_channel_asset_id\n" +
                "and     CCCAX.asset_catalog_id = CAT.asset_catalog_id\n" +
                "and     TIER.CLIENT_CHANNEL_ID = '4D810866798C4D748D802BE8AA6059D7'\n" +
                "and     CAT.ASSET_CATALOG_ID = '" + ASSET_CATALOG_ID + "'\n" +
                "--and     TIER.UPDATED_BY      = 'NEWCOFOR-R1TO8' --Region1-8\n" +
                "and     TIER.UPDATED_BY   =  " + PRODUCT_FEATURE_ID + " " +
                "AND     ACO.ASSET_COLOR_ID   = CAT.ASSET_COLOR_ID\n" +
                "AND     ACTL.ASSET_COLOR_ID  = ACO.ASSET_COLOR_ID\n" +
                "AND     ACTL.LANGUAGE_CODE   = 'es-MX'";

        data = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(environment, dbName), query);
        if (data.size() == 0) {
            Assert.assertTrue("No data found in DB.Query Used is:" + query + "", false);
        } else {

            ////////////////////Modification done by Priyanka////////////////////
            //Verify Asset Tier
            // try {
            //verificationErrors.append("\nAsset Tier : Actual value - "+clientOfferName+" Expected value - "+data.get(0).get("TIER_TYPE_CODE"));
            if (clientOfferName.contains(data.get(0).get("TIER_TYPE_CODE")))
                BasePage.verificationErrors.append("\nAsset Tier : Actual value - " + clientOfferName + " Expected value - " + data.get(0).get("TIER_TYPE_CODE"));
            else {
                bPassFailFlag = false;
                BasePage.verificationErrors.append("\nAsset Tier doesn't match : Actual value - " + clientOfferName + " Expected value - " + data.get(0).get("TIER_TYPE_CODE"));
            }
//                catch(AssertionError ae)
//                {
//                    bPassFailFlag = false;
//                }
            //Date
            String dbDate = data.get(0).get("SKU_START_DATE").substring(0, data.get(0).get("SKU_START_DATE").indexOf("."));
            Date formatDate = new SimpleDateFormat("yyyy-M-d", Locale.ENGLISH).parse(dbDate);
            String actualFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).format(formatDate);
            if (assetStartDate.contains(actualFormat))
                BasePage.verificationErrors.append("\nAsset Start Date: Actual value - " + assetStartDate + " Expected value - " + actualFormat);
            else {
                bPassFailFlag = false;
                BasePage.verificationErrors.append("\nAsset Start Date doesn't match : Actual value - " + assetStartDate + " Expected value - " + actualFormat);
            }
            //Verify color
            if (color.toUpperCase().contains(data.get(0).get("ASSET_COLOR_NAME").toUpperCase()))
                BasePage.verificationErrors.append("\n Asset Colour - " + color + ", expected Color: " + data.get(0).get("ASSET_COLOR_NAME"));
            else {
                bPassFailFlag = false;
                BasePage.verificationErrors.append("\n Asset Colour Actual doesn't match - " + color + ", expected Color: " + data.get(0).get("ASSET_COLOR_NAME"));
            }
            //Verify Asset Catlog Name
            if (assetCatlogName.toUpperCase().contains(data.get(0).get("ASSET_CATALOG_NAME").toUpperCase()))
                BasePage.verificationErrors.append("\nAsset Catalog Name -" + assetCatlogName + ", Expected -  " + data.get(0).get("ASSET_CATALOG_NAME"));
            else {
                bPassFailFlag = false;
                BasePage.verificationErrors.append("\n Asset Catalog Name Actual doesn't match -" + assetCatlogName + ", Expected -  " + data.get(0).get("ASSET_CATALOG_NAME"));
            }
            Assert.assertTrue(BasePage.verificationErrors.toString(), bPassFailFlag);
        }


        return flag;


    }


    /**
     * This method is to validate client offer details
     *
     * @author Sachin
     */
    public static void validateClientOfferDetails() throws Exception {
        boolean flag = true;
        boolean bPassFailFlag = true;
        verificationErrors.delete(0, verificationErrors.length());


        String query = "Select CLIENT_OFFER_NAME, SOLUTION_NAME, CO.MINIMUM_PRICE, CO.MAXIMUM_PRICE, \n" +
                "CX.effective_Start_Date, CX.effective_END_date, CO.INVOICE_ACCOUNT_NBR, CO.State_province_code, COP.currency_amount, CO.currency_code\n" +
                "from product.client_offer CO\n" +
                "JOIN PRODUCT.CLIENT_OFFER_SOLUTION_XREF CX ON (CO.client_offer_id = CX.client_offer_ID)\n" +
                "JOIN PRODUCT.SOLUTION S ON (CX.SOLUTION_ID = S.SOLUTION_ID)\n" +
                "JOIN PRODUCT.client_offer_price COP ON (CO.client_offer_id = COP.client_offer_ID)\n" +
                "--JOIN Product.solution_Product_XREF SPX on (S.Solution_ID = SPX.Solution_ID)\n" +
                "--JOIN Product.product P on (SPX.Product_ID = P.Product_ID) \n" +
                "where S.SOLUTION_ID in ('2A57E4B28D776E48E0531A3A060A383D','2A57E4B28D836E48E0531A3A060A383D','2A57E4B28D876E48E0531A3A060A383D', '2D3BD96FA29119BEE053183A060AAD32', '2D3BD96FA2D919BEE053183A060AAD32') \n" +
                "and co.active_IND||s.active_IND = 'YY'";

        data = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        if (data.size() == 0) {
            Assert.assertTrue("No data found in DB.Query Used is:" + query + "", false);
        } else {

            for (int i = 0; i < Asset.clientOfferData.size(); i++) {

                String CLIENT_OFFER_NAME = Asset.clientOfferData.get(i).get("CLIENT_OFFER_NAME");
                String SOLUTION_NAME = Asset.clientOfferData.get(i).get("SOLUTION_NAME");
                String MINIMUM_PRICE = Asset.clientOfferData.get(i).get("MINIMUM_PRICE");
                String MAXIMUM_PRICE = Asset.clientOfferData.get(i).get("MAXIMUM_PRICE");
                String EFFECTIVE_START_DATE = Asset.clientOfferData.get(i).get("EFFECTIVE_START_DATE");
                String EFFECTIVE_END_DATE = Asset.clientOfferData.get(i).get("EFFECTIVE_END_DATE");
                String INVOICE_ACCOUNT_NBR = Asset.clientOfferData.get(i).get("INVOICE_ACCOUNT_NBR");
                String STATE_PROVINCE_CODE = Asset.clientOfferData.get(i).get("STATE_PROVINCE_CODE");
                String CURRENCY_AMOUNT = Asset.clientOfferData.get(i).get("CURRENCY_AMOUNT");
                String CURRENCY_CODE = Asset.clientOfferData.get(i).get("CURRENCY_CODE");
                boolean exitflag = true;

                for (int j = 0; j < data.size(); j++) {

                    try {
                        verificationErrors.append("\nClient Offer Name : Expected value - " + CLIENT_OFFER_NAME + " Actual value - " + data.get(j).get("CLIENT_OFFER_NAME"));
                        Assert.assertTrue("\nClient Offer Name: Expected value " + CLIENT_OFFER_NAME + ", Actual value - " + data.get(j).get("CLIENT_OFFER_NAME"), StringUtils.equalsIgnoreCase(CLIENT_OFFER_NAME, data.get(j).get("CLIENT_OFFER_NAME")));
                    } catch (AssertionError ae) {
                        verificationErrors.append("\n" + ae.getMessage());
                        bPassFailFlag = false;
                        exitflag = false;
                    }
                    //Date
                    String startDateDb = data.get(j).get("EFFECTIVE_START_DATE").substring(0, data.get(j).get("EFFECTIVE_START_DATE").indexOf("."));
                    Date formatDateDb = new SimpleDateFormat("yyyy-M-d", Locale.ENGLISH).parse(startDateDb);
                    String formattedDateDb = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).format(formatDateDb);


                    //EFFECTIVE_START_DATE=EFFECTIVE_START_DATE.substring(0,EFFECTIVE_START_DATE.indexOf("."));
                    Date formatDateExcel = new SimpleDateFormat("yyyy-M-d", Locale.ENGLISH).parse(EFFECTIVE_START_DATE);
                    String EFFECTIVE_START_DATE_Formatted = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).format(formatDateExcel);

                    try {
                        verificationErrors.append("\n EFFECTIVE_START_DATE : Expected value - " + EFFECTIVE_START_DATE_Formatted + " Actual value - " + formattedDateDb);
                        Assert.assertTrue("\nEFFECTIVE_START_DATE : Expected value - " + EFFECTIVE_START_DATE_Formatted + " Actual value - " + formattedDateDb, StringUtils.equalsIgnoreCase(EFFECTIVE_START_DATE_Formatted, formattedDateDb));
                    } catch (AssertionError ae) {
                        verificationErrors.append("\n" + ae.getMessage());
                        bPassFailFlag = false;
                        exitflag = false;
                    }


                    String endDateDb = data.get(j).get("EFFECTIVE_END_DATE").substring(0, data.get(j).get("EFFECTIVE_END_DATE").indexOf("."));
                    Date format = new SimpleDateFormat("yyyy-M-d", Locale.ENGLISH).parse(endDateDb);
                    String actualDate = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).format(format);

                    //EFFECTIVE_END_DATE=EFFECTIVE_END_DATE.substring(0,EFFECTIVE_END_DATE.indexOf("."));
                    Date formatDateExcelendDate = new SimpleDateFormat("yyyy-M-d", Locale.ENGLISH).parse(EFFECTIVE_END_DATE);
                    String EFFECTIVE_END_DATE_Formatted = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).format(formatDateExcelendDate);

                    try {
                        verificationErrors.append("\n EFFECTIVE_END_DATE : Expected value - " + EFFECTIVE_END_DATE_Formatted + " Actual value - " + actualDate);
                        Assert.assertTrue("\nEFFECTIVE_END_DATE : Expected value - " + EFFECTIVE_END_DATE_Formatted + " Actual value - " + actualDate, StringUtils.equalsIgnoreCase(EFFECTIVE_END_DATE_Formatted, actualDate));
                    } catch (AssertionError ae) {
                        verificationErrors.append("\n" + ae.getMessage());
                        bPassFailFlag = false;
                        exitflag = false;
                    }
                    //Verify color
                    try {
                        verificationErrors.append("\nSolution Name Expected: - " + SOLUTION_NAME + ", Actual: " + data.get(j).get("SOLUTION_NAME"));
                        Assert.assertTrue("\n Solution Name - " + SOLUTION_NAME + ", Actual: " + data.get(j).get("SOLUTION_NAME"), StringUtils.equalsIgnoreCase(SOLUTION_NAME, data.get(j).get("SOLUTION_NAME")));
                    } catch (AssertionError ae) {
                        verificationErrors.append(ae.getMessage());
                        bPassFailFlag = false;
                        exitflag = false;
                    }
                    //Verify Asset Catlog Name
                    try {
                        verificationErrors.append("\nMAXIMUM_PRICE Expected -" + MAXIMUM_PRICE + ", Actual -  " + data.get(j).get("MAXIMUM_PRICE"));
                        Assert.assertTrue(" MAXIMUM_PRICE -" + MAXIMUM_PRICE + ", Actual -  " + data.get(j).get("MAXIMUM_PRICE"), StringUtils.equalsIgnoreCase(MAXIMUM_PRICE, data.get(j).get("MAXIMUM_PRICE")));
                    } catch (AssertionError ae) {
                        verificationErrors.append(ae.getMessage());
                        bPassFailFlag = false;
                        exitflag = false;
                    }

                    try {
                        verificationErrors.append("\nMINIMUM_PRICE Expected -" + MINIMUM_PRICE + ", Actual -  " + data.get(j).get("MINIMUM_PRICE"));
                        Assert.assertTrue(" MINIMUM_PRICE -" + MINIMUM_PRICE + ", Actual -  " + data.get(j).get("MINIMUM_PRICE"), StringUtils.equalsIgnoreCase(MINIMUM_PRICE, data.get(j).get("MINIMUM_PRICE")));
                    } catch (AssertionError ae) {
                        verificationErrors.append(ae.getMessage());
                        bPassFailFlag = false;
                        exitflag = false;
                    }

                    try {
                        verificationErrors.append("\nINVOICE_ACCOUNT_NBR Expected -" + INVOICE_ACCOUNT_NBR + ", Actual -  " + data.get(j).get("INVOICE_ACCOUNT_NBR"));
                        Assert.assertTrue(" INVOICE_ACCOUNT_NBR -" + MINIMUM_PRICE + ", Actual -  " + data.get(j).get("INVOICE_ACCOUNT_NBR"), StringUtils.equalsIgnoreCase(INVOICE_ACCOUNT_NBR, data.get(j).get("INVOICE_ACCOUNT_NBR")));
                    } catch (AssertionError ae) {
                        verificationErrors.append(ae.getMessage());
                        bPassFailFlag = false;
                        exitflag = false;
                    }


                    try {
                        verificationErrors.append("\nSTATE_PROVINCE_CODE Expected -" + STATE_PROVINCE_CODE + ", Actual -  " + data.get(j).get("STATE_PROVINCE_CODE"));
                        Assert.assertTrue(" STATE_PROVINCE_CODE -" + MINIMUM_PRICE + ", Actual -  " + data.get(j).get("STATE_PROVINCE_CODE"), StringUtils.equalsIgnoreCase(STATE_PROVINCE_CODE, data.get(j).get("STATE_PROVINCE_CODE")));
                    } catch (AssertionError ae) {
                        verificationErrors.append(ae.getMessage());
                        bPassFailFlag = false;
                        exitflag = false;
                    }

                    try {
                        verificationErrors.append("\nCURRENCY_AMOUNT Expected -" + CURRENCY_AMOUNT + ", Actual -  " + data.get(j).get("CURRENCY_AMOUNT"));
                        Assert.assertTrue(" CURRENCY_AMOUNT -" + CURRENCY_AMOUNT + ", Actual -  " + data.get(j).get("CURRENCY_AMOUNT"), StringUtils.equalsIgnoreCase(CURRENCY_AMOUNT, data.get(j).get("CURRENCY_AMOUNT")));
                    } catch (AssertionError ae) {
                        verificationErrors.append(ae.getMessage());
                        bPassFailFlag = false;
                        exitflag = false;
                    }


                    try {
                        verificationErrors.append("\nCURRENCY_CODE Expected -" + CURRENCY_CODE + ", Actual -  " + data.get(j).get("CURRENCY_CODE"));
                        Assert.assertTrue(" CURRENCY_CODE -" + CURRENCY_CODE + ", Actual -  " + data.get(j).get("CURRENCY_CODE"), StringUtils.equalsIgnoreCase(CURRENCY_CODE, data.get(j).get("CURRENCY_CODE")));
                    } catch (AssertionError ae) {
                        verificationErrors.append(ae.getMessage());
                        bPassFailFlag = false;
                        exitflag = false;
                    }

                    if (exitflag == true)
                        break;

                }

                if (bPassFailFlag == false)
                    flag = false;
            }
            if (bPassFailFlag == false)
                Assert.assertTrue(verificationErrors.toString(), flag);
        }
    }


    /**
     * This method is used to very asset details for nTelos, Claro, Rogers and Fido clients
     *
     * @param clientOfferName  - Tier Name
     * @param assetStartDate
     * @param color
     * @param assetCatlogName
     * @param incidentTypeCode
     * @param environment
     * @param dbName
     * @return
     */

    public static void verifyAssetDetails(String clientOfferName, String assetStartDate, String color, String assetCatlogName, String incidentTypeCode, String environment, String dbName) throws Exception {

        String assetQuery = null;
        verificationErrors.delete(0, verificationErrors.length());
        boolean bPassFailFlag = true;
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos")) {
            PRODUCT_FEATURE_ID = "1E3847806C86301AE05358FE14AC39E4";
            CLIENT_CHANNEL_ID_1 = "13B5241E87B43EB0E05358FE14AC89E6";
            CLIENT_CHANNEL_ID_2 = "13B5241E87BE3EB0E05358FE14AC89E6";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro")) {
            PRODUCT_FEATURE_ID = "0145AA2611054DEF8849233B10011678";
            CLIENT_CHANNEL_ID_1 = "4E816684471E40F58841BEC96E89A37A";
            CLIENT_CHANNEL_ID_2 = "866A1227F5BA412BBEE6185AC5823938";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers")) {
            PRODUCT_FEATURE_ID = "254B40A66A710A6DE053183A060A17DA";
            CLIENT_CHANNEL_ID_1 = "24AB28B802A73342E05358FE14AC8F47";
            CLIENT_CHANNEL_ID_2 = "24AB28B802A83342E05358FE14AC8F47";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Fido")) {
            PRODUCT_FEATURE_ID = "2561D9C495EF2555E053183A060A5F76";
            CLIENT_CHANNEL_ID_1 = "24AB28B802A93342E05358FE14AC8F47";
            CLIENT_CHANNEL_ID_2 = "24AB28B802AA3342E05358FE14AC8F47";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Verizon")) {
            PRODUCT_FEATURE_ID = "2561D9C495EF2555E053183A060A5F76";
            CLIENT_CHANNEL_ID_1 = "1E5CA95819B601D09936005056A72010";
            CLIENT_CHANNEL_ID_2 = "1E5CA95819B601D09936005056A72010";
        }
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos") || ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers") || ApplicationConfiguration.getClient().equalsIgnoreCase("FIdo")) {


            assetQuery = "select CAT.ASSET_CATALOG_ID, CAT.ASSET_CATALOG_NAME, COLOR.ASSET_COLOR_NAME, CCA.CLIENT_ASSET_SKU_NBR, TT.TIER_TYPE_CODE, TX.EFFECTIVE_START_DATE, TX.EFFECTIVE_END_DATE\n" +
                    "from ASSET.ASSET_CATALOG CAT, ASSET.CLIENT_CHANNEL_ASSET CCA, PRODUCT.TIER TIER, PRODUCT.TIER_ASSET_CATALOG_XREF TX, PRODUCT.TIER_TYPE TT, ASSET.ASSET_CTLG_CLNT_CHNL_AST_XREF CCCAX, ASSET.ASSET_COLOR COLOR\n" +
                    "where CAT.ASSET_CATALOG_ID = TX.ASSET_CATALOG_ID\n" +
                    "and TX.TIER_ID = TIER.TIER_ID\n" +
                    "--and TIER.TIER_ID = FAM.TIER_ID\n" +
                    "and TT.TIER_TYPE_CODE = TIER.TIER_TYPE_CODE\n" +
                    "and CCA.CLIENT_CHANNEL_ID = TIER.CLIENT_CHANNEL_ID\n" +
                    "and cca.client_channel_asset_id = CCCAX.client_channel_asset_id\n" +
                    "and CCCAX.asset_catalog_id = CAT.asset_catalog_id\n" +
                    "--and FAM.FEATURE_ATTRIBUTE_MAP_ID = FAX.FEATURE_ATTRIBUTE_MAP_ID\n" +
                    "--and FAX.FEATURE_ATTRIBUTE_ID = FA.FEATURE_ATTRIBUTE_ID\n" +
                    "and COLOR.asset_color_id = CAT.asset_color_id\n" +
                    "--and FAM.product_feature_id = '254B40A66A710A6DE053183A060A17DA'\n" +
                    "and CCA.client_channel_id in('" + CLIENT_CHANNEL_ID_1 + "','" + CLIENT_CHANNEL_ID_2 + "')\n" +
                    "--and FA.attribute_name = 'SERVICE FEE'\n" +
                    "and CAT.asset_catalog_id = '" + ASSET_CATALOG_ID + "'\n" +
                    "order by CAT.asset_catalog_id, tier.created_by";

            /*assetQuery = "select CAT.ASSET_CATALOG_ID, FAM.INCIDENT_TYPE_CODE, CAT.ASSET_CATALOG_NAME, COLOR.ASSET_COLOR_NAME, CCA.CLIENT_ASSET_SKU_NBR, TT.TIER_TYPE_CODE, FA.attribute_name, FA.attribute_value, TX.EFFECTIVE_START_DATE, TX.EFFECTIVE_END_DATE\n" +
                    "from ASSET.ASSET_CATALOG CAT, ASSET.CLIENT_CHANNEL_ASSET CCA, PRODUCT.TIER TIER, PRODUCT.TIER_ASSET_CATALOG_XREF TX, PRODUCT.TIER_TYPE TT, ASSET.ASSET_CTLG_CLNT_CHNL_AST_XREF CCCAX,\n" +
                    "product.feature_attribute_map FAM, PRODUCT.FEATURE_ATTRIBUTE_XREF FAX, product.feature_attribute FA, ASSET.ASSET_COLOR COLOR\n" +
                    "where CAT.ASSET_CATALOG_ID = TX.ASSET_CATALOG_ID\n" +
                    "and TX.TIER_ID = TIER.TIER_ID\n" +
                    "and TIER.TIER_ID = FAM.TIER_ID\n" +
                    "and TT.TIER_TYPE_CODE = TIER.TIER_TYPE_CODE\n" +
                    "and CCA.CLIENT_CHANNEL_ID = TIER.CLIENT_CHANNEL_ID\n" +
                    "and cca.client_channel_asset_id = CCCAX.client_channel_asset_id\n" +
                    "and CCCAX.asset_catalog_id = CAT.asset_catalog_id\n" +
                    "and FAM.FEATURE_ATTRIBUTE_MAP_ID = FAX.FEATURE_ATTRIBUTE_MAP_ID\n" +
                    "and FAX.FEATURE_ATTRIBUTE_ID = FA.FEATURE_ATTRIBUTE_ID\n" +
                    "and COLOR.asset_color_id = CAT.asset_color_id\n" +
                    "and FAM.product_feature_id = '" + PRODUCT_FEATURE_ID + "'\n" +
                    "and CCA.client_channel_id in('" + CLIENT_CHANNEL_ID_1 + "','" + CLIENT_CHANNEL_ID_2 + "')\n" +
                    "and FA.attribute_name = 'SERVICE FEE'\n" +
                    "--and FAM.INCIDENT_TYPE_CODE = '" + incidentTypeCode + "'\n" +
                    "--and TT.TIER_TYPE_CODE= '" + clientOfferName + "'\n" +
                    "and CAT.asset_catalog_id = '" + ASSET_CATALOG_ID + "'\n" +
                    "order by CAT.asset_catalog_id, tier.created_by";*/
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
            assetQuery = "select CAT.ASSET_CATALOG_ID, FAM.INCIDENT_TYPE_CODE, CAT.ASSET_CATALOG_NAME,ACTL.ASSET_COLOR_NAME, CCA.CLIENT_ASSET_SKU_NBR, TT.TIER_TYPE_CODE, FA.attribute_name, FA.attribute_value, TX.EFFECTIVE_START_DATE, TX.EFFECTIVE_END_DATE\n" +
                    "from ASSET.ASSET_CATALOG CAT,ASSET.ASSET_COLOR_TL ACTL,ASSET.CLIENT_CHANNEL_ASSET CCA, PRODUCT.TIER TIER, PRODUCT.TIER_ASSET_CATALOG_XREF TX, PRODUCT.TIER_TYPE TT, ASSET.ASSET_CTLG_CLNT_CHNL_AST_XREF CCCAX,\n" +
                    "product.feature_attribute_map FAM, PRODUCT.FEATURE_ATTRIBUTE_XREF FAX, product.feature_attribute FA, ASSET.ASSET_COLOR COLOR\n" +
                    "where CAT.ASSET_CATALOG_ID = TX.ASSET_CATALOG_ID\n" +
                    "and TX.TIER_ID = TIER.TIER_ID\n" +
                    "and TIER.TIER_ID = FAM.TIER_ID\n" +
                    "and TT.TIER_TYPE_CODE = TIER.TIER_TYPE_CODE\n" +
                    "and CCA.CLIENT_CHANNEL_ID = TIER.CLIENT_CHANNEL_ID\n" +
                    "and cca.client_channel_asset_id = CCCAX.client_channel_asset_id\n" +
                    "and CCCAX.asset_catalog_id = CAT.asset_catalog_id\n" +
                    "and FAM.FEATURE_ATTRIBUTE_MAP_ID = FAX.FEATURE_ATTRIBUTE_MAP_ID\n" +
                    "and FAX.FEATURE_ATTRIBUTE_ID = FA.FEATURE_ATTRIBUTE_ID\n" +
                    "and COLOR.asset_color_id = CAT.asset_color_id\n" +
                    "AND ACTL.ASSET_COLOR_ID = COLOR.ASSET_COLOR_ID\n" +
                    "and FAM.product_feature_id = '" + PRODUCT_FEATURE_ID + "'\n" +
                    "and CCA.client_channel_id in('" + CLIENT_CHANNEL_ID_1 + "','" + CLIENT_CHANNEL_ID_2 + "')\n" +
                    "and FA.attribute_name = 'SERVICE FEE'\n" +
                    "and FAM.INCIDENT_TYPE_CODE = '" + incidentTypeCode + "'\n" +
                    "and TT.TIER_TYPE_CODE= '" + clientOfferName + "'\n" +
                    "and CAT.asset_catalog_id = '" + ASSET_CATALOG_ID + "'\n" +
                    "order by CAT.asset_catalog_id, tier.created_by";
        } else {
            assetQuery = "select CAT.ASSET_CATALOG_ID, FAM.INCIDENT_TYPE_CODE, CAT.ASSET_CATALOG_NAME, COLOR.ASSET_COLOR_NAME, CCA.CLIENT_ASSET_SKU_NBR, TT.TIER_TYPE_CODE, FA.attribute_name, FA.attribute_value, TX.EFFECTIVE_START_DATE, TX.EFFECTIVE_END_DATE\n" +
                    "from ASSET.ASSET_CATALOG CAT, ASSET.CLIENT_CHANNEL_ASSET CCA, PRODUCT.TIER TIER, PRODUCT.TIER_ASSET_CATALOG_XREF TX, PRODUCT.TIER_TYPE TT, ASSET.ASSET_CTLG_CLNT_CHNL_AST_XREF CCCAX,\n" +
                    "product.feature_attribute_map FAM, PRODUCT.FEATURE_ATTRIBUTE_XREF FAX, product.feature_attribute FA, ASSET.ASSET_COLOR COLOR\n" +
                    "where CAT.ASSET_CATALOG_ID = TX.ASSET_CATALOG_ID\n" +
                    "and TX.TIER_ID = TIER.TIER_ID\n" +
                    "and TIER.TIER_ID = FAM.TIER_ID\n" +
                    "and TT.TIER_TYPE_CODE = TIER.TIER_TYPE_CODE\n" +
                    "and CCA.CLIENT_CHANNEL_ID = TIER.CLIENT_CHANNEL_ID\n" +
                    "and cca.client_channel_asset_id = CCCAX.client_channel_asset_id\n" +
                    "and CCCAX.asset_catalog_id = CAT.asset_catalog_id\n" +
                    "and FAM.FEATURE_ATTRIBUTE_MAP_ID = FAX.FEATURE_ATTRIBUTE_MAP_ID\n" +
                    "and FAX.FEATURE_ATTRIBUTE_ID = FA.FEATURE_ATTRIBUTE_ID\n" +
                    "and COLOR.asset_color_id = CAT.asset_color_id\n" +
                    "and CCA.client_channel_id in('" + CLIENT_CHANNEL_ID_1 + "','" + CLIENT_CHANNEL_ID_2 + "')\n" +
                    "and FA.attribute_name = 'SERVICE FEE'\n" +
                    "and TT.TIER_TYPE_CODE= '" + clientOfferName + "'\n" +
                    "and CAT.asset_catalog_id = '" + ASSET_CATALOG_ID + "'\n" +
                    "order by CAT.asset_catalog_id, tier.created_by";
        }


        data = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(environment, dbName), assetQuery);
        if (data.size() == 0) {
            Assert.assertTrue("No data found in DB.Query Used is:\n " + assetQuery + "", false);
        } else {
                /*
                Assert.assertEquals("Verify Asset Tier :", data.get(0).get("TIER_TYPE_CODE"), clientOfferName.toUpperCase());


                String dbDate = data.get(0).get("SKU_START_DATE").substring(0, data.get(0).get("SKU_START_DATE").indexOf("."));
                Date formatDate = new SimpleDateFormat("yyyy-M-d", Locale.ENGLISH).parse(dbDate);
                String actualFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).format(formatDate);

                Assert.assertEquals("Verify Asset Start Date :",actualFormat, assetStartDate);


                //Assert.assertEquals("Verify Asset Start Date :", data.get(0).get("SKU_START_DATE"), assetStartDate);

                //Verify color
                Assert.assertEquals("Verify Asset Color :", data.get(0).get("ASSET_COLOR_NAME"), color);

                //Verify Asset Catlog Name
                Assert.assertEquals("Verify Asset Catalog Name :", data.get(0).get("ASSET_CATALOG_NAME").toUpperCase(), assetCatlogName.toUpperCase());

                //Verify CLIENT ASSET SKU NAME
               */
             /*if(data.get(0).get("CLIENT_ASSET_SKU_NAME").equalsIgnoreCase(assetSkuName)){
                 System.out.println("Asset start date is "+data.get(0).get("CLIENT_ASSET_SKU_NAME")+" is as expected "+assetSkuName);
			 }
			 else{
				 flag = false;
				 System.out.println("Asset start date is "+data.get(0).get("CLIENT_ASSET_SKU_NAME")+" is not as expected "+assetSkuName);
			 }*/
            try {
                verificationErrors.append("\nAsset Tier : Actual value - " + clientOfferName.toUpperCase() + " Expected value - " + data.get(0).get("TIER_TYPE_CODE"));
                Assert.assertTrue("\nAsset Tier match : Actual value - " + clientOfferName + " Expected value - " + data.get(0).get("TIER_TYPE_CODE"), clientOfferName.contains(data.get(0).get("TIER_TYPE_CODE")));
            } catch (AssertionError ae) {
                verificationErrors.append("\n " + ae.getMessage());
                bPassFailFlag = false;
            }
            //Date
            String dbDate = data.get(0).get("EFFECTIVE_START_DATE").substring(0, data.get(0).get("EFFECTIVE_START_DATE").indexOf("."));
            Date formatDate = new SimpleDateFormat("yyyy-M-d", Locale.ENGLISH).parse(dbDate);
            Date effectiveStartDate = new SimpleDateFormat("yyyy-M-d", Locale.ENGLISH).parse(assetStartDate);
            String startDate = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).format(effectiveStartDate);
            String actualFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).format(formatDate);
            try {
                verificationErrors.append("\n Asset Start Date : Actual value - " + actualFormat + " Expected value - " + startDate);
                Assert.assertTrue("\nAsset Start Date match : Actual value - " + startDate + " Expected value - " + actualFormat, startDate.contains(actualFormat));
            } catch (AssertionError ae) {
                verificationErrors.append("\n" + ae.getMessage());
                bPassFailFlag = false;
            }
            //Verify color
            try {
                verificationErrors.append("\nAsset Colour Actual - " + color + ", expected Color: " + data.get(0).get("ASSET_COLOR_NAME"));
                Assert.assertTrue("\nAsset Color match : Actual- " + color + ", expected Color - " + data.get(0).get("ASSET_COLOR_NAME"), color.toUpperCase().contains(data.get(0).get("ASSET_COLOR_NAME").toUpperCase()));
            } catch (AssertionError ae) {
                verificationErrors.append(ae.getMessage());
                bPassFailFlag = false;
            }
            //Verify Asset Catlog Name
            try {
                verificationErrors.append("\nAsset Catalog Name Actual -" + assetCatlogName + ", Expected -  " + data.get(0).get("ASSET_CATALOG_NAME"));
                Assert.assertTrue("\nAsset Catalog Name match : Actual -" + assetCatlogName + ", Expected -  " + data.get(0).get("ASSET_CATALOG_NAME"), assetCatlogName.toUpperCase().contains(data.get(0).get("ASSET_CATALOG_NAME").toUpperCase()));
            } catch (AssertionError ae) {
                verificationErrors.append(ae.getMessage());
                bPassFailFlag = false;
            }
            if (bPassFailFlag == false)
                Assert.assertTrue(verificationErrors.toString(), bPassFailFlag);
             /*   else
                    AutomationHooks.scenarioWrite.write(verificationErrors.toString());*/

        }
        //System.out.println(data);


    }

    /**
     * This method is used to verify asset details for Claro Peru client
     * Created By Kapil Gonjari
     *
     * @param custermerData
     * @param rowIndex
     * @return
     */
    public static void verifyAssetDetails_Latam(HashMap<String, String> custermerData, int rowIndex) throws Exception {

        String assetQuery = "\n" +
                "SELECT  C.NAME CLIENT, CC.NAME CLIENT_CHANNEL, CO.REGION_CODE, CP.CLIENT_PRODUCT_RETAIL_NAME, CP.CLIENT_PRODUCT_SKU_NBR, TR.TIER_TYPE_CODE, CO.CLIENT_OFFER_NAME,\n" +
                "        CCA.CLIENT_ASSET_SKU_NAME, CCA.CLIENT_ASSET_SKU_NBR, ACL.ASSET_COLOR_NAME, AC.ASSET_CATALOG_NAME, FAM.INCIDENT_TYPE_CODE, FA.ATTRIBUTE_VALUE  \n" +
                "FROM       ASSET.ASSET_CATALOG AC                             \n" +
                "INNER JOIN ASSET.ASSET_COLOR   ACL                            ON (AC.ASSET_COLOR_ID             = ACL.ASSET_COLOR_ID)\n" +
                "INNER JOIN PRODUCT.FEATURE_ATTRIBUTE_MAP FAM                  ON (AC.ASSET_CATALOG_ID           = FAM.ASSET_CATALOG_ID)\n" +
                "INNER JOIN PRODUCT.FEATURE_ATTRIBUTE_XREF FAX                 ON (FAM.FEATURE_ATTRIBUTE_MAP_ID  = FAX.FEATURE_ATTRIBUTE_MAP_ID)\n" +
                "INNER JOIN PRODUCT.FEATURE_ATTRIBUTE FA                       ON (FAX.FEATURE_ATTRIBUTE_ID      = FA.FEATURE_ATTRIBUTE_ID)\n" +
                "INNER JOIN PRODUCT.PRODUCT_FEATURE PF                         ON (FAM.PRODUCT_FEATURE_ID        = PF.PRODUCT_FEATURE_ID)\n" +
                "INNER JOIN PRODUCT.PRODUCT_FEATURE_XREF PFX                   ON (PFX.FEATURE_ID                = PF.PRODUCT_FEATURE_ID)\n" +
                "INNER JOIN PRODUCT.SOLUTION_PRODUCT_XREF SPX                  ON (SPX.PRODUCT_ID                = PFX.PRODUCT_ID)\n" +
                "INNER JOIN PRODUCT.CLIENT_OFFER_SOLUTION_XREF COSX            ON (COSX.SOLUTION_ID              = SPX.SOLUTION_ID)\n" +
                "INNER JOIN PRODUCT.CLIENT_OFFER CO                            ON (CO.CLIENT_OFFER_ID            = COSX.CLIENT_OFFER_ID)\n" +
                "INNER JOIN CLIENT.CLIENT_CHANNEL CC                           ON (CO.CLIENT_CHANNEL_ID          = CC.CLIENT_CHANNEL_ID)\n" +
                "INNER JOIN CLIENT.CLIENT C                                    ON (CC.CLIENT_ID                  = C.CLIENT_ID)\n" +
                "INNER JOIN PRODUCT.TIER_ASSET_CATALOG_XREF TACX               ON AC.ASSET_CATALOG_ID = TACX.ASSET_CATALOG_ID\n" +
                "INNER JOIN PRODUCT.TIER TR                                    ON TACX.TIER_ID = TR.TIER_ID AND TACX.EFFECTIVE_END_DATE >= SYSDATE \n" +
                "INNER JOIN PRODUCT.CLIENT_OFFER_TIER_XREF COTX                ON COTX.TIER_ID = TR.TIER_ID AND COTX.EFFECTIVE_END_DATE >= SYSDATE AND CO.CLIENT_OFFER_ID = COTX.CLIENT_OFFER_ID\n" +
                "INNER JOIN ASSET.ASSET_CTLG_CLNT_CHNL_AST_XREF ACCCAX         ON AC.ASSET_CATALOG_ID = ACCCAX.ASSET_CATALOG_ID AND ACCCAX.EFFECTIVE_END_DATE >= SYSDATE \n" +
                "INNER JOIN ASSET.CLIENT_CHANNEL_ASSET CCA                     ON ACCCAX.CLIENT_CHANNEL_ASSET_ID = CCA.CLIENT_CHANNEL_ASSET_ID AND NVL(CCA.SKU_END_DATE,SYSDATE+1) >= SYSDATE \n" +
                "INNER JOIN PRODUCT.CLIENT_PRODUCT_CLIENT_OFR_XREF CPCOX       ON CPCOX.CLIENT_OFFER_ID = COTX.CLIENT_OFFER_ID AND CPCOX.EFFECTIVE_END_DATE >= SYSDATE \n" +
                "INNER JOIN PRODUCT.CLIENT_PRODUCT CP                          ON CP.CLIENT_PRODUCT_ID = CPCOX.CLIENT_PRODUCT_ID \n" +
                "WHERE SYSDATE BETWEEN FAX.EFFECTIVE_START_DATE AND FAX.EFFECTIVE_END_DATE\n" +
                "AND   FA.ATTRIBUTE_NAME                                   = 'SERVICE FEE'\n" +
                "AND   PF.FEATURE_TYPE_CODE                                = 'Service Fee'\n" +
                "AND   CO.REGION_CODE                                      = 'LIMA'\n" +
                "AND   CC.CLIENT_CHANNEL_NBR                               = '7770103'\n" +
                "AND   C.CLIENT_NBR                                        = '110012'\n" +
                "\n" +
                "--AND   AC.ASSET_CATALOG_NAME                               = 'Apple S106BLN'--<change as per ur asset>\n" +
                "ORDER BY AC.ASSET_CATALOG_NAME\n";


        ArrayList<HashMap<String, String>> eventsResult = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), assetQuery);

        if (eventsResult.size() == 0) {
            Assert.assertTrue("No data found in DB.Query Used is:\n " + assetQuery + "", false);
        } else {
            Assert.assertEquals("Asset Catalog name not matched", eventsResult.get(rowIndex).get("ASSET_CATALOG_NAME"), CustomerDetails.customerData.get("ASSET_CATALOG_NAME"));
            Assert.assertEquals("Incident Type not Found", eventsResult.get(rowIndex).get("INCIDENT_TYPE_CODE"), CustomerDetails.customerData.get("INCIDENT_TYPE_CODE"));
            Assert.assertEquals("Deductible do not match", eventsResult.get(rowIndex).get("ATTRIBUTE_VALUE"), CustomerDetails.customerData.get("ATTRIBUTE_VALUE"));
            Assert.assertEquals("Client offer name do not match", eventsResult.get(rowIndex).get("CLIENT_OFFER_NAME"), CustomerDetails.customerData.get("CLIENT_OFFER_NAME"));
            Assert.assertEquals("Client offer name do not match", eventsResult.get(rowIndex).get("CLIENT_PRODUCT_SKU_NBR"), CustomerDetails.customerData.get("CLIENT_PRODUCT_SKU_NBR"));

        }


    }


}