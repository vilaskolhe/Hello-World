package com.asurion.pages;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import org.junit.Assert;

public class IncidentFulfillmentPage extends BasePage {

    private UIElement continueButtonAccessories = new UIElement(UIType.Button, UILocatorType.Xpath, "/html/body/div[2]/form/div[3]/div/table/tbody/tr/td/div/div/span/div/div/table/tbody/tr[2]/td/div/table[2]/tbody/tr[2]/td/table/tbody/tr/td/div/span/table/tbody/tr/td[2]/div/div/div/table/tbody/tr/td/nobr/span/button");
    private UIElement selectSnrFeeYes = new UIElement(UIType.RadioButton, UILocatorType.CSS, "#AdditionalChargeAuthorizedtrue");
    private UIElement selectSnrFeeNo = new UIElement(UIType.RadioButton, UILocatorType.CSS, "#AdditionalChargeAuthorizedfalse");
    //private UIElement submitOrder = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='CT']/button");
    private UIElement submitOrder = new UIElement(UIType.Button, UILocatorType.CSS, "button.Hoz_New_Continue_Btn.pzhc");
    private UIElement replacementEquipment1 = new UIElement(UIType.Button, UILocatorType.CSS, "div[id='RULE_KEY'] table[id='hoz_ReplacementDeviceMultiViewAlt'] tr:nth-of-type(1) td:nth-of-type(3) div[id='RULE_KEY'] button[class='Multiview_Select_Device pzhc']");
    private UIElement replacementEquipment4 = new UIElement(UIType.Button, UILocatorType.Name, "ReplacementDeviceSelectBtn_ReplacementDetails.ReplacementItemDetailList(2)_1");

    private UIElement cpmInteractionDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmInteractionDivFrame");
    private UIElement caseNumberEU = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-test-id='2015081013593405235772']");

    private UIElement cpmTabbedNavigationDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    private UIElement diaction = new UIElement(UIType.Frame, UILocatorType.Name, "DIACTION");
    private UIElement clientStoreCity = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedClientStoreCity");
    private UIElement clientStoreZip = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedClientStoreZip");
    //claro store objects
    // private UIElement claroStoreButton= new UIElement(UIType.Link, UILocatorType.Link, "Tab2");
    private UIElement clientStoreState = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedClientStoreState");
    private UIElement clientStoreRegion = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedClientStoreRegion");

    private UIElement clientClaroStoreAddress = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='$PClientStoreFilteredList$ppxResults$l1']/td[3]/div/span/button");
    private UIElement clientClaroStoreAddress_LA = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']//div[@id='PEGA_GRID_CONTENT']//tr[@pl_index='1']/td[3]//button[@class='InFormContinueButton pzhc']");
    private UIElement changeClaroStoreAddress = new UIElement(UIType.Button, UILocatorType.Xpath, "(//button[@type='button'])[7]");

    private UIElement useEnteredAddressButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[3]/div/div/div[1]/div/div/div/div/div[3]//span/button");
    private UIElement suggesteddAddressButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[3]/div/div/div[2]/div/div/div/div//button");
    private UIElement suggestedAddress = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[3]//div[2]//div[2]//div[@id='RULE_KEY']/div/div/div/div[4]/div/div/div/div/div[1]");
    private UIElement fullsuggestedAddress = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[3]//div[2]//div[2]//div[@id='RULE_KEY']/div/div/div/div[4]/div/div/div/div");

    // private UIElement storeAddress = new UIElement(UIType.Button, UILocatorType.Xpath, "(//button[@class=\"InFormContinueButton pzhc\"])[2]");
    private UIElement storeAddress = new UIElement(UIType.Button, UILocatorType.Xpath, "(//button[@class='InFormContinueButton pzhc'])[1]");
    private UIElement confirmationMessage = new UIElement(UIType.Label, UILocatorType.CSS, ".content.layout-content-default.content-default.hoz_sayTxtColOne");
    private UIElement endofclaimConfirmation = new UIElement(UIType.Label, UILocatorType.CSS, "div[id='CT']>div>div>div>div>div[class='content-item content-paragraph item-1   ']>div");
    private UIElement overrideAndCountinue = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='CT']/div/div/span/button");

    private UIElement addAddress = new UIElement(UIType.Link, UILocatorType.Link, "Add Address");
    // private UIElement overrideButtonResi = new UIElement(UIType.Button,UILocatorType.Xpath,"//div[@id='RULE_KEY']/div[2]/div[1]/div[1]/div[1]/div[1]//span/div[@id='CT']/button");
    private UIElement validateButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[@name='EnterNewAddressWrapper_pyWorkPage_13']");
    private UIElement validateAndContinueButton = new UIElement(UIType.Button, UILocatorType.CSS, "button.InFormContinueButton.pzhc");
    private UIElement validateAndContinueButtonnTelos = new UIElement(UIType.Button, UILocatorType.CSS, "table[id='pyActionArea'] table:nth-of-type(1) div[id='pyFlowActionHTML'] div[id='RULE_KEY'] div:nth-of-type(2) button.InFormContinueButton.pzhc");
    // private UIElement validateAndContinueButtonnTelos = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='CT']/div/div/div/div[2]/div/div/div/div/div/div/div/span/button");
    // private UIElement button = new UIElement(UIType.Button, UILocatorType.CSS, "#CT>divdiv>div>div.content-item.content-layout.item-2>div>div>div>div>div>div>div>span>button>div>div>div>div");
    private UIElement signatureRequired = new UIElement(UIType.CheckBox, UILocatorType.ID, "SignatureRequired");
    private UIElement validateAndContinueOverrideButtonnTelos = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='CT']/div/div/div/div[2]//span/button");
    //Out of Matrix
    private UIElement outOfMatrix = new UIElement(UIType.Link, UILocatorType.Xpath, "//li[@id='Tab2']/a");
    //private UIElement outOfMatrix = new UIElement(UIType.Link, UILocatorType.Link, "Out of Matrix");
    private UIElement selectAssetMake = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedOOMAssetMake");
    private UIElement selectAssetModel = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedOOMAssetModel");
    private UIElement selectAssetColor = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedOOMAssetCatalogID");
    private UIElement backOrderDeviceStatus = new UIElement(UIType.Button, UILocatorType.Xpath, "//table[@id='hoz_ReplacementDeviceMultiViewAlt']/tbody/tr[1]/td[2]//nobr/label");
    //private UIElement searchEquipment = new UIElement(UIType.Button, UILocatorType.Xpath, "//table[@id='hoz_outOfMatrixSearchCriteriaWrapper']//tr[2]/td[5]//button");
    private UIElement searchEquipment = new UIElement(UIType.Button, UILocatorType.Xpath, "//table[@id='hoz_outOfMatrixSearchCriteriaWrapper']//tr[2]/td[6]//button");
    private UIElement selectEquipment = new UIElement(UIType.Button, UILocatorType.CSS, ".field-item.dataValueWrite button.Multiview_Select_Device.pzhc");
    //selectaccesory
    private UIElement newOutOFMatrix = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "(//div[@id='RULE_KEY']//div/span[2]/input[@id='ManualReplacementTypeFilterALL_TYPES_NEW_ONLY'])[2]");
    private UIElement acessaryCheck = new UIElement(UIType.Label, UILocatorType.Xpath, "//input[@id='IsSelected1_rdi_1']");

    private UIElement Address1 = new UIElement(UIType.Label, UILocatorType.Xpath, "(//div[@id='CT']/div/div/span)[2]");
    private UIElement Address2 = new UIElement(UIType.Label, UILocatorType.Xpath, "(//div[@id='CT']/div/div/span)[3]");
    private UIElement saveAndContinueStoreAddress = new UIElement(UIType.Button, UILocatorType.CSS, "table[id='pyActionArea'] table:nth-of-type(1) div[id='pyFlowActionHTML'] div[id='RULE_KEY'] div:nth-of-type(2) button.InFormContinueButton.pzhc");

    //BTA
    private UIElement validateContinueEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='201605231550070406179179']");
    private UIElement residentAddressType = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "//input[@id='SelectShippingAddrTypeSHPNG']");
    private UIElement useThisAddress = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div[1]/div/div/div[3]/div/div/div/div/div/div/div/span/button/div/div/div/div");
    private UIElement lastName = new UIElement(UIType.TextBox, UILocatorType.ID, "LastName");

    private UIElement replacementEquipmentEU = new UIElement(UIType.Button, UILocatorType.CSS, "button.Multiview_Select_Device.pzhc");
    private UIElement radioYes = new UIElement(UIType.Button, UILocatorType.ID, "AdditionalChargeAuthorizedtrue");
    private UIElement buttonSubmitOrder = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='201506021600060859176907']");
    private UIElement buttonConfirmOrder = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='20150709092007013029303']");
    private UIElement overrideButtonEU = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='CT']/div/div/span/button");
    private UIElement yesdeviceActivationradiobutton = new UIElement(UIType.RadioButton, UILocatorType.Xpath, "//*[@id='DeviceActivationtrue_rdi_1']");


    private ActionPage actionPage;
    private HomePage homePage;
    private IdentifyCustomerPage identifyCustomerPage;
    private IncidentPathPage incidentPathPage;
    private EndCallPage EndCallPage;
    private PaymentPage creditCardTokenPage;
    public static String deviceMake;
    public static String deviceModel;
    public static String deviceColor;
    public static String storeAddress1 = "";
    public static String storeAddress2 = "";


    public IncidentFulfillmentPage() {
        actionPage = new ActionPage();
        homePage = new HomePage();
        identifyCustomerPage = new IdentifyCustomerPage();
        incidentPathPage = new IncidentPathPage();
        EndCallPage = new EndCallPage();
        creditCardTokenPage = new PaymentPage();

    }

    /////////
    public void select_replacement_equipment() throws Exception {
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment method)", false);
        if (driver.checkObjectExists(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("diaction is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment method)", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment method)", false);

        // select acessary
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("fido")) {
            if (driver.waitForElementPresenceWithTimeOut(acessaryCheck, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(acessaryCheck);
        }
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("sprint")) {
            if (driver.waitForElementPresenceWithTimeOut(yesdeviceActivationradiobutton, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(yesdeviceActivationradiobutton);
            }else
                System.out.println("Device activation radio button not found");
        }
        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(replacementEquipment1, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.javaScriptClick(replacementEquipment1);
        else
            Assert.assertTrue("replacementEquipment1 is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment method)", false);
    }

    /**
     * This method is used to check claim has been submitted or not.
     * Verify confirmation Message with Claim Id.
     *
     * @author Sachin
     * Modified by prabhat.das on 03/02/2016
     * Modification: changed the logic for handling Casenumbers
     * Modified by Priyanka on 13/05/2016
     * Modification: handle hold release for step
     */
    public void checkClaim() throws Exception {
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            if (BasePage.sPaymentCard != "" && BasePage.sPaymentCard != null) {
                if (actionPage.checkHold()) {
                    actionPage.releaseHold(CustomerDetails.customerData.get("MDN"));

                    // EndCallPage.endCall("Holds", "System Placed Hold");

                    System.out.println("end call Env " + ApplicationConfiguration.getClient());
                    if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
                        EndCallPage.endCall("Holds", "System Placed Hold");
                    } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                        EndCallPage.endCallWithIntentAreaAndOutcome("Call Handling", "Status Inquiry", "Claim History");
                    }

                    homePage.checkCallButton();
                    homePage.pressStart();

                    if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
                        homePage.selectClient("Telcel Mexico");
                    } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                        //System.out.println("ntelos");
                        homePage.selectClient("nTelos");
                    } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro")) {
                        homePage.selectClient("Claro Colombia");
                    }
                    identifyCustomerPage.searchUsingMDN(CustomerDetails.customerData.get("MDN"));
                    identifyCustomerPage.verifyCaller("Account Holder", "valid");
                    identifyCustomerPage.continueClaim();
                    incidentPathPage.select_incident_path("Resume Incident");
                    CommonUtilities.waitTime(15);

                    creditCardTokenPage.enterThePaymentDetails(BasePage.sPaymentCard);
                    clickSubmitOrder();
                }
            }

        }


      /*  driver.navigateToFrame(cpmInteractionDivFrame);
        navigateLowestLevelFrame(diaction);
        driver.switchToFrame(cpmTabbedNavigationDivFrame);*/
        CommonUtilities.waitTime(4);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(clickSubmitOrder method)", false);

        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(clickSubmitOrder method)", false);

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(clickSubmitOrder method)", false);


        if (!driver.waitForElementPresenceWithTimeOut(confirmationMessage, 80))
            Assert.assertTrue("confirmationMessage is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(checkClaim method)", false);
        else {
            Assert.assertTrue("confirmationMessage is not found, instead verified " + ApplicationConfiguration.getClient() + " agent instruction scripts", driver.getText(endofclaimConfirmation).contains("Verify the customer does not need any further assistance, and choose the appropriate end call reason"));
        }
//                assertEquals("Checking expected confirmation message", "The claim has been submitted successfully. Case number: " + CustomerDetails.customerData.get("CASENUMBER") + "", driver.getText(confirmationMessage));
        //driver.click(continueButton);
        //  driver.waitForElementPresence(accountHomePage);
           /* else {
                if(!CaptureIncidentPage.casenumbers.containsKey("CASENUMBER1"))
                {
                    if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER")) {
                        assertEquals("Checking expected confirmation message", "The claim has been submitted successfully. Case number: " + CaptureIncidentPage.casenumbers.get("CASENUMBER") + "", driver.getText(confirmationMessage));
                    }
                }
                else {
                    if (!CaptureIncidentPage.casenumbers.get("CASENUMBER").equalsIgnoreCase(CaptureIncidentPage.claimId) && !CaptureIncidentPage.casenumbers.containsKey("CASENUMBER2") ) {
                        assertEquals("Checking expected confirmation message", "The claim has been submitted successfully. Case number: " + CaptureIncidentPage.casenumbers.get("CASENUMBER1") + "", driver.getText(confirmationMessage));
                    }
                }
                if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER1") && !CaptureIncidentPage.casenumbers.get("CASENUMBER1").equalsIgnoreCase(CaptureIncidentPage.claimId)) {
                    assertEquals("Checking expected confirmation message", "The claim has been submitted successfully. Case number: " + CaptureIncidentPage.casenumbers.get("CASENUMBER2") + "", driver.getText(confirmationMessage));
                }
            }
            */


    }

    /**
     * Using this method click on submit order button
     *
     * @author Sachin
     */
    /////
    public void clickSubmitOrder() throws Exception {
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(clickSubmitOrder method)", false);

        navigateLowestLevelFrame(diaction);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(clickSubmitOrder method)", false);
        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(submitOrder, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.javaScriptClick(submitOrder);
        else
            Assert.assertTrue("submitOrder is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(clickSubmitOrder method)", false);
    }


    /**
     * This method is used to select enrolled shipping address
     * validate and override if required
     *
     * @author Sachin
     * Modification by : Priyanka
     * Modify the the code to select enrolled address for ntelos client
     * date  15/6/2016 Modify the the code to select enrolled address UAT/Prod Env
     */
    ////////////////////
    public void select_shipping_address() throws Exception {

        CommonUtilities.waitTime(4);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_shipping_address method)", false);
        if (driver.checkObjectExists(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.switchToFrame(diaction);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmTabbedNavigationDivFrame 1 is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_shipping_address method)", false);
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
            if (driver.waitForElementPresenceWithTimeOut(Address1, 5)) {
                storeAddress1 = driver.getText(Address1);
                if (driver.checkObjectExists(Address2, 5)) {
                    storeAddress2 = driver.getText(Address2);
                }
            }
        }
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos")) {
            if (driver.checkObjectExists(validateAndContinueButtonnTelos, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.waitAndClick(validateAndContinueButtonnTelos);
            else
                Assert.assertTrue("validateAndContinueButtonnTelos is not found for " + ApplicationConfiguration.getClient() + " on address selection page  validateAndContinue Button not found", false);

        } else {
            CommonUtilities.waitTime(1);
            if (driver.checkObjectExists(validateAndContinueButton, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(validateAndContinueButton);
        }


        if (ApplicationConfiguration.getClient().equalsIgnoreCase("TELCEL") || ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos")) {
            driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("cpmInteractionDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_shipping_address method)", false);
            if (driver.checkObjectExists(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.switchToFrame(diaction);
            if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("cpmTabbedNavigationDivFrame 1 is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_shipping_address method)", false);

            if (!driver.waitForElementPresenceWithTimeOut(lastName, 20)) {
                if (driver.waitForElementPresenceWithTimeOut(suggesteddAddressButton, 10)) {
                    if (driver.checkObjectExists(fullsuggestedAddress, 15))
                        BasePage.autoCorrectAddress = driver.getText(fullsuggestedAddress);
                    driver.javaScriptClick(suggesteddAddressButton);
                    driver.switchToDefaultContent();
                    if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                        Assert.assertTrue("cpmInteractionDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_shipping_address method)", false);
                    if (driver.checkObjectExists(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                        driver.switchToFrame(diaction);
                    if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                        Assert.assertTrue("cpmTabbedNavigationDivFrame 1 is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_shipping_address method)", false);

                    if (driver.waitForElementPresenceWithTimeOut(validateAndContinueButtonnTelos, 15))
                        driver.javaScriptClick(validateAndContinueButtonnTelos);
                }
            }

        }
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(overrideAndCountinue, 10)) {
            if (driver.checkObjectExists(lastName, 10)) {
                String sLastName = driver.getAttribute(lastName, "value");
                if (sLastName == null || sLastName.length() == 0) {
                    driver.type(lastName, CustomerDetails.customerData.get("LASTNAME"));
                    driver.tabOutOf(lastName);
                }
            }
            if (driver.waitForElementPresenceWithTimeOut(overrideAndCountinue, 20))
                driver.javaScriptScrollAndClick(overrideAndCountinue);
            if (driver.waitForElementPresenceWithTimeOut(validateAndContinueButtonnTelos, 15))
                driver.waitAndClick(validateAndContinueButtonnTelos);
        }
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            if (driver.waitForElementPresenceWithTimeOut(validateAndContinueButtonnTelos, 7))
                driver.waitAndClick(validateAndContinueButtonnTelos);
        }
    }


    /* This method is used to used to select the replacement device from Out of matrix.
       Param : make, model, color and device condition.
       Created By: prabhat.das
       Date : 03/23/2016
    */
    ////
    public void select_replacement_equipment_with_make_model_and_color_outofmatrix(String make, String
            model, String color, String condition) throws Exception {
        deviceMake = make;
        deviceModel = model;
        deviceColor = color;


        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment_with_make_model_and_color_outofmatrix method)", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment_with_make_model_and_color_outofmatrix method)", false);
        // if (ApplicationConfiguration.getClient().equalsIgnoreCase("claro") || ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
                /*if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                    Assert.assertTrue("diaction is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment_with_make_model_and_color_outofmatrix method)", false);
           // }*/
        driver.switchToFrame(cpmTabbedNavigationDivFrame);
        if (driver.waitForElementPresenceWithTimeOut(outOfMatrix, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.javaScriptClick(outOfMatrix);
        else
            Assert.assertTrue("outOfMatrix is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment_with_make_model_and_color_outofmatrix method)", false);

        CommonUtilities.waitTime(2);
        if (driver.checkObjectExists(selectAssetMake, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.select(selectAssetMake, make);
        else
            Assert.assertTrue("selectAssetMake is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment_with_make_model_and_color_outofmatrix method)", false);

        CommonUtilities.waitTime(2);
        if (driver.checkObjectExists(selectAssetModel, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.select(selectAssetModel, model);
        else
            Assert.assertTrue("selectAssetModel is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment_with_make_model_and_color_outofmatrix method)", false);

        CommonUtilities.waitTime(2);
        if (driver.checkObjectExists(selectAssetColor, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.select(selectAssetColor, color);
        else
            Assert.assertTrue("selectAssetColor is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment_with_make_model_and_color_outofmatrix method)", false);
        CommonUtilities.waitTime(5);
        if (condition.equalsIgnoreCase("New")) {
            if (driver.checkObjectExists(newOutOFMatrix, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(newOutOFMatrix);
            else
                Assert.assertTrue("newOutOFMatrix radio button is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_device_with_make_model_and_color_outofmatrix method)", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(searchEquipment, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.javaScriptClick(searchEquipment);
        else
            Assert.assertTrue("searchEquipment is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment_with_make_model_and_color_outofmatrix method)", false);

        if (driver.waitForElementPresenceWithTimeOut(selectEquipment, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.javaScriptClick(selectEquipment);
        else
            Assert.assertTrue("selectEquipment is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(select_replacement_equipment_with_make_model_and_color_outofmatrix method)", false);


    }

    /**
     * Using this method click on SNR fee and submit order button
     *
     * @author Shweta
     */
    public void clickSubmitOrderWithSNRFee(String snrFee) throws Exception {
        CommonUtilities.waitTime(10);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on review order page", false);
        }
        // navigateLowestLevelFrame(diaction);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on review order page", false);
        }

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found on review order page", false);
        }

        if (snrFee.equalsIgnoreCase("YES")) {
            CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(selectSnrFeeYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(selectSnrFeeYes);
            } else {
                Assert.assertTrue("SnrFeeYes radio button is not found on review order page", false);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(selectSnrFeeNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(selectSnrFeeNo);
            } else {
                Assert.assertTrue("SnrFeeNo radio button is not found on review order page", false);
            }
        }
        if (driver.waitForElementPresenceWithTimeOut(submitOrder, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(submitOrder);
        } else {
            Assert.assertTrue("submit Order button is not found on review order page", false);
        }
    }

    public void selectStoreAddress() throws Exception {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmInteractionDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("diaction is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);

        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro")) {
            CommonUtilities.waitTime(8);
            if (driver.checkObjectExists(clientStoreRegion, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(clientStoreRegion, "Occidente");
            else
                Assert.assertTrue("clientStoreRegion is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);

            if (driver.waitForElementPresenceWithTimeOut(clientStoreState, ApplicationConfiguration.getWaitForElementTimeout())) {
                CommonUtilities.waitTime(1);
                driver.select(clientStoreState, "CO-ANT");
            } else
                Assert.assertTrue("clientStoreState is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
            if (driver.waitForElementPresenceWithTimeOut(clientStoreCity, ApplicationConfiguration.getWaitForElementTimeout())) {
                CommonUtilities.waitTime(1);
                driver.select(clientStoreCity, "Caucasia");
            } else
                Assert.assertTrue("clientStoreCity is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);

            CommonUtilities.waitTime(3);

            if (driver.waitForElementPresenceWithTimeOut(clientClaroStoreAddress, ApplicationConfiguration.getWaitForElementTimeout())) {
                CommonUtilities.waitTime(1);
                driver.javaScriptClick(clientClaroStoreAddress);
            } else
                Assert.assertTrue("clientClaroStoreAddress is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro Peru")) {
            if (driver.checkObjectExists(clientStoreRegion, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(clientStoreRegion, CustomerDetails.customerData.get("REGION"));
            else
                Assert.assertTrue("clientStoreRegion is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);

            if (driver.waitForElementPresenceWithTimeOut(clientStoreState, ApplicationConfiguration.getWaitForElementTimeout())) {
                CommonUtilities.waitTime(1);
                //driver.select(clientStoreState, CustomerDetails.custermerData.get("STATE"));
                driver.select(clientStoreState, "LIM");
            } else
                Assert.assertTrue("clientStoreState is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
            if (driver.waitForElementPresenceWithTimeOut(clientStoreCity, ApplicationConfiguration.getWaitForElementTimeout())) {
                CommonUtilities.waitTime(1);
                driver.select(clientStoreCity, "LIMA");
            } else
                Assert.assertTrue("clientStoreCity is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
            if (driver.waitForElementPresenceWithTimeOut(clientStoreZip, ApplicationConfiguration.getWaitForElementTimeout())) {
                //driver.select(clientStoreZip, CustomerDetails.custermerData.get("CITY"));   //CustomerDetails.custermerData.get("POSTALCODE")//40905
                driver.selectListBox(clientStoreZip, "LIMA 1");
            } else
                Assert.assertTrue("clientStoreZip is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
            if (driver.waitForElementPresenceWithTimeOut(clientClaroStoreAddress_LA, ApplicationConfiguration.getWaitForElementTimeout())) {
                CommonUtilities.waitTime(1);
                driver.javaScriptClick(clientClaroStoreAddress_LA);
            } else
                Assert.assertTrue("clientClaroStoreAddress_LA is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {

            if (driver.checkObjectExists(clientStoreState, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(clientStoreState, "DF");
            else
                Assert.assertTrue("clientStoreState is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
            CommonUtilities.waitTime(2);
            if (driver.waitForElementPresenceWithTimeOut(clientStoreCity, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(clientStoreCity, "Mexico");
            else
                Assert.assertTrue("clientStoreCity is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
            CommonUtilities.waitTime(2);
            if (driver.waitForElementPresenceWithTimeOut(clientStoreZip, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.select(clientStoreZip, "1000");   //Make temporary change-39495 //CustomerDetails.custermerData.get("POSTALCODE")//40905
            } else {
                Assert.assertTrue("clientStoreZip is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
            }

            if (driver.waitForElementPresenceWithTimeOut(storeAddress, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(storeAddress);
                //driver.click (storeAddress);

            } else
                Assert.assertTrue("storeAddress is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
            CommonUtilities.waitTime(2);
            driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("cpmInteractionDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
            if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("diaction is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
            if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("cpmTabbedNavigationDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);


            if (driver.waitForElementPresenceWithTimeOut(saveAndContinueStoreAddress, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.waitAndClick(saveAndContinueStoreAddress);
            else
                Assert.assertTrue("saveAndContinueStoreAddress is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
        }
        //Select the "Select & Continue button"
        if (!ApplicationConfiguration.getClient().equalsIgnoreCase("telcel"))
            select_shipping_address();
    }

    public void overRideShipping() throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Incident details page.", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
        if (driver.waitForElementPresenceWithTimeOut(residentAddressType, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(residentAddressType);
        } else {
            Assert.assertTrue("Resident address button not found on page ", false);
        }
        driver.switchToDefaultContent();
        //       List<WebElement> iframeElements = driver.findElements(By.tagName("iframe"));
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("diaction is not found on Incident details page.", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(useThisAddress, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(useThisAddress);
        } else {
            Assert.assertTrue("Use this address button not found on page enrolled address page  ", false);
        }
    }

    public void select_replacement_equipmentEU() {
        CommonUtilities.waitTime(15);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
        }

        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, 50);
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());
        driver.switchToFrame(cpmTabbedNavigationDivFrame);
        if (driver.waitForElementPresenceWithTimeOut(replacementEquipmentEU, 50)) {
            driver.javaScriptClick(replacementEquipmentEU);
            System.out.println("Replacement Equipment selected on replacement equipment page");
        } else {
            System.out.println("Replacement Equipment not found on replacement equipment page");
            Assert.assertTrue("Replacement Equipment not found on replacement equipment page", false);
        }
    }

    public void select_shipping_addressEU() {
        CommonUtilities.waitTime(2);
        /*try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
        }*/
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout());

        if (driver.waitForElementPresenceWithTimeOut(validateContinueEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(validateContinueEU);
        } else {
            System.out.println("Validate & Continue button not found on shipping page");
            Assert.assertTrue("Validate & Continue button not found on shipping page", false);
        }

        driver.switchToDefaultContent();

        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("diaction is not found on Incident details page.", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
        }
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(useThisAddress, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(useThisAddress);
            CommonUtilities.waitTime(3);
            driver.switchToDefaultContent();
            driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
            driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());
            driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout());

            if (driver.waitForElementPresenceWithTimeOut(validateContinueEU, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptScrollAndClick(validateContinueEU);
                // System.out.println("Clicked on validate & Continue button on shipping page");
            } else {
                System.out.println("Validate & Continue button not found on shipping page");
                Assert.assertTrue("Validate & Continue button not found on shipping page", false);
            }
        } else {
            Assert.assertTrue("Use this address button not found on page enrolled address page  ", false);
        }
    }

    public void selectSNRFeeYes() {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        if (driver.elementExists(radioYes)) {
            driver.javaScriptClick(radioYes);
            System.out.println("Clicked on Yes radio button for SNR fee on order review page");
        }
    }

    public void clickSubmitOrderEU() {
        CommonUtilities.waitTime(7);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("kpn")) {
            if (driver.elementExists(radioYes)) {
                driver.javaScriptClick(radioYes);
                System.out.println("Clicked on Yes radio button for SNR fee on order review page");
            }
        }
        CommonUtilities.waitTime(3);
        if (driver.elementExists(buttonSubmitOrder)) {
            driver.javaScriptClick(buttonSubmitOrder);
            System.out.println("Clicked on Submit Order button on order review page");
        } else {
            System.out.println("Submit Order button not found on order review page");
            Assert.assertTrue("Submit Order button not found on order review page", false);
        }

        CommonUtilities.waitTime(3);

        if (driver.waitForElementPresenceWithTimeOut(buttonConfirmOrder, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(buttonConfirmOrder);
            System.out.println("Clicked on Confirm Order button on order review page");
        } else {
            System.out.println("Confirm Order button not found on order review page");
            Assert.assertTrue("Confirm Order button not found on order review page", false);
        }

    }

    public void override_shipping_addressEU() {
        CommonUtilities.waitTime(7);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident details page.", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("diaction is not found on Incident details page.", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found for " + ApplicationConfiguration.getClient() + " on incident fulfillment page(selectStoreAddress method)", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(overrideButtonEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(overrideButtonEU);
            System.out.println("Clicked on Override button on shipping page");
        } else {
            System.out.println("Override button not found on shipping page");
            //  Assert.assertTrue("Override button not found on shipping page", false);
        }

    }

}


