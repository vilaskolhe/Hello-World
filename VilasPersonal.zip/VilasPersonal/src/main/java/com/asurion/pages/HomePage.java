package com.asurion.pages;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.util.ApplicationConfiguration;
import org.junit.Assert;
import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.Keys;

import java.util.HashMap;

public class HomePage extends BasePage {
    private UIElement userId = new UIElement(UIType.TextBox, UILocatorType.ID, "txtUserID");
    private UIElement password = new UIElement(UIType.TextBox, UILocatorType.ID, "txtPassword");
    private UIElement logIn = new UIElement(UIType.Button, UILocatorType.ID, "sub");
    private UIElement callTab = new UIElement(UIType.Button, UILocatorType.CSS, "button.InteractionCloseTabButton");
    // private UIElement start = new UIElement(UIType.Link, UILocatorType.Link, "Start");
    private UIElement start = new UIElement(UIType.Link, UILocatorType.Xpath, "//*[@data-test-id='20150831103948089218523']");
    private UIElement cpmInteractionDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmInteractionDivFrame");
    private UIElement diaction = new UIElement(UIType.Frame, UILocatorType.Name, "DIACTION");
    private UIElement testIframe = new UIElement(UIType.Frame, UILocatorType.ID, "testiframe");
    private UIElement nameOfClient = new UIElement(UIType.ListBox, UILocatorType.ID, "ClientProfileID");
    private UIElement menuBar = new UIElement(UIType.Button, UILocatorType.CSS, "a.CPMLogTabbedWhite");
    //private UIElement application = new UIElement(UIType.Button, UILocatorType.CSS, "tr:nth-child(4)>td#ItemMiddle");
    private UIElement application = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[text()='Application']");
    private UIElement nTelosadvanceAgent = new UIElement(UIType.Button, UILocatorType.CSS, "td[title^='Horizon NA CST']");
    private UIElement horizonRMA = new UIElement(UIType.Button, UILocatorType.CSS, "td[title^='Horizon NA RMA']");
    // private UIElement horizonRMA = new UIElement(UIType.Button, UILocatorType.CSS, "#/contextMenu/ID1416325132235000/ID1472036733961000");

    private UIElement nTelosadvanceNACSATAdvancedAgent = new UIElement(UIType.Button, UILocatorType.CSS, "td[title^='Horizon NA CSAT Advanced Agent']");
    private UIElement logOut = new UIElement(UIType.Button, UILocatorType.CSS, "tr:nth-child(5)>td#ItemMiddle");
    private UIElement closeButton = new UIElement(UIType.Button, UILocatorType.CSS, "button.navigationCloseTabButton");
    private UIElement AccountHomeTab = new UIElement(UIType.Label, UILocatorType.CSS, "a[id='TABANCHOR_composite'] td[id='cpmNavigationTabData-TD'] div[id='RULE_KEY'] table:nth-of-type(1) td:nth-of-type(1) >nobr");
    private UIElement navigationiframe = new UIElement(UIType.Frame, UILocatorType.ID, "navigationiframe");
    private UIElement CaseServiceReqTab = new UIElement(UIType.Label, UILocatorType.Xpath, "//li[@id='Tab2']/a[@id='TABANCHOR']/span/span/label");
    private UIElement Status = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[2]/div/div/div[4]/div/div/div/div/div[2]");
    private UIElement customerCaseNumber = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//*[@id='CustomerCaseNumber']");
    private UIElement searchButton = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div/div/div/div[6]/div/div/span/button");
    private UIElement nTelosAsg = new UIElement(UIType.Button, UILocatorType.CSS, "td[title^='Horizon NA ASG Supervisor']");
    private UIElement selectCaseNumber = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='$PpgRepPgSubSectionReturnManagementWQBB$ppxResults$l1']/td[4]/div/span");
    private UIElement naFinance = new UIElement(UIType.Button, UILocatorType.CSS, "td[title^='Horizon NA Finance']"); //Horizon NA Finance 4.6  Iteration
    private UIElement finance = new UIElement(UIType.Button, UILocatorType.CSS, "td[title^='Finance']");
    private UIElement userRoleList = new UIElement(UIType.ListBox, UILocatorType.Xpath, ".//*[@id='yui-gen0']/div[10]/table/tbody/tr");
    private UIElement advanceAgent = new UIElement(UIType.Button, UILocatorType.CSS, "td[title^='Advanced Agent']");
    private UIElement channel = new UIElement(UIType.ListBox, UILocatorType.ID, "ClientChannelNumber");
    private UIElement AdvanceAgentCallMode = new UIElement(UIType.Button, UILocatorType.ID, "ModalButtonSubmit");

    private UIElement html = new UIElement(UIType.Button, UILocatorType.Xpath, "//html");
    private UIElement selectedLiveCallMode = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[@class='hoz_call_mode_selected pzhc']//div[text() = 'Live Call Mode']");
    private UIElement selectedOfflineFilingMode = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[@class='hoz_call_mode_selected pzhc']//div[text() = 'Offline Filing Mode']");
    private UIElement selectedResearchMode = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[@class='hoz_call_mode_selected pzhc']//div[text() = 'Research Mode']");
    private UIElement offlineModeRadioButton = new UIElement(UIType.RadioButton, UILocatorType.ID, "CallModeOFLNCLMFLG");
    private UIElement liveModeRadioButton = new UIElement(UIType.RadioButton, UILocatorType.ID, "CallModeCST");
    private UIElement researchModeRadioButton = new UIElement(UIType.RadioButton, UILocatorType.ID, "CallModeRSRCH");

    private UIElement offlineModeTab = new UIElement(UIType.Button, UILocatorType.Name, "IdentifyConsumerContainer_pyWorkPage_4");
    private UIElement researchModeTab = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='20161125134556032496748']");
    private UIElement liveModeTab = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='20161125134556032497771']");

    private UIElement modeSelectionContinueButton = new UIElement(UIType.Button, UILocatorType.ID, "ModalButtonSubmit");

    private UIElement advanceAgentEU = new UIElement(UIType.Button,UILocatorType.Xpath,"//td[text()[contains(.,'Horizon EU CSAT Advanced Agent')]]"); //Horizon EU CSAT Advanced Agent 4.7 Iteration
    private UIElement horizonEUCCR = new UIElement(UIType.Button,UILocatorType.Xpath,"//td[text()[contains(.,'Horizon EU CCR')]]");   //Horizon EU CCR 4.7 Iteration
    private UIElement horizonEUOCEO = new UIElement(UIType.Button,UILocatorType.Xpath,"//td[text()[contains(.,'Horizon EU OCEO ')]]");    //Horizon EU OCEO 4.7 Iteration
    private UIElement horizonEUCST = new UIElement(UIType.Button, UILocatorType.Xpath, "//td[text()[contains(.,'Horizon EU CST')]]");    private UIElement horizonEUATAC = new UIElement(UIType.Button,UILocatorType.Xpath,"//td[text()[contains(.,'Horizon EU ATAC')]]");
    private UIElement horizonEURMA = new UIElement(UIType.Button,UILocatorType.Xpath,"//td[text()[contains(.,'Horizon EU RMA')]]");
    private UIElement horizonEUFinance = new UIElement(UIType.Button,UILocatorType.Xpath,"//td[text()[contains(.,'Horizon EU Finance')]]");
    private UIElement horizonEUVerification = new UIElement(UIType.Button,UILocatorType.Xpath,"//td[text()[contains(.,'Horizon EU Instant Verification')]]");
    private UIElement horizonEUAdjust = new UIElement(UIType.Button,UILocatorType.Xpath,"//td[text()[contains(.,'Horizon EU Adjuster')]]");
    private UIElement horizonEUSecAdjust = new UIElement(UIType.Button,UILocatorType.Xpath,"//td[text()[contains(.,'Horizon EU Secondary Adjuster')]]");
    private UIElement horizonEUSuper = new UIElement(UIType.Button,UILocatorType.Xpath,"//td[text()[contains(.,'Horizon EU ASG Supervisor')]]");
    //3UK
    private UIElement horizonUKCST = new UIElement(UIType.Button, UILocatorType.Xpath, "//td[text()[contains(.,'Horizon UK CST')]]");
    private UIElement horizonUKFinance = new UIElement(UIType.Button, UILocatorType.Xpath, "//td[text()[contains(.,'Horizon UK Finance')]]");
    private UIElement horizonUKRMA = new UIElement(UIType.Button, UILocatorType.Xpath, "//td[text()[contains(.,'Horizon UK RMA ')]]");

    public static String fModeSelection = "";
    public static String sModeSelection = "";

    public void openPegaURL() throws Exception {
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3UK")) {
            driver.openURL("https://horizon-pega.us.qa3.test.asurion.net:8443/prweb/ADAuthentication/");
        } else {
            driver.openURL("https://horizon-pega.us.qa1.test.asurion.net:8443/prweb/ADAuthentication");
            CaptureIncidentPage.casenumbers = new HashMap<>();
        }
    }

    public void enterAutomatedLoginInfo() throws Exception {
        CommonUtilities.waitTime(5);
        if(driver.elementExists(userId)) {
            driver.type(userId, new String(Base64.decodeBase64("Y3dyLm1hbmlzaC5tZWh0YQ==")));
            driver.type(password, new String(Base64.decodeBase64("U3luZWNocm9uQDIwMTg=")));
            CommonUtilities.waitTime(1);
            driver.click(logIn);
        }
    }

    public boolean checkCallButton() throws Exception {
        CommonUtilities.waitTime(5);
        boolean result = driver.elementNotPresent(callTab, ApplicationConfiguration.getWaitForElementTimeout());
        return result;

    }

    public void closeCallButton() throws Exception {
        driver.switchToDefaultContent();
        if (driver.checkObjectExists(callTab, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.waitAndClick(callTab);
        } else {
            Assert.assertTrue("Call Tab is not found on Landing page", false);
        }
        if (driver.isAlertPresent())
            driver.acceptAlert();

    }

    public void pressStart() throws Exception {
        CommonUtilities.waitTime(5);
        // CommonUtilities.waitTime(25);
        driver.switchToDefaultContent();
            /*driver.waitForElementPresenceWithTimeOut(start, ApplicationConfiguration.getWaitForElementTimeout());
            driver.click(start);*/
        if (driver.waitForElementPresenceWithTimeOut(start, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(start);
        } else {
            Assert.assertTrue("Start button is not found on Landing page", false);
        }
        //CommonUtilities.waitTime(2);

    }

    public void selectClient(String client) throws Exception {
        CommonUtilities.waitTime(5);
        //CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, 50)) {
            driver.javaScriptClick(start);
            CommonUtilities.waitTime(2);
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, 40))
                Assert.assertTrue("CpmInteractionDivFrame is not found on Select Client page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Select Client page", false);
        }
        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(nameOfClient, 40)) {
            driver.select(nameOfClient, client);
        } else {
            Assert.assertTrue("Name Of Client is not found on Select Client page", false);
        }

    }
    public void selectCallMode() throws Exception{
        if(driver.waitForElementPresenceWithTimeOut(AdvanceAgentCallMode, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.click(AdvanceAgentCallMode);
        else
            System.out.println("Advance Agent Call Mode popup is not found");
    }

    public void switchUserAccount(String userRole) throws Exception {
        BasePage.userRole =userRole;
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (ApplicationConfiguration.getBrowser().equalsIgnoreCase("Chrome")) {
            System.out.println("waiting for on menu bar");
            if (driver.waitForElementPresenceWithTimeOut(menuBar, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(menuBar);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(menuBar, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.doubleClick(menuBar);
            } else {
                Assert.assertTrue("Menu bar is not found on home page", false);
            }
        }
        driver.waitForElementPresenceWithTimeOut(application, ApplicationConfiguration.getWaitForElementTimeout());
        //CommonUtilities.waitTime(3);
        driver.hoverOnMenu(application);
        if (userRole.equalsIgnoreCase("NACST")) {
            if (driver.waitForElementPresenceWithTimeOut(nTelosadvanceAgent, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(nTelosadvanceAgent);
            else
                Assert.assertTrue("nTelosadvanceAgent is not found on home page", false);
        }

        if (userRole.equalsIgnoreCase("NAASG")) {
            if (driver.waitForElementPresenceWithTimeOut(nTelosAsg, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(nTelosAsg);
            else
                Assert.assertTrue("nTelosAsg is not found on home page", false);
        }

        if (userRole.equalsIgnoreCase("NARMA")) {
            if (driver.waitForElementPresenceWithTimeOut(horizonRMA, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(horizonRMA);
            else
                Assert.assertTrue("NARMA is not found on home page", false);
        }
        if (userRole.equalsIgnoreCase("NAFinance")) {
            CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(naFinance, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(naFinance);
            else
                Assert.assertTrue("naFinance is not found on home page", false);
        }
        if (userRole.equalsIgnoreCase("Finance")) {
            if (driver.waitForElementPresenceWithTimeOut(finance, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(finance);
            else
                Assert.assertTrue("finance is not found on home page", false);
        }
        if (userRole.equalsIgnoreCase("AdvancedAgent")) {
            if (driver.waitForElementPresenceWithTimeOut(advanceAgent, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(advanceAgent);
            else
                Assert.assertTrue("Advanced Agent is not found on home page", false);
        }
        if (userRole.equalsIgnoreCase("NACSATAdvancedAgent")) {
            driver.click(nTelosadvanceNACSATAdvancedAgent);
        }

    }

    public void logOutFromApplication() throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (driver.waitForElementPresenceWithTimeOut(menuBar, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.doubleClick(menuBar);
        } else {
            Assert.assertTrue("Menu bar is not found on home page", false);
        }
        driver.waitForElementPresenceWithTimeOut(logOut, ApplicationConfiguration.getWaitForElementTimeout());
        driver.javaScriptClick(logOut);
        CommonUtilities.waitTime(1);
        if (driver.isAlertPresent())
            driver.acceptAlert();

    }

    /**
     * This method is used to status under Accound Home tab
     *
     * @param - Status(Delivered)
     * @author Priyanka
     */
    public void verifyStatusUnderAccountHomeTab(String status) throws Exception {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Identify Customer page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("diaction is not found on Identify Customer page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(closeButton, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.click(closeButton);

        if (driver.waitForElementPresenceWithTimeOut(AccountHomeTab, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.click(AccountHomeTab);
        else
            Assert.assertTrue("AccountHomeTab is not found on home page", false);

        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Identify Customer page", false);
        }
        navigateLowestLevelFrame(diaction);
        if (!driver.waitForFrameToLoad(navigationiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Identify Customer page", false);
        }
//            if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
//            {
//                Assert.assertTrue("cpmTabbedNavigationDivFrame is not found on contact details page", false);
//            }
        if (driver.waitForElementPresenceWithTimeOut(CaseServiceReqTab, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.waitAndClick(CaseServiceReqTab);
        else
            Assert.assertTrue("CaseServiceReqTab is not found on home page", false);
        if (driver.waitForElementPresenceWithTimeOut(Status, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertEquals("Verify Status", driver.getText(Status).toLowerCase(), status.toLowerCase());
        else
            Assert.assertTrue("Status is not found on home page", false);
    }

    /**
     * This method is used verify select the channel e.g Rogers -Fido
     */

    public void selectChannel(String client) throws Exception {
        CommonUtilities.waitTime(4);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(start);
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("CpmInteractionDivFrame is not found on Select Client page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Select Client page", false);
        }
        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(channel, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (BasePage.userRole.equalsIgnoreCase("NACST"))
               driver.doubleClick(channel);
            driver.select(channel, client);
        } else {
            Assert.assertTrue("Channel is not found on Select Client page", false);
        }
    }

    /**
     * This method is used to select Advance agent call mode
     *
     * @param - mode eg live call
     * @author Priyanka
     * Created date : 12/02/2016
     */
    public void selectMode(String mode) {

        System.out.println("ABC\n");
        driver.type(html, (Keys.chord(Keys.CONTROL, Keys.SUBTRACT)));
        driver.type(html, (Keys.chord(Keys.CONTROL, Keys.SUBTRACT)));
        driver.type(html, (Keys.chord(Keys.CONTROL, Keys.SUBTRACT)));
        driver.type(html, (Keys.chord(Keys.CONTROL, Keys.SUBTRACT)));

        if (mode.toLowerCase().contains("offline filing")) {
            driver.click(offlineModeRadioButton);
            fModeSelection = "offline filing";
        } else if (mode.toLowerCase().contains("live call")) {
            driver.click(liveModeRadioButton);
            fModeSelection = "live call";
        } else if (mode.toLowerCase().contains("research")) {
            driver.click(researchModeRadioButton);
            fModeSelection = "research";
        }
        driver.javaScriptClick(modeSelectionContinueButton);
    }

    public void switchUserAccountEU(String userRole){

        CommonUtilities.waitTime(15);
        driver.switchToDefaultContent();
        driver.waitForElementPresenceWithTimeOut(menuBar, ApplicationConfiguration.getWaitForElementTimeout());
        driver.javaScriptClick(menuBar);
        driver.waitForElementPresenceWithTimeOut(application, ApplicationConfiguration.getWaitForElementTimeout());
        driver.hoverOnMenu(application);
        CommonUtilities.waitTime(5);

        try {
            if(userRole.equalsIgnoreCase("AdvancedAgent")) {
                driver.javaScriptClick(advanceAgentEU);
            }
            if(userRole.equalsIgnoreCase("HorizonEUCCR")) {
                driver.javaScriptClick(horizonEUCCR);
            }
            if(userRole.equalsIgnoreCase("HorizonEUOCEO")) {
                driver.javaScriptClick(horizonEUOCEO);
            }
            if (userRole.equalsIgnoreCase("HorizonEUCST")) {
                if(ApplicationConfiguration.getClient().equalsIgnoreCase("3UK")) driver.click(horizonUKCST);
                else if(ApplicationConfiguration.getClient().equalsIgnoreCase("KPN")) driver.click(horizonEUCST);
                else System.out.println("Client not configured, Kindly contact Automation QA.");
            }
            if(userRole.equalsIgnoreCase("HorizonEUATAC")) {
                driver.javaScriptClick(horizonEUATAC);
            }
            if (userRole.equalsIgnoreCase("HorizonEURMA")) {
                if(ApplicationConfiguration.getClient().equalsIgnoreCase("3UK")) driver.click(horizonUKRMA);
                else if(ApplicationConfiguration.getClient().equalsIgnoreCase("KPN")) driver.click(horizonEURMA);
                else System.out.println("Client not configured, Kindly contact Automation QA.");
            }
            if (userRole.equalsIgnoreCase("HorizonEUFinance")) {
                if(ApplicationConfiguration.getClient().equalsIgnoreCase("3UK")) driver.click(horizonUKFinance);
                else if(ApplicationConfiguration.getClient().equalsIgnoreCase("KPN")) driver.click(horizonEUFinance);
                else System.out.println("Client not configured, Kindly contact Automation QA.");
            }
            if(userRole.equalsIgnoreCase("HorizonEUVerification")) {
                driver.javaScriptClick(horizonEUVerification);
            }
            if(userRole.equalsIgnoreCase("HorizonEUAdjuster")) {
                driver.javaScriptClick(horizonEUAdjust);
            }
            if(userRole.equalsIgnoreCase("HorizonEUSecAdjuster")) {
                driver.javaScriptClick(horizonEUSecAdjust);
            }
            if(userRole.equalsIgnoreCase("HorizonEUSupervisor")) {
                driver.javaScriptClick(horizonEUSuper);
            }

        } catch (Exception findFailed) {
            findFailed.printStackTrace();
        }

    }

    public void switchUserRoleForEurope(String userRole){
        driver.switchToDefaultContent();
        if (ApplicationConfiguration.getBrowser().equalsIgnoreCase("Chrome")) {
            System.out.println("waiting for on menu bar");
            if (driver.waitForElementPresenceWithTimeOut(menuBar, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(menuBar);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(menuBar, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.doubleClick(menuBar);
            } else {
                Assert.assertTrue("Menu bar is not found on home page", false);
            }
        }
        driver.waitForElementPresenceWithTimeOut(application, ApplicationConfiguration.getWaitForElementTimeout());
        //CommonUtilities.waitTime(3);
        driver.hoverOnMenu(application);
        if (userRole.equalsIgnoreCase("HorizonEUCST")) {
            if (driver.waitForElementPresenceWithTimeOut(horizonEUCST, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(horizonEUCST);
            else
                Assert.assertTrue("HorizonEUCST is not found on home page", false);
        }
    }

}