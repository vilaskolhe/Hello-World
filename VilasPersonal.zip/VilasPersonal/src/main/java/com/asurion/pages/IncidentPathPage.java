package com.asurion.pages;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.Generic;
import org.junit.Assert;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class IncidentPathPage extends BasePage {

    private UIElement continueButton = new UIElement(UIType.Button, UILocatorType.Xpath, "/html/body/div[2]/form/div[3]/div/table/tbody/tr/td/div/div/span/div/div/table/tbody/tr[4]/td/div/div/div/div/div/div/div/table/tbody/tr/td[2]/button");
    private UIElement navigationDivFrame = new UIElement(UIType.Button, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    // private UIElement startIncident = new UIElement(UIType.Button, UILocatorType.Xpath,".//*[@id='RULE_KEY']/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/span/button");
    private UIElement startIncident = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[contains(@class,'InFormContinueButton')] // *[text()='Start Incident']");
    private UIElement resumeIncident = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[contains(@class,'InFormContinueButton') ] // *[text()='Resume Incident']");
    private UIElement resumeIncidentEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='2015100111551802876838']");
    private UIElement cancelIncident = new UIElement(UIType.Button, UILocatorType.Xpath, "(/html/body/div[2]/form/div[3]/div/table/tbody/tr/td/div/div/span/div/div/table/tbody/tr[2]/td/div/table[2]/tbody/tr[2]/td/table/tbody/tr/td/div/span/table/tbody/tr/td[2]/div/div/div/div/div/div/div/div/div/div/div/div/span/button)[2]");
    private UIElement cpmInteractionDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmInteractionDivFrame");
    private UIElement cpmTabbedNavigationDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    private UIElement diaction = new UIElement(UIType.Frame, UILocatorType.Name, "DIACTION");
    private UIElement email = new UIElement(UIType.CheckBox, UILocatorType.Name, "ClientAccountContactPreferencesEmailDetail_PreferedEmailPage.ContactPreferenceGraphList(1)_53");
    //private UIElement continueContactButton = new UIElement(UIType.Button, UILocatorType.CSS, "table[id='pyActionArea'] tr:nth-of-type(2) table:nth-of-type(1) div[id='pyFlowActionHTML'] table:nth-of-type(1) tr:nth-of-type(1) div[id='RULE_KEY']>div:nth-of-type(2)>div>div>div>div>div>span>button[class='pzhc']");
    private UIElement continueContactButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[text()='Continue']");

    private UIElement continueContactButtonClaro = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[@class='pzhc'][@type='button']");

    private UIElement newEmail = new UIElement(UIType.TextBox, UILocatorType.ID, "NewEmailAddress");
    //private UIElement newEmailRadioButton = new UIElement(UIType.Button,UILocatorType.Name,"CustomerContactEmail_pyWorkPage_32");
    private UIElement newEmailRadioButton = new UIElement(UIType.Button, UILocatorType.CSS, "button[name='CustomerContactEmail_pyWorkPage_21']");
    private UIElement newEmailRadioButtonClaro = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[@name='CustomerContactEmail_pyWorkPage_21']");
    // private UIElement caseNumber = new UIElement(UIType.Label,UILocatorType.CSS,"table>tbody>tr>td:nth-child(9)>nobr>span");
    // private UIElement caseNumber = new UIElement(UIType.Label,UILocatorType.Xpath,"//table[@id='hoz_mainHeader']//tr[2]/td[4]//span");
    private UIElement caseNumber = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[1]//div[7]/div//span");
    private UIElement caseNumberEU = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-test-id='2015081013593405235772']");
  //  private UIElement none = new UIElement(UIType.Label, UILocatorType.CSS, "[name^='CustomerContactEmail_pyWorkPage_']");
    private UIElement none = new UIElement(UIType.Label, UILocatorType.Xpath, "//button[@name='CustomerContactEmails_pyWorkPage_9']");
    //private UIElement none = new UIElement(UIType.RadioButton,UILocatorType.CSS,"button[name=CustomerContactEmail_pyWorkPage_9]");
    private UIElement incidentCancellationReason = new UIElement(UIType.ListBox, UILocatorType.ID, "CancelSvcReqReason");
    private UIElement incidentCancellationContinueButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//table[@id='hoz_cancelServiceReqBtnWrapper']//td[3]//div[@id='CT']/button");

    private UIElement noneEmailButtonEU = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div[3]/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/span/button");
    //    private UIElement continueContactButtonEU = new UIElement(UIType.Button,UILocatorType.Xpath,".//*[@id='RULE_KEY']/div[2]/div/div/div/div/div/span/button");
    private UIElement continueContactButtonEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='20150717121243043216654']");
    private UIElement cancelIncidentEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='2015100111551802899232']");
    private UIElement incidentCancellationContinueButtonEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='20151111102731045263580']");
    private UIElement incidentCancellationConfirmationButtonEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='20150709092007013431228']");
    private UIElement cancellationReasonEU = new UIElement(UIType.ListBox, UILocatorType.ID, "CancelReviewReasonCode");
    private UIElement continueCancellationButtonEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='201508070502420546144515']");
    private UIElement cancelIncidentconfirmationMessage = new UIElement(UIType.Label, UILocatorType.CSS, "table[id='hoz_ModalWIndows'] table:nth-of-type(1) td:nth-of-type(2) div[id='RULE_KEY'] div.field-item.dataValueRead > span");
    private UIElement speakScript = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-test-id='2016041416061607561940']");
    private UIElement labelEnrollmentDateOnPanel = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div[2]/div/div/div[2]/div/div/div/div/div[1]/div/div/div/div/div[2]/div/div/div/div/div[2]");
    private UIElement labelEnrolledDate = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-test-id='20150730154023029737664']");
    private UIElement continueButtonLA = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@id=\"RULE_KEY\"]/div[2]/div/div/div/div/div/span/button/div/div/div/div");
    private UIElement customerAuthName = new UIElement(UIType.Label, UILocatorType.Xpath, "html/body/div[2]/form/div[3]/div[2]/table/tbody/tr/td/div/div/table/tbody/tr/td[3]/div/table/tbody/tr[1]/td/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div[1]/div/div/div[1]/div/div/div[2]/div");
    private UIElement customerName = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-test-id='201508101349240629182413']");
    private UIElement customerEmail = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-test-id='2015090114111808609537']");
    private UIElement actionsMenu = new UIElement(UIType.ListBox, UILocatorType.CSS, ".HeaderActionLink");
    private UIElement incidentPathDetermination = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='ASR-CCO-Work-IT-Incident_IncidentPathDetermination']");
    private UIElement launch = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/table/tbody/tr/td[1]/nobr/span/button");
    private UIElement deviceProtection = new UIElement(UIType.RadioButton, UILocatorType.Xpath, ".//*[@id='SelectedProductNameDevice Protection']");
    private UIElement esc13Month = new UIElement(UIType.RadioButton, UILocatorType.Xpath, ".//*[@id='SelectedProductNameExtended Service Contract 13 Months']");
    private UIElement esc24Month = new UIElement(UIType.RadioButton, UILocatorType.CSS, "input[id*=SelectedProductNameExtended]");
    private UIElement soluto = new UIElement(UIType.RadioButton, UILocatorType.Xpath, ".//*[@id='SelectedProductNameSoluto']");
    private UIElement productNamecontinueBtn = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[3]/div/div/div/div/div//button");

    public static String caseID = null;
    /////////////////
    public void select_incident_path(String incidentPath) throws Exception {
       driver.switchToDefaultContent();
      driver.waitForFrameToLoad(cpmInteractionDivFrame, 50);
        navigateLowestLevelFrame(diaction);

        switch (incidentPath) {
            case "Start Incident":
                CommonUtilities.waitTime(5);
                if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
                    Assert.assertTrue("cpmTabbedNavigationDivFrame is not found on contact details page", false);
                }
                if (driver.waitForElementPresenceWithTimeOut(startIncident, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.click(startIncident);
                } else {
                    Assert.assertTrue("Start Incident button is not found on Incident Path Page", false);
                }
                break;
            case "Resume Incident":
                if (driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.click(resumeIncident);
                } else {
                    Assert.assertTrue("Resume Incident button is not found on Incident Path Page", false);
                }
                break;
        }

    }

    /////////
    public void accept_default_contact() throws Exception {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("diaction is not found on contact details page", false);
        }
        //if(ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
             /*   if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                {
                    Assert.assertTrue("diaction1 is not found on contact details page", false);
                }*/
        //}
        //navigateLowestLevelFrame(diaction);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found on contact details page", false);
        }
        CommonUtilities.waitTime(1);

        if (driver.waitForElementPresenceWithTimeOut(none, ApplicationConfiguration.getWaitForElementTimeout())) {
            // driver.type(newEmail,"test@automation.com");
            driver.waitAndClick(none);
        } else {
            Assert.assertTrue("None Radio button is not found on contact details page", false);
        }
        // driver.waitForElementPresenceWithTimeOut(continueContactButton,60);
        // driver.javaScriptClick(continueContactButton);
        // driver.waitAndClick(continueContactButton);
        CommonUtilities.waitTime(5);
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
            if (driver.waitForElementPresenceWithTimeOut(continueContactButtonClaro, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(continueContactButtonClaro);
            } else {
                Assert.assertTrue("Continue Contact button is not found on contact details page", false);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(continueContactButton, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(continueContactButton);
            } else {
                Assert.assertTrue("Continue Contact button is not found on contact details page", false);
            }
        }


    }

    public void cancelIncident() throws Exception {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmInteractionDivFrame is not found on Cancel Incident page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("diaction is not found on Cancel Incident page", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found on Cancel Incident page", false);
        }
//        navigateLowestLevelFrame(diaction);
//        driver.switchToFrame(cpmTabbedNavigationDivFrame);

//        List<WebElement> e= driver.findElements(By.id("CancelSvcReqReason"));
//        for (WebElement e1:e)
//        {
//            System.out.println("dispaly "+e1.getText());
//        }

        if (driver.waitForElementPresenceWithTimeOut(cancelIncident, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.waitAndClick(cancelIncident);
        } else {
            Assert.assertTrue("Cancel Incident button is not found on Incident Path page", false);
        }
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();

        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmInteractionDivFrame is not found on Cancel Incident page", false);
        }
        navigateLowestLevelFrame(diaction);
        // driver.switchToFrame(cpmTabbedNavigationDivFrame);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found on Cancel Incident page", false);
        }

        if (driver.checkObjectExists(incidentCancellationReason, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(incidentCancellationReason, "Customer Request");
        } else {
            Assert.assertTrue("Incident Cancellation reason is not found on Cancel Incident page", false);
        }

        if (driver.checkObjectExists(incidentCancellationContinueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
//                driver.click(incidentCancellationContinueButton);
//                driver.waitAndClick(incidentCancellationContinueButton);
            driver.javaScriptClick(incidentCancellationContinueButton);
        } else {
            Assert.assertTrue("Incident Cancellation Continue button is not found on Cancel Incident page", false);
        }
        // The incident has been cancelled successfully
        CommonUtilities.waitTime(1);
        if (driver.checkObjectExists(cancelIncidentconfirmationMessage, ApplicationConfiguration.getWaitForElementTimeout())) {
            String confirmationMessage = driver.getText(cancelIncidentconfirmationMessage);
            assertEquals("Checking expected confirmation message", confirmationMessage, "The incident has been cancelled successfully");
        } else
            Assert.assertTrue("cancel Claim message is not found on cancel claim Page", false);


    }

    /**
     * This method is used to select resume incident
     */
    public void resumeRelasehold() throws Exception {
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Fido"))
            driver.click(resumeIncident);
        else {
            if (driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(resumeIncident);
            } else {
                Assert.assertTrue("Resume Incident button is not found on Incident Path Page", false);
            }
        }
    }

    public void selectProductName(String productName) {
        driver.switchToDefaultContent();

        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmInteractionDivFrame is not found on Cancel Incident page", false);
        }
        navigateLowestLevelFrame(diaction);
        // driver.switchToFrame(cpmTabbedNavigationDivFrame);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found on Cancel Incident page", false);
        }
        switch (productName) {
            case "Device Protection":
                driver.click(deviceProtection);
                break;
            case "Extended Service Contract 13 Months":
                driver.click(esc13Month);
                break;
            case "Extended Service Contract 24 Months":
                driver.click(esc24Month);
                break;
            case "Soluto":
                driver.click(soluto);
                break;
            default:
                assertTrue(productName + " is not implemented in selectProductName", false);
        }
    }

    public void clickContinueButton() {
        driver.click(productNamecontinueBtn);
    }

    public void captureClaimIdForStartIncidentEU(){
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame,60);
        driver.waitForFrameToLoad(diaction,60);
        if(driver.waitForElementPresenceWithTimeOut(caseNumberEU, ApplicationConfiguration.getWaitForElementTimeout()))
        {
            caseID = driver.getText(caseNumberEU);
            //System.out.println("CaseID for 3UK "+caseID);
            Generic.setGlobals("CASENUMBER", driver.getText(caseNumberEU));
        }
        else{
            Assert.assertTrue("CaseNumber not found IPD page", false);
        }
    }

    public void acceptDefaultContactDetailsEU(){
        driver.switchToDefaultContent();
        CommonUtilities.waitTime(5);
        driver.waitForFrameToLoad(cpmInteractionDivFrame,80);
        driver.waitForFrameToLoad(diaction,80);
        driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame,80);

        driver.waitForElementPresenceWithTimeOut(noneEmailButtonEU, 80);
        // driver.type(newEmail,"test@automation.com");
        driver.javaScriptClick(noneEmailButtonEU);
        System.out.println("Click on None radio button");
//        driver.waitForElementPresenceWithTimeOut(continueContactButtonEU, 60);
        if(driver.elementExists(continueContactButtonEU)){
            driver.javaScriptScrollAndClick(continueContactButtonEU);
        }
        else {
            System.out.println("Continue button is not displayed on UI.");
            Assert.assertTrue("Continue button is not displayed on UI.", false);
        }

        System.out.println("Click on Continue button");
    }
}
