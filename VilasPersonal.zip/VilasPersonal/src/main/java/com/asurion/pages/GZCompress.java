package com.asurion.pages;

import com.asurion.common.core.driver.TestDriver;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.zip.GZIPOutputStream;
import au.com.bytecode.opencsv.CSVReader;
import java.io.File;


/**
 * Created by SANDEEP.SUPEKAR on 7/27/2017.
 */
public class GZCompress {
    public GZCompress() {
        TestDriver.setPageName("GZ Compress page");
                }
    //private static final String OUTPUT_GZIP_FILE = "C:/Users/sandeep.supekar/Desktop/Compress/Asurion_Customer_Snapshot_PeopleSoft_20170720_2.csv.gz";
    //private static final String SOURCE_FILE ="C:/Users/sandeep.supekar/Desktop/Compress/Asurion_Customer_Snapshot_PeopleSoft_20170720_2.csv";
    public static void gzipIt(String source, String output){

        byte[] buffer = new byte[1024];

        try{

            GZIPOutputStream gzos =
                    new GZIPOutputStream(new FileOutputStream(output));

            FileInputStream in =
                    new FileInputStream(source);

            int len;
            while ((len = in.read(buffer)) > 0) {
                gzos.write(buffer, 0, len);
                System.out.println("data written to compressed file");
            }

            in.close();

            gzos.finish();
            gzos.close();

            System.out.println("Done");


        }catch(IOException ex){
            ex.printStackTrace();
        }

    }

    public static void deleteFile(String source){
        try{

            File file = new File(source);

            if(file.delete()){
                System.out.println(file.getName() + " is deleted from temp location!");
            }else{
                System.out.println("Delete operation is failed.");
            }

        }catch(Exception e){

            e.printStackTrace();

        }

    }
    }

