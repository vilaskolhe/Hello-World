package com.asurion.pages;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.horizon.generic.DataBaseHandler;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import com.asurion.util.Generic;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by RBharamgonde on 4/15/2015.
 */
public class MyWorkPage extends BasePage {

    private UIElement cpmInteractionDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmInteractionDivFrame");
    private UIElement diaction = new UIElement(UIType.Frame, UILocatorType.Name, "DIACTION");
    private UIElement testiframe = new UIElement(UIType.Frame, UILocatorType.ID, "testiframe");
    private UIElement cpmTabbedWorkDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmTabbedWork-DIVFrame");

    private UIElement navigationDivFrame = new UIElement(UIType.Button, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    private UIElement cpmTabbedNavigationDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    private UIElement actionLink = new UIElement(UIType.Link, UILocatorType.Link, "Actions");
    private UIElement resolutionlink = new UIElement(UIType.Link, UILocatorType.Link, "Resolution");
    private UIElement wQName = new UIElement(UIType.ListBox, UILocatorType.CSS, "#WQName");
    private UIElement wQNameEU = new UIElement(UIType.ListBox, UILocatorType.ID, "WQName");
    private String sHoldActionType = null;
    //private UIElement escalationNumber = new UIElement(UIType.TextBox, UILocatorType.ID, "pyID");
    private UIElement escalationNumber = new UIElement(UIType.TextBox, UILocatorType.ID, "pyID");
    private UIElement holdStage = new UIElement(UIType.ListBox, UILocatorType.ID, "HoldState");
    private UIElement holdCustomerCaseNumber = new UIElement(UIType.TextBox, UILocatorType.ID, "CustomerCaseNumber");
    private UIElement mobileDeviceNumber = new UIElement(UIType.TextBox, UILocatorType.ID, "MobileDeviceNumber");
    private UIElement serviceRequestNumber = new UIElement(UIType.TextBox, UILocatorType.ID, "ServiceRequestNumber");
    private UIElement customerCaseNumber = new UIElement(UIType.TextBox, UILocatorType.ID, "CustomerCaseNumber");
    private UIElement search = new UIElement(UIType.Button, UILocatorType.CSS, "span button.SearchButtons.pzhc");
    private UIElement clear = new UIElement(UIType.TextBox, UILocatorType.Name, "EscWorkSearchArea_pyDisplayHarness_32");
    private UIElement dataTable = new UIElement(UIType.Label, UILocatorType.ID, "PEGA_GRID_CONTENT");
    private UIElement refresh = new UIElement(UIType.Button, UILocatorType.Name, "EscDashboard_MyWork_pyDisplayHarness_9");
    private UIElement workqueue = new UIElement(UIType.Label, UILocatorType.CSS, "#Tab1 > #TABANCHOR > #TABSPAN");
    private UIElement worklist = new UIElement(UIType.Label, UILocatorType.CSS, "#Tab2 > #TABANCHOR > #TABSPAN");
    private UIElement data = new UIElement(UIType.Label, UILocatorType.CSS, "tr#$PpgRepPgSubSectionEnrollmentWQB$ppxResults$l1.oddRow.cellCont td.dataValueRead.gridCell.gridCellSelected div.oflowDivM span");
    //private UIElement dataCustomerCaseHold = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='PEGA_TABBED0']/div/div[1]//table[@id='gridLayoutTable']//div[@id='gridBody_right']//table[@id='bodyTbl_right']//tr[2]/td[2]");
    private UIElement dataCustomerCaseHold = new UIElement(UIType.Label, UILocatorType.Xpath, "//tr[@id='$PpgRepPgSubSectionHoldsWQB$ppxResults$l1']/td[2]//span");
    private UIElement dataRefundWQB = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='$PSFRResults$ppxResults$l1']/td[2]");
    private UIElement dataEnrollment = new UIElement(UIType.Label, UILocatorType.Xpath, "//tr[@id='$PpgRepPgSubSectionEnrollmentWQB$ppxResults$l1']/td[2]//span");
    private UIElement customerCaseHoldNumber = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//*[@data-test-id='2015060813024206686485']");
    // private UIElement refundRequestNumber = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//*[@data-test-id='2015060813024206686485']");

    private UIElement refundReasonAction = new UIElement(UIType.ListBox, UILocatorType.ID, "LineAction1");
    private UIElement careRefundResult = new UIElement(UIType.ListBox, UILocatorType.ID, "CareRefundResult");
    private UIElement refundOverrideReasonCode = new UIElement(UIType.ListBox, UILocatorType.ID, "PaymentOverrideReasonCode");
    private UIElement refundWBContinue = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']//*[text()='Continue']");
    //    private UIElement refundWBContinue = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']//button[contains(@class,'InFormContinueButton')]//*[text()='Continue']");

    private UIElement partialAppOrDenyNoteText = new UIElement(UIType.Button, UILocatorType.ID, "PartialAppOrDenyNoteText1");
    private UIElement escalate = new UIElement(UIType.CheckBox, UILocatorType.ID, "RefundEligibilityOverriden");
    private UIElement escalateReason = new UIElement(UIType.ListBox, UILocatorType.ID, "RefundEligibilityOverrideReasonCode");
    // private UIElement selectCaseNumber = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='$PpgRepPgSubSectionReturnManagementWQBB$ppxResults$l1']/td[4]/div/span");

    //HoldProcessingAction
    private UIElement holdProcessingAction = new UIElement(UIType.ListBox, UILocatorType.ID, "HoldsAction");
    private UIElement holdTroubleshootingAction = new UIElement(UIType.ListBox, UILocatorType.ID, "TroubleshootingAction");
    private UIElement addNote = new UIElement(UIType.CheckBox, UILocatorType.ID, "AddNote");
    //private UIElement searchButton = new UIElement(UIType.Button, UILocatorType.CSS, ".SearchButtons.pzhc");
    //private UIElement searchButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[@name='HoldsGridViewSearchBar_CustomerCaseHoldsPage_11']");
    // private UIElement searchButton = new UIElement(UIType.Button, UILocatorType.CSS, "div[class^='content-item content-field item-5'] div>span>button");
    private UIElement searchButton = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div/div/div/div[6]/div/div/span/button");
    private UIElement noteTab = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[2]/span[text()='Notes']");
    private UIElement getnoteType = new UIElement(UIType.Label, UILocatorType.Xpath, "//table[@id='bodyTbl_right']//tr[starts-with(@id,'$PD_CustomerNotes_pa')]/td[1]");
    private UIElement lockSymbol = new UIElement(UIType.Image, UILocatorType.Xpath, "//table[@id='bodyTbl_right']//tr[starts-with(@id,'$PD_CustomerNotes_pa')]/td[2]//div[@id='CT']/span/i/img");
    private UIElement getNoteDescription = new UIElement(UIType.Label, UILocatorType.Xpath, "//table[@id='bodyTbl_right']//tr[starts-with(@id,'$PD_CustomerNotes_pa')]/td[3]//span");
    //Release Hold
    private UIElement holdResolution = new UIElement(UIType.ListBox, UILocatorType.ID, "CustomerCaseHoldResolution");//"//div[@id='pyFlowActionHTML']//div[@id='RULE_KEY']//div[@id='CT']//select[@id='CustomerCaseHoldResolution']");
    private UIElement releaseHoldReason = new UIElement(UIType.ListBox, UILocatorType.ID, "ReleaseReasonCode");
    private UIElement continueButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[@class='layout layout-none float-right set-width-auto']//button");
    private UIElement outboundFlag = new UIElement(UIType.CheckBox, UILocatorType.ID, "OutboundFlag");
    private UIElement incidentPathDetermination = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='ASR-CCO-Work-IT-Incident_IncidentPathDetermination']");
    private UIElement launchButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[@class='SearchButtons pzhc']");
    //private UIElement resumeButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']//div[1]//button[starts-with(@class,'pzhc')]");
    private UIElement resumeButton = new UIElement(UIType.Button, UILocatorType.Xpath, "(//div[@id='RULE_KEY']//div[1]//button[starts-with(@class,'InFormContinueButton')])[1]");
    private UIElement firstAgreemnetStatus = new UIElement(UIType.Button, UILocatorType.Xpath, "//tr[@id='$PD_AssetList_Search$ppxResults$l2']/td[4]/div/span");
    private UIElement activeStatusRow = new UIElement(UIType.Button, UILocatorType.Xpath, "//tr[@id='$PD_AssetList_Search$ppxResults$l1']/td[4]//span");
    private UIElement secondAgreemnetStatus = new UIElement(UIType.Button, UILocatorType.Xpath, "//tr[@id='$PD_AssetList_Search$ppxResults$l1']/td[4]/div/span");
    private UIElement caseNumber = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[1]//div[6]/div//span");
    private UIElement mobileDeviceNumberNumber = new UIElement(UIType.Label, UILocatorType.ID, "MobileDeviceNumber");
    private UIElement serachButton = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[2]//div/div[5]//span/button[@class='SearchButtons pzhc']");
    private UIElement dataNACSTnTelos = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='$PpgRepPgSubSectionRefundWQB$ppxResults$l1']/td[6]");
    private UIElement datanTelos = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='$PpgRepPgSubSectionReturnManagementWQBB$ppxResults$l1']/td[4]/div/span");
    private UIElement cancellationActionEU = new UIElement(UIType.Button, UILocatorType.ID, "CancellationAction");
    private UIElement claimCancellationQueueEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='20150806101222071649826']");
    private UIElement resolutionReasonEU = new UIElement(UIType.Button, UILocatorType.ID, "ResolutionReasonCode");
    private UIElement cancellationActionContinueButtonEU = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='2015080614401108915262']");
    private UIElement countinueButton = new UIElement(UIType.Button, UILocatorType.CSS, "button.SearchButtons.pzhc");
    private UIElement action = new UIElement(UIType.ListBox, UILocatorType.CSS, "#ReturnAuthorizationResult");
    private UIElement subAction = new UIElement(UIType.ListBox, UILocatorType.CSS, "#ReasonForReturn");

    private UIElement dataTroubleshootHold = new UIElement(UIType.Label, UILocatorType.Xpath, "//tr[@id='$PpgRepPgSubSectionTroubleshootingWQB$ppxResults$l1']/td[2]");
    private UIElement resolutionType = new UIElement(UIType.ListBox, UILocatorType.ID, "ResolutionType");
    private UIElement triageSuccessful = new UIElement(UIType.RadioButton, UILocatorType.ID, "TBSResultTRGSCS");
    private UIElement triageUnsuccessful = new UIElement(UIType.RadioButton, UILocatorType.ID, "TBSResultTRGNTSCS");
    private UIElement traigeReason = new UIElement(UIType.ListBox, UILocatorType.ID, "TriageReason");
    private UIElement traigeReasonCode = new UIElement(UIType.ListBox, UILocatorType.ID, "TriageReasonCode");
    // private UIElement searchClick = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@id='RULE_KEY']/div/iv/div/div[11]/div/div/span/button");
    private UIElement searchClick = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='2015060813024206807231']");
    private UIElement dataFinanceReview = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='$PFRWorkbasketResults$ppxResults$l1']/td[2]");
    //private UIElement refundActions = new UIElement(UIType.ListBox, UILocatorType.Xpath, "(//select[@id='LineAction1'])[2]");
    private UIElement refundActions = new UIElement(UIType.ListBox, UILocatorType.Xpath, "(//tr[@id='$PCurrentBusinessContext$pCreatedPaymentOrder$pPaymentOrderLineList$l1']//select[@id='LineAction1'])[2]");

    private UIElement refundResult = new UIElement(UIType.ListBox, UILocatorType.ID, "RefundResult");
    private UIElement approvalAmount = new UIElement(UIType.TextBox, UILocatorType.Xpath, "(//tr[@id='$PCurrentBusinessContext$pCreatedPaymentOrder$pPaymentOrderLineList$l1']//input[@id='ApprovedAmount1'])[2]");
    //private UIElement paymentOverrideReasonCode = new UIElement(UIType.ListBox, UILocatorType.ID, "PaymentOverrideReasonCode");
    private UIElement financeReview = new UIElement(UIType.Label, UILocatorType.Xpath, "//tr[@id='$PD_ClientProfileWorkbasketList$ppxResults$l2']/td[1]/div/span");
    private UIElement refundReasonCode = new UIElement(UIType.TextBox, UILocatorType.Xpath, "(//tr[@id='$PCurrentBusinessContext$pCreatedPaymentOrder$pPaymentOrderLineList$l1']//textarea[@id='PartialAppOrDenyNoteText1'])[2]");

    ///////NA Adjuster Page Object//
    private UIElement nTelosClientSelection = new UIElement(UIType.CheckBox, UILocatorType.ID, "IsAccessible_rdi_1");
    private UIElement rogersClientSelection = new UIElement(UIType.CheckBox, UILocatorType.ID, "IsAccessible_rdi_2");
    private UIElement fidoClientSelection = new UIElement(UIType.CheckBox, UILocatorType.ID, "IsAccessible_rdi_3");
    private UIElement windClientSelection = new UIElement(UIType.CheckBox, UILocatorType.ID, "IsAccessible_rdi_4");
    private UIElement sprintClientSelection = new UIElement(UIType.CheckBox, UILocatorType.ID, "IsAccessible_rdi_5");
    private UIElement workType = new UIElement(UIType.ListBox, UILocatorType.ID, "WorkCategory");
    private UIElement carrier = new UIElement(UIType.ListBox, UILocatorType.ID, "Carrier");
    private UIElement searchBy = new UIElement(UIType.ListBox, UILocatorType.ID, "SearchFilter");
    private UIElement searchTextbox = new UIElement(UIType.TextBox, UILocatorType.ID, "Search");
    private UIElement searchButtonNAAdjusterHomePage = new UIElement(UIType.TextBox, UILocatorType.ID, "button[@name='CompassLowerPane_CustomerCaseHoldsPage_14']");
    private UIElement paymentContinue = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div[3]/div/div/div/div/div/span/button");
    private UIElement dataLabelRead = new UIElement(UIType.Label, UILocatorType.CSS, ".field-item.dataLabelRead");
    //SNR Buttons
    private UIElement searchButtonNAASG = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div[2]/div/div/div/div/div/div/div/div[5]/div/div/span/button");
    private UIElement wbSearchButton = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div/div/div/div[6]/div/div/span/button");   //".//*[@id='RULE_KEY']/div/div/div/div[6]/div/div/span/button" or ".//*[@id='RULE_KEY']/div[2]/div/div/div/div/div/div/div/div[5]/div/div/span/button"
    private UIElement selectCaseNumberNAASG = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='$PDetailedAllHoldsList$ppxResults$l1']/td[4]/div/span"); //".//*[@id='$PpgRepPgSubSectionReturnManagementWQBB$ppxResults$l1']/td[4]/div/span" or ".//*[@id='$PDetailedAllHoldsList$ppxResults$l1']/td[4]/div/span"
    private UIElement continueBtnRMA = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div[4]/div/div/div/div/div/span/button"); //".//*[@id='RULE_KEY']/div[3]/div/div/div/div/div/span/button or ".//*[@id='RULE_KEY']/div[4]/div/div/div/div/div/span/button"
    private UIElement continueBtn = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div[3]/div/div/div/div/div/span/button"); //UILocatorType.CSS, "button.InFormContinueButton.pzhc"
    private UIElement selectCaseNumberNACST = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='$PpgRepPgSubSectionRefundWQB$ppxResults$l1']/td[4]/div/span");
    private UIElement continueFlowRMA = new UIElement(UIType.Button, UILocatorType.Xpath, "//button[contains(@class,'InFormContinueButton')]//div//*[contains(text(),'Continue')]");
    //PNR Case Number in Workbasket
    private UIElement type1 = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='$PpgRepPgSubSectionReturnManagementWQBB$ppxResults$l1']/td[2]");
    private UIElement type2 = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='$PpgRepPgSubSectionReturnManagementWQBB$ppxResults$l2']/td[2]");

    private UIElement rMAcaseNumber = new UIElement(UIType.Label, UILocatorType.CSS, "#CustomerCaseNumber");
    private UIElement rMAsearchButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[text()='Search']");
    private UIElement rMAAction = new UIElement(UIType.ListBox, UILocatorType.ID, "ReturnAuthorizationResult");
    private UIElement chargePaymentSuccessful = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='20150610200426021027528']");
    private UIElement rMAsearchData = new UIElement(UIType.Label, UILocatorType.Xpath, "//tr[@id='$PpgRepPgSubSectionReturnManagementWQBB$ppxResults$l1']/td[6]");
    private UIElement financeReviewEU = new UIElement(UIType.Label, UILocatorType.Xpath, "//tr[@id='$PD_ClientProfileWorkbasketList$ppxResults$l1']/td[1]/div/span");
    private UIElement customerCaseNumberFinance = new UIElement(UIType.TextBox, UILocatorType.ID, "CustomerCaseNumber");
    private UIElement refundRequestNumber = new UIElement(UIType.TextBox, UILocatorType.Xpath, "//*[@data-test-id='2015060813024206686485']");
    HomePage homePage = new HomePage();

    /**
     * This method is used to search NoEnrollment for Approval and select data
     * search using enrollment request number
     *
     * @author Sachin
     */
    public void searchNoEnrollmentForApproval() throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos"))
            navigateLowestLevelFrame(diaction);

        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found on Landing page", false);
        }


        if (driver.waitForElementPresenceWithTimeOut(wQName, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(wQName, "Enrollment");
        } else {
            Assert.assertTrue("Enrollment option is not found in workbasket drop down list", false);
        }
        CommonUtilities.waitTime(2);
        waitForPageNavigation();
        if (driver.waitForElementPresenceWithTimeOut(escalationNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(escalationNumber, BasePage.enrollmentRequestNumber);
        } else {
            Assert.assertTrue("Escalation Number is not found on Landing page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(search, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(search);
        } else {
            Assert.assertTrue("Search button is not found on Landing page", false);
        }
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(dataEnrollment, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(dataEnrollment);
        } else {
            Assert.assertTrue("Enrollment Data is not found in Workbasket details", false);
        }

    }

    /**
     * This method is used to search hold for Approval and select data Customer Case Hold
     * search using hold number
     *
     * @author Sachin
     */
    public void searchHoldForApproval() throws Exception {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found on Landing page", false);
        }
        //navigateLowestLevelFrame(diaction);
        /*driver.waitForFrameToLoad(diaction, 60);
        if(ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
            driver.waitForFrameToLoad(diaction, 30);
        }*/

        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(wQName, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(wQName, "Customer Case Hold");
        } else {
            Assert.assertTrue("Customer Case Hold option is not found in workbasket drop down list", false);
        }
        waitForPageNavigation();
        CommonUtilities.waitTime(1);
        System.out.println("Refund Number: " + BasePage.refundReqNo);
        if (BasePage.refundReqNo == null || BasePage.refundReqNo.isEmpty())
            driver.type(customerCaseNumberFinance, CaptureIncidentPage.casenumbers.get("CASENUMBER"));
        else
            driver.type(refundRequestNumber, BasePage.refundReqNo);

        if (driver.waitForElementPresenceWithTimeOut(search, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(search);
        } else {
            Assert.assertTrue("Search button is not found on Landing page", false);
        }
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(dataCustomerCaseHold, ApplicationConfiguration.getWaitForElementTimeout())) {
            /*    String sValidateHoldNumber = driver.getText(dataCustomerCaseHold);
                  System.out.println("Validate Hold Number " + sValidateHoldNumber);*/
            //driver.click(dataCustomerCaseHold);
            driver.javaScriptClick(dataCustomerCaseHold);
        } else {
            Assert.assertTrue("Customer Case Hold Data is not found in Workbasket details", false);
        }


    }


    /**
     * This method is used to select hold pocessing action and continue
     *
     * @param sHoldAction eg. Continue with Customer Interaction
     * @author Arjun
     */
    public void holdReleaseProcessAction(String sHoldAction) throws Exception {

        // CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Hold details page", false);
        }
        // navigateLowestLevelFrame(diaction);

        if (sHoldActionType.equalsIgnoreCase("Troubleshooting")) {
            if (driver.waitForElementPresenceWithTimeOut(holdTroubleshootingAction, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.select(holdTroubleshootingAction, sHoldAction);
            } else {
                Assert.assertTrue("holdTroubleshootingAction  is not found on Hold details page", false);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(holdProcessingAction, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.select(holdProcessingAction, sHoldAction);
            } else {
                Assert.assertTrue("Hold Action Link is not found on Hold details page", false);
            }
        }
        if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueButton);
        } else {
            Assert.assertTrue("Continue button is not found on  Hold details page", false);
        }

    }


    /**
     * This method is used to select hold Ppocessing action and continue
     *
     * @param sHoldAction eg. Continue with Customer Interaction
     * @author Sachin
     */
    public void holdProcessAction(String sHoldAction) throws Exception {

        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Hold details page", false);
        }
        // driver.navigateToFrame(cpmInteractionDivFrame);
        navigateLowestLevelFrame(diaction);

        if (driver.waitForElementPresenceWithTimeOut(holdProcessingAction, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(holdProcessingAction, sHoldAction);
        } else {
            Assert.assertTrue("Hold Action Link is not found on Hold details page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueButton);
        } else {
            Assert.assertTrue("Continue button is not found on  Hold details page", false);
        }

    }

    /**
     * This method is used to select release the hold resolution and reaason
     *
     * @param resolution,reason eg. Approved,Verified in Billing System
     * @author Sachin
     * @modified by Arjun on 19 july  for  reason approve functionality.
     */
    public void releaseHoldResolutionReason(String resolution, String reason) throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Hold details page", false);
        }

        if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
            if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("Diaction is not found on Hold details page", false);
            if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
                Assert.assertTrue("cpmTabbedNavigationDivFrame is not found on Hold details page", false);
        }
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos") || ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers") || ApplicationConfiguration.getClient().equalsIgnoreCase("Fido")) {
            if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
                Assert.assertTrue("Diaction is not found on Hold details page", false);
            }
            //Updated code for to check the client for Rogers & fido, cpmTabbedNavigationDivFrame is not found for same client
            if (!ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers") && !ApplicationConfiguration.getClient().equalsIgnoreCase("Fido")) {
                if (driver.checkObjectExists(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.switchToFrame(cpmTabbedNavigationDivFrame);
                }
            }
            if (driver.checkObjectExists(resolutionlink, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(resolutionlink);
//                driver.click(resolutionlink);
            }
//            else {
//                Assert.assertTrue("Resolution Link is not found on  Hold details page", false);
//            }

        }
        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(holdResolution, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(holdResolution, resolution);
        } else {
            Assert.assertTrue("Customer Case Resolution List is not found on  Hold details page", false);
        }
        CommonUtilities.waitTime(1);
        //Updated code for to check the client for Rogers & fido , reason dropdown is disabled.
        if (!ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers") && !ApplicationConfiguration.getClient().equalsIgnoreCase("Fido")) {
            if (driver.checkObjectExists(releaseHoldReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.select(releaseHoldReason, reason);
            }
        }


    }

    /**
     * This method is used to click on continue button on release hold
     *
     * @author Sachin
     */
    public void continueChargeProcess() throws Exception {
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(continueBtnRMA, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueBtnRMA);
        } else {
            Assert.assertTrue("Continue button on RMA Charge page not found", false);
        }
    }

    public void continuedFlow() throws Exception {
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(continueFlowRMA, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueFlowRMA);
        } else {
            Assert.assertTrue("Continue button on RMA Charge page not found", false);
        }
    }

    public void CreateOutboundCall() throws Exception {
        if (driver.waitForElementPresenceWithTimeOut(outboundFlag, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(outboundFlag);
        } else {
            Assert.assertTrue("Outbound Flag check box is not found on  Hold details page", false);
        }


    }

    /**
     * This method is used resume the claim from Action Tab
     *
     * @param sType
     * @author Priyanka
     */
    public void resumeIncidentFromActionTab(String sType) throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Action link", false);
        }
        navigateLowestLevelFrame(diaction);
//        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());
//        if(ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
//            driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());
//        }
        if (driver.waitForElementPresenceWithTimeOut(actionLink, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(actionLink);
        } else {
            Assert.assertTrue("Action Link is not found in Header", false);
        }

        try {
            if (sType.equalsIgnoreCase("IncidentPathDetermination")) {
                if (driver.waitForElementPresenceWithTimeOut(incidentPathDetermination, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.doubleClick(incidentPathDetermination);
                } else {
                    Assert.assertTrue("Incident Path Determination Link is not found in Action link List", false);
                }
            }
        } catch (Exception findFailed) {
            findFailed.printStackTrace();
        }


        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Incident Path Determination page", false);
        }
        navigateLowestLevelFrame(diaction);

        CommonUtilities.waitTime(1);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on Incident Path Determination page", false);
        }
//            }
        if (driver.waitForElementPresenceWithTimeOut(resumeButton, ApplicationConfiguration.getWaitForElementTimeout())) {

            driver.javaScriptClick(resumeButton);
        } else {
            Assert.assertTrue("resumeButton is not found on Incident Path Determination page", false);
        }

    }

    public void verifyAgreementStatus(String statusNo, String status) throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Identify Customer page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Identify Customer page", false);
        }

        if (statusNo.equalsIgnoreCase("first")) {
            if (driver.checkObjectExists(firstAgreemnetStatus, ApplicationConfiguration.getWaitForElementTimeout())) {
                assertEquals("Verify first Agreement Status", driver.getText(firstAgreemnetStatus).toLowerCase(), status.toLowerCase());
            } else
                Assert.assertTrue("firstAgreemnetStatus is not found on Identify Customer page", false);
        } else if (statusNo.equalsIgnoreCase("second")) {
            if (driver.checkObjectExists(secondAgreemnetStatus, ApplicationConfiguration.getWaitForElementTimeout())) {
                assertEquals("Verify second Agreement Status", driver.getText(secondAgreemnetStatus).toLowerCase(), status.toLowerCase());
            } else
                Assert.assertTrue("secondAgreemnetStatus is not found on Identify Customer page", false);
        }


    }


    /**
     * This method is used to click on Active Status row
     *
     * @param status
     * @author Arjun
     * Creation Date : 21 June 2016
     */

    public void clickOnActiveStatusRow(String status) throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Identify Customer page", false);
        }
        // navigateLowestLevelFrame(diaction);
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Identify Customer page", false);
        }
        if (status.equalsIgnoreCase("Active")) {
            if (driver.checkObjectExists(activeStatusRow, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(activeStatusRow);
                CommonUtilities.waitTime(1);
            } else
                Assert.assertTrue("activeStatusRow is not found on Identify Customer page", false);
        }


    }


    /**
     * This method is used verify agreement status in database
     *
     * @author Priyanka
     */
    public void verifyAgreementStatusInDatabase() throws Exception {
        String mdn = CustomerDetails.customerData.get("MDN");
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        //String query = "select agreement_status_code from asset.agreement where agreement_id in(select agreement_id from asset.AGREEMENT_ASSET_XREF where asset_id in(select asset_id from asset.asset where MOBILE_DEVICE_NBR='" + mdn + "'))";
        String query = "select agreement_status_code from asset.agreement where agreement_id in(select agreement_id from asset.AGREEMENT_ASSET_XREF where asset_id in(select asset_id from asset.asset where MOBILE_DEVICE_NBR=dal.XXASU_ENCRYPT_RESTWS_CALL('voltage:fpe:1:enterprise.sprint@asurion.com','" + mdn + "')))";
        String sValue = "";
        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        HashMap<String, String> dataHashMap = null;
        if (result.size() > 0) {
            for (int iCount = 0; iCount < result.size(); iCount++) {
                dataHashMap = result.get(iCount);
                for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                    sValue = sValue + entry.getValue();
                }
            }
        } else
            assertTrue("no record found in asset.agreement table", false);
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
            assertTrue("Verify agreement status code in Database", sValue.contains("ACTV"));
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos")) {
            assertTrue("Verify agreement status code in Database", sValue.contains("ACTV"));
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers")) {
            assertTrue("Verify agreement status code in Database", sValue.contains("ACTV"));
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Fido")) {
            assertTrue("Verify agreement status code in Database", sValue.contains("ACTV"));
        }


    }

    public void update_Start_date(String iDay) throws Exception {
        String mdn = CustomerDetails.customerData.get("MDN");
        // String query = "Update asset.Agreement_Purchase Set Purchase_Date = Purchase_Date - interval '" + iDay + "' day where agreement_id =(select agreement_id from asset.AGREEMENT_ASSET_XREF where asset_id =(select asset_id from asset.asset where MOBILE_DEVICE_NBR='" + mdn + "'))";
        String query = "Update asset.asset Set asset_start_Date=asset_start_Date - interval '" + iDay + "'  day where asset_id in (select asset_id from asset.asset where MOBILE_DEVICE_NBR= '" + mdn + "')";
        System.out.println("query   " + query);
        DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);


    }
    /*
     * This method is used update the asset start date to current date
     * this function update the Purchase_Date
     *
     * @param iDay eg 20 days(back)
     * @author Khushboo
     */

    public void update_Start_dt(String iDay) throws Exception {
        String mdn = CustomerDetails.customerData.get("MDN");
        String query = "Update asset.asset Set asset_start_Date= (sysdate - '" + iDay + "') where asset_id in (select asset_id from asset.asset where MOBILE_DEVICE_NBR= '" + mdn + "')";
        System.out.println("query   " + query);
        DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);


    }

    /*
     * This method is used update the enrollment date in back end(table - asset.Agreement_Purchas)
     * this function update the Purchase_Date
     *
     * @param iDay eg 20 days(back)
     * @author Priyanka
     */
    public void update_enrollment_date(String iDay) throws Exception {
        String mdn = CustomerDetails.customerData.get("MDN");
        //String query = "Update asset.Agreement_Purchase Set Purchase_Date = Purchase_Date - interval '" + iDay + "' day where agreement_id in (select agreement_id from asset.AGREEMENT_ASSET_XREF where asset_id in (select asset_id from asset.asset where MOBILE_DEVICE_NBR='" + mdn + "'))";
        String query = "Update asset.Agreement_Purchase Set Purchase_Date = Purchase_Date - interval '" + iDay + "' day where agreement_id in (select agreement_id from asset.AGREEMENT_ASSET_XREF where asset_id in (select asset_id from asset.asset where MOBILE_DEVICE_NBR=dal.XXASU_ENCRYPT_RESTWS_CALL('voltage:fpe:1:enterprise.sprint@asurion.com','" + mdn + "')))";
        DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);


    }

    /**
     * This method is used check hold in rule_audit table
     * check the rulename(rule should not triggeed)
     *
     * @param sHold,sDatabase,sRuleName
     * @author Priyanka
     * Modified by prabhat.das on 02/26/2016
     * Modification: changed the logic for handling Casenumbers
     */
    public void verifyHoldRuleNotTriggeredQABlokusDatabase(String sHold, String sDatabase, String sRuleName) throws Exception {
        String clientchannelnumber = "";
        String casenumber = "";
        if (!CaptureIncidentPage.casenumbers.containsKey("CASENUMBER1")) {
            if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER")) {
                if (!CaptureIncidentPage.casenumbers.get("CASENUMBER").equalsIgnoreCase(CaptureIncidentPage.claimId)) {
                    casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
                } else {
                    casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER");
                }
            }
        } else {
            if (CaptureIncidentPage.casenumbers.get("CASENUMBER1").equalsIgnoreCase(CaptureIncidentPage.claimId))

                casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
            else
                casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER2");

        }
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Telcel")) {
            clientchannelnumber = "5007";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            clientchannelnumber = "7770001";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro")) {
            clientchannelnumber = "7770101";
        }
        CommonUtilities.waitTime(3);
        String query = "select rulename from rule_audit where casenumber='" + casenumber + "' and clientchannelnumber='" + clientchannelnumber + "' and rulename like '%" + sRuleName + "%'";
        System.out.println("Not hold query" + query);
        String sValue = "";
        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        HashMap<String, String> dataHashMap = null;
        if (result.size() > 0) {
            for (int iCount = 0; iCount < result.size(); iCount++) {
                dataHashMap = result.get(iCount);
                for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                    sValue = sValue + entry.getValue();
                }
            }
        }
//            else
//                assertTrue("no reocrd found in rule_audit table", false);

        assertTrue("Verify Hold status in Database", !(sValue.contains(sRuleName)));

    }

    /**
     * This method is used check hold in rule_audit table
     * check the rulename(rule should triggeed)
     *
     * @param sHold,sDatabase,sRuleName
     * @author Priyanka
     * Modified by prabhat.das on 02/26/2016
     * Modification: changed the logic for handling Casenumbers
     */
    public void verifyHoldQABlokusDatabase(String sHold, String sDatabase, String sRuleName) throws Exception {
//
        String mdn = CustomerDetails.customerData.get("MDN");
        String clientchannelnumber = "";
        String casenumber = "";

        CommonUtilities.waitTime(5);
        if (!CaptureIncidentPage.casenumbers.containsKey("CASENUMBER1")) {
            if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER")) {
                if (!CaptureIncidentPage.casenumbers.get("CASENUMBER").equalsIgnoreCase(CaptureIncidentPage.claimId)) {
                    casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
                } else {
                    casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER");
                }
            }
        } else {
            if (CaptureIncidentPage.casenumbers.get("CASENUMBER1").equalsIgnoreCase(CaptureIncidentPage.claimId))
                casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
            else
                casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER2");
        }
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Telcel")) {
            clientchannelnumber = "5007";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            clientchannelnumber = "7770001";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro")) {
            clientchannelnumber = "7770101";
        }
        CommonUtilities.waitTime(3);
        String query = "select rulename from rule_audit where casenumber='" + casenumber + "' and clientchannelnumber='" + clientchannelnumber + "' and rulename like '%" + sRuleName + "%'";
        // select rulename from rule_audit where casenumber='1012122397' and clientchannelnumber='5007' and ruleaction like '%Document%' and rulename like '%HighEndModel_LowTenure200_Global%'
        String sValue = "";
        System.out.println(query);
        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        HashMap<String, String> dataHashMap = null;
        for (int iCount = 0; iCount < result.size(); iCount++) {
            dataHashMap = result.get(iCount);
            for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                sValue = sValue + entry.getValue();
            }
        }
        System.out.println(sValue);
        System.out.println(sRuleName);
        assertTrue("Verify Hold status in Database", sValue.toLowerCase().contains(sRuleName.toLowerCase().trim()));


    }

    public void verifyCasenumberSameReship() throws Exception {
        driver.navigateToFrame(cpmInteractionDivFrame);
        //driver.switchToFrame(diaction);
        navigateLowestLevelFrame(diaction);
        driver.checkObjectExists(caseNumber, ApplicationConfiguration.getWaitForElementTimeout());
        System.out.println("caseNumber " + driver.getText(caseNumber));
        String storedCaseNo = CustomerDetails.customerData.get("CASENUMBER");
        String sUICaseNo = driver.getText(caseNumber);
        assertTrue("Verify case number should same ", storedCaseNo.equals(sUICaseNo));

    }

    /**
     * This method is used to insert data into ACCOUNT_MASTER table
     *
     * @author Priyanka
     */
    public void insertRecordIntoAccountMasterTable() throws Exception {
        String clientAccountNumber = CustomerDetails.customerData.get("CLIENTACCOUNTNUMBER");
        String iNumber = Generic.RandomNumber();

        String query = "INSERT INTO ACCOUNT_MASTER(ACCOUNTID,ACCOUNTNUMBER,ISNEGATIVE,ISEXCEPTION,RISKCATEGORYID,CLIENTREFERENCEID,NOTES,ISACTIVE) values ('" + iNumber + "','" + clientAccountNumber + "','1','0','002','CR001','Automation','1')";
        DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);

    }

    public void searchHoldForApprovalUsing_MDN() throws Exception {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found on Landing page", false);
        }

        CommonUtilities.waitTime(2);
        if (driver.checkObjectExists(mobileDeviceNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(mobileDeviceNumber, CustomerDetails.customerData.get("MDN"));  // CustomerDetails.customerData.get("MDN")
        } else {
            Assert.assertTrue("MDN is not found on Landing page", false);
        }
        CommonUtilities.waitTime(2);

        if (driver.waitForElementPresenceWithTimeOut(searchButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(searchButton);
        } else {
            Assert.assertTrue("Search button is not found on Landing page", false);
        }
        CommonUtilities.waitTime(10);

        if (driver.waitForElementPresenceWithTimeOut(datanTelos, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(datanTelos);
        } else if (driver.waitForElementPresenceWithTimeOut(dataNACSTnTelos, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(dataNACSTnTelos);
        } else
            Assert.assertTrue("Data is not found in Workbasket details", false);
    }


    public void Verification_of_insurance(String clientOfferName, String insurance) throws Exception {
        String mdn = CustomerDetails.customerData.get("MDN");
        //String query = "Select Client_Offer_Name from Client_Offer where Client_Offer_ID in ( Select Client_Offer_ID from Agreement where CLIENT_ACCOUNT_ID in ( select CLIENT_ACCOUNT_ID from Asset where Mobile_device_nbr = '" + mdn + "'))";
        String query = "Select Client_Offer_Name from Client_Offer where Client_Offer_ID in ( Select Client_Offer_ID from Agreement where CLIENT_ACCOUNT_ID in ( select CLIENT_ACCOUNT_ID from Asset where Mobile_device_nbr =dal.XXASU_ENCRYPT_RESTWS_CALL('voltage:fpe:1:enterprise.sprint@asurion.com','" + mdn + "')))";
        int size = 0;
        String sValue = "";
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        size = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), query).size();
        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), query);
        HashMap<String, String> dataHashMap = null;
        for (int iCount = 0; iCount < size; iCount++) {
            dataHashMap = result.get(iCount);
            for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                sValue = sValue + entry.getValue();
            }
        }
        assertTrue("Verify Hold status in Database", sValue.toLowerCase().contains(clientOfferName.toLowerCase()));
        System.out.println(sValue + " " + insurance);

    }

    public void updateAssetTableWithDetailsisNegativeORisExcisRiskCategoryLookUPID(String isNegORisExc, String isRiskCategoryLookUPID, String client) throws Exception {
        String updateAssetTableQuery = "";
        String clientRefId = "";

        String mdn = CustomerDetails.customerData.get("MDN");
        String make = CustomerDetails.customerData.get("MAKE");
        String model = CustomerDetails.customerData.get("MODEL");

        if (client.equalsIgnoreCase("ntelos")) {
            clientRefId = "3";
        } else if (client.equalsIgnoreCase("telcel")) {
            clientRefId = "1";
        } else if (client.equalsIgnoreCase("claro")) {
            clientRefId = "4";
        }
        if (!isNegORisExc.toLowerCase().contains("null")) {
            if (isNegORisExc.toLowerCase().contains("is_negative")) {
                updateAssetTableQuery = "update Asset set is_negative='" + isNegORisExc.split("=")[1] + "',Risk_Category_LookUP_ID='" + isRiskCategoryLookUPID.split("=")[1] + "' where asset_make_id =(select asset_make_id from Asset_make where asset_make_name = '" + make.trim() + "') and asset_model_id =(select asset_model_id from Asset_model where asset_model_nbr = '" + model.trim() + "') and client_reference_id ='" + clientRefId + "'";

            } else if (isNegORisExc.toLowerCase().contains("is_exception")) {
                updateAssetTableQuery = "update Asset set is_exception='" + isNegORisExc.split("=")[1] + "',Risk_Category_LookUP_ID='" + isRiskCategoryLookUPID.split("=")[1] + "' where asset_make_id =(select asset_make_id from Asset_make where asset_make_name = '" + make.trim() + "') and asset_model_id =(select asset_model_id from Asset_model where asset_model_nbr = '" + model.trim() + "') and client_reference_id ='" + clientRefId + "'";
            }

        } else if (isNegORisExc.toLowerCase().contains("null")) {
            updateAssetTableQuery = "update Asset set is_exception=null,Risk_Category_LookUP_ID=null where asset_make_id =(select asset_make_id from Asset_make where asset_make_name = '" + make.trim() + "') and asset_model_id =(select asset_model_id from Asset_model where asset_model_nbr = '" + model.trim() + "') and client_reference_id ='" + clientRefId + "'";

        }

        DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), updateAssetTableQuery);


    }

    public void updateAssetTableWithDetailsActivefromdateActivefromdate(String isNegative, String isExeception, String isRiskCategoryLookUPID, String activefromdate, String activeTodate, String client) throws Exception {
        String updateAssetTableQuery = "";
        String clientRefId = "";

        String mdn = CustomerDetails.customerData.get("MDN");
        String make = CustomerDetails.customerData.get("MAKE");
        String model = CustomerDetails.customerData.get("MODEL");


        if (client.equalsIgnoreCase("ntelos")) {
            clientRefId = "3";
        } else if (client.equalsIgnoreCase("telcel")) {
            clientRefId = "1";
        } else if (client.equalsIgnoreCase("claro")) {
            clientRefId = "4";
        }
        String activeFromDate = "(select TO_CHAR(sysdate-" + activefromdate + ", 'DD-MON-YY') from dual)";
        String activeToDate = "(select TO_CHAR(sysdate-" + activeTodate + ", 'DD-MON-YY') from dual)";


        if (!(isNegative.toLowerCase().contains("null")) && !(isExeception.toLowerCase().contains("null"))) {
            updateAssetTableQuery = "update Asset set is_negative='" + isNegative + "',is_exception='" + isExeception + "',Risk_Category_LookUP_ID='" + isRiskCategoryLookUPID + "',active_from_date = " + activeFromDate + ",active_to_date = " + activeToDate + " where asset_make_id =(select asset_make_id from Asset_make where asset_make_name = '" + make.trim() + "') and asset_model_id =(select asset_model_id from Asset_model where asset_model_nbr like '%" + model.trim() + "%') and client_reference_id ='" + clientRefId + "'";
        } else if ((isNegative.toLowerCase().contains("null")) && !(isExeception.toLowerCase().contains("null"))) {
            updateAssetTableQuery = "update Asset set is_negative=null,is_exception='" + isExeception + "',Risk_Category_LookUP_ID='" + isRiskCategoryLookUPID + "',active_from_date = " + activeFromDate + ",active_to_date = " + activeToDate + " where asset_make_id =(select asset_make_id from Asset_make where asset_make_name = '" + make.trim() + "') and asset_model_id =(select asset_model_id from Asset_model where asset_model_nbr like '%" + model.trim() + "%') and client_reference_id ='" + clientRefId + "'";
        } else if (!(isNegative.toLowerCase().contains("null")) && (isExeception.toLowerCase().contains("null"))) {
            updateAssetTableQuery = "update Asset set is_negative='" + isNegative + "',is_exception=null,Risk_Category_LookUP_ID='" + isRiskCategoryLookUPID + "',active_from_date = " + activeFromDate + ",active_to_date = " + activeToDate + " where asset_make_id =(select asset_make_id from Asset_make where asset_make_name = '" + make.trim() + "') and asset_model_id =(select asset_model_id from Asset_model where asset_model_nbr like '%" + model.trim() + "%') and client_reference_id ='" + clientRefId + "'";
        } else if ((isNegative.toLowerCase().contains("null")) && (isExeception.toLowerCase().contains("null"))) {
            updateAssetTableQuery = "update Asset set is_negative=null,is_exception=null,Risk_Category_LookUP_ID='" + isRiskCategoryLookUPID + "',active_from_date = " + activeFromDate + ",active_to_date = " + activeToDate + " where asset_make_id =(select asset_make_id from Asset_make where asset_make_name = '" + make.trim() + "') and asset_model_id =(select asset_model_id from Asset_model where asset_model_nbr like '%" + model.trim() + "%') and client_reference_id ='" + clientRefId + "'";
        }

        DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), updateAssetTableQuery);

        String selectRiskCategoryLookUPIDQuery = "select Risk_Category_LookUP_ID from Asset where asset_make_id =(select asset_make_id from Asset_make where asset_make_name = '" + make.trim() + "') and asset_model_id =(select asset_model_id from Asset_model where asset_model_nbr like '% " + model.trim() + "%') and client_reference_id ='" + clientRefId + "'";
        String sRetrivedResult = "";
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), selectRiskCategoryLookUPIDQuery);
        HashMap<String, String> dataHashMap = null;
        for (int iCount = 0; iCount < result.size(); iCount++) {
            dataHashMap = result.get(iCount);
            for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                sRetrivedResult = sRetrivedResult + entry.getValue();
            }
        }

        assertTrue("Verify data is updated or not in Database", sRetrivedResult.contains(isRiskCategoryLookUPID));


    }


    public void storeAssertDetails() throws Exception {
        String mdn = CustomerDetails.customerData.get("MDN");

        //String query = "select asset_catalog_name from asset.asset_catalog where asset_catalog_id=(select asset_catalog_ID from asset.asset where mobile_device_nbr='" + mdn + "')";
        String query = "select asset_catalog_name from asset.asset_catalog where asset_catalog_id=(select asset_catalog_ID from asset.asset where mobile_device_nbr=dal.XXASU_ENCRYPT_RESTWS_CALL('voltage:fpe:1:enterprise.sprint@asurion.com','" + mdn + "'))";
        int size = 0;
        String sValue = "";
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        size = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query).size();
        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        HashMap<String, String> dataHashMap = null;
        for (int iCount = 0; iCount < size; iCount++) {
            dataHashMap = result.get(iCount);
            for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                sValue = sValue + entry.getValue();
            }
        }

        BasePage.assetDeatils = sValue;


    }


    public void updateAssetTableUsingAssetCatalog(String isNegORisExc, String isRiskCategoryLookUPID, String client) throws Exception {
        String sqlUpdateQuery = "";
        String clientRefId = "";

        String mdn = CustomerDetails.customerData.get("MDN");
        String make = CustomerDetails.customerData.get("MAKE");
        String model = CustomerDetails.customerData.get("MODELNAME");
        String modelName = model.substring(model.indexOf(" "), model.length());
        if (client.equalsIgnoreCase("ntelos")) {
            clientRefId = "3";
        } else if (client.equalsIgnoreCase("telcel")) {
            clientRefId = "1";
        } else if (client.equalsIgnoreCase("claro")) {
            clientRefId = "4";
        }
        if (!isNegORisExc.toLowerCase().contains("null")) {
            if (isNegORisExc.toLowerCase().contains("is_negative")) {
                sqlUpdateQuery = "update Asset set is_negative='" + isNegORisExc.split("=")[1] + "',Risk_Category_LookUP_ID='" + isRiskCategoryLookUPID.split("=")[1] + "' where asset_make_id =(select asset_make_id from Asset_make where asset_make_name = '" + make.trim() + "') and asset_model_id =(select asset_model_id from Asset_model where asset_model_nbr like '%" + modelName.trim() + "%') and client_reference_id ='" + clientRefId + "'";

            } else if (isNegORisExc.toLowerCase().contains("is_exception")) {
                sqlUpdateQuery = "update Asset set is_exception='" + isNegORisExc.split("=")[1] + "',Risk_Category_LookUP_ID='" + isRiskCategoryLookUPID.split("=")[1] + "' where asset_make_id =(select asset_make_id from Asset_make where asset_make_name = '" + make.trim() + "') and asset_model_id =(select asset_model_id from Asset_model where asset_model_nbr like '%" + modelName.trim() + "%') and client_reference_id ='" + clientRefId + "'";
            }

        } else if (isNegORisExc.toLowerCase().contains("null")) {
            sqlUpdateQuery = "update Asset set is_exception=null,Risk_Category_LookUP_ID=null where asset_make_id =(select asset_make_id from Asset_make where asset_make_name = '" + make.trim() + "') and asset_model_id =(select asset_model_id from Asset_model where asset_model_nbr like = '" + model.trim() + "') and client_reference_id ='" + clientRefId + "'";

        }

        System.out.println("query " + sqlUpdateQuery);

        DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), sqlUpdateQuery);


    }

    public void searchHoldUsingStageAndCaseNumber() throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found on Landing page", false);
        }
        if (driver.checkObjectExists(holdStage, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(holdStage, "Pending");
        } else {
            Assert.assertTrue("Hold State is not found on Hold Details page", false);
        }
        if (driver.checkObjectExists(holdCustomerCaseNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(holdCustomerCaseNumber, CustomerDetails.customerData.get("CASENUMBER"));
        } else {
            Assert.assertTrue("Customer Case Number for hold is not found on Hold Details page", false);
        }


    }

    public void searchNoEnrollmentForApprovalEU() {

        CommonUtilities.waitTime(10);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout());
        CommonUtilities.waitTime(4);
        if (driver.elementExists(wQNameEU) || driver.checkObjectExists(wQNameEU, 45)) {
            driver.select(wQNameEU, "Enrollment");
            System.out.println("Selected Enrollment in drop down list on home page");
        } else {
            System.out.println("Enrollment not found in drop down list on home page");
            Assert.assertTrue("Enrollment not found in drop down list on home page", false);
        }

        waitForPageNavigation();

        if (driver.checkObjectExists(mobileDeviceNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(mobileDeviceNumber, CustomerDetails.customerData.get("MDN"));
            System.out.println("Entered MDN on home page");
        } else {
            System.out.println("MDN not found on home page");
            Assert.assertTrue("MDN not found on home page", false);
        }

        if (driver.checkObjectExists(search, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(search);
            System.out.println("Clicked on search button on home page");
        } else {
            System.out.println("Search button not found on home page");
            Assert.assertTrue("Search button not found on home page", false);
        }
        CommonUtilities.waitTime(2);

        if (driver.checkObjectExists(dataEnrollment, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(dataEnrollment);
            System.out.println("Clicked on data enrollment button on home page");
        } else {
            System.out.println("Data Enrollment button not found on home page");
            Assert.assertTrue("Data Enrollment button not found on home page", false);
        }
    }

    public void selectViewQueueEU(String types) {
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout());

        if (driver.checkObjectExists(wQName, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(wQName, types);
            System.out.println("Selected View Queue for from drop down list on home page" + types);
        } else {
            System.out.println("View Queue for drop down list not found on home page");
            Assert.assertTrue("View Queue for drop down list not found on home page", false);
        }
        CommonUtilities.waitTime(5);
        waitForPageNavigation();

        if (driver.checkObjectExists(mobileDeviceNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(mobileDeviceNumber, CustomerDetails.customerData.get("MDN"));
            System.out.println("Entered MDN on home page");
        } else {
            System.out.println("MDN not found on home page");
            Assert.assertTrue("MDN not found on home page", false);
        }
        if (driver.checkObjectExists(search, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(search);
            System.out.println("Clicked on search button on home page");
        } else {
            System.out.println("Search button not found on home page");
            Assert.assertTrue("Search button not found on home page", false);
        }
        CommonUtilities.waitTime(2);

        if (driver.checkObjectExists(claimCancellationQueueEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(claimCancellationQueueEU);
            System.out.println("Clicked on Claim Cancellation Queue on home page");
        } else {
            System.out.println("Claim Cancellation Queue not found on home page");
            Assert.assertTrue("Claim Cancellation Queue not found on home page", false);
        }

    }


    public void cancellationActionReasonEU(String CancelReason, String ResolutionReason) {
        CommonUtilities.waitTime(8);
        driver.switchToDefaultContent();
        driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout());
        driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout());
//        driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout());

        if (driver.checkObjectExists(cancellationActionEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(cancellationActionEU, CancelReason);
            System.out.println("Selected Incident Cancellation Reason " + CancelReason);
        } else {
            System.out.println("Incident Cancellation Reason drop down not found");
            Assert.assertTrue("Incident Cancellation Reason drop down not found", false);
        }
        if (driver.checkObjectExists(resolutionReasonEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(resolutionReasonEU, ResolutionReason);
            System.out.println("Selected Incident Resolution Reason" + ResolutionReason);
        } else {
            System.out.println("Incident Resolution Reason drop down not found");
            Assert.assertTrue("Incident Resolution Reason drop down not found", false);
        }
        if (driver.checkObjectExists(cancellationActionContinueButtonEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(cancellationActionContinueButtonEU);
            System.out.println("Clicked on cancellation Action Continue Button ");
        } else {
            System.out.println("Cancellation Action Continue Button not found");
            Assert.assertTrue("Cancellation Action Continue Button not found", false);
        }
    }

    /**
     * This method is used check hold in QA-BK db
     * check the rulename(rule should triggeed)
     *
     * @param sHold,sDatabase,sRuleName
     * @author Priyanka
     * Date - 10/05/2016
     */
    public void verifyRulenameQABackingDatabase(String sHold, String sDatabase, String sRuleName) throws Exception {


//
        String mdn = CustomerDetails.customerData.get("MDN");
        String clientchannelnumber = "";
//            String casenumber = CustomerDetails.customerData.get("CASENUMBER");
        String casenumber = "";

        CommonUtilities.waitTime(2);
        if (!CaptureIncidentPage.casenumbers.containsKey("CASENUMBER1")) {
            if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER")) {
                if (!CaptureIncidentPage.casenumbers.get("CASENUMBER").equalsIgnoreCase(CaptureIncidentPage.claimId)) {
                    casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
                } else {
                    casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER");
                }
            }
        } else {
            if (CaptureIncidentPage.casenumbers.get("CASENUMBER1").equalsIgnoreCase(CaptureIncidentPage.claimId))
                casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER1");
            else
                casenumber = CaptureIncidentPage.casenumbers.get("CASENUMBER2");
        }
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Telcel")) {
            clientchannelnumber = "5007";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            clientchannelnumber = "7770001";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro")) {
            clientchannelnumber = "7770101";
        }
        CommonUtilities.waitTime(3);
        String query = "select rulename from rule_audit where casenumber='" + casenumber + "' and clientchannelnumber='" + clientchannelnumber + "' and rulename like '%" + sRuleName + "%'";
        // select rulename from rule_audit where casenumber='1012122397' and clientchannelnumber='5007' and ruleaction like '%Document%' and rulename like '%HighEndModel_LowTenure200_Global%'
        String sValue = "";
        System.out.println(query);
        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        HashMap<String, String> dataHashMap = null;
        for (int iCount = 0; iCount < result.size(); iCount++) {
            dataHashMap = result.get(iCount);
            for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                sValue = sValue + entry.getValue();
            }
        }
        assertTrue("Verify Hold status in Database", sValue.toLowerCase().contains(sRuleName.toLowerCase().trim()));


    }


    /**
     * This method is used check rule event in QA-BK databse.
     * check the rulename(rule should triggeed)
     *
     * @param sEventName,sTableName,sDatabase
     * @author Arjun
     * Date -2 june 2016
     */
    public void verifyRuleEventQABackingDatabase(String sEventName, String sTableName, String sDatabase) throws Exception {
        String mdn = CustomerDetails.customerData.get("MDN");
        String actualEventName = "";
        String eventServiceRequest = "";
        String eventHoldChange = "";
        String eventIncidentType = "";
        String[] allParameterStringArray;

        if (sTableName.equalsIgnoreCase("D_velocityTable")) {
            allParameterStringArray = sEventName.split(",");
            eventIncidentType = allParameterStringArray[0];
            if (allParameterStringArray.length > 1)
                eventServiceRequest = allParameterStringArray[1];
            if (allParameterStringArray.length > 2)
                eventHoldChange = allParameterStringArray[2];
        }

        //String clientchannelnumber = "";
        //String casenumber ="";
        String clientAccID = "";
        CommonUtilities.waitTime(2);
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        ArrayList<HashMap<String, String>> resultClientAccountIDS = new ArrayList<>();
        ArrayList<HashMap<String, String>> resultInteractionLineNbr = new ArrayList<>();
        ArrayList<HashMap<String, String>> resultEventDetails = new ArrayList<>();
        CommonUtilities.waitTime(2);

        //Get Client Account ID from dal db
        //  String queryClinetAcountID = "select CLIENT_ACCOUNT_ID from Asset where  MOBILE_DEVICE_NBR ='" + mdn + "'";
        String queryClinetAcountID = "select CLIENT_ACCOUNT_ID from Asset where  MOBILE_DEVICE_NBR =dal.XXASU_ENCRYPT_RESTWS_CALL('voltage:fpe:1:enterprise.sprint@asurion.com','" + mdn + "')";
        resultClientAccountIDS = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), queryClinetAcountID);
        clientAccID = resultClientAccountIDS.get(0).get("CLIENT_ACCOUNT_ID");

        //Get interaction line number from dal db
        String queryInteractionLine = "select INTERACTION_LINE_NBR from INTERACTION_LINE where CLIENT_ACCOUNT_ID  ='" + clientAccID + "'order by INTERACTION_LINE_NBR desc";
        resultInteractionLineNbr = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), queryInteractionLine);
        String interactionLineNbr = resultInteractionLineNbr.get(0).get("INTERACTION_LINE_NBR");

        //Check the rule name in Backing db.
        //String queryEvent = "select * from d_velocity  where interactionnumber  ='" + interactionLineNbr + "'" ;
        String queryEvent = "select ES.eventname from D_EventSubscription ES ,D_Interaction_EventSubscrip_EB linktable ,D_interaction interaction where linktable.pid$=interaction.id$ and ES.id$=linktable.id$ and interaction.interactionnumber='" + interactionLineNbr + "'";

        resultEventDetails = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "bk"), interactionLineNbr);
        String sValue = "";
        System.out.println(queryEvent);
        HashMap<String, String> dataHashMap = null;
        for (int iCount = 0; iCount < result.size(); iCount++) {
            dataHashMap = result.get(iCount);
            for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                sValue = sValue + entry.getValue();
            }
        }

        //String eventDetails = resultEventDetails.get(0).get("NAME");
        //assertTrue("Verification of evenrt name in DB", resultEventDetails.get(0).get("NAME").equalsIgnoreCase(sEventName));
        if (sTableName.equalsIgnoreCase("D_velocityTable")) {
            if (eventIncidentType != null) {
                assertTrue("Verify event name in Database", sValue.toLowerCase().contains(eventIncidentType.toLowerCase().trim()));
            }

            if (eventServiceRequest != null) {
                assertTrue("Verify event name in Database", sValue.toLowerCase().contains(eventServiceRequest.toLowerCase().trim()));
            }

            if (eventHoldChange != null) {
                assertTrue("Verify event name in Database", sValue.toLowerCase().contains(eventHoldChange.toLowerCase().trim()));
            }
        } else
            assertTrue("Verify event name in Database", sValue.toLowerCase().contains(eventIncidentType.toLowerCase().trim()));


    }

    /**
     * This method is used check rule event in QA-BK databse.
     * check the rulename(rule should triggeed)
     *
     * @param sEventName,sTableName,sDatabase
     * @author Khushboo
     * Date -29 july 2016
     */
    public void verifyRuleEventQABackingDb(String sEventName, String sTableName) throws Exception {
        //verifyEventQABackingDb

        String mdn = CustomerDetails.customerData.get("MDN");
        String actualEventName = "";
        String eventServiceRequest = "";
        String eventHoldChange = "";
        String eventIncidentType = "";
        String[] allParameterStringArray;

        if (sTableName.equalsIgnoreCase("EventSubscription")) {
            allParameterStringArray = sEventName.split(",");
            eventIncidentType = allParameterStringArray[0];
            if (allParameterStringArray.length > 1)
                eventServiceRequest = allParameterStringArray[1];
            if (allParameterStringArray.length > 2)
                eventHoldChange = allParameterStringArray[2];
        }
        String clientAccID = "";
        CommonUtilities.waitTime(2);
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        ArrayList<HashMap<String, String>> resultClientAccountIDS = new ArrayList<>();
        ArrayList<HashMap<String, String>> resultInteractionLineNbr = new ArrayList<>();
        ArrayList<HashMap<String, String>> resultEventDetails = new ArrayList<>();
        CommonUtilities.waitTime(2);

        //Get Client Account ID from dal db
        // String queryClinetAcountID = "select CLIENT_ACCOUNT_ID from asset.asset where  MOBILE_DEVICE_NBR ='" + mdn + "'";
        String queryClinetAcountID = "select CLIENT_ACCOUNT_ID from asset.asset where  MOBILE_DEVICE_NBR =dal.XXASU_ENCRYPT_RESTWS_CALL('voltage:fpe:1:enterprise.sprint@asurion.com','" + mdn + "')";
        resultClientAccountIDS = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), queryClinetAcountID);
        clientAccID = resultClientAccountIDS.get(0).get("CLIENT_ACCOUNT_ID");

        //Get interaction line number from dal db
        String queryInteractionLine = "select INTERACTION_LINE_NBR from INTERACTION_LINE where CLIENT_ACCOUNT_ID  ='" + clientAccID + "'order by INTERACTION_LINE_NBR desc";
        resultInteractionLineNbr = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), queryInteractionLine);
        String interactionLineNbr = resultInteractionLineNbr.get(0).get("INTERACTION_LINE_NBR");

        //Check the rule name in Backing db.
        //String queryEvent = "select * from d_velocity  where interactionnumber  ='" + interactionLineNbr + "'" ;
        String queryEvent = "select ES.eventname from D_EventSubscription ES ,D_Interaction_EventSubscrip_EB linktable ,D_interaction interaction where linktable.pid$=interaction.id$ and ES.id$=linktable.id$ and interaction.interactionnumber='" + interactionLineNbr + "'";

        resultEventDetails = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "bk"), interactionLineNbr);
        String sValue = "";
        System.out.println(queryEvent);
        HashMap<String, String> dataHashMap = null;
        for (int iCount = 0; iCount < result.size(); iCount++) {
            dataHashMap = result.get(iCount);
            for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                sValue = sValue + entry.getValue();
            }
        }
        if (sTableName.equalsIgnoreCase("D_EventSubscription")) {
            if (eventIncidentType != null) {
                assertTrue("Verify event name in Database", sValue.toLowerCase().contains(eventIncidentType.toLowerCase().trim()));
            }

            if (eventServiceRequest != null) {
                assertTrue("Verify event name in Database", sValue.toLowerCase().contains(eventServiceRequest.toLowerCase().trim()));
            }

            if (eventHoldChange != null) {
                assertTrue("Verify event name in Database", sValue.toLowerCase().contains(eventHoldChange.toLowerCase().trim()));
            }
        } else
            assertTrue("Verify event name in Database", sValue.toLowerCase().contains(eventIncidentType.toLowerCase().trim()));


    }

    /**
     * This method is used check rule event in QA-BK databse.
     * check the rulename(rule should triggeed)
     *
     * @param sEventName,sTableName,sDatabase
     * @author Khushboo
     * Date -29 july 2016
     */
   /* public void verifyEventQABackingDb(String sEventName, String sDBName) throws Exception {
        //verifyEventQABackingDb

        String mdn = CustomerDetails.customerData.get("MDN");

        String arrEventName[] = sEventName.split(",");

        ArrayList<HashMap<String, String>> result = new ArrayList<>();

        String selectEventQuery = "select ES.eventname from D_EventSubscription ES ,D_Interaction_EventSubscrip_EB linktable ,D_interaction interaction where linktable.pid$=interaction.id$ and ES.id$=linktable.id$";

        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "BK"), selectEventQuery);
        String sEventNameformDB = "";
        System.out.println(selectEventQuery);

        HashMap<String, String> dataHashMap = null;
        if (result.size() > 0) {
            for (int iCount = 0; iCount < result.size(); iCount++) {
                dataHashMap = result.get(iCount);
                for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                    sEventNameformDB = sEventNameformDB + entry.getValue();
                }
            }
            for (int jCount = 0; jCount < arrEventName.length; jCount++) {
                assertTrue("verification of event name ", sEventNameformDB.contains(arrEventName[jCount]));
            }
        } else
            assertTrue("no records found in table ", false);


    }

*/

    /**
     * This method is used to search the hold and approve it
     *
     * @Param sHoldType
     * @author Arjun
     * Date -22 june 2016
     */
    public void searchHoldAndApproval(String sHoldType) throws Exception {
        sHoldActionType = sHoldType;
        //  CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found on Landing page", false);
        }
        //   CommonUtilities.waitTime(3);
        if (driver.waitForElementPresenceWithTimeOut(wQName, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(wQName, sHoldType);
        } else {
            Assert.assertTrue("Troubleshoot Hold option is not found in workbasket drop down list", false);
        }
        // CommonUtilities.waitTime(1);
        //  waitForPageNavigation();
        if (driver.waitForElementPresenceWithTimeOut(mobileDeviceNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(mobileDeviceNumber, CustomerDetails.customerData.get("MDN"));
        } else {
            Assert.assertTrue("mobileDeviceNumber is not found on Landing page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(search, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(search);
        } else {
            Assert.assertTrue("Search button is not found on Landing page", false);
        }
        CommonUtilities.waitTime(4);
        if (driver.waitForElementPresenceWithTimeOut(dataTroubleshootHold, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(dataTroubleshootHold);
        } else {
            Assert.assertTrue("dataTroubleshootHold Hold Data is not found in Workbasket details", false);
        }

    }


    /**
     * This method is used release hold with resolution for Triage
     *
     * @author Arjun
     * @Param resolution, triageOption
     * date - 22/06/2015
     */
    public void releaseHoldResolutionWithTriageOption(String resolution, String triageOption, String reason) throws Exception {
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Hold details page", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found for " + ApplicationConfiguration.getClient() + " on MyworkPage)", false);

        if (driver.waitForElementPresenceWithTimeOut(resolutionType, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(resolutionType, resolution);
        } else {
            Assert.assertTrue("resolutionType  List is not found on  Hold details page", false);
        }
        //    CommonUtilities.waitTime(1);
        if (triageOption.equalsIgnoreCase("Triage Successful")) {
            if (driver.checkObjectExists(triageSuccessful, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(triageSuccessful);
            } else {
                Assert.assertTrue("triageSuccessful option is not found on  Hold details page", false);
            }
            //Select the Triage Reason
            // CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(traigeReasonCode, ApplicationConfiguration.getWaitForElementTimeout())) {
                //driver.select(traigeReasonCode, "Customer Issue Resolved");
                driver.select(traigeReasonCode, reason);
            } else {
                Assert.assertTrue("traigeReason is not found on  Hold details page", false);
            }
        }
//            CommonUtilities.waitTime(1);
        if (triageOption.equalsIgnoreCase("Triage Unsuccessful")) {
            if (driver.checkObjectExists(triageUnsuccessful, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(triageUnsuccessful);
            } else {
                Assert.assertTrue("triageUnsuccessful option is not found on  Hold details page", false);
            }
            //Select the Triage Reason
            CommonUtilities.waitTime(2);
            if (driver.waitForElementPresenceWithTimeOut(traigeReasonCode, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.select(traigeReasonCode, reason);
                //driver.select(traigeReason, "Customer Issue Resolved");
            } else {
                Assert.assertTrue("traigeReason is not found on  Hold details page", false);
            }
        }
        //Click on Continue button
        if (driver.checkObjectExists(continueBtn, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueBtn);
            //  CommonUtilities.waitTime(2);
        } else {
            Assert.assertTrue("continueBtn is not found on  Hold details page", false);
        }


    }


    /**
     * This method is used approve refund from workQueue.
     *
     * @author Arjun
     * @Param sReason
     * date - 26/06/2015
     */
    public void approveRefundFromFinanceWorkQueue(String sReason) throws Exception {
        String arrRefund[] = sReason.split(":");
        String refundReson = arrRefund[0];
        String refundAction = arrRefund[1];
        String refundOverrideReason = arrRefund[2];
        String sApprovalAmount = null;
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found found on finance review workbasket page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(financeReview, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(financeReview);
        } else {
            Assert.assertTrue("financeReview is not found on finance review workbasket page", false);
        }
        waitForPageNavigation();
        CommonUtilities.waitTime(1);
        System.out.println("Refund Number: " + BasePage.refundReqNo);
        if (BasePage.refundReqNo == null || BasePage.refundReqNo.isEmpty())
            driver.type(customerCaseNumberFinance, CaptureIncidentPage.casenumbers.get("CASENUMBER"));
        else
            driver.type(refundRequestNumber, BasePage.refundReqNo);

       /* if (driver.waitForElementPresenceWithTimeOut(customerCaseHoldNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            CommonUtilities.waitTime(1);
            driver.type(customerCaseHoldNumber, BasePage.refundReqNo);
        } else {
            Assert.assertTrue("Customer Case Hold Number is not found on finance review workbasket page", false);
        }*/
        if (driver.waitForElementPresenceWithTimeOut(searchClick, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(searchClick);
        } else {
            Assert.assertTrue("Search button is not found on finance review workbasket", false);
        }
        CommonUtilities.waitTime(5);
        if (driver.elementExists(dataLabelRead)) {
            if (driver.getText(dataLabelRead).equalsIgnoreCase("No work items available")) {
                System.out.println("Refund Request is not found in Finance Review Workbasket");
                homePage.switchUserAccount("NACST");
                System.out.println("I approve refund request from Finance Review Workbasket");
                approveRefundFromWorkBasket("Approve:Submit:Customer Escalation");
            }
        } else {
            CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(dataFinanceReview, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(dataFinanceReview);
            } else {
                Assert.assertTrue("Finance review Data is not found on finance review workbasket page", false);
            }
            CommonUtilities.waitTime(3);
            driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
                Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
            }
            if (driver.waitForElementPresenceWithTimeOut(refundActions, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(refundActions, refundReson);
            else
                Assert.assertTrue("refundReasonAction is not found on Refund WB page", false);
            CommonUtilities.waitTime(2);
            if (driver.waitForElementPresenceWithTimeOut(refundResult, ApplicationConfiguration.getWaitForElementTimeout())) {
                CommonUtilities.waitTime(2);
                driver.select(refundResult, "Return to Workqueue");
                CommonUtilities.waitTime(2);
                driver.select(refundResult, refundAction);
            } else
                Assert.assertTrue("RefundResult  is not found on Refund WB page", false);

            if (driver.waitForElementPresenceWithTimeOut(refundWBContinue, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(refundWBContinue);
            else
                Assert.assertTrue("refundWBContinue button is not found on finance review workbasket page", false);
        }
    }

    /**
     * This method is used approve refund from work backet
     *
     * @author Priyanka
     * @Param resons(seperated by :)
     * date - 14/06/2015
     */
    public void approveRefundFromWorkBasket(String sReason) throws Exception {
        String arrRefund[] = sReason.split(":");
        String refundReson = arrRefund[0];
        String careRefund = arrRefund[1];
        String refundOverrideReason = arrRefund[2];

        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found on Landing page", false);
        }

        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(wQName, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(wQName, "Refund Workbasket");
        } else {
            Assert.assertTrue("Customer Case Hold option is not found in workbasket drop down list", false);
        }
        CommonUtilities.waitTime(1);
        waitForPageNavigation();
        CommonUtilities.waitTime(1);
        System.out.println("Refund Number: " + BasePage.refundReqNo);
        if (BasePage.refundReqNo == null || BasePage.refundReqNo.isEmpty())
            driver.type(customerCaseNumberFinance, CaptureIncidentPage.casenumbers.get("CASENUMBER"));
        else
            driver.type(refundRequestNumber, BasePage.refundReqNo);

        if (driver.waitForElementPresenceWithTimeOut(search, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(search);
        } else {
            Assert.assertTrue("Search button is not found on Landing page", false);
        }
        CommonUtilities.waitTime(5);
        if (driver.elementExists(dataLabelRead)) {
            if (driver.getText(dataLabelRead).equalsIgnoreCase("No work items available"))
                System.out.println("Refund Request is not found in Refund Workbasket");
        } else {
            CommonUtilities.waitTime(5);
            if (driver.waitForElementPresenceWithTimeOut(dataRefundWQB, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(dataRefundWQB);
            } else {
                Assert.assertTrue("Customer Case Hold Data is not found in Workbasket details", false);
            }

            CommonUtilities.waitTime(4);
            driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
                Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
            }

            if (driver.waitForElementPresenceWithTimeOut(refundReasonAction, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(refundReasonAction, refundReson);
            else
                Assert.assertTrue("refundReasonAction is not found on Refund WB page", false);

            if (driver.waitForElementPresenceWithTimeOut(careRefundResult, ApplicationConfiguration.getWaitForElementTimeout())) {
                CommonUtilities.waitTime(2);
                driver.select(careRefundResult, "Return to Workqueue");
                CommonUtilities.waitTime(2);
                driver.select(careRefundResult, careRefund);
            } else
                Assert.assertTrue("careRefundResult  is not found on Refund WB page", false);
            CommonUtilities.waitTime(3);
            if (driver.waitForElementPresenceWithTimeOut(refundOverrideReasonCode, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(refundOverrideReasonCode, refundOverrideReason);

            if (driver.waitForElementPresenceWithTimeOut(refundWBContinue, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(refundWBContinue);
            else
                Assert.assertTrue("refundWBContinue button is not found on Refund WB page", false);

            if (driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
                if (!driver.isSelected(escalate)) {
                    driver.click(escalate);
                    if (driver.checkObjectExists(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                        driver.select(escalateReason, "Customer Goodwill");
                        driver.javaScriptClick(continueButton);
                        homePage.switchUserAccount("NAFinance");
                        approveRefundFromNAFinanceWorkBasket("Approve:Submit");
                    }
                }
            }
        }
    }

        /**
         * This method is used to check Velocity in D_Velocity Table
         *
         * @author Priyanka
         * @Param sVelocityType(seperated by, ) and velocityCount
         * date - 29/07/2016
         */

    public void checkVelocityD_VelocityTable(String sVelocityType, String velocityCount) throws Exception {
        String arrVelocityCount[] = null;
        if (velocityCount.contains("than")) {
            arrVelocityCount = velocityCount.split("than");
            velocityCount = arrVelocityCount[1].trim();
        }
        String arrVelocityType[] = sVelocityType.split(",");
        System.out.println(sVelocityType);
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        // String selectInteractionNo = "Select INTERACTION_line_NBR from INTERACTION.INTERACTION_line where Client_account_ID in( Select Client_account_id from ASSET.Asset where Mobile_device_nbr = '" + CustomerDetails.customerData.get("MDN") + "') Order by created_date desc";
        String selectInteractionNo = "Select INTERACTION_line_NBR from INTERACTION.INTERACTION_line where Client_account_ID in( Select Client_account_id from ASSET.Asset where Mobile_device_nbr =dal.XXASU_ENCRYPT_RESTWS_CALL('voltage:fpe:1:enterprise.sprint@asurion.com','" + CustomerDetails.customerData.get("MDN") + "'))and AGENT_NAME ='svc.US_q_Horizon_A' Order by created_date desc";

        String interaction_nbr = "";
        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), selectInteractionNo);
        HashMap<String, String> dataHashMap = null;

        if (result.size() > 0)
            interaction_nbr = result.get(0).get("INTERACTION_LINE_NBR");
        else
            assertTrue("no record found on welcome letters after create new enrollments", false);

        String tempVar = "";
        for (int iCounter = 0; iCounter < arrVelocityType.length; iCounter++) {
            if (iCounter != arrVelocityType.length - 1)
                tempVar = tempVar + "'" + arrVelocityType[iCounter] + "',";
            else
                tempVar = tempVar + "'" + arrVelocityType[iCounter] + "'";
        }

        String selectVelocityQuery = "select velocity from D_Velocity where VELOCITYTYPE in (" + tempVar + ") and INTERACTIONNUMBER = '" + interaction_nbr + "'";
        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "QABACKING"), selectVelocityQuery);
        if (arrVelocityCount != null) {

            if (arrVelocityCount[0].contains("greater")) {
                if (result.size() > 0) {
                    for (int iCount = 0; iCount < result.size(); iCount++) {
                        dataHashMap = result.get(iCount);
                        for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                            Assert.assertTrue("verify asset value : ", Integer.parseInt(entry.getValue()) > Integer.parseInt(velocityCount));
                        }
                    }
                } else
                    assertTrue("no reocrd found in rule_audit table", false);
            }
        } else {
            if (result.size() > 0) {
                for (int iCount = 0; iCount < result.size(); iCount++) {
                    dataHashMap = result.get(iCount);
                    for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                        Assert.assertTrue("verify asset value : ", entry.getValue().contains(velocityCount));
                    }
                }
            } else
                assertTrue("no reocrd found in rule_audit table", false);
        }


    }

    public void selectActionType(String actionType) throws Exception {
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(action, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.select(action, actionType);
        else
            Assert.assertTrue("Action is not found on SNR WB page", false);
    }

    public void selectSubActionType(String actionType) throws Exception {
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(action, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.select(subAction, actionType);
        else
            Assert.assertTrue("Action is not found on SNR WB page", false);
    }


    public void continuePayment() throws Exception {
        CommonUtilities.waitTime(3);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(paymentContinue, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.javaScriptClick(paymentContinue);
        else
            Assert.assertTrue("Payment Continue button is not found on Charge Fee page", false);
    }

    /**
     * This method is used to select PNR entry from RMA Workbasket
     *
     * @author Nandini Mujumdar
     * date - 24/08/2016
     */
    public void searchCaseNumberUsing_MDN() throws Exception {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found on Landing page", false);
        }
        CommonUtilities.waitTime(2);
        if (driver.checkObjectExists(mobileDeviceNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(mobileDeviceNumber, CustomerDetails.customerData.get("MDN"));  // CustomerDetails.customerData.get("MDN")
        } else {
            Assert.assertTrue("MDN is not found on Landing page", false);
        }
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(searchButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(searchButton);
        } else {
            Assert.assertTrue("Search button is not found on Landing page", false);
        }
        CommonUtilities.waitTime(10);
        if (driver.waitForElementPresenceWithTimeOut(type1, ApplicationConfiguration.getWaitForElementTimeout())) {
            // System.out.println("Type1: "+ driver.getText(type1)+"Type2: "+driver.getText(type2));
            if (driver.getText(type1).equalsIgnoreCase("PNR")) {
                driver.javaScriptClick(type1);
            } else if (driver.getText(type2).equalsIgnoreCase("PNR")) {
                driver.javaScriptClick(type2);
            } else {
                Assert.assertTrue("PNR recond is not found in RMA Workbasket", false);
            }
        }
    }

    /**
     * This method is used to approve DED Refund from RMA Workbasket
     *
     * @author Nandini Mujumdar
     * date - 07/09/2016
     */
    public void approveDEDRefundFromFinanceWorkQueue(String sReason) throws Exception {
        String arrRefund[] = sReason.split(":");
        String refundReson = arrRefund[0];
        String refundAction = arrRefund[1];
        String sApprovalAmount = null;
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found found on finance review workbasket page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(financeReview, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(financeReview);
        } else {
            Assert.assertTrue("financeReview is not found on finance review workbasket page", false);
        }

        waitForPageNavigation();
        CommonUtilities.waitTime(1);
        System.out.println("Refund Number: " + BasePage.refundReqNo);
        if (BasePage.refundReqNo == null || BasePage.refundReqNo.isEmpty())
            driver.type(customerCaseNumberFinance, CaptureIncidentPage.casenumbers.get("CASENUMBER"));
        else
            driver.type(refundRequestNumber, BasePage.refundReqNo);

        if (driver.waitForElementPresenceWithTimeOut(searchClick, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(searchClick);
        } else {
            Assert.assertTrue("Search button is not found on finance review workbasket", false);
        }
        CommonUtilities.waitTime(8);
        if (driver.elementExists(dataLabelRead)) {
            if (driver.getText(dataLabelRead).equalsIgnoreCase("No work items available")) {
                homePage.switchUserAccount("NACST");
                approveRefundFromWorkBasket("Approve:Submit:Customer Escalation");
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(dataFinanceReview, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(dataFinanceReview);
            } else {
                Assert.assertTrue("Finance review Data is not found on finance review workbasket page", false);
            }
            CommonUtilities.waitTime(2);
            driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
                Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
            }
            if (driver.waitForElementPresenceWithTimeOut(refundActions, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(refundActions, refundReson);
            else
                Assert.assertTrue("refundReasonAction is not found on Refund WB page", false);
            CommonUtilities.waitTime(2);
            if (driver.waitForElementPresenceWithTimeOut(refundResult, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(refundResult, refundAction);
            else
                Assert.assertTrue("RefundResult  is not found on Refund WB page", false);
            if (driver.waitForElementPresenceWithTimeOut(refundWBContinue, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(refundWBContinue);
            else
                Assert.assertTrue("refundWBContinue button is not found on Refund WB page", false);
        }
    }

    /**
     * This method is used approve refund from NF Finance work backet or from Refund work basket without verifying Total Amount on UI
     *
     * @author Nandini
     * @Param resons(seperated by :)
     * date - 11/01/2017
     */
    public void approveRefundRequestFromNAFinanceWorkbasket(String sReason) throws Exception {
        String arrRefund[] = sReason.split(":");
        String refundReson = arrRefund[0];
        String refundAction = arrRefund[1];
        String refundOverrideReason = arrRefund[2];
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found found on finance review workbasket page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(financeReview, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(financeReview);
        } else {
            Assert.assertTrue("financeReview is not found on finance review workbasket page", false);
        }

        waitForPageNavigation();
        CommonUtilities.waitTime(1);
        System.out.println("Refund Number: " + BasePage.refundReqNo);
        if (BasePage.refundReqNo == null || BasePage.refundReqNo.isEmpty())
            driver.type(customerCaseNumberFinance, CaptureIncidentPage.casenumbers.get("CASENUMBER"));
        else
            driver.type(refundRequestNumber, BasePage.refundReqNo);

        if (driver.waitForElementPresenceWithTimeOut(searchClick, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(searchClick);
        } else {
            Assert.assertTrue("Search button is not found on finance review workbasket", false);
        }
        CommonUtilities.waitTime(5);
        if (driver.elementExists(dataLabelRead)) {
            if (driver.getText(dataLabelRead).equalsIgnoreCase("No work items available")) {
                System.out.println("Refund Request is not found in Finance Review Workbasket");
                homePage.switchUserAccount("NACST");
                System.out.println("I approve refund request from Finance Review Workbasket");
                approveRefundFromWorkBasket("Approve:Submit:Customer Escalation");
            }
        } else {
            CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(dataFinanceReview, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(dataFinanceReview);
            } else {
                Assert.assertTrue("Finance review Data is not found on finance review workbasket page", false);
            }
            CommonUtilities.waitTime(3);
            driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
                Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
            }
            if (driver.waitForElementPresenceWithTimeOut(refundActions, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(refundActions, refundReson);
            else
                Assert.assertTrue("refundReasonAction is not found on Refund WB page", false);
            CommonUtilities.waitTime(2);
            if (driver.waitForElementPresenceWithTimeOut(refundResult, ApplicationConfiguration.getWaitForElementTimeout())) {
                CommonUtilities.waitTime(2);
                driver.select(refundResult, "Return to Workqueue");
                CommonUtilities.waitTime(2);
                driver.select(refundResult, refundAction);
            } else
                Assert.assertTrue("RefundResult  is not found on Refund WB page", false);
            CommonUtilities.waitTime(3);
            if (driver.waitForElementPresenceWithTimeOut(refundOverrideReasonCode, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(refundOverrideReasonCode, refundOverrideReason);

            if (driver.waitForElementPresenceWithTimeOut(refundWBContinue, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(refundWBContinue);
            else
                Assert.assertTrue("refundWBContinue button is not found on finance review workbasket page", false);
        }
    }


    /**
     * This method is used approve refund from NF Finance agtfer getting Escalation on Review Workbasket
     *
     * @author Nandini Mujumdar
     * @Param resons(seperated by :)
     * date - 14/02/2017
     */

    public void approveRefundFromNAFinanceWorkBasket(String sReason) {
        String arrRefund[] = sReason.split(":");
        String refundReson = arrRefund[0];
        String refundAction = arrRefund[1];
        String sApprovalAmount = null;
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found found on finance review workbasket page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(financeReview, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(financeReview);
        } else {
            Assert.assertTrue("financeReview is not found on finance review workbasket page", false);
        }

        waitForPageNavigation();
        CommonUtilities.waitTime(1);
        System.out.println("Refund Number: " + BasePage.refundReqNo);
        if (BasePage.refundReqNo == null || BasePage.refundReqNo.isEmpty())
            driver.type(customerCaseNumberFinance, CaptureIncidentPage.casenumbers.get("CASENUMBER"));
        else
            driver.type(refundRequestNumber, BasePage.refundReqNo);

        if (driver.waitForElementPresenceWithTimeOut(searchClick, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(searchClick);
        } else {
            Assert.assertTrue("Search button is not found on finance review workbasket", false);
        }
        CommonUtilities.waitTime(5);
        if (driver.elementExists(dataLabelRead)) {
            if (driver.getText(dataLabelRead).equalsIgnoreCase("No work items available")) {
                System.out.println("Refund Request is not found in Finance Review Workbasket");
            }
        } else {
            CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(dataFinanceReview, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(dataFinanceReview);
            } else {
                Assert.assertTrue("Finance review Data is not found on finance review workbasket page", false);
            }
            CommonUtilities.waitTime(3);
            driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
                Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
            }
            if (driver.waitForElementPresenceWithTimeOut(refundActions, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(refundActions, refundReson);
            else
                Assert.assertTrue("refundReasonAction is not found on Refund WB page", false);
            CommonUtilities.waitTime(2);
            if (driver.waitForElementPresenceWithTimeOut(refundResult, ApplicationConfiguration.getWaitForElementTimeout())) {
                CommonUtilities.waitTime(2);
                driver.select(refundResult, "Return to Workqueue");
                CommonUtilities.waitTime(2);
                driver.select(refundResult, refundAction);
            } else
                Assert.assertTrue("RefundResult  is not found on Refund WB page", false);
            CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(refundWBContinue, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(refundWBContinue);
            else
                Assert.assertTrue("refundWBContinue button is not found on finance review workbasket page", false);
        }
    }

    /**
     * This method is used to select the action from the Workqueue tab for 3UK
     *
     * @param action
     * @author Nandini.Mujumdar
     * @since 22/06/2017
     */
    public void viewQueueFor(String action) {
        String caseId = "";
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk") || ApplicationConfiguration.getClient().equalsIgnoreCase("kpn")) {
            caseId = Generic.getValuesFromGlobals("CASENUMBER");
        } else caseId = CaptureIncidentPage.casenumbers.get("CASENUMBER");
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found on Landing page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(wQName, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(wQName, action);
        } else {
            Assert.assertTrue(action + " option is not found in workbasket drop down list", false);
        }
        CommonUtilities.waitTime(2);
        waitForPageNavigation();
        if (driver.waitForElementPresenceWithTimeOut(rMAcaseNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(rMAcaseNumber, caseId);
        } else {
            Assert.assertTrue("Case Number field is not found on Landing page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(rMAsearchButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(rMAsearchButton);
        } else {
            Assert.assertTrue("Search button is not found on Landing page", false);
        }
        com.asurion.qa.util.CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(rMAsearchData, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(rMAsearchData);
        } else {
            Assert.assertTrue("Searched Data is not found in EU RMA Workbasket", false);
        }
    }

    public void selectReasonFromActionDropdown(String option) {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (driver.checkObjectExists(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.switchToFrame(cpmInteractionDivFrame);
        }
        if (driver.checkObjectExists(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.switchToFrame(diaction);
        }
        if (driver.checkObjectExists(cpmTabbedWorkDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.switchToFrame(cpmTabbedWorkDivFrame);
        }

        if (driver.waitForElementPresenceWithTimeOut(rMAAction, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(rMAAction, option);
        } else {
            Assert.assertTrue("rMAAction  is not found on Hold details page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(continueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(continueButton);
        } else {
            Assert.assertTrue("Continue button is not found on  Hold details page", false);
        }
    }


    /**
     * Ths method is used to verify Payment Succesful message on UI for Charge payemnt in RMA flow
     *
     * @param :
     * @Author :   Jitendra Kumar Tiwary
     * Created Date :   12-01-2017
     */
    public void verifyChargeFeePaymentSuccessfulONUI() throws Exception {
        assertEquals("Verifying Charge Fee payment is successful", "Payment Successful.", driver.getText(chargePaymentSuccessful).trim());
    }

    /**
     * This method is used to approve DED Refund from EU RMA Workbasket
     *
     * @author Nandini Mujumdar
     * date - 03/07/2017
     */
    public void approveDEDRefundFromEUFinanceWorkQueue(String sReason) throws Exception {
        String arrRefund[] = sReason.split(":");
        String refundReson = arrRefund[0];
        String refundAction = arrRefund[1];
        String sApprovalAmount = null;
        String caseId = "";
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found found on finance review workbasket page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(financeReviewEU, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(financeReviewEU);
        } else {
            Assert.assertTrue("financeReview is not found on finance review workbasket page", false);
        }

        CommonUtilities.waitTime(1);
        waitForPageNavigation();
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk") || ApplicationConfiguration.getClient().equalsIgnoreCase("kpn")) {
            caseId = Generic.getValuesFromGlobals("CASENUMBER");
        } else caseId = CaptureIncidentPage.casenumbers.get("CASENUMBER");
        if (driver.waitForElementPresenceWithTimeOut(customerCaseHoldNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(customerCaseNumber, caseId);
        } else {
            Assert.assertTrue("Case Number is not found on finance review workbasket page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(searchClick, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(searchClick);
        } else {
            Assert.assertTrue("Search button is not found on finance review workbasket", false);
        }
        CommonUtilities.waitTime(8);
        if (driver.elementExists(dataLabelRead)) {
            if (driver.getText(dataLabelRead).equalsIgnoreCase("No work items available")) {
                homePage.switchUserAccountEU("HorizonEUCST");
                approveRefundFromEUCSTWorkBasket("Approve:Submit:Customer Escalation");
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(dataFinanceReview, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(dataFinanceReview);
            } else {
                Assert.assertTrue("Finance review Data is not found on finance review workbasket page", false);
            }
            CommonUtilities.waitTime(2);
            driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
                Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
            }
            if (driver.waitForElementPresenceWithTimeOut(refundActions, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(refundActions, refundReson);
            else
                Assert.assertTrue("refundReasonAction is not found on Refund WB page", false);
            CommonUtilities.waitTime(2);
            if (driver.waitForElementPresenceWithTimeOut(refundResult, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(refundResult, refundAction);
            else
                Assert.assertTrue("RefundResult  is not found on Refund WB page", false);
            if (driver.waitForElementPresenceWithTimeOut(refundWBContinue, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(refundWBContinue);
            else
                Assert.assertTrue("refundWBContinue button is not found on Refund WB page", false);
        }
    }

    /**
     * This method is used approve refund from EU Finance agtfer getting Escalation on Review Workbasket
     *
     * @author Nandini Mujumdar
     * @Param resons(seperated by :)
     * date - 03/07/2017
     */

    public void approveRefundFromEUFinanceWorkBasket(String sReason) {
        String arrRefund[] = sReason.split(":");
        String refundReson = arrRefund[0];
        String refundAction = arrRefund[1];
        String sApprovalAmount = null;
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found found on finance review workbasket page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(financeReview, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(financeReview);
        } else {
            Assert.assertTrue("financeReview is not found on finance review workbasket page", false);
        }

        waitForPageNavigation();
        CommonUtilities.waitTime(1);
        System.out.println("Refund Number: " + BasePage.refundReqNo);
        if (BasePage.refundReqNo == null || BasePage.refundReqNo.isEmpty())
            driver.type(customerCaseNumberFinance, CaptureIncidentPage.casenumbers.get("CASENUMBER"));
        else
            driver.type(refundRequestNumber, BasePage.refundReqNo);

        if (driver.waitForElementPresenceWithTimeOut(searchClick, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(searchClick);
        } else {
            Assert.assertTrue("Search button is not found on finance review workbasket", false);
        }
        CommonUtilities.waitTime(5);
        if (driver.elementExists(dataLabelRead)) {
            if (driver.getText(dataLabelRead).equalsIgnoreCase("No work items available")) {
                System.out.println("Refund Request is not found in Finance Review Workbasket");
            }
        } else {
            CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(dataFinanceReview, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(dataFinanceReview);
            } else {
                Assert.assertTrue("Finance review Data is not found on finance review workbasket page", false);
            }
            CommonUtilities.waitTime(3);
            driver.switchToDefaultContent();
            if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
                Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
            }
            if (driver.waitForElementPresenceWithTimeOut(refundActions, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.select(refundActions, refundReson);
            else
                Assert.assertTrue("refundReasonAction is not found on Refund WB page", false);
            CommonUtilities.waitTime(2);
            if (driver.waitForElementPresenceWithTimeOut(refundResult, ApplicationConfiguration.getWaitForElementTimeout())) {
                CommonUtilities.waitTime(2);
                driver.select(refundResult, "Return to Workqueue");
                CommonUtilities.waitTime(2);
                driver.select(refundResult, refundAction);
            } else
                Assert.assertTrue("RefundResult  is not found on Refund WB page", false);
            CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(refundWBContinue, ApplicationConfiguration.getWaitForElementTimeout()))
                driver.javaScriptClick(refundWBContinue);
            else
                Assert.assertTrue("refundWBContinue button is not found on finance review workbasket page", false);
        }
    }

    /**
     * This method is used approve refund from EUCST work backet
     *
     * @author Nandini
     * @Param resons(seperated by :)
     * date - 5/07/2017
     */
    public void approveRefundFromEUCSTWorkBasket(String sReason) throws Exception {
        String arrRefund[] = sReason.split(":");
        String refundReson = arrRefund[0];
        String careRefund = arrRefund[1];
        String refundOverrideReason = arrRefund[2];
        String caseId = "";

        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(testiframe, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Testiframe is not found on Landing page", false);
        }

        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(wQName, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(wQName, "Refund Workbasket");
        } else {
            Assert.assertTrue("Customer Case Hold option is not found in workbasket drop down list", false);
        }
        CommonUtilities.waitTime(1);
        waitForPageNavigation();
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk") || ApplicationConfiguration.getClient().equalsIgnoreCase("kpn")) {
            caseId = Generic.getValuesFromGlobals("CASENUMBER");
        } else caseId = CaptureIncidentPage.casenumbers.get("CASENUMBER");
        if (driver.waitForElementPresenceWithTimeOut(customerCaseHoldNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(customerCaseNumber, caseId);
        } else {
            Assert.assertTrue("Customer Case Hold Number is not found on Landing page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(search, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(search);
        } else {
            Assert.assertTrue("Search button is not found on Landing page", false);
        }
        CommonUtilities.waitTime(8);
        if (driver.waitForElementPresenceWithTimeOut(dataRefundWQB, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(dataRefundWQB);
        } else {
            Assert.assertTrue("Customer Case Hold Data is not found in Workbasket details", false);
        }
        CommonUtilities.waitTime(4);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmInteractionDivFrame is not found on contact details page", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(refundReasonAction, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.select(refundReasonAction, refundReson);
        else
            Assert.assertTrue("refundReasonAction is not found on Refund WB page", false);

        if (driver.waitForElementPresenceWithTimeOut(careRefundResult, ApplicationConfiguration.getWaitForElementTimeout())) {
            CommonUtilities.waitTime(2);
            driver.select(careRefundResult, "Return to Workqueue");
            CommonUtilities.waitTime(2);
            driver.select(careRefundResult, careRefund);
        } else
            Assert.assertTrue("careRefundResult  is not found on Refund WB page", false);
        CommonUtilities.waitTime(3);
        if (driver.waitForElementPresenceWithTimeOut(refundOverrideReasonCode, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.select(refundOverrideReasonCode, refundOverrideReason);

        if (driver.waitForElementPresenceWithTimeOut(refundWBContinue, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.javaScriptClick(refundWBContinue);
        else
            Assert.assertTrue("refundWBContinue button is not found on Refund WB page", false);

        if (driver.waitForElementPresenceWithTimeOut(escalate, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (!driver.isSelected(escalate)) {
                driver.click(escalate);
                if (driver.checkObjectExists(escalateReason, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.select(escalateReason, "Customer Goodwill");
                    driver.waitAndClick(continueButton);
                    homePage.switchUserAccountEU("HorizonEUFinance");
                    approveDEDRefundFromEUFinanceWorkQueue("Approve:Submit");
                }
            }
        }
    }
}
