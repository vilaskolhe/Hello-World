package com.asurion.pages;

import com.asurion.common.core.uielement.UIElement;
import com.asurion.common.core.uielement.UILocatorType;
import com.asurion.common.core.uielement.UIType;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.horizon.generic.DataBaseHandler;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import com.asurion.util.Generic;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

//import junit.framework.Assert;

public class PaymentPage extends BasePage {

    private UIElement cpmInteractionDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmInteractionDivFrame");
    private UIElement cpmTabbedNavigationDivFrame = new UIElement(UIType.Frame, UILocatorType.ID, "cpmTabbedNavigation-DIVFrame");
    private UIElement diaction = new UIElement(UIType.Frame, UILocatorType.Name, "DIACTION");

    private UIElement shippingMethodCode = new UIElement(UIType.ListBox, UILocatorType.ID, "SelectedShippingMethodCode");
    private UIElement signatureRequired = new UIElement(UIType.CheckBox, UILocatorType.ID, "SignatureRequired");
    private UIElement creditDebitCardPaymentMode = new UIElement(UIType.CheckBox, UILocatorType.ID, "SelectedPaymentMethodCCDC");
    private UIElement eCheckPaymentMode = new UIElement(UIType.CheckBox, UILocatorType.ID, "SelectedPaymentMethodECHECK");
    private UIElement ePaperClaimCVV = new UIElement(UIType.CheckBox, UILocatorType.ID, "IsCardPaymentOverride");
    private UIElement cardNumber = new UIElement(UIType.TextBox, UILocatorType.CSS, "input#CardNumber");
    private UIElement firstName = new UIElement(UIType.TextBox, UILocatorType.ID, "FirstName");
    private UIElement lastName = new UIElement(UIType.TextBox, UILocatorType.ID, "LastName");
    private UIElement addressIndicator = new UIElement(UIType.CheckBox, UILocatorType.ID, "AddressIndicator");
    private UIElement addressLine1 = new UIElement(UIType.TextBox, UILocatorType.ID, "AddressLine1");
    private UIElement addressLine2 = new UIElement(UIType.TextBox, UILocatorType.ID, "AddressLine2");
    private UIElement cityName = new UIElement(UIType.TextBox, UILocatorType.ID, "CityName");
    private UIElement stateProvinceCode = new UIElement(UIType.TextBox, UILocatorType.ID, "StateProvinceCode");
    private UIElement postalCode = new UIElement(UIType.TextBox, UILocatorType.ID, "PostalCode");
    private UIElement expiryMonth = new UIElement(UIType.ListBox, UILocatorType.ID, "ExpiryMonth");
    private UIElement expiryYear = new UIElement(UIType.ListBox, UILocatorType.ID, "ExpiryYear");
    private UIElement cvvCode = new UIElement(UIType.ListBox, UILocatorType.ID, "cvv");
    private UIElement btaContinueButton = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[text()='Continue']");
    private UIElement countinueButton = new UIElement(UIType.Button, UILocatorType.Xpath, ".//*[@id='RULE_KEY']/div[6]/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/span/button");
    //  private UIElement countinueButton = new UIElement(UIType.Button, UILocatorType.CSS, "table[id='pyActionArea'] div[id='pyFlowActionHTML'] td:nth-of-type(2) div[id='RULE_KEY'] div:nth-of-type(4) span>button");
    private UIElement countinueButtonnTelos = new UIElement(UIType.Button, UILocatorType.CSS, "table[id='pyActionArea'] div[id='pyFlowActionHTML'] td:nth-of-type(2) div[id='RULE_KEY'] span>button[class='pzhc']");
    private UIElement InvalidCCMessage = new UIElement(UIType.Label, UILocatorType.Xpath, "//div[contains(text(),'nvalid credit card number')]");
    private UIElement invalidCCErrorMsg = new UIElement(UIType.Button, UILocatorType.CSS, ".field-item.dataLabelWrite.sectionheaders_dataLabelWrite");
    private UIElement additionalChargesYes = new UIElement(UIType.CheckBox, UILocatorType.CSS, "#AdditionalChargeAuthorizedtrue");
    private UIElement additionalChargesNo = new UIElement(UIType.CheckBox, UILocatorType.CSS, "#AdditionalChargeAuthorizedfalse");
    private UIElement countinueButtonClaro = new UIElement(UIType.Button, UILocatorType.Xpath, "//div[@id='RULE_KEY']/div[6]/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/span/button");

    private UIElement countinueButtonWind = new UIElement(UIType.Button, UILocatorType.CSS, "table[id='pyActionArea'] div[id='pyFlowActionHTML'] td:nth-of-type(2) div[id='RULE_KEY'] div:nth-of-type(1) span>button");
    //nTelos
    private UIElement MiddleName = new UIElement(UIType.TextBox, UILocatorType.ID, "MiddleName");
    private UIElement routingNumber = new UIElement(UIType.TextBox, UILocatorType.ID, "BankRoutingNumber");
    private UIElement accountNumber = new UIElement(UIType.TextBox, UILocatorType.ID, "BankAccountNumber");
    private UIElement checkNumber = new UIElement(UIType.TextBox, UILocatorType.ID, "BankAccountCheckNumber");
    private UIElement driverLicenceNumber = new UIElement(UIType.TextBox, UILocatorType.ID, "DriverLicenseNumber");
    private UIElement LicenseStateProvinceCode = new UIElement(UIType.ListBox, UILocatorType.ID, "DriverLicenseStateProvinceCode");
    private UIElement btaPaymentMode = new UIElement(UIType.RadioButton, UILocatorType.CSS, "input#SelectedPaymentMethodBTA");
    private UIElement ispPaymentMode = new UIElement(UIType.Button, UILocatorType.CSS, "input#SelectedPaymentMethodISP");
    private UIElement ISPPayment = new UIElement(UIType.Label, UILocatorType.CSS, "(.//*[@id='CT']/div/div/div/div[1]/div/div)[9]");
    private UIElement ISPPaymentCountinueButton = new UIElement(UIType.Button, UILocatorType.CSS, "table[id='pyActionArea'] tr:nth-of-type(2) table:nth-of-type(1) div[id='pyFlowActionHTML'] div[id='RULE_KEY'] div:nth-of-type(4) button[class='pzhc']");
    private UIElement UsedForBillingAddressENROLLED = new UIElement(UIType.RadioButton, UILocatorType.ID, "UsedForBillingAddressENROLLED");

    //Invalid card
    private UIElement makenewpaymentAgain = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@id='RULE_KEY']/div[2]/div/div/div[2]/div/div/div/div/div[2]/div/div/span/button");
    private UIElement PaymentInStore = new UIElement(UIType.Label, UILocatorType.CSS, ".boldheaderlabels_dataLabelWrite>nobr>label");

    //EU
    private UIElement radioUseEnrolledAddress = new UIElement(UIType.RadioButton, UILocatorType.ID, "UsedForBillingAddressENROLLED");
    private UIElement pencilDeductible = new UIElement(UIType.Image, UILocatorType.Xpath, "//*[@name='DisplayTotalFee_pyWorkPage_12']");
    private UIElement editDeductibleframe = new UIElement(UIType.Frame, UILocatorType.ID, "modaldialog_hd");
    private UIElement deductible = new UIElement(UIType.TextBox, UILocatorType.ID, "AdjustedServiceFeeAmount");
    private UIElement deductibleSave = new UIElement(UIType.Button, UILocatorType.Xpath, "//*[@data-test-id='20150803152914041280153']");
    private UIElement reason = new UIElement(UIType.ListBox, UILocatorType.ID, "FeeOverrideReasonCode");
    private UIElement setToCurSign = new UIElement(UIType.Label, UILocatorType.Xpath, ".//*[@id='locale_$PpyWorkPage$ppyTestprop']");
    private UIElement deductibleAmount = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-tour-id='2016041417020134006316745610']");
    private UIElement shipping = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-tour-id='2016041417020134006316745611']");
    private UIElement totalDueFees = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-tour-id='2016041417020134006316745613']");
    private UIElement feeIfNotReturned = new UIElement(UIType.Label, UILocatorType.Xpath, "//*[@data-tour-id='201604141702013400631672123']");


    public void btaPaymentMethod() throws Exception {
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("Diaction is not found on Payment page", false);

        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on Payment page", false);
        }
        CommonUtilities.waitTime(4);
        if (driver.waitForElementPresenceWithTimeOut(additionalChargesYes, 8)) {
            driver.javaScriptClick(additionalChargesYes);
        }
        CommonUtilities.waitTime(4);
        if (driver.waitForElementPresenceWithTimeOut(btaPaymentMode, 18)) {
            driver.javaScriptClick(btaPaymentMode);
        } else {
            System.out.println("BTA radio button is not found on Payment page");
        }
        CommonUtilities.waitTime(2);
        if (driver.waitForElementPresenceWithTimeOut(additionalChargesYes, 8)) {
            driver.javaScriptClick(additionalChargesYes);
        }

        CommonUtilities.waitTime(4);
        if (driver.waitForElementPresenceWithTimeOut(btaContinueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(btaContinueButton);
        } else {
            Assert.assertTrue("Continue button is not found on Payment page", false);
        }
    }

    //////////////////////
    public void enterThePaymentDetails(String creditCardNumber) throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }
        if (driver.checkObjectExists(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            driver.switchToFrame(diaction);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout()))
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on Payment page", false);

        String customerName = CustomerDetails.customerData.get("CUSTOMERNAME");
        String[] employeeDetails = customerName.split(" ");
        System.out.println("First name :: " + employeeDetails[0]);
        System.out.println("Last  name :: " + employeeDetails[1]);
        if (employeeDetails.length > 2) {

            System.out.println("Last  name :: " + employeeDetails[2]);
            employeeDetails[1] = employeeDetails[2];

        }
        employeeDetails[1] = employeeDetails[1].replace("%", "");
        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(cardNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (driver.waitForElementPresenceWithTimeOut(cardNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.type(cardNumber, creditCardNumber);
            } else {
                Assert.assertTrue("Credit Card Number is not found on Payment page", false);
            }
            //name is autopopulating
                /*
                if( driver.checkObjectExists(firstName, ApplicationConfiguration.getWaitForElementTimeout()))
                {
                    driver.type(firstName, employeeDetails[0]);
                } else {
                    Assert.assertTrue("First Name is not found on Payment page", false);
                }
                */
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos") || ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers") || ApplicationConfiguration.getClient().equalsIgnoreCase("Fido") || ApplicationConfiguration.getClient().equalsIgnoreCase("Freedom") || ApplicationConfiguration.getClient().equalsIgnoreCase("Telus") || ApplicationConfiguration.getClient().equalsIgnoreCase("KOODO")) {
                if (driver.checkObjectExists(lastName, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.type(lastName, employeeDetails[1]);
                } else {
                    Assert.assertTrue("Last Name is not found on Payment page", false);
                }
            }

            if (driver.checkObjectExists(expiryMonth, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.select(expiryMonth, "12-Dec");
            } else {
                Assert.assertTrue("Expiry Month List is not found on Payment page", false);
            }
            if (driver.checkObjectExists(expiryYear, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.select(expiryYear, "2018");
            } else {
                Assert.assertTrue("Expiry Month List is not found on Payment page", false);
            }
            if (driver.checkObjectExists(cvvCode, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.type(cvvCode, "112");
            } else {
                Assert.assertTrue("CVV code is not found on Payment page", false);
            }
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos") || ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("Claro") || ApplicationConfiguration.getClient().equalsIgnoreCase("Fido") || ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers") || ApplicationConfiguration.getClient().equalsIgnoreCase("Freedom") || ApplicationConfiguration.getClient().equalsIgnoreCase("Telus") || ApplicationConfiguration.getClient().equalsIgnoreCase("KOODO")) {
                if (driver.waitForElementPresenceWithTimeOut(UsedForBillingAddressENROLLED, 5)) {
                    if (!driver.isSelected(UsedForBillingAddressENROLLED))
                        driver.javaScriptClick(UsedForBillingAddressENROLLED);
                } else
                    Assert.assertTrue("UsedForBillingAddressENROLLED is not found on Payment page", false);

            } else {
                if (driver.checkObjectExists(addressLine1, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.type(addressLine1, "650 Grassmere Park");
                } else {
                    Assert.assertTrue("Address is not found on Payment page", false);
                }
                if (driver.checkObjectExists(cityName, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.type(cityName, "Nashville");
                } else {
                    Assert.assertTrue("Name of City is not found on Payment page", false);
                }
                if (driver.checkObjectExists(stateProvinceCode, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.type(stateProvinceCode, "TN");
                } else {
                    Assert.assertTrue("State Province Code is not found on Payment page", false);
                }
                if (driver.checkObjectExists(postalCode, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.type(postalCode, "37211");
                } else {
                    Assert.assertTrue("Postal Code is not found on Payment page", false);
                }
            }

            if (driver.waitForElementPresenceWithTimeOut(additionalChargesYes, 2)) {
                driver.javaScriptClick(additionalChargesYes);
            }

            if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                if (driver.waitForElementPresenceWithTimeOut(countinueButtonnTelos, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.waitAndClick(countinueButtonnTelos);
                } else {
                    Assert.assertTrue("Continue button is not found on Payment page", false);
                }
            } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
                if (driver.checkObjectExists(countinueButtonClaro, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.javaScriptClick(countinueButtonClaro);
                    CommonUtilities.waitTime(3);
                } else {
                    Assert.assertTrue("Continue button claro client is not found on Payment page", false);
                }
            } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("FREEDOM")) {
                if (driver.checkObjectExists(countinueButtonWind, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.javaScriptClick(countinueButtonWind);
                } else {
                    Assert.assertTrue("Continue button Wind client is not found on Payment page", false);
                }
            } else {
                if (driver.checkObjectExists(countinueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
                    driver.javaScriptClick(countinueButton);
                } else {
                    Assert.assertTrue("Continue button is not found on Payment page", false);
                }
            }
            System.out.println("I entered Credit Card details and clicked on continue");
        } else {
            Assert.assertTrue("Credit card field is not found on Payment page", false);
        }


    }

    public void insertTokenCheckTokenStatus(String tokenRef, String sStatus) throws Exception {
        int size;
        System.out.println("Token Number Value = " + tokenRef);
        String query = "select PCI_TOKEN from payment where PCI_TOKEN= '" + tokenRef + "'";
        size = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query).size();

        String Updated_active_from_date = "(select add_months(sysdate,-3) from dual)";
        String Updated_INactive_from_date = "(select add_months(sysdate,+1) from dual)";

        if (size > 0) {
            if (sStatus.equalsIgnoreCase("active")) {
                query = "update payment set active_from_date =" + Updated_active_from_date + " where PCI_Token = " + tokenRef;
            } else if (sStatus.equalsIgnoreCase("inactive")) {
                query = "update payment set active_from_date =" + Updated_INactive_from_date + " where PCI_Token = " + tokenRef;
            }
            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        } else {
            if (sStatus.equalsIgnoreCase("active")) {
                query = "insert into payment(Payment_ID,PCI_Token,Payment_Method_Type_Code,Is_negative,risk_category_lookup_id,client_reference_id,active_from_date,Notes) values('1004','U15IMNU16J3F2777','CCDC','1','2','3'," + Updated_active_from_date + ",'CreditCard in negative')";
            } else if (sStatus.equalsIgnoreCase("inactive")) {
                query = "insert into payment(Payment_ID,PCI_Token,Payment_Method_Type_Code,Is_negative,risk_category_lookup_id,client_reference_id,active_from_date,Notes) values('1004','U15IMNU16J3F2777','CCDC','1','2','3'," + Updated_INactive_from_date + ",'CreditCard in negative')";

            }
            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        }


    }

    public void ClientAccountNumberCheck() throws Exception {
        int size;
        String client_reference_id = "";
        String client_account_id = "";
        String MDN = CustomerDetails.customerData.get("MDN");

        if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
            client_reference_id = "1";
            client_account_id = "TAN" + MDN.charAt(0) + MDN.substring(5);
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            client_reference_id = "3";
            client_account_id = "BAN9015995";

        }

        String query = "select EXTERNAL_REFERENCE_ID from CLIENT_ACCOUNT where EXTERNAL_REFERENCE_ID= '" + client_account_id + "'";
        size = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query).size();

        String Updated_active_from_date = "SELECT SYSDATE-20 FROM dual";
        String Updated_active_to_date = "SELECT SYSDATE-1 FROM dual";

        if (size > 0) {

            query = "update CLIENT_ACCOUNT set is_exception='null',is_negative ='1',risk_category_lookup_id='3',client_reference_id='" + client_reference_id + "',active_from_date =(" + Updated_active_from_date + "), active_to_date=(" + Updated_active_to_date + "),notes='Automation - InActiveAccountNumber InList' where EXTERNAL_REFERENCE_ID = " + client_account_id;
            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        } else {
            query = "insert into CLIENT_ACCOUNT(CLIENT_ACCOUNT_ID,EXTERNAL_REFERENCE_ID,IS_NEGATIVE,RISK_CATEGORY_LOOKUP_ID,CLIENT_REFERENCE_ID,active_from_date,active_to_date,Notes) values('09000044','" + client_account_id + "','1','3','" + client_reference_id + "',(" + Updated_active_from_date + "),(" + Updated_active_to_date + "),'Automation - InActiveAccountNumber InList')";
            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        }


    }

    public void insertTokenCheckTokenIsException(String tokenRef, String sStatus) throws Exception {
        int size;
        System.out.println("Token Number Value = " + tokenRef);
        String query = "select PCI_TOKEN from payment where PCI_TOKEN= '" + tokenRef + "'";
        size = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query).size();
        if (size > 0) {
            if (sStatus.equalsIgnoreCase("InExceptionList")) {
                query = "update payment set IS_EXCEPTION='1' where PCI_Token = " + tokenRef;
            } else if (sStatus.equalsIgnoreCase("NotInExceptionList")) {
                query = "update payment set IS_EXCEPTION='0' where PCI_Token = " + tokenRef;
            }
            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        } else {
            if (sStatus.equalsIgnoreCase("InException")) {
                query = "insert into payment(Payment_ID,PCI_Token,Payment_Method_Type_Code,Is_negative,IS_EXCEPTION,risk_category_lookup_id,client_reference_id,active_from_date,Notes) values('1004','U15IMNU16J3F2777','CCDC','0','1','2','3','10-AUG-15','CreditCard in negative')";
            } else if (sStatus.equalsIgnoreCase("NotInException")) {
                query = "insert into payment(Payment_ID,PCI_Token,Payment_Method_Type_Code,Is_negative,IS_EXCEPTION,risk_category_lookup_id,client_reference_id,active_from_date,Notes) values('1004','U15IMNU16J3F2777','CCDC','0','0','2','3','10-AUG-15','CreditCard in negative')";
            }
            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        }


    }

    public void TokenInExceptionListForDifferentClient(String tokenRef) throws Exception {
        int size;
        System.out.println("Token Number Value = " + tokenRef);
        String query = "select PCI_TOKEN from payment where PCI_TOKEN= '" + tokenRef + "'";

        size = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query).size();
        if (size > 0) {
            query = "update payment set CLIENT_REFERENCE_ID='6' where PCI_Token = " + tokenRef;
            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        } else {
            query = "insert into payment(Payment_ID,PCI_Token,Payment_Method_Type_Code,Is_negative,IS_EXCEPTION,risk_category_lookup_id,client_reference_id,active_from_date,Notes) values('1004','U15IMNU16J3F2777','CCDC','0','1','2','6','10-AUG-15','CreditCard in negative')";
            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        }


    }

    public void verifyInvalidCardDetailsMessage() throws Exception {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }
        navigateLowestLevelFrame(diaction);
        driver.switchToFrame(cpmTabbedNavigationDivFrame);
        System.out.println("Message for invalid Credit Card" + driver.getText(invalidCCErrorMsg));
        Assert.assertEquals("Payment Failed", driver.getText(invalidCCErrorMsg));
    }

    /**
     * This method used to for entering echeck payment details
     *
     * @param - bankAccountnumber(echeck account number is given by user)
     *          [eg. bankAccountnumber=439085000]
     * @author Shweta
     */

    public void enterEcheckPaymentDetails(String bankAccountnumber) throws Exception {
        CommonUtilities.waitTime(5);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Payment page", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("cpmTabbedNavigationDivFrame is not found on Payment page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(eCheckPaymentMode, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(eCheckPaymentMode);
        } else {
            Assert.assertTrue("ECheck radio button is not found on Payment page", false);
        }
        CommonUtilities.waitTime(2);
        driver.type(firstName, CustomerDetails.customerData.get("FIRSTNAME"));
        driver.type(lastName, CustomerDetails.customerData.get("LASTNAME"));
        if (driver.checkObjectExists(accountNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(accountNumber, bankAccountnumber);
            driver.type(routingNumber, "123456780");
            driver.type(checkNumber, "1001");
            driver.type(driverLicenceNumber, "6548551");
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos") || ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("Claro") || ApplicationConfiguration.getClient().equalsIgnoreCase("Fido") || ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers") || ApplicationConfiguration.getClient().equalsIgnoreCase("Wind") || ApplicationConfiguration.getClient().equalsIgnoreCase("Tracfone")) {
                if (driver.waitForElementPresenceWithTimeOut(UsedForBillingAddressENROLLED, 5))
                    driver.javaScriptClick(UsedForBillingAddressENROLLED);
            } else {
                driver.type(addressLine1, "650 Grassmere Park");
                driver.type(cityName, "Nashville");
                //driver.type(stateProvinceCode, "TN");
                driver.select(LicenseStateProvinceCode, "TN - Tennessee");
                driver.type(postalCode, "37211");
            }
            //If statement added for Cricket Client as It accepts only text for License State Province field
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("Cricket"))
                driver.select(LicenseStateProvinceCode, "TN - Tennessee");
            else
            driver.type(LicenseStateProvinceCode, "TN");

            if (driver.checkObjectExists(additionalChargesYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.click(additionalChargesYes);
            }
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("nTelos") || ApplicationConfiguration.getClient().equalsIgnoreCase("Cricket")) {
                driver.javaScriptClick(countinueButtonnTelos);
            }
        }
    }


    /**
     * This method used to insert details in clientAccount
     *
     * @param - sAllParameters
     * @author Arjun
     * @Created Date - 2 june 2016
     */
    public void insertDetailsInClientAccount(String sAllParameters) throws Exception {
        int size;
        String client_reference_id = "";
        String client_account_id = "";
        String MDN = CustomerDetails.customerData.get("MDN");

           /* String insertQuery;
            //Split all Parameters
            String[] allParameterStringArray = sAllParameters.split(",");
            String sException= allParameterStringArray[0];
            String sNegative= allParameterStringArray[1];
            String sRiskCategoryID= allParameterStringArray[2];
            String accountCheck= allParameterStringArray[3];*/

        String insertQuery;
        String sNegative = null;
        String sException = null;
        String sRiskCategoryID = null;

        //Split all Parameters
        String[] allParameterStringArray = sAllParameters.split(",");
        String[] splitEmail = allParameterStringArray[0].split("=");
        String insertedEmailID = splitEmail[1];

        //
        //Split all Parameters
        String[] IsNegative = allParameterStringArray[1].split("=");
        sNegative = IsNegative[1];

        String[] IsException = allParameterStringArray[2].split("=");
        sException = IsException[1];

        String[] IsRiskCategoryID = allParameterStringArray[3].split("=");
        sRiskCategoryID = IsRiskCategoryID[1];
        String rule = allParameterStringArray[4];

          /*  if(ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
                client_reference_id = "1";
                client_account_id= "TAN" +MDN.charAt(0)+MDN.substring(5);
            }
            else
            */

        //For Partial IN  - 6 digitA/c #
        if (sRiskCategoryID.equalsIgnoreCase("3") && ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            client_reference_id = "3";
            client_account_id = "BAN" + MDN.charAt(0) + MDN.substring(5);
        }

        //Full
        if (sRiskCategoryID.equalsIgnoreCase("2") && ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            client_reference_id = "3";
            client_account_id = "BAN9015995";
        }

        String query = "select EXTERNAL_REFERENCE_ID from CLIENT_ACCOUNT where EXTERNAL_REFERENCE_ID= '" + client_account_id + "'";
        size = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query).size();

        String Updated_active_from_date = "SELECT SYSDATE-20 FROM dual";
        String Updated_active_to_date = "SELECT SYSDATE-1 FROM dual";

        if (size > 0) {

            query = "update CLIENT_ACCOUNT set is_exception='" + sException + "',is_negative ='" + sNegative + "',risk_category_lookup_id='" + sRiskCategoryID + "',client_reference_id='" + client_reference_id + "',active_from_date =(" + Updated_active_from_date + "), active_to_date=(" + Updated_active_to_date + "),notes='Automation - InActiveAccountNumber InList' where EXTERNAL_REFERENCE_ID = " + client_account_id;
            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        } else {
            query = "insert into CLIENT_ACCOUNT(CLIENT_ACCOUNT_ID,EXTERNAL_REFERENCE_ID,IS_NEGATIVE,RISK_CATEGORY_LOOKUP_ID,CLIENT_REFERENCE_ID,active_from_date,active_to_date,Notes)" +
                    " values('09000044','" + client_account_id + "','" + sNegative + "','" + sRiskCategoryID + "','" + client_reference_id + "',(" + Updated_active_from_date + "),(" + Updated_active_to_date + "),'Automation - InActiveAccountNumber InList')";

            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), query);
        }


    }

    /**
     * This method used to make payment again  which comes after
     * entering declined credit card details
     *
     * @author Shweta
     */
    public void makeNewPaymentAgain() throws Exception {
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Payment page", false);
        }
            /*if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            {
                Assert.assertTrue("Diaction 1 is not found on Payment page", false);
            }*/
        // navigateLowestLevelFrame(diaction);
        driver.switchToFrame(cpmTabbedNavigationDivFrame);
        if (driver.checkObjectExists(makenewpaymentAgain, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.click(makenewpaymentAgain);
        } else {
            Assert.assertTrue("Continue button to make payment again is not found on Payment page", false);
        }


    }

    /**
     * This method used to insert data in to Payment Table
     *
     * @param - sAllParameters(accept 3 Para in one string)
     *          [eg. cardtoken=U15IMNU16J3F2777,Is_Negative=1,ActiveToDate=null]
     * @author Priyanka
     */
    public void insertRecordIntoPaymentTable(String sAllParameters) throws Exception {
        String insertQuery;
        String activeToDate = "";
        String setIsNegOrExcFlag = "";
        String clientReference = "";
        String updatPaymentTableQuery;
        //Split all Parameters
        String[] allParameterStringArray = sAllParameters.split(",");
        String tokenRef = allParameterStringArray[0].split("=")[1];
        //check flag is_Negative or Is_exception
        String[] isNegOrExcFlag = new String[2];
        if (allParameterStringArray[1].toLowerCase().contains("is_negative")) {
            isNegOrExcFlag[0] = "Is_negative";
            isNegOrExcFlag[1] = allParameterStringArray[1].split("=")[1];
        } else if (allParameterStringArray[1].toLowerCase().contains("is_exception")) {
            isNegOrExcFlag[0] = "Is_exception";
            isNegOrExcFlag[1] = allParameterStringArray[1].split("=")[1];
        }

        if (!allParameterStringArray[2].contains("=")) {
            activeToDate = (allParameterStringArray[2].split(" ")[1]);
        } else {
            activeToDate = (allParameterStringArray[2].split("=")[1]);
        }

        if (!allParameterStringArray[2].contains("null")) {
            activeToDate = "(select TO_CHAR(sysdate-" + activeToDate + ", 'DD-MON-YY') from dual)";
        } else {
            activeToDate = null;
        }
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Telcel")) {
            clientReference = "1";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            clientReference = "3";
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro")) {
            clientReference = "2";
        }

        if (allParameterStringArray.length > 2) {
            if (allParameterStringArray[3].toLowerCase().contains("client_reference_id")) {
                clientReference = (allParameterStringArray[3].split("=")[1]);

            }
        }


        String iNumber = Generic.RandomNumber();
        String SelectTokenQuery = "select PCI_TOKEN from payment where PCI_TOKEN= '" + tokenRef + "'";
        String tokenRefence = "";
        ArrayList<HashMap<String, String>> result = new ArrayList<>();
        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), SelectTokenQuery);
        HashMap<String, String> dataHashMap = null;
        for (int iCount = 0; iCount < result.size(); iCount++) {
            dataHashMap = result.get(iCount);
            for (Map.Entry<String, String> entry : dataHashMap.entrySet()) {
                tokenRefence = tokenRefence + entry.getValue();
            }
        }
        if (!tokenRefence.toLowerCase().contains(tokenRef.toLowerCase())) {
            insertQuery = "insert into payment(Payment_ID,PCI_Token,Payment_Method_Type_Code," + isNegOrExcFlag[0] + ",risk_category_lookup_id,client_reference_id,active_from_date,active_to_date,Notes) values('" + iNumber + "','" + tokenRef + "','CCDC','" + isNegOrExcFlag[1] + "','2','" + clientReference + "',(select TO_CHAR(sysdate-20, 'DD-MON-YY') from dual)," + activeToDate + ",'Automation TestCases')";
            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), insertQuery);
        } else {
            if (!sAllParameters.toLowerCase().contains("is_exception")) {
                setIsNegOrExcFlag = "Is_exception=null";
            } else if (!sAllParameters.toLowerCase().contains("is_negative")) {
                setIsNegOrExcFlag = "is_negative=null";
            }
            updatPaymentTableQuery = "update payment set Payment_Method_Type_Code='CCDC',risk_category_lookup_id=2,client_reference_id = " + clientReference + "," + isNegOrExcFlag[0] + "= " + isNegOrExcFlag[1] + "," + setIsNegOrExcFlag + ",active_from_date =(select TO_CHAR(sysdate-20, 'DD-MON-YY') from dual),active_to_date=" + activeToDate + " where PCI_Token = '" + tokenRef + "'";

            DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "risk"), updatPaymentTableQuery);

        }


    }

    /**
     * This method used to select SNR fee on payment page
     *
     * @author Shweta
     */
    public void selectSnrFee(String snrFee) throws Exception {
        CommonUtilities.waitTime(15);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Payment page", false);
        }
           /* if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            {
                Assert.assertTrue("Diaction 1 is not found on Payment page", false);
            }*/
        // navigateLowestLevelFrame(diaction);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on Payment page", false);
        }

        //  driver.checkObjectExists(additionalCharges, ApplicationConfiguration.getWaitForElementTimeout());
        if (snrFee.equalsIgnoreCase("YES")) {
            CommonUtilities.waitTime(15);
            if (driver.waitForElementPresenceWithTimeOut(additionalChargesYes, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(additionalChargesYes);
            } else {
               // Assert.assertTrue("SNR/PNR Fee 'YES' radio button is not found on Payment page", false);
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(additionalChargesNo, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(additionalChargesNo);
            } else {
               // Assert.assertTrue("SNR/PNR Fee 'NO' radio button is not found on Payment page", false);
            }
        }


    }

    public void selectISPPayment() throws Exception {
        CommonUtilities.waitTime(1);
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Payment page", false);
        }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on Payment page", false);
        }
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro Peru")) {
            if (driver.waitForElementPresenceWithTimeOut(countinueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(countinueButton);
            } else {
                Assert.assertTrue("Continue button is not found on Payment page", false);
            }
        }
        //Added condition for Telcel
        else if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
            CommonUtilities.waitTime(1);
            if (driver.waitForElementPresenceWithTimeOut(PaymentInStore, ApplicationConfiguration.getWaitForElementTimeout())) {
                assertEquals("Verify Payment type as :", "pay in store", driver.getText(PaymentInStore).toLowerCase());
            }
        } else {
            if (driver.waitForElementPresenceWithTimeOut(ispPaymentMode, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(ispPaymentMode);
            } else {
                Assert.assertTrue("ISP Payment Radio Button is not found on Payment page", false);
            }

            if (driver.waitForElementPresenceWithTimeOut(ISPPayment, ApplicationConfiguration.getWaitForElementTimeout())) {
                assertEquals("Verify Payment type as :", "In Store Payment", driver.getText(ISPPayment).toLowerCase());
            }
            CommonUtilities.waitTime(4);

            if (driver.waitForElementPresenceWithTimeOut(countinueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(countinueButton);
            } else {
                Assert.assertTrue("Continue button is not found on Payment page", false);
            }
        }

    }

    public void processCreditCardPaymentEU(String creditCardNumber) throws Exception {
        CommonUtilities.waitTime(1);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }

        navigateLowestLevelFrame(diaction);

        // }
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on Payment page", false);
        }

        CommonUtilities.waitTime(1);
        if (driver.waitForElementPresenceWithTimeOut(cardNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (driver.waitForElementPresenceWithTimeOut(cardNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.type(cardNumber, creditCardNumber);
            } else {
                Assert.assertTrue("Credit Card Number is not found on Payment page", false);
            }
        /*    if (driver.checkObjectExists(firstName, ApplicationConfiguration.getWaitForElementTimeout())) {
//                    driver.type(firstName, CustomerDetails.customerData.get("FIRSTNAME"));
                driver.type(firstName, "EUQA");
            } else {
                Assert.assertTrue("First Name is not found on Payment page", false);
            }
            if (driver.checkObjectExists(lastName, ApplicationConfiguration.getWaitForElementTimeout())) {
//                    driver.type(lastName, CustomerDetails.customerData.get("LASTNAME").replace("%",""));
                driver.type(lastName, "Automation");
            } else {
                Assert.assertTrue("Last Name is not found on Payment page", false);
            }*/
            if (driver.checkObjectExists(expiryMonth, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.select(expiryMonth, "01-Jan");
            } else {
                Assert.assertTrue("Expiry Month List is not found on Payment page", false);
            }
            if (driver.checkObjectExists(expiryYear, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.select(expiryYear, "2019");
            } else {
                Assert.assertTrue("Expiry Month List is not found on Payment page", false);
            }
            if (driver.checkObjectExists(cvvCode, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.type(cvvCode, "198");
            } else {
                Assert.assertTrue("CVV code is not found on Payment page", false);
            }

            if (driver.checkObjectExists(radioUseEnrolledAddress, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(radioUseEnrolledAddress);
            } else {
                Assert.assertTrue("Use Enrolled Address radio button is not found on Payment page", false);
            }

            if (driver.checkObjectExists(countinueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptScrollAndClick(countinueButton);
            } else {
                Assert.assertTrue("Continue button is not found on Payment page", false);
            }

        } else {
            Assert.assertTrue("Credit card field is not found on Payment page", false);
        }
    }

    public void EditDeductibleAmount(String DedAmount, String curSign, String ReasonCode) {
        CommonUtilities.waitTime(3);

        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }
        navigateLowestLevelFrame(diaction);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on Payment page", false);
        }

        CommonUtilities.waitTime(3);
        if (driver.checkObjectExists(pencilDeductible, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.javaScriptClick(pencilDeductible);
            System.out.println("Clicked on Edit button for Deductible amount");
        } else {
            System.out.println("Edit Deductible amount button is not displayed. Check if the user has privileges");
            Assert.assertTrue("Edit Deductible amount button is not displayed", false);
        }

        CommonUtilities.waitTime(6);
        if (driver.elementExists(editDeductibleframe)) {
            System.out.println("Edit Deductible window is displayed");
        } else {
            System.out.println("Edit Deductible window is not displayed");
            Assert.assertTrue("Edit Deductible window is not displayed", false);
        }

        CommonUtilities.waitTime(1);
        if (driver.elementExists(deductible)) {
            driver.type(deductible, DedAmount);
            System.out.println("Deductible amount is updated");
        } else {
            System.out.println("Deductible text box is not displayed");
            Assert.assertTrue("Deductible text box is not displayed", false);
        }

        if (driver.elementExists(reason)) {
            driver.select(reason, ReasonCode);
            System.out.println("Deductible amount adjustment reason is selected");
        } else {
            System.out.println("Deductible amount adjustment reason dropdown is not displayed");
            Assert.assertTrue("Deductible amount adjustment reason dropdown is not displayed", false);
        }

        if (driver.waitForElementPresenceWithTimeOut(setToCurSign, ApplicationConfiguration.getWaitForElementTimeout())) {
            if (driver.getText(setToCurSign).equals(curSign)) {
                System.out.println("Set to currency sign is displayed as " + curSign);
            } else {
                System.out.println("Set to currency sign is different from " + curSign);
                Assert.assertTrue("Set to currency sign is different from " + curSign, false);
            }
        } else {
            System.out.println("Unable to identify the set to currency sign");
            Assert.assertTrue("Unable to identify the set to currency sign", false);
        }

        if (driver.elementExists(deductibleSave)) {
            driver.javaScriptClick(deductibleSave);
            System.out.println("Clicked Save button on Edit Deductible window");
        } else {
            System.out.println("Save button on Edit Deductible window is not displayed");
            Assert.assertTrue("Save button on Edit Deductible window is not displayed", false);
        }

        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }
        navigateLowestLevelFrame(diaction);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on Payment page", false);
        }

        CommonUtilities.waitTime(3);

        if (driver.elementExists(deductibleAmount)) {
            if (driver.getText(deductibleAmount).equals(curSign + DedAmount + ".00")) {
                System.out.println("Modified Excess Fee is updated in Order Fulfillment Fees section");
            } else {
                System.out.println("Modified Excess Fee is not updated in Order Fulfillment Fees section");
                //org.junit.Assert.assertTrue("Modified Excess Fee is not updated in Order Fulfillment Fees section", false);
            }
        } else {
            System.out.println("Deductible amount field is not displayed in Fees section");
            Assert.assertTrue("Deductible amount field is not displayed in Fees section", false);
        }
        CommonUtilities.waitTime(6);
    }

    public void ValidateCurrencySignFees(String curSign) {
        CommonUtilities.waitTime(3);

        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }
        navigateLowestLevelFrame(diaction);

        CommonUtilities.waitTime(1);
        navigateLowestLevelFrame(diaction);
        if (!driver.waitForFrameToLoad(cpmTabbedNavigationDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmTabbedNavigationDivFrame is not found on Payment page", false);
        }

        CommonUtilities.waitTime(1);

        if (driver.elementExists(deductibleAmount)) {
            if (driver.getText(deductibleAmount).contains(curSign)) {
                System.out.println("Currency sign for Excess Fee is displayed correctly as: " + curSign);
            } else {
                System.out.println("Currency sign for Excess Fee is displayed incorrectly");
                Assert.assertTrue("Currency sign for Excess Fee is displayed incorrectly", false);
            }
        } else {
            System.out.println("Deductible amount field is not displayed in Fees section");
            Assert.assertTrue("Deductible amount field is not displayed in Fees section", false);
        }

        if (driver.elementExists(shipping)) {
            if (driver.getText(shipping).contains(curSign)) {
                System.out.println("Currency sign for Shipping Fee is displayed correctly as: " + curSign);
            } else {
                System.out.println("Currency sign for Shipping Fee is displayed incorrectly");
                Assert.assertTrue("Currency sign for Shipping Fee is displayed incorrectly", false);
            }
        } else {
            System.out.println("Shipping field is not displayed in Fees section");
            Assert.assertTrue("Shipping field is not displayed in Fees section", false);
        }

        if (driver.elementExists(totalDueFees)) {
            if (driver.getText(totalDueFees).contains(curSign)) {
                System.out.println("Currency sign for TOTAL DUE Fee in Fees section is displayed correctly as: " + curSign);
            } else {
                System.out.println("Currency sign for TOTAL DUE Fee in Fees section is displayed incorrectly");
                Assert.assertTrue("Currency sign for TOTAL DUE Fee in Fees section is displayed incorrectly", false);
            }
        } else {
            System.out.println("TOTAL DUE Fee in Fees section is not displayed");
            Assert.assertTrue("TOTAL DUE Fee in Fees section is not displayed", false);
        }

        if (driver.elementExists(feeIfNotReturned)) {
            if (driver.getText(feeIfNotReturned).contains(curSign)) {
                System.out.println("Currency sign for 'fee if not returned' in Claimed Device section is displayed correctly as: " + curSign);
            } else {
                System.out.println("Currency sign for 'fee if not returned' in Claimed Device section is displayed incorrectly");
                Assert.assertTrue("Currency sign for 'fee if not returned' in Claimed Device section is displayed incorrectly", false);
            }
        } else {
            System.out.println("'fee if not returned' in Claimed Device is not displayed");
            Assert.assertTrue("'fee if not returned' in Claimed Device is not displayed", false);
        }
    }

    /**
     * This method used to for entering declined credit card details
     *
     * @param - invalid_CreditcardNumber(declined credit card number is given by user)
     *          [eg. invalid_CreditcardNumber=5432673002690551]
     * @author Shweta
     */
    public void enterInvalidCreditCardPaymentDetails(String invalid_CreditcardNumber) throws Exception {
        CommonUtilities.waitTime(2);
        driver.switchToDefaultContent();
        if (!driver.waitForFrameToLoad(cpmInteractionDivFrame, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("CpmInteractionDivFrame is not found on Payment page", false);
        }
        if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout())) {
            Assert.assertTrue("Diaction is not found on Payment page", false);
        }
            /*if (!driver.waitForFrameToLoad(diaction, ApplicationConfiguration.getWaitForElementTimeout()))
            {
                Assert.assertTrue("Diaction 1 is not found on Payment page", false);
            }*/
        //navigateLowestLevelFrame(diaction);
        driver.switchToFrame(cpmTabbedNavigationDivFrame);

        String customerName = CustomerDetails.customerData.get("CUSTOMERNAME");
        String[] employeeDetails = customerName.split(" ");
        System.out.println("First name :: " + employeeDetails[0]);
        System.out.println("Last  name :: " + employeeDetails[1]);


        if (driver.checkObjectExists(cardNumber, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(cardNumber, invalid_CreditcardNumber);
        } else {
            Assert.assertTrue("Credit Card Number is not found on Payment page", false);
        }
        if (driver.checkObjectExists(firstName, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(firstName, employeeDetails[0]);
        } else {
            Assert.assertTrue("First Name is not found on Payment page", false);
        }
        if (driver.checkObjectExists(lastName, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(lastName, employeeDetails[1]);
        } else {
            Assert.assertTrue("Last Name is not found on Payment page", false);
        }
        if (driver.checkObjectExists(expiryMonth, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(expiryMonth, "02-Feb");
        } else {
            Assert.assertTrue("Expiry Month List is not found on Payment page", false);
        }
        if (driver.checkObjectExists(expiryYear, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.select(expiryYear, "2018");
        } else {
            Assert.assertTrue("Expiry Month List is not found on Payment page", false);
        }
        if (driver.checkObjectExists(cvvCode, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(cvvCode, "123");
        } else {
            Assert.assertTrue("CVV code is not found on Payment page", false);
        }
        if (driver.checkObjectExists(addressLine1, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(addressLine1, "650 Grassmere Park");
        } else {
            Assert.assertTrue("Address is not found on Payment page", false);
        }
        if (driver.checkObjectExists(cityName, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(cityName, "Nashville");
        } else {
            Assert.assertTrue("Name of City is not found on Payment page", false);
        }
        if (driver.checkObjectExists(stateProvinceCode, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(stateProvinceCode, "TN");
        } else {
            Assert.assertTrue("State Provinance Code is not found on Payment page", false);
        }
        if (driver.checkObjectExists(postalCode, ApplicationConfiguration.getWaitForElementTimeout())) {
            driver.type(postalCode, "37211");
        } else {
            Assert.assertTrue("Postal Code is not found on Payment page", false);
        }
        if (driver.waitForElementPresenceWithTimeOut(additionalChargesYes, 1)) {
            driver.click(additionalChargesYes);
        }
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
            if (driver.waitForElementPresenceWithTimeOut(countinueButtonnTelos, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.waitAndClick(countinueButtonnTelos);
            } else {
                Assert.assertTrue("Continue button is not found on Payment page", false);
            }
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
            if (driver.checkObjectExists(countinueButtonClaro, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(countinueButtonClaro);
                CommonUtilities.waitTime(3);
            } else {
                Assert.assertTrue("Continue button claro client is not found on Payment page", false);
            }
        } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("FREEDOM")) {
            if (driver.checkObjectExists(countinueButtonWind, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(countinueButtonWind);
            } else {
                Assert.assertTrue("Continue button Wind client is not found on Payment page", false);
            }
        } else {
            if (driver.checkObjectExists(countinueButton, ApplicationConfiguration.getWaitForElementTimeout())) {
                driver.javaScriptClick(countinueButton);
            } else {
                Assert.assertTrue("Continue button is not found on Payment page", false);
            }
        }
    }
}