package runner;

import com.asurion.common.core.driver.TestDriver;
import com.asurion.pages.SubBillingPortalPages;
import org.openqa.selenium.By;

import java.io.File;

/**
 * Created by Vilas.Kolhe on 5/16/2017.
 */
public class DemoFileUpload {
    public static void main(String[] args) {
        TestDriver d = TestDriver.getDriver("chrome","local","57");
        SubBillingPortalPages x=new SubBillingPortalPages();
        System.out.println("Unique : " + d.getUniqueStringOfReqLength(31,false));
//
//        d.navigate("http://lqasedcobui001v:8080/SubBillingPortal/index.htm#/IntentChargeUpload)");
//        File f =new File("src/abc/yourfile.txt");
//        String fullPath = f.getAbsolutePath();
//
//
//        d.getWebDriver().findElement(By.id("FileUpload")).sendKeys("C:\\Cucumber Projects\\FrameworkImplementation\\src\\test\\resources\\data\\NewCreateTemplate1.xlsx");
    }
}
