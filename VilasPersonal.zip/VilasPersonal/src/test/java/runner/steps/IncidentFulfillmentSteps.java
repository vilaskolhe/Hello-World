package runner.steps;

import com.asurion.common.core.util.CommonUtilities;
import com.asurion.pages.*;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class IncidentFulfillmentSteps {

    private IncidentFulfillmentPage incidentFulfillmentPage;
    private PaymentPage creditCardTokenPage;
    private ActionPage actionPage;
    private HomePage homePage;
    private IdentifyCustomerPage identifyCustomerPage;
    private IncidentPathPage incidentPathPage;
    private EndCallPage EndCallPage;

    public IncidentFulfillmentSteps() {
        incidentFulfillmentPage = new IncidentFulfillmentPage();
        creditCardTokenPage = new PaymentPage();
        actionPage = new ActionPage();
        homePage = new HomePage();
        identifyCustomerPage = new IdentifyCustomerPage();
        incidentPathPage = new IncidentPathPage();
        EndCallPage = new EndCallPage();
    }

    @And("^I select the replacement equipment$")
    public void I_select_the_replacement_equipment() throws Exception {
        System.out.println("I select the replacement equipment");
        incidentFulfillmentPage.select_replacement_equipment();
    }

    @And("^I select the shipping address$")
    public void I_select_the_shipping_address() throws Exception {
        System.out.println("I select the shipping address");
        incidentFulfillmentPage.select_shipping_address();
    }

    @And("^I submit the Order$")
    public void I_submit_the_order() throws Exception {
        System.out.println("I submit the Order");
        incidentFulfillmentPage.clickSubmitOrder();
    }

    @Then("^I verify the claim is complete$")
    public void I_verify_the_claim_is_complete() throws Exception {
        System.out.println("I verify the claim is complete");
       // incidentFulfillmentPage.checkClaim();
    }


    @And("^I select SNR fee \"([^\"]*)\" and submit the Order$")
    public void I_select_SNR_fee_and_submit_the_Order(String snrFee) throws Exception {
        System.out.println("I select SNR fee " + snrFee + " and submit the Order");
        incidentFulfillmentPage.clickSubmitOrderWithSNRFee(snrFee);

        if (actionPage.checkHold()) {
            actionPage.releaseHold(CustomerDetails.customerData.get("MDN"));
            //actionPage.releaseHold(CustomerDetails.customerData.get("MDN"));
            // EndCallPage.endCall("Holds", "System Placed Hold");

            System.out.println("end call Env " + ApplicationConfiguration.getClient());
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
                EndCallPage.endCall("Holds", "System Placed Hold");
            } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                EndCallPage.endCallWithIntentAreaAndOutcome("Call Handling", "Status Inquiry", "Claim History");
            }

            homePage.checkCallButton();
            homePage.pressStart();

            if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
                homePage.selectClient("Telcel Mexico");
            } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                homePage.selectClient("nTelos");
            }
            identifyCustomerPage.searchUsingMDN(CustomerDetails.customerData.get("MDN"));
            identifyCustomerPage.verifyCaller("Account Holder", "valid");
            identifyCustomerPage.continueClaim();
            incidentPathPage.select_incident_path("Resume Incident");
            CommonUtilities.waitTime(10);

            creditCardTokenPage.enterThePaymentDetails("4111111111111111");
            incidentFulfillmentPage.clickSubmitOrderWithSNRFee(snrFee);
        }
    }

    @And("^I select the store address for shipping$")
    public void I_select_the_store_address_for_shipping ()throws Exception{
        System.out.println("\n I select the store address for shipping");
        incidentFulfillmentPage.selectStoreAddress();
    }

    @And("^I Override the shipping address$")
    public void I_override_the_shipping_address ()throws Exception {
        System.out.println("\n I Override the shipping address");
        incidentFulfillmentPage.overRideShipping();
    }

    @And("^I select the replacement equipment EU$")
    public void I_select_the_replacement_equipment_EU()  {
        System.out.println("I select the replacement equipment EU");
        incidentFulfillmentPage.select_replacement_equipmentEU();
    }

    @And("^I select the shipping address EU$")
    public void I_select_the_shipping_address_EU () {
        System.out.println("I select the shipping address EU");
        incidentFulfillmentPage.select_shipping_addressEU();
    }

    @And("^I select Yes to SNR Question EU$")
    public void I_select_yes_SNR_EU() throws Throwable {
        System.out.println("I select Yes to SNR Fee EU");
        incidentFulfillmentPage.selectSNRFeeYes();
    }

    @And("^I submit and confirm the Order EU$")
    public void I_submit_the_order_EU () {
        System.out.println("I submit and confirm the Order EU");
        incidentFulfillmentPage.clickSubmitOrderEU();
    }

    @And("^I override the shipping address EU$")
    public void I_override_the_shipping_address_EU() {
            incidentFulfillmentPage.override_shipping_addressEU();
    }

}