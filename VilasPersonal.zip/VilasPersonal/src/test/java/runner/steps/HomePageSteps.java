package runner.steps;

import com.asurion.common.core.driver.TestDriver;
import com.asurion.common.core.util.CommonUtilities;
import com.asurion.pages.CaptureIncidentPage;
import com.asurion.pages.HomePage;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

import static org.junit.Assert.assertTrue;

public class HomePageSteps {

    private HomePage homePage;
    private CaptureIncidentPage captureIncidentPage;
    private TestDriver testDriver;

    public HomePageSteps() {
        homePage = new HomePage();
        captureIncidentPage = new CaptureIncidentPage();
    }


    @Given("^I am on the Horizon homepage$")
    public void I_am_on_homepage_for_Horizon() throws Exception {
        System.out.println("I am on the Horizon homepage");
        ApplicationConfiguration.printTestRunDetails();
        if (ApplicationConfiguration.getUrlType().equalsIgnoreCase("Pega")) {
            homePage.openPegaURL();
            homePage.enterAutomatedLoginInfo();
        } else if (ApplicationConfiguration.getUrlType().equalsIgnoreCase("QA01"))
            homePage.goToHomePage();
    }

    @And("^I select the client \"([^\"]*)\"$")
    public void I_select_the_client(String client) throws Exception {
        System.out.println("I select the client " + client);
            if(ApplicationConfiguration.getClient().equalsIgnoreCase("Fido"))
                homePage.selectClient("Rogers");
            /*else if(ApplicationConfiguration.getClient().equalsIgnoreCase("Freedom Mobile") )
                homePage.selectClient("Freedom Mobile");*/
            else
                homePage.selectClient(client);

        }

    @And("^I switch user role as \"([^\"]*)\"$")
    public void I_switch_user_role(String userRole) throws Exception {
        System.out.println("I switch user role as " + userRole);
        homePage.switchUserAccount(userRole);
    }

    @And("^I start the call$")
    public void I_start_the_call() throws Exception {
        System.out.println("I start the call");
        homePage.pressStart();
    }

    @And("^I logout from the application")
    public void I_logout_the_application() throws Throwable {
        System.out.println("I logout from the application");
       // homePage.logOutFromApplication();
    }

    @Then("^I verify that call is ended$")
    public void I_verify_that_call_is_ended() throws Exception {
        System.out.println("I verify that call is ended");
        assertTrue("Checking if call is ended", homePage.checkCallButton());
    }

    @And("^I start a customer interaction$")
    public void I_start_a_customer_interaction() throws Exception {
        System.out.println("I start a customer interaction");
        homePage.pressStart();
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("claro peru")) {
            CommonUtilities.waitTime(8);
            captureIncidentPage.capture_CorrelationID();
        }
    }

    @And("^I verify (.+) status on Account Home tab")
    public void I_verify_status_under_AccountHomeTab(String status) throws Exception {
        System.out.println("I verify " + status + " status on Account Home tab");
        homePage.verifyStatusUnderAccountHomeTab(status);
    }

    @And("^I select the channel \"([^\"]*)\"$")
    public void I_select_the_channel(String client) throws Exception {
        if(ApplicationConfiguration.getClient().equalsIgnoreCase("Fido"))
            homePage.selectChannel("Fido");
        else if(ApplicationConfiguration.getClient().equalsIgnoreCase("Rogers"))
            homePage.selectChannel("Rogers");
        else if(ApplicationConfiguration.getClient().equalsIgnoreCase("FREEDOM"))
            homePage.selectChannel("Freedom Mobile");
        else
            homePage.selectChannel(client);
    }

    @And("^I select \"([^\"]*)\" mode$")
    public void I_select_the_mode(String mode) throws Throwable {
        homePage.selectMode(mode);

    }

    @And("^I switch user role for EU as \"([^\"]*)\"$")
    public void I_switch_user_role_EU(String userRole) throws Throwable {
        System.out.println("I switch user role as" + userRole);
        homePage.switchUserAccountEU(userRole);
    }

    @And("^I switch user role for 3uk as \"([^\"]*)\"$")
    public void I_switch_user_role_3uk(String userRole) throws Throwable{
        System.out.println("I switch user role with new method " + userRole);
        homePage.switchUserRoleForEurope(userRole);
    }

}