package runner.steps;


import com.asurion.common.core.util.CommonUtilities;
import com.asurion.pages.*;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.junit.Assert;

public class ActionSteps {

    private ActionPage actionPage;
    private HomePage homePage;
    private IdentifyCustomerPage identifyCustomerPage;
    private IncidentPathPage incidentPathPage;
    private CaptureIncidentPage captureIncidentPage;
    private EndCallPage EndCallPage;

    private PaymentPageSteps paymentPageSteps;
    private IncidentFulfillmentSteps incidentFulfillmentSteps;

    public ActionSteps() {

        actionPage = new ActionPage();
        homePage = new HomePage();
        identifyCustomerPage = new IdentifyCustomerPage();
        incidentPathPage = new IncidentPathPage();
        captureIncidentPage = new CaptureIncidentPage();
        paymentPageSteps = new PaymentPageSteps();
        incidentFulfillmentSteps = new IncidentFulfillmentSteps();
        EndCallPage = new EndCallPage();
    }

    @And("^I release risk holds if exist and resume incident$")
    public void I_release_risk_holds() throws Exception {
        /*System.out.println("I release risk holds if exist and resume incident");
        if (actionPage.checkHold()) {
            actionPage.releaseHold(CustomerDetails.customerData.get("MDN"));
            // System.out.println("end call Env " + ApplicationConfiguration.getClient());
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro peru")) {
                EndCallPage.endCall("Holds", "System Placed Hold");
            } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                EndCallPage.endCallWithIntentAreaAndOutcome("Call Handling", "Status Inquiry", "Claim History");
            }
            boolean result = homePage.checkCallButton();
            if (!result)
                Assert.assertTrue("tab is not cloesd", false);
            homePage.pressStart();

            if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
                homePage.selectClient("Telcel Mexico");
            } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                homePage.selectClient("nTelos");
            } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro")) {
                homePage.selectClient("Claro Colombia");
            } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro Peru")) {
                homePage.selectClient("Claro Peru");
            }
            identifyCustomerPage.searchUsingMDN(CustomerDetails.customerData.get("MDN"));
            identifyCustomerPage.verifyCaller("Account Holder", "valid");
            identifyCustomerPage.continueClaim();
            incidentPathPage.select_incident_path("Resume Incident");
            CommonUtilities.waitTime(10);
        }*/
    }

    /////
    @Then("^I release review hold if exist and resume incident by entering credit card number \"([^\"]*)\"$")
    public void I_release_review_hold_if_exist_and_resume_incident_by_entering_credit_card_number(String cardNumber) throws Exception {
        System.out.println("I release review hold if exist and resume incident by entering credit card number " + cardNumber);
        if (actionPage.checkHold()) {
            actionPage.releaseHold(CustomerDetails.customerData.get("MDN"));

            // System.out.println("end call Env " + ApplicationConfiguration.getClient());
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel") || ApplicationConfiguration.getClient().equalsIgnoreCase("claro")) {
                EndCallPage.endCall("Holds", "System Placed Hold");
            } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                EndCallPage.endCallWithIntentAreaAndOutcome("Call Handling", "Status Inquiry", "Claim History");
            }
            homePage.checkCallButton();
            homePage.pressStart();

            if (ApplicationConfiguration.getClient().equalsIgnoreCase("telcel")) {
                homePage.selectClient("Telcel Mexico");
            } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("ntelos")) {
                homePage.selectClient("nTelos");
            } else if (ApplicationConfiguration.getClient().equalsIgnoreCase("Claro")) {
                homePage.selectClient("Claro Colombia");
            }
            identifyCustomerPage.searchUsingMDN(CustomerDetails.customerData.get("MDN"));
            identifyCustomerPage.verifyCaller("Account Holder", "valid");
            identifyCustomerPage.continueClaim();
            incidentPathPage.select_incident_path("Resume Incident");

            paymentPageSteps.I_enter_the_payment_Detailsand_release_hold_if_exist(cardNumber);
            incidentFulfillmentSteps.I_submit_the_order();
        }
    }

    @And("^I start the refund process$")
    public void I_start_the_refund_process() throws Exception {
        System.out.println("I start the refund process");
        actionPage.startRefundProcess();
    }

    // Method in use
    @And("^I process the refund request with reason \"([^\"]*)\" and core device required \"([^\"]*)\" and envelope required \"([^\"]*)\" and submit refund$")
    public void I_process_the_refund_request(String reason, String withCoreDevice, String envelope) throws Exception {
        System.out.println("I process the refund request with reason " + reason);
        actionPage.processRefundRequest(reason, withCoreDevice, envelope);
    }
    //Method in use for 3UK
    @And("^I process the refund request with reason \"([^\"]*)\" and core device required \"([^\"]*)\" and envelope required \"([^\"]*)\" and submit refund for 3UK$")
    public void I_process_the_refund_request_for_3uk(String reason, String withCoreDevice, String envelope) throws Exception {
        System.out.println("I process the refund request with reason " + reason);
        actionPage.processRefundRequestfor3UK(reason, withCoreDevice, envelope);
    }

    //Method in use for 3UK DED Refund
    @And("^I process the DED Refund request with reason \"([^\"]*)\" and core device required \"([^\"]*)\" and envelope required \"([^\"]*)\" and submit refund for 3UK$")
    public void I_process_the_DEDRefund_request_for_3uk(String reason, String withCoreDevice, String envelope) throws Exception {
        System.out.println("I process the DED Refund request with reason " + reason);
        actionPage.process3UKRefundRequestForDEDRefund(reason, withCoreDevice, envelope);
    }

    @Then("^I verify the refund is submitted$")
    public void I_verify_the_refund_submitted() throws Exception {
        System.out.println("I verify the refund is submitted");
        actionPage.verifyRefundIsSubmitted();
    }

    @And("^I select the casenumber for refund process$") //Nandini
    public void I_select_the_casenumber_for_refund_process() throws Exception {
        System.out.println("I select the casenumber for refund process");
        actionPage.selectCaseNumberForRefundProcess();
    }

    @And("^I select the \"([^\"]*)\" type for refund process$") //Nandini
    public void I_select_the_casenumber_for_refund_process(String feeType) throws Exception {
        System.out.println("I select the fee type for refund process");
        actionPage.selectFeeForRefund(feeType);
    }

    // Method in use
    @And("^I process the refund request with refund reason \"([^\"]*)\" and code device returned \"([^\"]*)\"$")
    public void I_process_refund_request_with_refund_reason_and_code_device_details(String reason, String coredeviceYesNo) throws Exception {
        System.out.println("I process the refund request with refund reason " + reason);
        actionPage.refundRequestWithCodeDeviceDetails(reason, coredeviceYesNo);
    }

    // Method in use
    @And("^I select \"([^\"]*)\" for the send envelope and escalate if \"([^\"]*)\" error message recevied$")
    public void I_select_the_refund_reason(String envelopesOrNo, String errorMessage) throws Exception {
        actionPage.handleEnvelopeAndEscalateCheck(envelopesOrNo, errorMessage);
    }

    // Method in use
    @And("^I select \"([^\"]*)\" for the send envelope and escalate if \"([^\"]*)\" is appeared and submit refund$")
    public void I_handle_the_envelope_and_escalate(String envelopesOrNo, String errorMessage) throws Exception {
        System.out.println("I select " + envelopesOrNo + " for the send envelope and escalate if " + errorMessage + " is appeared and submit refund");
        actionPage.envelopeAndEscalate(envelopesOrNo, errorMessage);
    }

    // Method in use
    @And("^I select \"([^\"]*)\" for send envelope and and submit refund$")
    public void I_select_envelope_option_and_submit_refund(String envelopesOption) throws Exception{
        System.out.println("I select " + envelopesOption + " for the send envelope and submit refund");
        actionPage.approveRefundRequestFromNAFinanceWorkBasket(envelopesOption);
    }

    // Method in use
    @And("^I select \"([^\"]*)\" for the send envelope and verify escalate \"([^\"]*)\" check for \"([^\"]*)\"$")
    public void I_handle_the_envelope_and_verify_escalate_check(String envelopeYesOrNo, String errorMessage, String eligibiltyCheck) throws Exception {
        System.out.println("I select " + envelopeYesOrNo + " for the send envelope and verify escalate");
        actionPage.envelopeAndVerifyEscalateCheckAvailability(envelopeYesOrNo, errorMessage, eligibiltyCheck);
    }

   /* @And("^I process the refund request for duplicate fee with reason \"([^\"]*)\" and core device required with device reason \"([^\"]*)\"$")
    public void I_process_the_refund_request_for_duplicate_fee_with_reason_and_core_device_required_with_device_reason(String reason1, String deviceReason1) throws Exception {
        actionPage.refundRequestForDuplicateFee(reason1, deviceReason1);
    }*/

    @And("^I close the browser$")
    public void I_close_the_browser(){
        System.out.println("I close the browser.");
        actionPage.closeBrowser();
    }

    @And("^I verified x value in y table$")
    public void I_verified_x_value_in__table(){
        System.out.println("I verified x value in y table.");

    }

    @And("^I select \"([^\"]*)\" Fee refund$")
    public void I_select_refund_feeType(String refund){
        System.out.println("I select " + refund + " refund");
            actionPage.selectFeeForRefund(refund);
    }

}