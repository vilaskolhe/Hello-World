package runner.steps;

import com.asurion.qa.errorReporting.ErrorReporter;
import com.asurion.qa.util.CommonUtilities;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.common.core.driver.TestDriver;
import com.asurion.pages.ShipPhonePage;
import com.asurion.pages.IdentifyCustomerPage;
import com.asurion.util.CustomerDetails;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import com.asurion.util.Generic;

import static junit.framework.TestCase.assertEquals;

/**
 * Created by rbharamgonde on 2/19/2015.
 */
public class ShipSteps {

    private ShipPhonePage shipPage;
    private IdentifyCustomerPage identifyCustomerPage;

    public ShipSteps() {
        shipPage = new ShipPhonePage();
        identifyCustomerPage = new IdentifyCustomerPage();

    }


    @And("^I ship the asset$")
    public void I_ship_the_asset() throws Exception {
        System.out.println("I ship the asset");
        shipPage.shipPhone();

    }

    @And("^I deliver the asset$")
    public void I_deliver_the_asset() throws Exception {
        System.out.println("I deliver the asset");
        shipPage.deliveryEvent();
    }

    @And("^I release backordered device$")
    public void I_release_backordered_device() throws Exception {
        shipPage.releaseBackorderedDevice();
    }

    @And("^I submit salvage return event$")
    public void I_submit_salvage_return_event() throws Exception {
        shipPage.submitSalvageReturnEvent();
    }

    @And("^I ship the asset for KPN$")
    public void I_ship_the_asset_for_KPN() throws Throwable {
        Generic.shipClaim(Generic.getValuesFromGlobals("CASENUMBER"), "RNL");
    }

    @And("^I return the asset for KPN$")
    public void I_return_the_asset_EU() throws Throwable {
        Generic.returnPhone(Generic.getValuesFromGlobals("CASENUMBER"), "RNL");
    }

    @And("^I verify that order status is Shipped for current claim$")
    public void I_verify_the_order_status_shipped() throws Exception {
        System.out.println("\n I verify that order status is Shipped for current claim");
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk")) {
            identifyCustomerPage.waitAndCheckForRequestToBeCompleted();
            Generic.waitForOrderStatusEU("Shipped", "8", Generic.getValuesFromGlobals("CASENUMBER"), "RUK");
        } else Generic.waitForOrderStatusEU("Shipped", "8", Generic.getValuesFromGlobals("CASENUMBER"), "RNL");
    }

    @And("^I verify that order status is Shipped for renewal claim$")
    public void I_verify_the_order_status_shipped_for_renewal() throws Exception {
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk")) {
            Generic.waitForRenewalOrderStatusEU("Shipped", "8", Generic.getValuesFromGlobals("CASENUMBER"), "RUK");
        } else Generic.waitForRenewalOrderStatusEU("Shipped", "8", Generic.getValuesFromGlobals("CASENUMBER"), "RNL");
    }


    //3uk
    @And("^I verify that order status is Ready for current claim$")
    public void I_verify_the_order_status_ready() throws Throwable {
        System.out.println("I verify that order status is Ready for current claim");
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk")) {
            Generic.waitForOrderStatusEU("Ready", "2", Generic.getValuesFromGlobals("CASENUMBER"), "RUK");
        } else Generic.waitForOrderStatusEU("Ready", "2", Generic.getValuesFromGlobals("CASENUMBER"), "RNL");
    }

    @And("^I verify that order status is Ready for Renewal claim$")
    public void I_verify_the_order_status_ready_for_renewal() throws Throwable {
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk")) {
            Generic.waitForRenewalOrderStatusEU("Ready", "2", Generic.getValuesFromGlobals("CASENUMBER"), "RUK");
        } else Generic.waitForRenewalOrderStatusEU("Ready", "2", Generic.getValuesFromGlobals("CASENUMBER"), "RNL");
    }

    @And("^I verify that order status is Returned for current claim$")
    public void I_verify_the_order_status_returned() throws Exception {
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk")) {
            Generic.waitForOrderStatusEU("Returned", "10", Generic.getValuesFromGlobals("CASENUMBER"), "RUK");
        } else Generic.waitForOrderStatusEU("Returned", "10", Generic.getValuesFromGlobals("CASENUMBER"), "RNL");
    }

    @And("^I verify that order status is Returned for renewal claim$")
    public void I_verify_the_order_status_returned_for_renewal() throws Exception {
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk")) {
            Generic.waitForRenewalOrderStatusEU("Returned", "10", Generic.getValuesFromGlobals("CASENUMBER"), "RUK");
        } else Generic.waitForRenewalOrderStatusEU("Returned", "10", Generic.getValuesFromGlobals("CASENUMBER"), "RNL");
    }

    @And("^I update service request status as Completed for EU$")
    public void I_update_service_request_status_as_Completed_EU() throws Exception {
        Generic.updateServiceRequestStatusEU();
    }

    @And("^I ship the asset for 3UK$")
    public void I_ship_the_asset_EU_3UK() throws Throwable {
        System.out.println("I ship the asset for 3UK");
        Generic.shipClaim(Generic.getValuesFromGlobals("CASENUMBER"), "RUK");
    }

    @And("^I return the asset for 3UK$")
    public void I_return_the_asset_3UK() throws Throwable {
        Generic.returnPhone(Generic.getValuesFromGlobals("CASENUMBER"), "RUK");
    }

    @And("^I verify the case status is \"([^\"]*)\" in shipping order table KPN$")
    public void I_verify_case_status_ship(String status) throws Throwable {
        System.out.println("\nI verify the case status is " +status+" in shipping order table in DAL");
        identifyCustomerPage.waitAndCheckForRequestToBeCompleted();
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk")) {
            Generic.verifyCaseStatusIsShipInShippingOrderTableDAL(Generic.getValuesFromGlobals("DAL_MDN"), status);
        } else
            Generic.verifyCaseStatusIsShipInShippingOrderTableDAL(Generic.getValuesFromGlobals("MDN"), status);
    }

    @And("^I verify record is present in start RMA table KPN$")
    public void I_verify_RMATable() throws Throwable {
        Generic.verifyStartRMATableDAL(Generic.getValuesFromGlobals("CASENUMBER"));
    }

    @And("^I capture SalesOrder Number and Tracking Number from DAX DB$")
    public void I_sales_order_tracking_number_DAXDB() throws Throwable {
        System.out.println("\n I capture SalesOrder Number and Tracking Number from DAX DB");
        String warehouse = "RNL";
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk")) warehouse = "RUK";
      //  System.out.println("******Case Number required for Deliver the Asset"+Generic.getValuesFromGlobals("CASENUMBER"));
        Generic.getDetailsFromDAXDB("SALESORDERNUMBER", Generic.getValuesFromGlobals("CASENUMBER"), warehouse);
        Generic.getDetailsFromDAXDB("TRACKINGNUMBER", Generic.getValuesFromGlobals("CASENUMBER"), warehouse);
        identifyCustomerPage.waitAndCheckForRequestToBeCompleted();
    }

    @And("^I ship the asset EU$")
    public void I_ship_the_asset_EU() throws Throwable {
      CommonUtilities.waitTime(5);
        System.out.println("I ship the asset EU");
        System.out.println("Case Number for shipping the asset : "+Generic.getValuesFromGlobals("CASENUMBER"));
        try {
                if (ApplicationConfiguration.getClient().equalsIgnoreCase("kpn")) {
                    Generic.shipClaim(Generic.getValuesFromGlobals("CASENUMBER"), "RNL");
                } else {
                    Generic.shipClaim(Generic.getValuesFromGlobals("CASENUMBER"), "RUK");
                }
            identifyCustomerPage.waitAndCheckForRequestToBeCompleted();
            CommonUtilities.waitTime(30);
        } catch (Exception e) {
            ErrorReporter.reportError(e);
        }
    }
}
