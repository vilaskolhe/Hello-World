package runner.steps;

import com.asurion.pages.IncidentPathPage;
import cucumber.api.java.en.And;

public class IncidentPathSteps {

    private IncidentPathPage incidentPathPage;

    public IncidentPathSteps() {
        incidentPathPage = new IncidentPathPage();
    }


    @And("^I select an Incident Path \"([^\"]*)\"$")
    public void I_select_an_Incident_Path(String incidentPath) throws Exception {
        System.out.println("I select an Incident Path as " + incidentPath);
        incidentPathPage.select_incident_path(incidentPath);
    }


    @And("^I accept default contact details$")
    public void I_accept_default_contact_details() throws Exception {
        System.out.println("\n I accept default contact details");
        incidentPathPage.accept_default_contact();
    }

    @And("^I select product name as \"([^\"]*)\"$")
    public void I_select_product_name_as(String productName) throws Throwable {
        System.out.println("I select product name as "+productName);
          //  incidentPathPage.selectProductName(productName);
    }

    @And("^I click on continue button$")
    public void I_click_on_continue_button() throws Throwable {
        System.out.println("I click on continue button");
        incidentPathPage.clickContinueButton();
    }

    @And("^I capture case id for start incident EU$")
    public void I_capture_case_id_for_start_incidentEU()  {
        System.out.println("I capture case id for EU");
        incidentPathPage.captureClaimIdForStartIncidentEU();
    }

    @And("^I accept default contact details EU$")
    public void I_accept_default_contact_detailsEU()  {
        System.out.println("I accept default contact details for EU");
        incidentPathPage.acceptDefaultContactDetailsEU();
    }
}


