package runner.steps;

import com.asurion.database.DatabaseValidationUtil;
import com.asurion.pages.CaptureIncidentPage;
import com.asurion.pages.IncidentPathPage;
import com.asurion.util.ApplicationConfiguration;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

import org.junit.Assert;
import runner.AutomationHooks;
import com.asurion.util.Generic;

import java.util.List;
import java.util.Map;

/**
 * Created by User on 8/24/2016.
 */
public class DatabaseSteps {

    private DatabaseValidationUtil databaseValidationUtil = DatabaseValidationUtil.getDatabaseValidationUtil();
    private static boolean isScenarioPassed;
    private String query;
    private String caseNumber;

    @Before
    public void beforeScenario(Scenario scenario) {
        isScenarioPassed = true;
    }

    @Given("^required database query$")
    public void cdrequired_database_query(String query) throws Throwable {


        System.out.println("required database query----------------------------------------------------------------------");
        this.query = query;

    }

    @Given("^data of \"([^\"]*)\" table$")
    public void data_of_table(String tableType, List<Map<String, String>> expectedData) throws Throwable {
        System.out.println("required database query-----++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        if(ApplicationConfiguration.getClient().equalsIgnoreCase("3UK"))
            caseNumber = IncidentPathPage.caseID;
        else
            caseNumber = CaptureIncidentPage.claimId;
        System.out.println("data of " + tableType + " table");

        List<Map<String, String>> actualData = databaseValidationUtil.verifyGivenDataInTable(query, caseNumber , expectedData);
        System.out.println("Expected data :  \n" + DataTable.create(expectedData));
        System.out.println("Actual data : \n" + DataTable.create(actualData));
        try {
            DataTable.create(actualData).diff(expectedData);
        } catch (Exception ex) {
            AutomationHooks.currentScenario.write("" + ex);
            isScenarioPassed = false;
        }
    }

    @Then("^I verify all above given data$")
    public void i_verify_all_above_given_data() throws Throwable {
        System.out.println("\n I verify all above given data");
        Assert.assertTrue("Data validation failed ", isScenarioPassed);
    }

    @And("^I wait for (\\d+) minutes for delay capture charge$")
    public void i_wait_fordelay_capture_charge(int minutes) throws Throwable{
        System.out.println("\n I wait for " +minutes+" minutes for delay capture charge");
        Generic.waitForGivenMinute(minutes);
    }

    @Given("^I initialize common column values for \"([^\"]*)\"$")
    public void i_initialize_common_column_values(String transactionType) throws Throwable {
        System.out.println("\n I initialize common column values for " + transactionType);
        if(ApplicationConfiguration.getClient().equalsIgnoreCase("3UK")){
            databaseValidationUtil.initializeCommonValues(transactionType, IncidentPathPage.caseID );
           // System.out.println("Case Number for 3UK : "+Generic.getValuesFromGlobals("CASENUMBER"));
        }else {
            databaseValidationUtil.initializeCommonValues(transactionType, CaptureIncidentPage.claimId);
        }
    }

    @And("^execute given query and print result$")
    public void execute_given_query_and_print_result() throws Throwable {
        System.out.println("execute given query and print result");
        databaseValidationUtil.printResultSet(databaseValidationUtil.executeGivenQuery(query));
    }

    @And("^execute given query$")
    public void execute_given_query() throws Throwable {
        System.out.println("execute given query");
        databaseValidationUtil.executeGivenQuery(query);
    }

    @Given("^execute given update query$")
    public void execute_given_update_query() throws Throwable {
        System.out.println("execute given update query");
        databaseValidationUtil.returnFormattedQuery(query);
        databaseValidationUtil.executeGivenUpdateQuery(query);
    }

}
