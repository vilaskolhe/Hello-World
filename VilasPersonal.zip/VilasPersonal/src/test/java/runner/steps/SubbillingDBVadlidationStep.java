package runner.steps;

import com.asurion.util.ApplicationConfiguration;
import com.asurion.pages.SubBillingPortalPages;
import com.asurion.pages.SubbillingDBValidationPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

import java.util.HashMap;

/**
 * Created by NANDINI.MUJUMDAR on 10/11/2017.
 */
public class SubbillingDBVadlidationStep {

    private SubbillingDBValidationPage subbillingDBValidationPage;
    private SubBillingPortalPages subBillingPortalPages;

    public SubbillingDBVadlidationStep() {
        subBillingPortalPages = new SubBillingPortalPages();
        subbillingDBValidationPage = new SubbillingDBValidationPage();
    }

    @And("^I display validation status$")
    public void i_display_validation_status() throws Throwable {
        System.out.println("\nI display validation status");
        subbillingDBValidationPage.displayValidationReport();
    }

/*    @And("^I verify Refund Adjudication for option \"([^\"]*)\" with \"([^\"]*)\" in DB as \"([^\"]*)\"$")
    public void i_verify_refund_adjudication_option_in_database(String systemOption, String mop, String selectedOption) throws Throwable {
        System.out.println("\nI verify Refund Adjudication for option " + systemOption + " with " + mop +" in DB as " + selectedOption);
        subbillingDBValidationPage.verifyRefundAdjudicationInDatabase(systemOption, mop, selectedOption, SubBillingPortalPages.sbClient);
    }*/

    @And("^I verify Systematic Settlement for option \"([^\"]*)\" with \"([^\"]*)\" in DB as \"([^\"]*)\"$")
    public void i_verify_systematic_settlement_option_in_database(String systemOption, String mop, String selectedOption) throws Throwable {
        System.out.println("\nI verify Systematic Settlement for option " + systemOption + " with" + mop+" in DB as " + selectedOption);
        subbillingDBValidationPage.verifySystematicSettlementInDatabase(systemOption, mop, selectedOption, SubBillingPortalPages.sbClient);
    }

    @And("^I verify DAX Integration status for \"([^\"]*)\" as \"([^\"]*)\" in database$")
    public void i_verify_DAX_Integration_in_database(String mop, String selectedOption) throws Throwable{
        System.out.println("\nI verify DAX Integration status in database");
        subbillingDBValidationPage.validateDAXintegration(SubBillingPortalPages.sbClient, mop, selectedOption);
    }

    @Then("^I verify Aggregate Analysis option in DB as \"([^\"]*)\" for MOP as \"([^\"]*)\"$")
    public void i_verify_AggregateAnalysis_system_option_in_database(String selectedoption, String mop) throws Throwable {
        if (SubBillingPortalPages.isRecordPresent == true) {
            System.out.println("\nI verify Aggregate Analysis option in Database as " + selectedoption + " for Refund Adjudication");
            subbillingDBValidationPage.verifySystemOptionForAggregateAnalysisInDatabase(selectedoption, mop, SubBillingPortalPages.sbClient);
        }
    }

    @Then("^I verify Check Settlement option in DB as \"([^\"]*)\" for MOP as \"([^\"]*)\"$")
    public void i_verify_CheckSettlement_system_option_in_database( String selectedoption, String mop) throws Throwable{
        if(SubBillingPortalPages.isRecordPresent == true) {
            System.out.println("\nI verify Check Settlement option in Database as " + selectedoption + " for Refund Adjudication");
            subbillingDBValidationPage.verifySystemOptionForCheckSettlementInDatabase(selectedoption, mop, SubBillingPortalPages.sbClient);
        }
    }

    @Then("^I verify Settlement Initiated option in DB as \"([^\"]*)\" for MOP as \"([^\"]*)\"$")
    public void i_verify_SettlementInitiated_system_option_in_database( String selectedoption, String mop) throws Throwable{
        if(SubBillingPortalPages.isRecordPresent == true) {
            System.out.println("\nI verify Settlement Initiated option in Database as " + selectedoption + " for Refund Adjudication");
            subbillingDBValidationPage.verifySystemOptionForSettlementInitiatedInDatabase(selectedoption, mop, SubBillingPortalPages.sbClient);
        }
    }

    @Then("^I verify Settlement InProcess option in DB as \"([^\"]*)\" for MOP as \"([^\"]*)\"$")
    public void i_verify_SettlementInProcess_system_option_in_database( String selectedoption, String mop) throws Throwable {
        if (SubBillingPortalPages.isRecordPresent == true) {
            System.out.println("\nI verify Settlement InProcess option in Database as " + selectedoption + " for Refund Adjudication");
            subbillingDBValidationPage.verifySystemOptionForSettlementInProcessInDatabase(selectedoption, mop, SubBillingPortalPages.sbClient);
        }
    }

    @Then("^I verify Check Refund option in DB as \"([^\"]*)\" for MOP as \"([^\"]*)\"$")
    public void i_verify_CheckRefund_system_option_in_database( String selectedoption, String mop) throws Throwable {
        if (SubBillingPortalPages.isRecordPresent == true) {
            System.out.println("\nI verify Check Refund option in Database as " + selectedoption + " for Refund Adjudication");
            subbillingDBValidationPage.verifySystemOptionForCheckRefundInDatabase(selectedoption, mop, SubBillingPortalPages.sbClient);
        }
    }

    @Then("^I verify Refund Initiated option in DB as \"([^\"]*)\" for MOP as \"([^\"]*)\"$")
    public void i_verify_RefundInitiated_system_option_in_database( String selectedoption, String mop) throws Throwable {
        if (SubBillingPortalPages.isRecordPresent == true) {
            System.out.println("\nI verify Refund Initiated option in Database as " + selectedoption + " for Refund Adjudication");
            subbillingDBValidationPage.verifySystemOptionForRefundInitiatedInDatabase(selectedoption, mop, SubBillingPortalPages.sbClient);
        }
    }

    @Then("^I verify Refund InProcess option in DB as \"([^\"]*)\" for MOP as \"([^\"]*)\"$")
    public void i_verify_RefundInProcess_system_option_in_database( String selectedoption, String mop) throws Throwable {
        if (SubBillingPortalPages.isRecordPresent == true) {
            System.out.println("\nI verify Refund InProcess option in Database as " + selectedoption + " for Refund Adjudication");
            subbillingDBValidationPage.verifySystemOptionForRefundInProcessInDatabase(selectedoption, mop, SubBillingPortalPages.sbClient);
        }
    }

    @Then("^I verify Check Chargeback option in DB as \"([^\"]*)\" for MOP as \"([^\"]*)\"$")
    public void i_verify_CheckChargeback_system_option_in_database( String selectedoption, String mop) throws Throwable {
        if (SubBillingPortalPages.isRecordPresent == true) {
            System.out.println("\nI verify Check Chargeback option in Database as " + selectedoption + " for Refund Adjudication");
            subbillingDBValidationPage.verifySystemOptionForCheckChargebackInDatabase(selectedoption, mop, SubBillingPortalPages.sbClient);
        }
    }

    @Then("^I verify Chargeback Initiated option in DB as \"([^\"]*)\" for MOP as \"([^\"]*)\"$")
    public void i_verify_ChargebackInitiated_system_option_in_database(String selectedoption, String mop) throws Throwable {
        if (SubBillingPortalPages.isRecordPresent == true) {
            System.out.println("\nI verify Check Chargeback option in Database as " + selectedoption + " for Refund Adjudication");
            subbillingDBValidationPage.verifySystemOptionForChargebackInitiatedInDatabase(selectedoption, mop, SubBillingPortalPages.sbClient);
        }
        // Reset flag value for next record
        SubBillingPortalPages.isRecordPresent = true;
    }


    @Then("^I get the Intent details from Portal and verify into Database for \"([^\"]*)\"$")
    public void verifyDataInBasics(String transcationType)throws Throwable{
        System.out.println("I get the Intent details from Portal and verify into Database");
        subbillingDBValidationPage.verifyPortalData(transcationType);
    }

    @Then("^I verify updated \"([^\"]*)\" in database$")
    public void i_verify_updated_portal_data_in_database(String data) throws Throwable{
        System.out.println("I verify updated "+data+" in database");
        subBillingPortalPages.getPortalIntentID();
        subbillingDBValidationPage.verifyupdatedportalDataInDB(data);

    }

}

