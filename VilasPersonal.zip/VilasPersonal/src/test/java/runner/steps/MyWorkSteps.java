package runner.steps;


import com.asurion.pages.MyWorkPage;
import com.asurion.pages.ThreeUKSwappedImeiPage;
import com.asurion.qa.errorReporting.ErrorReporter;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;


public class MyWorkSteps {

    private MyWorkPage myWorkPage;
    ThreeUKSwappedImeiPage threeUKSwappedImeiPage;

    public MyWorkSteps() {
        myWorkPage = new MyWorkPage();
        threeUKSwappedImeiPage = new ThreeUKSwappedImeiPage();
    }

    @And("^I search no enrollment for approval$")
    public void I_search_no_enrollment_for_approval() throws Exception {
        System.out.println("I search no enrollment for approval");
        myWorkPage.searchNoEnrollmentForApproval();
    }

    @And("^I search customer case hold for approval$")
    public void I_search_customer_case_hold_for_approval() throws Exception {
        System.out.println("I search customer case hold for approval");
        myWorkPage.searchHoldForApproval();
    }

    @And("^I approve refund from workbasket with reasons (.+)")
    public void I_approve_refund_from_workbasket_reasons(String reasons) throws Exception {
        System.out.println("I approve refund from workbasket with reasons " + reasons);
        myWorkPage.approveRefundFromWorkBasket(reasons);
    }

    @And("^I continue hold process action with \"([^\"]*)\"$")
    public void I_continue_hold_process_action(String sHoldAction) throws Exception {
        System.out.println("I continue hold process action with " + sHoldAction);
        myWorkPage.holdProcessAction(sHoldAction);
    }

    @And("^I select release the hold resolution \"([^\"]*)\" and reason \"([^\"]*)\"$")
    public void I_select_release_hold_resolution_and_reason(String resolution, String reason) throws Exception {
        System.out.println("I select release the hold resolution " + resolution + " and reason " + reason);
        myWorkPage.releaseHoldResolutionReason(resolution, reason);
    }

    @And("^I continue the release hold process$")
    public void Continue_release_hold_process() throws Exception {
        System.out.println("I continue the release hold process");
        myWorkPage.continueChargeProcess();
    }

    @And("^I Create Outbound Call$")
    public void Create_Outbound_Call() throws Exception {
        System.out.println("I Create Outbound Call");
        myWorkPage.CreateOutboundCall();
    }


    @And("^I redirect the \"([^\"]*)\" from action tab$")
    public void resume_Incident_From_ActionTab(String sType) throws Exception {
        System.out.println(" redirect the " + sType + " from action tab");
        myWorkPage.resumeIncidentFromActionTab(sType);
    }

    @And("^I verify the \"([^\"]*)\" agreement status is \"([^\"]*)\"$")
    public void verify_agreement_status(String statusNo, String status) throws Exception {
        System.out.println("I verify the " + statusNo + " agreement status is " + status);
        myWorkPage.verifyAgreementStatus(statusNo, status);
    }

    @And("^I verify agreement status in database$")
    public void verify_agreement_status_in_Database() throws Exception {
        System.out.println("I verify agreement status in database");
        myWorkPage.verifyAgreementStatusInDatabase();
    }

    @Then("^I update the asset start date (.+) days back$")
    public void update_Start_date(String iDays) throws Exception {
        System.out.println("I update the asset start date " + iDays + " days back");
        myWorkPage.update_Start_date(iDays);

    }

    @And("^I update the asset start date (.+) days back from current date$")
    public void update_Start_dt(String iDays) throws Exception {
        System.out.println("I update the asset start date " + iDays + " days back from current date");
        myWorkPage.update_Start_dt(iDays);
    }

    @Then("^I verify (.+) hold should not triggered in (.+) database using rulename (.+)$")
    public void verify_Hold_not_in_QABlokus_Database(String sHoldType, String Database, String sRuleName) throws Exception {
        System.out.println("");
        myWorkPage.verifyHoldRuleNotTriggeredQABlokusDatabase(sHoldType, Database, sRuleName);
    }

    @Then("^I verify (.+) hold triggered in (.+) database with rulename (.+)$")
    public void verify_Hold_in_QABlokus_Database(String sHoldType, String Database, String sRuleName) throws Exception {
        System.out.println("");
        myWorkPage.verifyHoldQABlokusDatabase(sHoldType, Database, sRuleName.trim());

    }

    @Then("^I verify (.+) rulename in (.+) table with (.+) database")
    public void verify_rulenameQABacking_database(String sRulename, String sTableName, String sDatabase) throws Exception {
        System.out.println("");
        myWorkPage.verifyRulenameQABackingDatabase(sRulename, sTableName, sDatabase.trim());

    }


    @Then("^I verify (.+) eventname in (.+) table with (.+) database")
    public void verify_eventNameQABacking_database(String sEventname, String sTableName, String sDatabase) throws Exception {
        System.out.println("");
        myWorkPage.verifyRuleEventQABackingDatabase(sEventname, sTableName, sDatabase.trim());
    }

    @And("^I verify the eventname \"([^\"]*)\" received in \"([^\"]*)\" table from IM$")
    public void verify_eventNameQABacking_db(String sEventname, String sTableName) throws Exception {
        System.out.println("I verify the eventname  received in table from IM");
        myWorkPage.verifyRuleEventQABackingDb(sEventname, sTableName);
    }

    @And("I verify (.+) event in (.+) db$")
    public void verify_eventNameQABackingDB(String sEventname, String sDBname) throws Exception {
        System.out.println("I verify " + sEventname + " event in " + sDBname + " db");
       // myWorkPage.verifyEventQABackingDb(sEventname, sDBname);
    }

    @Then("^I update the enrollment date (.+) days back$")
    public void update_enrollment_date(String iDays) throws Exception {
        System.out.println("I update the enrollment date " + iDays + " days back");
        myWorkPage.update_enrollment_date(iDays);

    }

    @Then("^I verify case number should be same for reship$")
    public void casenumber_same_for_reship() throws Exception {
        System.out.println("I verify case number should be same for reship");
        myWorkPage.verifyCasenumberSameReship();

    }

    @Then("^I insert a record into Account Master Table$")
    public void insertReord_into_AccountMasterTable() throws Exception {
        System.out.println("I insert a record into Account Master Table");
        myWorkPage.insertRecordIntoAccountMasterTable();
    }

    @And("^I search customer case hold for approval using MDN$")
    public void I_search_customer_case_hold_for_approval_uding_mdn() throws Exception {
        System.out.println("I search customer case hold for approval using MDN");
        myWorkPage.searchHoldForApprovalUsing_MDN();
    }

    @And("^I search customercase number for PNR using MDN$")
    public void I_search_customer_case_for_PNRclaim_uding_mdn() throws Exception {
        System.out.println("I search customercase number for PNR using MDN");
        myWorkPage.searchCaseNumberUsing_MDN();
    }

    @And("^I search customer case hold using state and casenumber$")
    public void I_search_customer_case_hold_using_state_and_casenumber() throws Exception {
        System.out.println("I search customer case hold using state and casenumber");
        myWorkPage.searchHoldUsingStageAndCaseNumber();
    }

    @And("^Verification of (.+) in backend for (.+) insurance$")
    public void Verification_insurance(String clientOfferName, String insurance) throws Exception {
        System.out.println("Verification of " + clientOfferName + " in backend for " + insurance + " insurance");
        myWorkPage.Verification_of_insurance(clientOfferName, insurance);
    }

    @And("^I update the asset table with details is_negative=(.+),is_Exception=(.+),isRiskCategoryLookUPID=(.+) and activefromdate (.+) days back,activeTodate (.+) days back for (.+) client")
    public void update_the_assetWith_Details_activefromdate_activefromdate(String isNegative, String isException, String isRiskCategoryLookUPID, String activefromdate, String activeTodate, String Client) throws Exception {
        System.out.println("I update the asset table with details is_negative=" + isNegative);
        myWorkPage.updateAssetTableWithDetailsActivefromdateActivefromdate(isNegative, isException, isRiskCategoryLookUPID, activefromdate, activeTodate, Client);
    }

    @And("^I update the asset table with details (.+) ,(.+) for (.+) client$")
    public void update_the_assetWith_Details_isNegativeORisExc_isRiskCategoryLookUPID(String isNegativeORisExc, String isRiskCategoryLookUPID, String client) throws Exception {
        System.out.println("I update the asset table with details " + isNegativeORisExc);
        myWorkPage.updateAssetTableWithDetailsisNegativeORisExcisRiskCategoryLookUPID(isNegativeORisExc, isRiskCategoryLookUPID, client);
    }

    @And("^I store asset details$")
    public void store_Assert_details() throws Exception {
        System.out.println("I store asset details");
        myWorkPage.storeAssertDetails();
    }

    @And("^I update the asset table (.+) ,(.+) for (.+) client using asset catalog$")
    public void I_update_the_asset_table_using_asset_catalog(String isNegativeORisExc, String isRiskCategoryLookUPID, String client) throws Exception {
        System.out.println("I update the asset table ");
        myWorkPage.updateAssetTableUsingAssetCatalog(isNegativeORisExc, isRiskCategoryLookUPID, client);
    }

    @And("^I search no enrollment for approval EU$")
    public void I_search_no_enrollment_for_approval_EU() {
        System.out.println("I search no enrollment for approval EU");
        myWorkPage.searchNoEnrollmentForApprovalEU();
    }

    @And("^I select view queue for \"([^\"]*)\" EU$")
    public void I_select_View_Queue_for(String types) throws Throwable {
        System.out.println("I select view queue for " + types + " EU");
        myWorkPage.selectViewQueueEU(types);
    }

    @And("^I select Cancellation Action reason as \"([^\"]*)\" and Resolution Reason as \"([^\"]*)\" EU$")
    public void I_select_Cancellation_Action_reason_as_and_Resolution_Reason_as_EU(String cancelReason, String resolutionReason) throws Throwable {
        System.out.println("I select Cancellation Action reason as " + cancelReason);
        myWorkPage.cancellationActionReasonEU(cancelReason, resolutionReason);
    }

    @And("^I click on \"([^\"]*)\" status row$")
    public void I_click_on_status_row(String status) throws Throwable {
        System.out.println("I click on " + status + " status row");
        myWorkPage.clickOnActiveStatusRow(status);

    }

    @And("^I search \"([^\"]*)\" hold for approval$")
    public void I_search_hold_for_approval(String sHoldType) throws Throwable {
        System.out.println("I search " + sHoldType + " hold for approval");

        myWorkPage.searchHoldAndApproval(sHoldType);
    }

    @And("^I select resolution type \"([^\"]*)\" and triage option \"([^\"]*)\" and reason \"([^\"]*)\"$")
    public void I_select_resolution_type_and_triage_option_and_reason(String resolution, String triageOption, String reason) throws Throwable {
        System.out.println("I select resolution type " + resolution + " and triage option " + triageOption + " and reason " + reason);
        myWorkPage.releaseHoldResolutionWithTriageOption(resolution, triageOption, reason);
    }


    @And("^I approve refund from finance workqueue with reasons (.+)")
    public void I_approve_refund_from_workqueue_resons(String reasons) throws Exception {
        System.out.println("I approve refund from finance workqueue with reasons " + reasons);
        myWorkPage.approveRefundFromFinanceWorkQueue(reasons);
    }


    @And("^I continue the release hold process action with \"([^\"]*)\"$")
    public void I_continue_the_release_hold_process_action_with(String sHoldAction) throws Throwable {
        System.out.println("I continue the release hold process action with " + sHoldAction);
        myWorkPage.holdReleaseProcessAction(sHoldAction);

    }

    @And("^velocity for (.+) in D_Velocity table should be (.+)")
    public void check_velocity_in_D_VelocityTable(String sVelocityType, String velocityCount) throws Throwable {
        System.out.println("velocity for " + sVelocityType + " in D_Velocity table should be " + velocityCount);
        myWorkPage.checkVelocityD_VelocityTable(sVelocityType, velocityCount);
    }

    @And("^I select the action as \"([^\"]*)\"$")
    public void selectActionAndContinue(String actionType) throws Throwable {
        System.out.println("I select the action as " + actionType);
        myWorkPage.selectActionType(actionType);
    }

    @And("^I select the sub action as \"([^\"]*)\"$")
    public void selectSubActionAndContinue(String actionType) throws Throwable {
        System.out.println("I select the sub action as " + actionType);
        myWorkPage.selectSubActionType(actionType);
    }

    @And("^And I select the PNR entry from workbasket$")
    public void selectPNRCaseNumber() throws Throwable {
        System.out.println("And I select the PNR entry from workbasket");
    }

    @And("^I continue with the charge$")
    public void continueCharge() throws Exception {
        System.out.println("I continue with the charge");
        myWorkPage.continueChargeProcess();
    }

    @And("^I continued the flow$")
    public void continuedFlow() throws Exception {
        System.out.println("I continue with the charge");
        myWorkPage.continuedFlow();
    }

    @And("^I verify that charge process is completed$")
    public void continueSNRProcess() throws Exception {
        System.out.println("I verify that charge process is completed");
        myWorkPage.continuePayment();
    }

    @And("^I approve ded refund from workbasket with reasons (.+)")
    public void I_approve_ded_refund_from_workbasket_reasons(String reasons) throws Exception {
        System.out.println("I approve ded refund from workbasket with reasons " + reasons);
        myWorkPage.approveDEDRefundFromFinanceWorkQueue(reasons);
    }

    @And("^I navigate to \"([^\"]*)\" workqueue and search using casenumber$")
    public void I_navigate_to_Return_Management_workqueue(String option) throws Exception {
        System.out.println("I navigate to EU-RMA workqueue and search using casenumber");
            myWorkPage.viewQueueFor(option);
    }

    @And("^I select the action as (.+) and continue$")
    public void I_select_the_action_as_Charge_Fee_and_continue(String action) throws Exception {
        System.out.println("I select the action Charge Fee and continue");
        //myWorkPage.selectReasonFromActionDropdown(action);
        myWorkPage.selectActionType(action);
        myWorkPage.continueChargeProcess();
        myWorkPage.continuePayment();
    }

    @And("^I verify the charge payment is successful on UI$")
    public void Verify_the_charge_payment_is_successful() throws Exception {
        System.out.println("I verify the charge payment is successful on UI");
            myWorkPage.verifyChargeFeePaymentSuccessfulONUI();
    }
}
