package runner.steps;

import com.asurion.pages.HoldPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.junit.Assert;

public class HoldPageSteps {
    private HoldPage holdPage;

    public HoldPageSteps() {
        holdPage = new HoldPage();

    }

    @And("^I create the hold \"([^\"]*)\"$")
    public void I_create_the_hold(String holdType) throws Exception {
        System.out.println("I create the hold " + holdType);
        holdPage.createHold(holdType);
    }

    @And("^I add note \"([^\"]*)\" and note type \"([^\"]*)\" to the hold$")
    public void I_note_to_the_hold(String noteText, String noteType) throws Exception {
        System.out.println("I add note " + noteText);
        holdPage.addnoteToHold(noteText, noteType);
    }

    @And("^I submit the hold$")
    public void I_submit_the_hold() throws Exception {
        System.out.println("I submit the hold");
        holdPage.submitHold();
    }

    @And("^I release the holds if exist and resume incident$")
    public void I_release_holds_from_screen_if_exist() throws Exception {
        System.out.println("I release the holds if exist and resume incident");
        holdPage.releaseHoldAndResume();
    }

    @And("^verify \"([^\"]*)\" hold is triggered$")
    public void verify_Hold_triggered_or_not(String holdType) throws Exception {
        System.out.println("verify " + holdType + " hold is triggered");
        holdPage.checkHoldType(holdType);
    }

    @And("^I release the \"([^\"]*)\" hold type and \"([^\"]*)\" sub type$")
    public void release_Hold_With_SubType(String holdType, String subType) throws Exception {
        System.out.println("I release the " + holdType + " hold type and " + subType + " sub type");
        holdPage.releaseHoldWithSubType(holdType, subType);
    }

    @And("^I verify IAV message is displayed$")
    public void verify_IAV_message_is_displayed() throws Exception {
        System.out.println("I verify IAV message is displayed");
        String message = holdPage.iavMessage();
        Assert.assertTrue("Realtime Verification Currently verification", message.contains("Realtime Verification"));
    }

    @And("^I release the hold type \"([^\"]*)\" and sub type \"([^\"]*)\"$")
    public void release_hold_with_SubTypehold(String holdType, String subType) throws Exception {
        System.out.println("I release the hold type " + holdType + " and sub type " + subType);
        holdPage.releaseHoldWithSubTypehold(holdType, subType);
    }

    @Then("^I verify \"([^\"]*)\" hold should not triggered$")
    public void verify_Hold_not_triggered(String holdType) throws Exception {
        System.out.println("I verify " + holdType + " hold should not triggered");
        holdPage.checkHoldNotApply(holdType);
    }

    @Then("^I override next action reason \"([^\"]*)\"$")
    public void override_Next_action_reason(String reason) throws Exception {
        System.out.println("I override next action reason " + reason);
        holdPage.overridNextActionReason(reason);
    }

    @Then("^I release the \"([^\"]*)\" holds and cancel incident using (.+) user role$")
    public void release_hold_and_cancel_incident(String holdType, String user) throws Exception {
        System.out.println("I release the " + holdType + " holds and cancel incident using ");
        holdPage.release_holdAndCancelIncidentFornTelos(holdType, user);
    }

    @Then("^I release the hold from UI if exists and resume incident$")
    public void release_hold_from_UI_exists_resume_incident() throws Exception {
        System.out.println("I release the hold from UI if exists and resume incident");
        holdPage.release_HoldFromUI();
    }

    @Then("^I select create outbound call$")
    public void select_create_outbound_call() throws Exception {
        System.out.println("I select create outbound call");
        holdPage.selectCreateOutboundCall();
    }

    @Given("^I check if Risk is ON$")
    public void I_check_if_Risk_is_ON() throws Throwable {
        System.out.println("I check if Risk is ON");
        // Express the Regexp above with the code you wish you had
        //        HoldPage.checkRiskisON();
        //    }
        //    @And("^I check if rulename \"([^\"]*)\" is \"([^\"]*)\"$")
        //    public void I_check_if_rulename_is_ON(String holdType, String holdStatus) throws Exception, SQLException, ClassNotFoundException {
        // Express the Regexp above with the code you wish you had
        //        HoldPage.checkRuleisON(holdType, holdStatus);
        //    }
        // }
    }
}