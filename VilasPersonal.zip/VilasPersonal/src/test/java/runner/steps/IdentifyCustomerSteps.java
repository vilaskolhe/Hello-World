package runner.steps;


import com.asurion.pages.IdentifyCustomerPage;
import com.asurion.util.CustomerDetails;
import cucumber.api.java.en.And;
import com.asurion.util.Generic;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.common.core.util.CommonUtilities;

public class IdentifyCustomerSteps {
    private IdentifyCustomerPage identifyCustomerPage;

    public IdentifyCustomerSteps() {
        identifyCustomerPage = new IdentifyCustomerPage();

    }

    @And("^I search using an MDN$")
    public void I_search_using_an_MDN() throws Exception {
        System.out.println("I search using an MDN");
       identifyCustomerPage.searchUsingMDN(CustomerDetails.customerData.get("MDN"));
       //identifyCustomerPage.searchUsingMDN("7100385623");
    }

    @And("^I search claim using MDN \"([^\"]*)\"$")
    public void I_search_claim_using_MDN(String mdn) throws Exception {
        System.out.println("I search claim using as MDN "+ mdn);
        identifyCustomerPage.searchMDN(mdn);
    }


    @And("^I continue the claim process$")
    public void I_continue_the_claim_process() throws Exception {
        System.out.println("I continue the claim process");
        identifyCustomerPage.continueClaim();
    }

    @And("^I verify caller details$")
    public void iVerifyCallerDetails() throws Throwable {
        System.out.println("I verify caller details");
        identifyCustomerPage.verifyCallerNameAndAddress();
    }

    @And("^I verify the caller \"([^\"]*)\"$")
    public void I_verify_the_caller(String callerData) throws Throwable{
        System.out.println("I verify caller details");
        String testType="valid";
        identifyCustomerPage.verifyCaller(callerData, testType);
    }

    @And("^I search enrolled MDN for 3UK")
    public void Select_search_Enrolled_MDN() throws Throwable {
        System.out.println("I search enrolled MDN for 3UK");
        identifyCustomerPage.selectClientAndCountryAndSearchEnrolledMDNEU("", "3UK");
    }

    @And("^I wait and check for the Service Request Status to be Complete on PEGA UI EU")
    public void I_wait_and_check_for_the_shipping_status_change_on_PEGA_UI_Nth_reship_EU() throws Throwable {
        System.out.println("I wait and check for the Service Request Status to be Complete on PEGA UI EU");
            String warehouse = "RNL";
            if (ApplicationConfiguration.getClient().equalsIgnoreCase("3uk")) warehouse = "RUK";
            CommonUtilities.waitTime(10);
            Generic.getDetailsFromDAXDB("SALESORDERNUMBER", Generic.getValuesFromGlobals("CASENUMBER"), warehouse);
            Generic.getDetailsFromDAXDB("TRACKINGNUMBER", Generic.getValuesFromGlobals("CASENUMBER"), warehouse);
            identifyCustomerPage.waitAndCheckForServiceRequestStatusComplete_EU();

    }

    @And("^I wait for (\\d+) minutes for charge entry$")
    public void i_wait_fordelay_capture_charge(int minutes) throws Throwable{
        System.out.println("\n I wait for " +minutes+" minutes for delay capture charge");
        int count = minutes;
        for(int i = 0; i<count; i++){
            Generic.waitForGivenMinute(1);
            identifyCustomerPage.waitAndCheckForRequestToBeCompleted();
        }
        System.out.println("Wait for "+ minutes+ " is over.");
    }
}