package runner.steps;

import com.asurion.qa.errorReporting.ErrorReporter;
import com.asurion.pages.ThreeUKSwappedImeiPage;
import cucumber.api.java.en.And;
import com.asurion.util.Generic;
/**
 * Created by NANDINI.MUJUMDAR on 6/22/2017.
 */
public class ThreeUKSwappedImeiSteps {
    private ThreeUKSwappedImeiPage threeUKSwappedImeiPage;
    public ThreeUKSwappedImeiSteps() {threeUKSwappedImeiPage = new ThreeUKSwappedImeiPage();
    }

    @And("^I get default data for delivery confirm 3UK Enrollment$")
    public void I_get_default_data__delivery_confirm_3UK() throws Exception {
        System.out.println("\nI get default data for delivery confirm 3UK Enrollment");
            threeUKSwappedImeiPage.get3UKDefaultDataDeliveryConfirm();
    }

    @And("^I initialize data for delivery confirm 3UK$")
    public void I_initialize_data_delivery_confirm_3UK() throws Exception {
        System.out.println("\n I initialize data for delivery confirm 3UK ");
            threeUKSwappedImeiPage.initializeFileDataDeliveryConfirm3UK();
    }

    @And("^I create shipping status file for delivery confirm 3UK$")
    public void I_delivery_confirm_KPN() throws Exception {
        System.out.println("\nI create shipping status file for delivery confirm 3UK");
            threeUKSwappedImeiPage.createFilesDeliveryConfirm3UK("DeliveryConfirm");
            Generic.verifyStatusInReplacedAssetTable(Generic.getValuesFromGlobals("MDN"), "NEW");
//            Generic.run3UKShipmentStatusJob();
            Generic.verifyTrackingNumberRecordPresentInShipmentTransactionDetailTableDAL(Generic.getValuesFromGlobals("TRACKINGNUMBER"), "COMPLETE");
    }

    @And("^I process DPD Delivery confirmation file for 3UK$")
    public void I_DPD_delivery_confirm_3UK() throws Exception {
        System.out.println("\nI process DPD Delivery confirmation file for 3UK");
            threeUKSwappedImeiPage.createFilesDeliveryConfirm3UK("DeliveryConfirm");
            Generic.runDPDDeliveryConfirmationJob3UK();
//        Generic.verifyTrackingNumberRecordPresentInShipmentTransactionDetailTableDAL(Generic.getValuesFromGlobals("TRACKINGNUMBER"),"COMPLETE");
    }

    @And("^I set data \"([^\"]*)\" and \"([^\"]*)\" into hashmap for DPD Confirmation 3UK$")
    public void I_set_data_int_hashmap_for_dpd_confrmation3UK(String param, String value) throws Exception {
            // threeUKSwappedImeiPage.updateDifferentDataForEnrollment(param, value);
    }

}
