package runner.steps;

import com.asurion.pages.EndCallPage;
import cucumber.api.java.en.And;

public class EndCallPageSteps {

    private EndCallPage endCallPage;

    public EndCallPageSteps() {
        endCallPage = new EndCallPage();
    }


    @And("^I end the call with reason \"([^\"]*)\" and endcall result \"([^\"]*)\"$")
    public void I_end_the_call_with_reason_and_endcallresult(String reason, String endCallResult) throws Exception {
        System.out.println("I end the call with reason " + reason);
        endCallPage.endCall(reason, endCallResult);
    }

    @And("^I end the call with intent \"([^\"]*)\" endcall area \"([^\"]*)\" and outcome \"([^\"]*)\"")
    public void I_end_the_call_with_intent_area_and_outcome(String reason, String endCallResult, String outcome) throws Exception {
        System.out.println("I end the call with intent " + reason);
        endCallPage.endCallWithIntentAreaAndOutcome(reason, endCallResult, outcome);
    }

    //3uk
    @And("^I end the call with reason Claim and reason result Submitted claim EU$")
    public void I_end_the_call_with_reason_and_endcallresult_EU() {
        System.out.println("I end the call with reason Claim and reason result Submitted claim EU");
        endCallPage.closeCallButton();
    }

    @And("^I verify localized objects on End Call EU$")
    public void I_verify_localized_objects_on_End_Call_EU() {
        System.out.println("I verify localized objects on End Call EU");
        endCallPage.verifyEndCallLocObjectsEU();
    }


    @And("^I end the call with reason \"([^\"]*)\" and endcall result \"([^\"]*)\" EU$")
    public void I_end_the_call_with_reason_and_endcall_result_EU(String reason, String endCallResult) throws Throwable {
        System.out.println("I end the call with reason " + reason);
        endCallPage.selectEndCallEU();
        endCallPage.endCallWithReasonEU(reason, endCallResult);
        endCallPage.selectEndCallConfirmationButtonEU();
    }

    @And("^I close the End Call window EU$")
    public void iCloseTheEndCallWindowEU() throws Throwable {
        System.out.println("I close the End Call window EU");
        endCallPage.clickCancelEndCallEU();
    }

}