package runner.steps;

import com.asurion.pages.BasePage;
import com.asurion.pages.SubBillingPortalPages;
import com.asurion.util.ApplicationConfiguration;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by vilas.kolhe on 5/3/2017.
 */
public class SubBillingPortalSteps {

    private SubBillingPortalPages subBillingPortalPages; //= new SubBillingPortalPages();

    public SubBillingPortalSteps() {
        subBillingPortalPages = new SubBillingPortalPages();
    }


//    @Given("^I login as the automation tester in SB portal$")
//    public void i_login_as_the_automation_tester_in_SB_portal()  {
//        System.out.println("ABC");
//    }
//
//    @When("^I click on \"([^\"]*)\" on home page of SB portal$")
//    public void i_click_on_on_home_page_of_SB_portal(String arg1)  {
//    }
//
//    @Then("^I see, Browse button$")
//    public void i_see_Browse_button()  {
//    }
//
//    @Then("^I select file type \"([^\"]*)\" radio button$")
//    public void i_select_file_type_radio_button(String arg1)  {
//    }
//
//    @Then("^I select \"([^\"]*)\" Operation Type radio button$")
//    public void i_select_Operation_Type_radio_button(String arg1)  {
//    }
//
//    @Then("^I click Browse button to upload the file$")
//    public void i_click_Browse_button_to_upload_the_file()  {
//    }
//
//    @Then("^I select the file from \"([^\"]*)\" Location$")
//    public void i_select_the_file_from_Location(String arg1)  {
//    }
//
//    @Then("^I click on Upload File button$")
//    public void click_on_Upload_File_button()  {
//    }


    @Given("^I login as the automation tester in SB portal$")
    public void i_login_as_the_automation_tester_in_SB_portal() {
        System.out.println("\nI login to SB Portal");
        subBillingPortalPages.navigateToSBPortal();
    }

    @When("^I click on \"([^\"]*)\" on home page of SB portal$")
    public void i_click_on_on_home_page_of_SB_portal(String basicAmendment) {
        System.out.println("\nI click on " + basicAmendment + " on home page");
        subBillingPortalPages.selectBasicsAmendmentFromHomePage(basicAmendment);
    }

    @Then("^I see, Browse button$")
    public void i_see_Upload_File_Tab() {
        subBillingPortalPages.browseButtonIsVisible();
    }

    @Then("^I select file type \"([^\"]*)\" radio button$")
    public void i_select_file_type_radio_button(String fileType) {
        subBillingPortalPages.selectFileType(fileType);
    }

    @Then("^I select \"([^\"]*)\" Operation Type radio button$")
    public void i_select_Operation_Type_radio_button(String operationType) {
        subBillingPortalPages.selectOperationType(operationType);
    }

    @Then("^I click Browse button to upload the file$")
    public void i_click_Browse_button_to_upload_the_file() {
        subBillingPortalPages.clickOnBrowseButton();
    }

    @Then("^I select the file from \"([^\"]*)\" location$")
    public void i_select_the_file_from_window_popup(String filePath) {
        subBillingPortalPages.pickTheFileFromLocation(filePath);
    }

    @Then("^I see file \"([^\"]*)\" is successfully uploaded$")
    public void i_see_file_is_successfully_uploaded(String fileName) {
        subBillingPortalPages.checkFileUploaded(fileName);
    }

    @Then("^I click on Upload File button$")
    public void click_on_Upload_File_button() {
        subBillingPortalPages.clickOnIntentChargeUploadButton();
    }

    @Then("^I see, intent charge resubmit page$")
    public void i_see_intent_charge_resubmit_page() {
        subBillingPortalPages.verifyIntentChargeResubmitPageIsDisplayed();
    }

    @Then("^I select Method Of Payment as \"([^\"]*)\"$")
    public void i_select_Method_Of_Payment_as(String paymentMethod) {
        subBillingPortalPages.selectMethodOfPayment(paymentMethod);
    }

    @Then("^I select Client as \"([^\"]*)\"$")
    public void i_select_Client_as(String client) {
        subBillingPortalPages.selectClient(client);
    }

    @Then("^I select the Record Type as \"([^\"]*)\"$")
    public void i_select_the_Record_Type_as(String recordType) {
        subBillingPortalPages.selectRecordType(recordType);
    }

    @Then("^I select the Start Date as \"([^\"]*)\"$")
    public void i_select_the_Start_Date_as(String date) {
        subBillingPortalPages.enterStartDate(date);
    }

    @Then("^I select the End Date as \"([^\"]*)\"$")
    public void i_select_the_End_Date_as(String date) {
        subBillingPortalPages.enterEndDate(date);
    }

    @Then("^I click Search button to search the record$")
    public void i_click_Search_button_to_search_the_record() {
        subBillingPortalPages.clickOnSearchonSBPortal();
    }

    @Then("^I see resubmit table is displayed$")
    public void i_see_resubmit_table_is_displayed() {
        subBillingPortalPages.verifyResubmitTableisDisplayed();
    }

    @Given("^I prepare excel at \"([^\"]*)\"$")
    public void i_prepare_excel(String path, Map<String, String> dataTable) {
        subBillingPortalPages.setCellDataNew(path, dataTable);
    }

    @When("^I updated the excel file at \"([^\"]*)\"$")
    public void i_updated_the_excel_file_at(String filePath) {
    }

    @When("^I select all transactions with \"([^\"]*)\" status$")
    public void i_select_all_transactions_with_status(String statusToSelect) {
        subBillingPortalPages.selectTransactionToSendToDAX(statusToSelect);
    }

    @When("^I click on Resubmit To Dax button$")
    public void i_click_on_Resubmit_To_Dax_button() {
    }

    @Then("^I compared below values of uploaded excel with database$")
    public void i_compared_below_values_of_uploaded_excel_with_database(Map<String, String> DataMap) throws Exception {
        subBillingPortalPages.compareExcelDataWithDB(DataMap);
    }

    @And("^I select the Type as \"([^\"]*)\"$")
    public void i_select_the_type(String type) throws Exception {
        System.out.println("\nI select the Type as " + type);
        subBillingPortalPages.systemOption_selectType(type);
    }

    @And("^I select the Client as \"([^\"]*)\"$")
    public void i_select_the_client_as(String client) throws Exception {
        System.out.println("\nI select the Client as " + client);
        subBillingPortalPages.systemOption_selectClient(client);
    }

    @And("^I select the Client$")
    public void i_select_the_client() throws Exception {
        String client;
        System.out.println("\nI select the Client as " + ApplicationConfiguration.getClient());
        if (ApplicationConfiguration.getClient().equalsIgnoreCase("Freedom")) {
            client = "Freedom Mobile";
        } else {
            client = ApplicationConfiguration.getClient();
        }
        subBillingPortalPages.systemOption_selectClient(client);
    }

    @And("^I select the Payement Method as \"([^\"]*)\"$")
    public void i_select_payment_method(String mop) throws Exception {
        System.out.println("\nI select the Payement Method as " + mop);
        subBillingPortalPages.systemOption_selectMOP(mop);
    }

    @And("^I select Category as \"([^\"]*)\"$")
    public void i_select_category(String category) throws Exception {
        System.out.println("\nI select Category as " + category);
        subBillingPortalPages.systemOption_selectCategory(category);
    }

    @Then("^I click on search$")
    public void i_search_the_record() throws Exception {
        System.out.println("\nI click on Search");
        subBillingPortalPages.systemOption_search();
    }

    @And("^I select Aggregate Analysis option as \"([^\"]*)\"$")
    public void i_select_AggregateAnalysis_option(String selectedOption) throws Exception {
        System.out.println("\nI select Aggregate Analysis option as " + selectedOption);
        subBillingPortalPages.setAggregateAnalysis(selectedOption);
    }

    @And("^I select Check Settlement option as \"([^\"]*)\" with \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_select_Check_Settlement_system_option(String selectedOption, String settlementInitiated, String settlementInProcess) throws Exception {
        System.out.println("\nI select Check Settlement option as " + selectedOption + "with " + settlementInitiated + " and " + settlementInProcess);
        subBillingPortalPages.setCheckSettlement(selectedOption, settlementInitiated, settlementInProcess);
    }

    @And("^I select Check Refund option as \"([^\"]*)\" with \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_select_Check_Refund_system_option(String selectedOption, String refundInitiated, String refundInProcess) throws Exception {
        System.out.println("\nI select Check Refund option as " + selectedOption + "with " + refundInitiated + " and " + refundInProcess);
        subBillingPortalPages.setCheckRefund(selectedOption, refundInitiated, refundInProcess);
    }

    @And("^I select Check ChargeBack option as \"([^\"]*)\" with \"([^\"]*)\"$")
    public void i_select_Check_Chargeback_system_option(String selectedOption, String ChrgBckInitiated) throws Exception {
        System.out.println("\nI select Check Chargeback option as " + selectedOption + "with " + ChrgBckInitiated);
        subBillingPortalPages.setCheckChargeBack(selectedOption, ChrgBckInitiated);
    }

    @And("^I click on Save button$")
    public void i_click_on_save_button() throws Exception {
        if (subBillingPortalPages.isRecordPresent == true) {
            System.out.println("\nI click on Save button");
            subBillingPortalPages.clickOnSave();
        } else
            System.out.println("");
    }

    @And("^I verify search result$")
    public void i_verify_search_result() throws Throwable {
        System.out.println("\nI verify search result");
        subBillingPortalPages.searchResult();
    }

    @And("^I select DAX Integration Configuration option as \"([^\"]*)\" and click on Save button$")
    public void i_select_DAX_Integration_Configuration_option(String selectedOption) throws Throwable {
        System.out.println("\n select DAX Integration Configuration option as " + selectedOption + " and click on Save button");
        subBillingPortalPages.setSystemOptionForDAXIntegration(selectedOption);
    }

    @And("^I select Systematic Settlement option as \"([^\"]*)\" and click on Save button$")
    public void i_select_SystematicSettlement_option(String selectedOption) throws Throwable {
        System.out.println("\nI select Systematic Settlement option as " + selectedOption + " and click on Save button");
        subBillingPortalPages.setSystematicSettlement(selectedOption);
    }

    @And("^I select \"([^\"]*)\" option as \"([^\"]*)\"$")
    public void i_select_system_option(String systemOption, String selectedOption) throws Throwable {
        if (SubBillingPortalPages.isRecordPresent == true) {
            System.out.println("\nI select " + systemOption + " option as " + selectedOption);
            subBillingPortalPages.selectGivenSystemOption(systemOption, selectedOption);
        }
    }

    @And("^I verify record on screen for MOP as \"([^\"]*)\"$")
    public void i_verify_record_on_screen(String mop) throws Throwable {
        subBillingPortalPages.verifyRecordIsFoundORNotForGivenClient(mop, SubBillingPortalPages.sbClient);
    }

    @And("^I search for the casenumber$")
    public void i_search_for_the_casenumber() throws Throwable {
        System.out.println("\nI search for the casenumber");
        subBillingPortalPages.searchCaseNumber();
    }

    @And("^I select the IntentReference$")
    public void i_select_intentreference() throws Throwable {
        System.out.println("\nI select the IntentReference");
        subBillingPortalPages.selectIntentRef();
    }

    @And("^I select \"([^\"]*)\" panel$")
    public void i_select_given_panel(String panel) throws Throwable {
        System.out.println("\nI select " + panel + " panel");
        subBillingPortalPages.selectGivenPanel(panel);
    }

    @And("^I click on Edit button$")
    public void i_click_on_edit() throws Throwable {
        System.out.println("\nI click on Edit button");
        subBillingPortalPages.clickOnEditBtn();
    }

    @And("^I update \"([^\"]*)\" to \"([^\"]*)\" and save$")
    public void i_update_porta_data(String columnType, String amount) throws Throwable {
        System.out.println("\nI update "+ " and verify in database");
        subBillingPortalPages.updateGivenData(columnType, amount);
    }
}
