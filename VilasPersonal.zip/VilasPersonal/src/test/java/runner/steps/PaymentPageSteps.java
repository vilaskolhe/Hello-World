package runner.steps;

import com.asurion.pages.*;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.junit.Assert;

public class PaymentPageSteps {

    private PaymentPage creditCardTokenPage;
    private ActionPage actionPage;
    private HomePage homePage;
    private IdentifyCustomerPage identifyCustomerPage;
    private IncidentPathPage incidentPathPage;
    private EndCallPage EndCallPage;


    public PaymentPageSteps() {
        creditCardTokenPage = new PaymentPage();
        actionPage = new ActionPage();
        homePage = new HomePage();
        identifyCustomerPage = new IdentifyCustomerPage();
        incidentPathPage = new IncidentPathPage();
        EndCallPage = new EndCallPage();
    }

    @And("^I enter payment details with credit card number \"([^\"]*)\" and release hold if exist$")
    public void I_enter_the_payment_Detailsand_release_hold_if_exist(String creditCardNumber) throws Exception {
        System.out.println("I enter payment details with credit card number " + creditCardNumber + " and release hold if exist");
        BasePage.sPaymentCard = creditCardNumber;
        creditCardTokenPage.enterThePaymentDetails(creditCardNumber);
    }

    @And("^I enter payment details with Bank Account number \"([^\"]*)\"$")
    public void I_enter_payment_details_with_Bank_Account_number(String bankAccountnumber) throws Throwable {
        System.out.println("I enter payment details with Bank Account number " + bankAccountnumber);
        creditCardTokenPage.enterEcheckPaymentDetails(bankAccountnumber);
    }

    @Then("^I enter payment details with Bank Account number \"([^\"]*)\" and release hold if exist$")
    public void I_enter_payment_details_with_Bank_Account_number_and_release_hold_if_exist(String bankAccountnumber) throws Exception {
        System.out.println("I enter payment details with Bank Account number " + bankAccountnumber + " and release hold if exist");
        creditCardTokenPage.enterEcheckPaymentDetails(bankAccountnumber);
    }

    @Then("^I enter payment details with credit card number \"([^\"]*)\" and SNR fee \"([^\"]*)\" and release hold if exist$")
    public void I_enter_payment_details_with_credit_card_number_and_SNR_fee_and_release_hold_if_exist(String creditCardNumber, String snrFee) throws Exception {
        System.out.println("I enter payment details with credit card number " + creditCardNumber + " and SNR fee " + snrFee + " and release hold if exist");
        creditCardTokenPage.selectSnrFee(snrFee);
        BasePage.sPaymentCard = creditCardNumber;
        creditCardTokenPage.enterThePaymentDetails(creditCardNumber);
       /* if (actionPage.checkHold()) {
            actionPage.releaseHold(CustomerDetails.customerData.get("MDN"));
            actionPage.continueRelasehold();
            incidentPathPage.resumeRelasehold();
            creditCardTokenPage.selectSnrFee(snrFee);
            creditCardTokenPage.enterThePaymentDetails(creditCardNumber);
        }*/
    }

    @Then("^I verify payment type as ISP$")
    public void I_verify_payment_type_as_ISP() throws Exception {
        creditCardTokenPage.selectISPPayment();
    }

    @And("^I select the payment method as BTA$")
    public void I_select_the_payment()throws Exception
    {
        System.out.println("I select the payment mode as BTA");
        creditCardTokenPage.btaPaymentMethod();
    }

    @Then("^I enter payment details with invalid credit card number \"([^\"]*)\"$")
    public void I_enter_payment_details_with_invalid_credit_card_number(String invalid_CreditcardNumber) throws Exception{
        creditCardTokenPage.enterInvalidCreditCardPaymentDetails(invalid_CreditcardNumber);
    }

    @And("^I verify invalid card details message$")
    public void I_verify_invalid_card_details_message() throws Exception{
        creditCardTokenPage.verifyInvalidCardDetailsMessage();
    }

    @And("^I process Credit Card details for EU")
    public void I_enter_the_payment_Details_EU()throws Exception {
        System.out.println("I process Credit Card details for EU");
        creditCardTokenPage.processCreditCardPaymentEU("4111111111111111");
    }
}