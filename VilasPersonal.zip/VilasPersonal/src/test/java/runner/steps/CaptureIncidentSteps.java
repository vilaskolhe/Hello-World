package runner.steps;

import com.asurion.pages.CaptureIncidentPage;
import cucumber.api.java.en.And;

public class CaptureIncidentSteps {

    private CaptureIncidentPage captureIncidentPage;

    public CaptureIncidentSteps() {
        captureIncidentPage = new CaptureIncidentPage();
    }

    @And("^I select the Incident Type \"([^\"]*)\"$")
    public void I_select_the_Incident_Type(String incidentType) throws Exception {
        System.out.println("I select the Incident Type " + incidentType);
        captureIncidentPage.select_Incident_Type(incidentType);
    }

    @And("^I enter the Incident Date \"([^\"]*)\"$")
    public void I_enter_the_Incident_Date(String incidentDateString) throws Exception {
        System.out.println("I enter the Incident Date " + incidentDateString);
        captureIncidentPage.enter_incident_date(incidentDateString);
    }


    @And("^I accept the default Asset")
    public void I_accept_the_default_asset() throws Exception {
        System.out.println("\nI accept the default Asset");
      //  captureIncidentPage.accept_default_asset();
    }

    @And("^I submit the Incident Details Information$")
    public void I_submit_the_Incident_Information() throws Exception {
        System.out.println("I submit the Incident Details Information");
        captureIncidentPage.submit_incident_information();
    }


    @And("^I Select the Covered Event \"([^\"]*)\"$")
    public void I_Select_the_Covered_Event(String coverdEvent) throws Exception {
        System.out.println("I Select the Covered Event as: "+coverdEvent);
        captureIncidentPage.select_Covered_Event(coverdEvent);
    }

    @And("^I capture the case number$")
    public void I_capture_the_case_number() throws Exception {
       /* System.out.println("I capture the case number");
        captureIncidentPage.capture_case_number();*/
    }

    @And("^I select the specified asset with make \"([^\"]*)\",model \"([^\"]*)\" and color \"([^\"]*)\"$")
    public void I_select_the_specified_assert_with_details(String sMake, String sModel, String sColor) throws Exception {
        System.out.println("I select the specified asset with make " + sMake + ", model " + sModel + " and color " + sColor);
        captureIncidentPage.selectSpecifiedAssetWithDetails(sMake.trim(), sModel.trim(), sColor.trim());
    }

    @And("^I enter the incident date today EU$")
    public void I_enter_the_incident_date_today_EU()throws Exception{
        System.out.println("I enter the incident date as Today");
        captureIncidentPage.enter_incident_date_EU();
    }

    @And("^I accept the default asset EU")
    public void I_accept_the_default_asset_EU()throws Exception {
       // captureIncidentPage.accept_default_asset_EU();
    }

    @And("^I select the EU Incident Type \"([^\"]*)\"$")
    public void I_select_the_Incident_Type_EU(String incidentType)throws Exception{
        System.out.println("I select the EU Incident Type as : "+incidentType);
        captureIncidentPage.select_Incident_TypeEU(incidentType);
    }
}

