package runner.steps;

import cucumber.api.java.en.And;
import com.asurion.util.Generic;

/**
 * Created by NANDINI.MUJUMDAR on 7/11/2017.
 */
public class KPNSwappedIMEISteps {

    @And("^I verify the shipment status is \"([^\"]*)\"$")
    public void I_verify_shipment_status(String status) throws Throwable {
        System.out.println("\n I verify the shipment status is "+ status );
        Generic.verifyShipmentStatus(Generic.getValuesFromGlobals("TRACKINGNUMBER"),status);
    }

    @And("^I verify record available in ShipmentTransactionDetail Table$")
    public void I_verify_ShipmentTransactionDetail()throws Throwable
    {
        System.out.println("\n I verify record available in ShipmentTransactionDetail Table");
        Generic.verifyTrackingNumberRecordPresentInShipmentTransactionDetailTableDAL(Generic.getValuesFromGlobals("TRACKINGNUMBER"),"COMPLETE");
    }
}
