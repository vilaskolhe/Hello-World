package runner.steps;

import com.asurion.common.core.util.CommonUtilities;
import com.asurion.pages.ActionPage;
import com.asurion.pages.HomePage;
import com.asurion.util.ApplicationConfiguration;
import cucumber.api.java.en.And;
import org.apache.commons.codec.binary.Base64;
import org.sikuli.script.Key;
import org.sikuli.script.Screen;

/**
 * Created by User on 10-Aug-16.
 */
public class CommonSteps {
    ActionPage actionPage = new ActionPage();
    HomePage homePage = new HomePage();

    @And("^I login as the automation service account$")
    public void I_login_as_the_automation_service_account() throws Exception {
        // Hardcoded values
        System.out.println("Sikuli execution starts.....");
        Thread.sleep(8000);
        Screen s = new Screen();
        if(ApplicationConfiguration.getClient().equalsIgnoreCase("Claro")||(ApplicationConfiguration.getClient().equalsIgnoreCase("Telcel"))||(ApplicationConfiguration.getClient().equalsIgnoreCase("Tracfone"))){
            s.type("cwr.manish.mehta");
            s.type(Key.TAB);
            s.type(new String(Base64.decodeBase64("QXN1cmlvbl8yMDE4")));
            s.type(Key.ENTER);
        }
        else{
            s.type("Nandini.Mujumdar");
            s.type(Key.TAB);
            s.type(new String(Base64.decodeBase64("QXN1cmlvbkAwNjE3")));
            s.type(Key.ENTER);
    }
        CommonUtilities.waitTime(2);
        homePage.selectCallMode();
        System.out.println("Sikuli execution ends");
    }
}
