package runner.steps;

import com.asurion.pages.ThreeUKAddEnrollPage;
import com.asurion.qa.errorReporting.ErrorReporter;
import com.asurion.util.DateUtil;
import com.asurion.util.Generic;
import cucumber.api.java.en.And;

/**
 * Created by cwr.rohit.aher on 2/17/2016.
 */
public class ThreeUKAddEnrollSteps {

    private ThreeUKAddEnrollPage threeUKAddEnrollPage;

    public ThreeUKAddEnrollSteps(){
        threeUKAddEnrollPage = new ThreeUKAddEnrollPage();

    }

    //3uk
    @And("^I enter default data into hashmap for enrollment EU3UK$")
    public void I_enter_default_data_into_hashmap_for_enrollment_EU3UK()throws Exception
    {
        threeUKAddEnrollPage.getDefaultDataIntoHashmap();
    }

    @And("^I set data \"([^\"]*)\" and \"([^\"]*)\" into hashmap for enrollment EU3UK$")
    public void I_set_data_int_hashma_for_enrollment_EU3UK(String param,String value)throws Throwable
    {
//        threeUKAddEnrollPage.getDefaultDataIntoHashmap();
        if(value.equalsIgnoreCase("Yesterday")) {
            value= DateUtil.getFormattedDatetime("dd/MM/yyyy hh:mm:ss", DateUtil.getModifiedDateTime("Day", -1));
        }
        threeUKAddEnrollPage.setDifferentDataForEnrollment(param,value);



    }

    // 3uk
    @And("^I initialize data from hashmap EU3UK$")
    public void I_initialize_data_from_hashmap_EU3UK()throws Throwable
    {

        threeUKAddEnrollPage.threeinitializeFileData();

    }
    @And("^I initialize data from hashmap for denial add enrollment EU3UK$")
    public void I_initialize_data_from_hashmap_denial_add_enrollment_EU3UK()throws Throwable
    {

        threeUKAddEnrollPage.denialThreeInitilizeFileData();

    }

    //3uk
    @And("^I create the files with data to \"([^\"]*)\" Enrollment for EU3UK$")
    public void I_enter_the_data_into_files_and_create_the_file_for_EU3UK(String scenarioType) throws Throwable {

        try {
//        threeUKAddEnrollPage.getDefaultDataIntoHashmap();
            threeUKAddEnrollPage.createETLfiles(scenarioType);
            Generic.run3UKEnrollmentJobs jobs = Generic.run3UKEnrollmentJob();
            Generic.verifyMDNPresentInAgreementTableDAL(Generic.getValuesFromGlobals("DAL_MDN"), "ACTV", jobs.scheduleJobId3);
        } catch (Exception e) {
            ErrorReporter.reportError(e, true);
        }
    }

    /*@And("^I create files \"([^\"]*)\" and run the job for DQ Report for EU3UK$")
    public void I_create_files_and_runthe_job_for_EU3UK(String scenarioType)throws Throwable
    {
//        threeUKAddEnrollPage.getDefaultDataIntoHashmap();
        threeUKAddEnrollPage.createETLfiles(scenarioType);
        Generic.runEnrollmentJob();

    }*/

    /*@And("^I Create the files with denial data to \"([^\"]*)\" Enrollment for EU3UK$")
    public void I_enter_the_data_into_files_and_create_the_file_for_denial_EU3UK(String scenarioType)throws Throwable
    {
//        threeUKAddEnrollPage.getDefaultDataIntoHashmap();
        threeUKAddEnrollPage.createETLfiles(scenarioType);
        Generic.runEnrollmentJob();
        Generic.verifyRecordPresentInDenialAgreementTableDAL("MDN");
    }*/



   /* @And("^I create the files with data to CANCEL Enrollment for EU3UK$")
    public void I_enter_the_data_into_files_and_create_the_file_for_EU3UK_Cancellation()throws Throwable
    {
        threeUKAddEnrollPage.createETLfiles("CANCEL");
        Generic.runEnrollmentJob();
        Generic.verifyMDNPresentInAgreementTableDAL(Generic.getValuesFromGlobals("MDN"), "TRMNTD");
    }
*/
   /* @And("^I create the files with data to CANCEL Enrollment for EU3UK with record exists in PSFT and Billing File$")
    public void I_enter_the_data_into_files_and_create_the_file_for_EU3UK_Cancl_PSFT_YES_Bill_Yes()throws Throwable
    {
        threeUKAddEnrollPage.createETLfiles("RECORDWITHCANCELRESONCODE");
        Generic.runEnrollmentJob();
        Generic.verifyMDNPresentInAgreementTableDAL(Generic.getValuesFromGlobals("MDN"), "ACTV");
    }*/

    /*@And("^I create the files with data to CANCEL Enrollment for EU3UK with record exists in PSFT and not in  Billing$")
    public void I_enter_the_data_into_files_and_create_the_file_for_EU3UK_Cancl_PSFT_YES_Bill_No()throws Throwable
    {
        threeUKAddEnrollPage.createETLfiles("CANCELPSFTYESBILLINGNO");
        Generic.runEnrollmentJob();
        Generic.verifyMDNPresentInAgreementTableDAL(Generic.getValuesFromGlobals("MDN"), "ACTV");
    }

    @And("^I create the files with data to CANCEL Enrollment for EU3UK with record exists in PSFT and Billing But Not in SC$")
    public void I_enter_the_data_into_files_and_create_the_file_for_EU3UK_Cancl_PSFT_YES_Bill_YES_CANCEL_NO()throws Throwable
    {
        threeUKAddEnrollPage.createETLfiles("CANCELPSFTYESBILLINGYESS&CNO");
        Generic.runEnrollmentJob();
        Generic.verifyMDNPresentInAgreementTableDAL(Generic.getValuesFromGlobals("MDN"), "ACTV");
    }

    @And("^I create the files with data to CANCEL Enrollment for EU3UK with record exists in PSFT and not in Billing and S&C$")
    public void I_enter_the_data_into_files_and_create_the_file_for_EU3UK_Cancl_PSFT_YES_Bill_No_CANCEL_NO()throws Throwable
    {
        threeUKAddEnrollPage.createETLfiles("CANCELPSFTYESBILLINGNOS&CNO");
        Generic.runEnrollmentJob();
        Generic.verifyMDNPresentInAgreementTableDAL(Generic.getValuesFromGlobals("MDN"), "ACTV");
    }

    @And("^I create the files with data to CANCEL Enrollment for EU3UK with record exists S&C with No Insurance End Date$")
    public void I_enter_the_data_into_files_and_create_the_file_for_EU3UK_Cancellation_with_No_InsuranceEndDate()throws Throwable
    {
        threeUKAddEnrollPage.createETLfiles("CANCEL");
        Generic.runEnrollmentJob();
        Generic.verifyMDNPresentInAgreementTableDAL(Generic.getValuesFromGlobals("MDN"), "ACTV");
    }

    @And("^I create the files with data to CANCEL Enrollment for EU3UK with valid record exists in S&C and BAN Exists in Billing Not in PSFT$")
    public void I_EU3UK_Cancellation_with_validSC_YesBilling_NoPSFT()throws Throwable
    {
        threeUKAddEnrollPage.createETLfiles("CANCELWITHYESBLNOPSFT");
        Generic.runEnrollmentJob();
        Generic.verifyMDNPresentInAgreementTableDAL(Generic.getValuesFromGlobals("MDN"), "TRMNTD");
    }

    @And("^I create the files with data to CANCEL Enrollment for EU3UK with no insurance end date in S&C and BAN Exists in Billing Not in PSFT$")
    public void I_EU3UK_Cancellation_with_No_Insurance_End_date_inSC_YesBilling_NoPSFT()throws Throwable
    {
        threeUKAddEnrollPage.createETLfiles("CANCELWITHYESBLNOPSFT");
        Generic.runEnrollmentJob();
        Generic.verifyMDNPresentInAgreementTableDAL(Generic.getValuesFromGlobals("MDN"), "ACTV");
    }

    @And("^I verify the Cancellation Reason code is saved as \"([^\"]*)\" in Agreement Table in DAL DB$")
    public void I_Verify_Cancellation_Reason_In_Agreement_Table_EU3UK(String cancellationReason)throws Throwable
    {
        Generic.verifyCancellationReasonInAgreementTableDAL(cancellationReason);
    }
*/

}
