package runner;

import com.asurion.common.core.driver.TestDriver;
import com.asurion.horizon.client.ClientBeans;
import com.asurion.horizon.client.StageData;
import com.asurion.horizon.generic.DataBaseHandler;
import com.asurion.horizon.generic.ExcelReader;
import com.asurion.pages.BasePage;
import com.asurion.pages.CaptureIncidentPage;
import com.asurion.pages.SubBillingPortalPages;
import com.asurion.soap.*;
import com.asurion.util.ApplicationConfiguration;
import com.asurion.util.CustomerDetails;
import com.asurion.util.Generic;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.junit.Assert;

import java.util.*;


public class AutomationHooks {
    public static String ScenarioName = "";
    public static String scenarioTag = "";
    public static String dataFilePath = ApplicationConfiguration.dataFilePath;
    private static boolean dunit = false;
    private static boolean isAllRowsDeleted = false;
    public static ArrayList<HashMap<String, HashMap<String, String>>> scenarioData = null;
    public static Scenario currentScenario;
    public static List<String> listOfExecutingScenarios = new LinkedList<String>();
    public static boolean isNeedToFail = false;
    public AutomationHooks() {

        ApplicationConfiguration.loadConfiguration();
        //ApplicationConfiguration.setEmsProps();

    }

    @Before
    public void beforeScenario(Scenario scenario) throws Exception {
        StagingRequest sr= new StagingRequest();
        listOfExecutingScenarios.add(scenario.getName());
        System.out.println("size of list = "+listOfExecutingScenarios.size());
        failHereIfRequired();
        System.out.println("Running the scenario : " + scenario.getName());
        ScenarioName = scenario.getName();
        scenarioTag = scenario.getSourceTagNames().toString();
        if ((!scenario.getSourceTagNames().contains("@!Stage") && !scenario.getSourceTagNames().contains("@AssetVerification"))) {
            if (!dunit) {
                if (scenario.getSourceTagNames().contains("@IMDATA")) {
                    if (!isAllRowsDeleted) {
                        ExcelReader.deleteAllRowsFromExcel("Data/DataReport.xlsx");
                        isAllRowsDeleted = true;
                    }
                } else if (scenario.getSourceTagNames().contains("@BASICS")) {
                    if (!isAllRowsDeleted) {
                        ExcelReader.deleteAllRowsFromExcel("Data/BasicsData.xlsx");
                        isAllRowsDeleted = true;
                    }
                } else if (scenario.getSourceTagNames().contains("@END_TO_END")) {
                    if (!isAllRowsDeleted) {
                        ExcelReader.deleteAllRowsFromExcel("Data/BasicsE2E.xlsx");
                        isAllRowsDeleted = true;
                    }
                }
                System.out.println(ApplicationConfiguration.getEnvironment());
                if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonprod")) {
                    dataFilePath = "Data/ProdData.xlsx";
                }
                else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonprod") && scenario.getSourceTagNames().contains("@ProdStaging")) {
                    dataFilePath = "Data/ProdStagingData.xlsx";
                }
                else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa") && scenario.getSourceTagNames().contains("@FRM"))  {
                    dataFilePath = "Data/CurrentSprint.xlsx";
                }
                else if ((ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa") || ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonuat") || ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizondevint")) && scenario.getSourceTagNames().contains("@PIV")) {
                    dataFilePath = "Data/QAPIV.xlsx";
                }
                else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa") && scenario.getSourceTagNames().contains("@E2ESmoke") && !(scenario.getSourceTagNames().contains("@REGRESSION"))) {
                    dataFilePath = "Data/E2ESmokeTest.xlsx";
                }
                else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa") && scenario.getSourceTagNames().contains("@END_TO_END")) {
                    dataFilePath = "Data/E2ETestingData.xlsx";
                }
                else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa") && scenario.getSourceTagNames().contains("@COMPASS")) {
                    dataFilePath = "Data/CampassScenarioData.xlsx";
                }
                else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa") && scenario.getSourceTagNames().contains("@REGRESSION") &&scenario.getSourceTagNames().contains("@TELCEL")){
                    dataFilePath = "Data/ScenarioData_E2E_Testing_Telcel.xlsx";
                }
                //Added by Priya on 11/10/2016
                else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa") && scenario.getSourceTagNames().contains("@CLARO_COLUMBIA")) {
                    dataFilePath = "Data/E2E_Testing_ClaroColombia.xlsx";
                }
/*
                else if (ApplicationConfiguration.getEnvironment().equalsIgnoreCase("horizonqa") && scenario.getSourceTagNames().contains("@TRACFONE")){
                    //dataFilePath = "Data/E2E_Testing_Tracfone.xlsx";
                    dataFilePath = System.getProperty("user.dir")
                            + "/src/test/resources/data/StagingData.xlsx";
                }
*/
                System.out.println(ApplicationConfiguration.getClient());
                if (StageData.stageScenarioDataViaPreInterFace(ApplicationConfiguration.getEnvironment(), "enrollment", ApplicationConfiguration.getClient(), dataFilePath, listOfExecutingScenarios)) {
                    dunit = true;
                } else {
                    System.err.println("Data staging utility failed to execute. please check logs.");
                    Assert.assertTrue("Data Staging Utility for " + ApplicationConfiguration.getClient() + "is Failed.", false);
                }
            }
            for (int i = 0; i < StageData.scenarioData.size(); i++) {
                if (StageData.scenarioData.get(i).containsKey(ScenarioName)) {
                    CustomerDetails.customerData = StageData.scenarioData.get(i).get(ScenarioName);
                    break;
                }
            }
        }
        if (!scenario.getSourceTagNames().contains("") && scenario.getSourceTagNames().contains("@AssetVerification")) {
            if (!dunit) {
                if (ApplicationConfiguration.getClient().equalsIgnoreCase("TELCEL")) {
                    if (StageData.stageAssetDataForTelcel(ApplicationConfiguration.getEnvironment(), "enrollment", ApplicationConfiguration.getClient(), "Data/TelcelAssetValidation.xlsx")) {
                        System.out.println("Enrollment Data successfully inserted in enrollmentPreinterface table");
                    } else {
                        System.err.println("Data staging utility failed to execute. please check logs.");
                        System.exit(1);
                    }
                } else {
                    StageData.stageAssetDataForEast(ApplicationConfiguration.getEnvironment(), "enrollment", ApplicationConfiguration.getClient(), "Data/NorthAmericaAssetValidation.xlsx");
                    System.out.println("Enrollment Data successfully inserted in enrollmentPreinterface table");
                }
                Publisher.publishRequestToQueue(sr.getPreInterFaceToInterFaceRequest(ClientBeans.getEnrollmentId(), ApplicationConfiguration.getClient()));
                if (ClientBeans.getEnrollmentStatus(ApplicationConfiguration.getEnvironment(), ClientBeans.getEnrollmentId())) {
                    System.out.println("Enrollment is successful");
                    dunit = true;
                } else {
                    System.err.println("Data staging utility failed to execute. please check logs.");
                    System.exit(1);
                }
                ClientBeans.markEnrollmentAsHistory(ApplicationConfiguration.getClient(), ApplicationConfiguration.getEnvironment(), ClientBeans.getEnrollmentId());
            }
            if (StageData.assetData.containsKey(ScenarioName)) {
                CustomerDetails.clientAssetList = StageData.assetData.get(ScenarioName);
            }
        }
    }

    @After
    public void afterScenario(Scenario scenario) throws Exception {
        failHereIfRequired();
        System.out.println("scenario name=" + scenario.getName());
        System.out.println("scenario is =" + scenario.getStatus());
        if (scenario.getSourceTagNames().contains("@IMDATA")) {
            String caseNumber = CustomerDetails.customerData.get("CASENUMBER");
            if (CustomerDetails.customerData.containsKey("CASENUMBER1")) {
                if (!CustomerDetails.customerData.get("CASENUMBER").equalsIgnoreCase(CustomerDetails.customerData.get("CASENUMBER1"))) {
                    caseNumber = "FirstCaseNumber : " + caseNumber + ", Second Casenumber :" + CustomerDetails.customerData.get("CASENUMBER1");
                }
            }

            if (scenario.isFailed())
                ExcelReader.writeToExcel("Data/DataReport.xlsx", scenario.getName(), CustomerDetails.customerData.get("MDN"), caseNumber, "Failed", CustomerDetails.customerData.get("MAKE"), CustomerDetails.customerData.get("MODEL"));
            else
                ExcelReader.writeToExcel("Data/DataReport.xlsx", scenario.getName(), CustomerDetails.customerData.get("MDN"), caseNumber, "Passed", CustomerDetails.customerData.get("MAKE"), CustomerDetails.customerData.get("MODEL"));
        } else if (scenario.getSourceTagNames().contains("@BASICS")) {
            String caseNumber = CustomerDetails.customerData.get("CASENUMBER");
            if (CustomerDetails.customerData.containsKey("CASENUMBER1")) {
                if (!CustomerDetails.customerData.get("CASENUMBER").equalsIgnoreCase(CustomerDetails.customerData.get("CASENUMBER1"))) {
                    caseNumber = "FirstCaseNumber : " + caseNumber + ", Second Casenumber :" + CustomerDetails.customerData.get("CASENUMBER1");
                }
            }
            if (scenario.isFailed())
                ExcelReader.writeToExcel("Data/BasicsData.xlsx", scenario.getName(), CustomerDetails.customerData.get("MDN"), caseNumber, "Failed", CustomerDetails.customerData.get("MAKE"), CustomerDetails.customerData.get("MODEL"));
            else
                ExcelReader.writeToExcel("Data/BasicsData.xlsx", scenario.getName(), CustomerDetails.customerData.get("MDN"), caseNumber, "Passed", CustomerDetails.customerData.get("MAKE"), CustomerDetails.customerData.get("MODEL"));
        } else if (scenario.getSourceTagNames().contains("@E2E")) {
            String caseNumber = CustomerDetails.customerData.get("CASENUMBER");
            if (CustomerDetails.customerData.containsKey("CASENUMBER1")) {
                if (!CustomerDetails.customerData.get("CASENUMBER").equalsIgnoreCase(CustomerDetails.customerData.get("CASENUMBER1"))) {
                    caseNumber = "FirstCaseNumber : " + caseNumber + ", Second Casenumber :" + CustomerDetails.customerData.get("CASENUMBER1");
                }
            }
            if (scenario.isFailed())
                ExcelReader.writeToExcel("Data/BasicsE2E.xlsx", scenario.getName(), CustomerDetails.customerData.get("MDN"), caseNumber, "Failed", CustomerDetails.customerData.get("MAKE"), CustomerDetails.customerData.get("MODEL"));
            else
                ExcelReader.writeToExcel("Data/BasicsE2E.xlsx", scenario.getName(), CustomerDetails.customerData.get("MDN"), caseNumber, "Passed", CustomerDetails.customerData.get("MAKE"), CustomerDetails.customerData.get("MODEL"));
        }
        else if((scenario.getSourceTagNames().contains("@SO_DAX_INTEGRATION_ON")) && (!scenario.isFailed())){
            if (SubBillingPortalPages.isDAXOptionPresent== true)
                scenario.write("DAX Integration Configuration is set as 1 in BASICS for "+ ApplicationConfiguration.getClient());
            else if(SubBillingPortalPages.isDAXOptionPresent== false){
                scenario.write("DAX Integration Configuration is not set for " + ApplicationConfiguration.getClient());
                SubBillingPortalPages.isDAXOptionPresent=true;
            }
        }
        else if((scenario.getSourceTagNames().contains("@SO_DAX_INTEGRATION_OFF")) && (!scenario.isFailed())){
            if (SubBillingPortalPages.isDAXOptionPresent== true)
                scenario.write("DAX Integration Configuration is set as 0 in BASICS for "+ ApplicationConfiguration.getClient());
            else if(SubBillingPortalPages.isDAXOptionPresent== false) {
                scenario.write("DAX Integration Configuration is not set for " + ApplicationConfiguration.getClient());
                SubBillingPortalPages.isDAXOptionPresent=true;
            }
        }
        else if((scenario.getSourceTagNames().contains("@SO_APS_INTEGRATION")) && (!scenario.isFailed())){
            if (SubBillingPortalPages.isAPSIntegrationPresent== true)
                scenario.write("APS Integration Configuration is present for "+ ApplicationConfiguration.getClient());
            else if(SubBillingPortalPages.isDAXOptionPresent== false) {
                scenario.write("DAX Integration Configuration is not set for " + ApplicationConfiguration.getClient());
                SubBillingPortalPages.isAPSIntegrationPresent=true;
            }
        }
        if (scenario.isFailed()) {
            TestDriver driver = TestDriver.getDriver(ApplicationConfiguration.getBrowser(), ApplicationConfiguration.getRunType(), ApplicationConfiguration.getBrowserVersion());
            I_print_the_test_report(scenario);
            driver.failure(scenario);
        }
        else
            I_print_the_test_report(scenario);
       /* System.out.println("Scenario execution completed =" + scenario.getName());
        System.out.println("Scenario executed is " + (scenario.isFailed() ? "Failed": "Passed"));*/
        System.out.println("scenario end time =" + new Date());

    }

    public void I_print_the_test_report(Scenario scenario) throws Exception {

        print_intractionNo_SR_SO();
        if (CustomerDetails.customerData != null) {
            scenario.write("MDN for this scenario is " + CustomerDetails.customerData.get("MDN") + "");
            if (!(CustomerDetails.customerData.get("INTRACTIONNUMBER") == "" || CustomerDetails.customerData.get("INTRACTIONNUMBER") == null))
                scenario.write("INTRACTIONNUMBER  for this scenario is " + CustomerDetails.customerData.get("INTRACTIONNUMBER") + "");
            if (!(CustomerDetails.customerData.get("SERVICEREQUESTID") == "" || CustomerDetails.customerData.get("SERVICEREQUESTID") == null))
                scenario.write("SERVICEREQUESTNUMBER for this scenario is " + CustomerDetails.customerData.get("SERVICEREQUESTID") + "");
            if (!(CustomerDetails.customerData.get("SERVICEORDERID") == "" || CustomerDetails.customerData.get("SERVICEORDERID") == null))
                scenario.write("SERVICEORDERNUMBER for this scenario is " + CustomerDetails.customerData.get("SERVICEORDERID") + "");
            if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER"))
                scenario.write("First Claim CaseNumber :" + CaptureIncidentPage.casenumbers.get("CASENUMBER"));
            if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER1"))
                scenario.write("Second Claim CaseNumber :" + CaptureIncidentPage.casenumbers.get("CASENUMBER1"));
            if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER2"))
                scenario.write("Third Claim CaseNumber :" + CaptureIncidentPage.casenumbers.get("CASENUMBER2"));
            if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER3"))
                scenario.write("Fourth Claim CaseNumber :" + CaptureIncidentPage.casenumbers.get("CASENUMBER3"));
            if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER4"))
                scenario.write("Fifth Claim CaseNumber :" + CaptureIncidentPage.casenumbers.get("CASENUMBER4"));
            if (CaptureIncidentPage.casenumbers.containsKey("CASENUMBER5"))
                scenario.write("Sixth Claim CaseNumber :" + CaptureIncidentPage.casenumbers.get("CASENUMBER5"));


            if (CustomerDetails.customerData.containsKey("DATASTAGGED")) {
                if (CustomerDetails.customerData.get("DATASTAGGED").equalsIgnoreCase("NO")) {
                    scenario.write(" \nAsset information is not found in DAL DB for  " + CustomerDetails.customerData.get("STANDARD MAKE") + "");
                }
            }
            if (scenario.getSourceTagNames().contains("@ClientOffer")) {

                scenario.write(BasePage.verificationErrors.toString());
//            System.out.println(BasePage.bPassFailFlag);
//            Assert.assertTrue(BasePage.verificationErrors.toString(), BasePage.bPassFailFlag);

            }
            if (CustomerDetails.customerData.containsKey("CORRELATIONALID")) {
                if (!(CustomerDetails.customerData.get("CORRELATIONALID") == "" || CustomerDetails.customerData.get("CORRELATIONALID") == null)) {
                    scenario.write(" \nCorrelation ID For the Scenario is : " + CustomerDetails.customerData.get("CORRELATIONALID"));
                }
            }
        } else if(ApplicationConfiguration.getClient().equalsIgnoreCase("3UK")){
           // scenario.write(" \nCorrelation ID For the Scenario is : " + BasePage.CorrelationID);
            scenario.write("3UK MDN for this scenario is : " + Generic.getValuesFromGlobals("DAL_MDN"));
            scenario.write("3UK CaseNumber is : " + Generic.getValuesFromGlobals("CASENUMBER"));
        }
    }

    /**
     * This method is used to print intraction No,SR,SO
     *
     * @author Priyanka
     * Last Updated By : Kapil Gonjari on 25 May 2016
     * Added code to Print Correlation ID which will help in getting the TIBCO log for Executed scenario
     */
    public void print_intractionNo_SR_SO() throws Exception {
        try {
            if (CustomerDetails.customerData != null) {
                if (!ApplicationConfiguration.getClient().equalsIgnoreCase("kpn")) {
                    ArrayList<HashMap<String, String>> result = new ArrayList<>();
                    String selectInteractionNo = "Select INTERACTION_line_NBR from INTERACTION.INTERACTION_line where Client_account_ID in( Select Client_account_id from ASSET.Asset where Mobile_device_nbr = '" + CustomerDetails.customerData.get("MDN") + "') Order by created_date desc";
                    String selectServiceReqID = "Select Service_Request_nbr from Customer.Service_Request where Agreement_id in (Select Agreement_id from ASSET.Agreement where Client_Account_ID in (Select Client_Account_ID from Asset.Asset where Mobile_device_nbr = '" + CustomerDetails.customerData.get("MDN") + "'))";
                    String selectServiceOrdID = "select SERVICE_ORDER_nbr from Customer.SERVICE_ORDER WHERE Service_Order_ID IN (select Item_Id from CUSTOMER.CUSTOMER_CASE_CATEGORY where Item_Type_Code = 'SVCORD' and Customer_Case_ID in (select Customer_Case_ID FROM CUSTOMER.CUSTOMER_CASE where Customer_Case_Nbr = '" + CustomerDetails.customerData.get("CASENUMBER") + "'))";

                    String interaction_nbr = "";
                    result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), selectInteractionNo);
                    HashMap<String, String> dataHashMap = null;
                    if (result.size() > 0) {
                        dataHashMap = result.get(0);
                        interaction_nbr = dataHashMap.values().toString();
                        CustomerDetails.customerData.put("INTRACTIONNUMBER", interaction_nbr);
                    }
                    String Service_Request_ID = "";
                    result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), selectServiceReqID);
                    if (result.size() > 0) {
                        dataHashMap = result.get(0);
                        Service_Request_ID = dataHashMap.values().toString();
                        CustomerDetails.customerData.put("SERVICEREQUESTID", Service_Request_ID);
                    }

                    String Service_Order_ID = "";
                    if (!(CustomerDetails.customerData.get("CASENUMBER") == "" || CustomerDetails.customerData.get("CASENUMBER") == null)) {
                        result = DataBaseHandler.executeSQLQuery(DataBaseHandler.getConnection(ApplicationConfiguration.getEnvironment(), "dal"), selectServiceOrdID);
                        if (result.size() > 0) {
                            dataHashMap = result.get(0);
                            Service_Order_ID = dataHashMap.values().toString();
                            CustomerDetails.customerData.put("SERVICEORDERID", Service_Order_ID);
                        }
                    }
                }
                if (BasePage.CorrelationID != "" || BasePage.CorrelationID != null)
                    CustomerDetails.customerData.put("CORRELATIONALID", BasePage.CorrelationID);
            }
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    private static void failHereIfRequired() {

        if (isNeedToFail) {
            throw  new NullPointerException("Please ignore this exception");
        }
    }
}

