package runner;

import com.asurion.util.ScenarioNameGetter;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;


@RunWith(Cucumber.class)
@CucumberOptions(dryRun = false,
        plugin = {"html:target/report/cucumber-html", "json:target/cucumber.json"},
        features = {"src/test/resources/features"},
        tags = {"@nTelos_Basics"}
)
public class RunCukesTest {
    @BeforeClass
    public static void setup() throws Throwable {
        System.out.println("junit before class");
        AutomationHooks.isNeedToFail = true;
        ScenarioNameGetter.getScenarioNamesList();
        AutomationHooks.isNeedToFail = false;
    }
}
